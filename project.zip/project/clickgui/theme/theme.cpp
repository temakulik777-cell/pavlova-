#include "../clickgui.h"
#include <algorithm>
#include <cmath>
#include <string>
#include <unordered_map>
#include <cstring>
#include "../good_luck/oxo/oxorany.h"

ClickGUI::Theme::Theme() {
    SetLightMode(false);
}

namespace {
static inline int HexDigitToInt(char c) {
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    return -1;
}

static inline bool ParseHexByte(const char* p, unsigned int& out) {
    const int hi = HexDigitToInt(p[0]);
    const int lo = HexDigitToInt(p[1]);
    if (hi < 0 || lo < 0) {
        return false;
    }
    out = static_cast<unsigned int>((hi << 4) | lo);
    return true;
}
}

ImVec4 ClickGUI::Theme::HexToImVec4(const char* hex_color) {
    if (!hex_color || !*hex_color) {
        return ImVec4(0.0f, 0.0f, 0.0f, 1.0f);
    }

    static std::unordered_map<std::string, ImVec4> color_cache;
    const auto cached = color_cache.find(hex_color);
    if (cached != color_cache.end()) {
        return cached->second;
    }

    const char* p = hex_color;
    if (p[0] == '#') {
        ++p;
    }
    const size_t len = std::strlen(p);

    unsigned int r = 0, g = 0, b = 0, a = 255;

    if (len == 6 || len == 8) {
        const bool ok_rgb = ParseHexByte(p + 0, r)
            && ParseHexByte(p + 2, g)
            && ParseHexByte(p + 4, b);
        if (ok_rgb && len == 8) {
            ParseHexByte(p + 6, a);
        }
    }

    const ImVec4 color(
        r / 255.0f,
        g / 255.0f,
        b / 255.0f,
        a / 255.0f
    );
    color_cache.emplace(hex_color, color);
    return color;
}

void ClickGUI::Theme::SetLightMode(bool enabled) {
    (void)enabled;
    material.onPrimary = "#FFFFFF";
    material.secondary = "#4E4E4E";
    material.onSecondary = "#FFFFFF";
    material.surface = "#161616";
    material.surfaceContainer = "#131313FF";
    material.surfaceVariant = "#1C1C1C";
    material.surfaceTransparent = "#13131300";
    material.surfaceVariantTransparent = "#16161664";
    material.onSurface = "#FFFFFF";
    material.onSurfaceVariant = "#646464";
    material.outline = "#4A4A4ABF";
    SetAccentColor(accentR, accentG, accentB);
}

void ClickGUI::Theme::SetAccentColor(float r, float g, float b) {
    accentR = std::clamp(r, 0.0f, 1.0f);
    accentG = std::clamp(g, 0.0f, 1.0f);
    accentB = std::clamp(b, 0.0f, 1.0f);
    ImVec4 resolved = GetResolvedAccentColor();

    auto to_u8 = [](float v) -> int {
        return std::clamp((int)std::lround(v * 255.0f), 0, 255);
    };

    const int rr = to_u8(resolved.x);
    const int gg = to_u8(resolved.y);
    const int bb = to_u8(resolved.z);
    std::snprintf(accentPrimaryHex, sizeof(accentPrimaryHex), "#%02X%02X%02X", rr, gg, bb);
    std::snprintf(accentGlowHex, sizeof(accentGlowHex), "#%02X%02X%02X64", rr, gg, bb);

    material.primary = accentPrimaryHex;
    material.primaryGlow = accentGlowHex;
}

void ClickGUI::Theme::SetAccentGradientColor(float r, float g, float b) {
    accentGradientR = std::clamp(r, 0.0f, 1.0f);
    accentGradientG = std::clamp(g, 0.0f, 1.0f);
    accentGradientB = std::clamp(b, 0.0f, 1.0f);
    SetAccentColor(accentR, accentG, accentB);
}

void ClickGUI::Theme::SetUserAccentGradient(float r1, float g1, float b1, float r2, float g2, float b2) {
    userAccentR1 = std::clamp(r1, 0.0f, 1.0f);
    userAccentG1 = std::clamp(g1, 0.0f, 1.0f);
    userAccentB1 = std::clamp(b1, 0.0f, 1.0f);
    userAccentR2 = std::clamp(r2, 0.0f, 1.0f);
    userAccentG2 = std::clamp(g2, 0.0f, 1.0f);
    userAccentB2 = std::clamp(b2, 0.0f, 1.0f);
    SetAccentColor(accentR, accentG, accentB);
}

void ClickGUI::Theme::SetAccentMode(ClickGUI::Theme::AccentMode mode) {
    accentMode = mode;
    SetAccentColor(accentR, accentG, accentB);
}

void ClickGUI::Theme::SetAccentGradientDirection(ClickGUI::Theme::AccentGradientDirection direction) {
    accentGradientDirection = direction;
    SetAccentColor(accentR, accentG, accentB);
}

void ClickGUI::Theme::SetAnimatedAccentEnabled(bool enabled) {
    animatedAccentEnabled = enabled;
}

void ClickGUI::Theme::SetAnimatedAccentParams(float color_spacing, float speed, float smoothness, float strength) {
    animatedAccentColorSpacing = std::clamp(color_spacing, 0.02f, 1.0f);
    animatedAccentSpeed = std::clamp(speed, 0.0f, 3.0f);
    animatedAccentSmoothness = std::clamp(smoothness, 0.02f, 1.0f);
    animatedAccentStrength = std::clamp(strength, 0.0f, 1.5f);
}

void ClickGUI::Theme::GetResolvedAccentGradient(ImVec4& out_start, ImVec4& out_end) const {
    switch (accentMode) {
        case AccentMode::Accent:
            out_start = ImVec4(accentR, accentG, accentB, 1.0f);
            out_end = out_start;
            break;
        case AccentMode::AccentGradient:
            // UI layout uses secondary preview on the left, so keep gradient order consistent with visual order.
            out_start = ImVec4(accentGradientR, accentGradientG, accentGradientB, 1.0f);
            out_end = ImVec4(accentR, accentG, accentB, 1.0f);
            break;
        case AccentMode::User:
        default:
            out_start = ImVec4(userAccentR1, userAccentG1, userAccentB1, 1.0f);
            out_end = ImVec4(userAccentR2, userAccentG2, userAccentB2, 1.0f);
            break;
    }
}

ImVec4 ClickGUI::Theme::GetResolvedAccentColor() const {
    ImVec4 start, end;
    GetResolvedAccentGradient(start, end);
    return ImVec4(
        start.x + (end.x - start.x) * 0.5f,
        start.y + (end.y - start.y) * 0.5f,
        start.z + (end.z - start.z) * 0.5f,
        1.0f
    );
}

void ClickGUI::Theme::SetColor(ImGuiCol idx, const char* hex_color) {
    ImGui::GetStyle().Colors[idx] = HexToImVec4(hex_color);
}

void ClickGUI::Theme::ApplyTheme() {
    ImGuiStyle& style = ImGui::GetStyle();
    style.AntiAliasedLines = rendering.antiAliasedLines;
    style.AntiAliasedFill = rendering.antiAliasedFill;
    style.WindowRounding = shape.windowRounding;
    style.ChildRounding = shape.childRounding;
    style.FrameRounding = shape.frameRounding;
    style.PopupRounding = shape.popupRounding;
    style.ScrollbarSize = metrics.scrollbarSize;
    style.ScrollbarRounding = shape.scrollbarRounding;
    style.GrabRounding = shape.grabRounding;
    style.TabRounding = shape.tabRounding;

    SetColor(ImGuiCol_WindowBg, "#0F0F0FBF");
    SetColor(ImGuiCol_Border, "#00000000");
    SetColor(ImGuiCol_FrameBg, material.surfaceVariant);
    SetColor(ImGuiCol_FrameBgHovered, material.outline);
    SetColor(ImGuiCol_FrameBgActive, material.surfaceContainer);
    SetColor(ImGuiCol_TitleBgActive, "#1A1A1A");
    SetColor(ImGuiCol_Text, material.onSurface);
    SetColor(ImGuiCol_CheckMark, material.primary);
    SetColor(ImGuiCol_SliderGrab, material.primary);
    SetColor(ImGuiCol_SliderGrabActive, material.primary);
    SetColor(ImGuiCol_Button, material.primary);
    SetColor(ImGuiCol_ButtonHovered, material.primary);
    SetColor(ImGuiCol_ButtonActive, material.primary);
    SetColor(ImGuiCol_Header, material.primary);
    SetColor(ImGuiCol_HeaderHovered, material.primary);
    SetColor(ImGuiCol_HeaderActive, material.primary);
    SetColor(ImGuiCol_Separator, material.outline);
    SetColor(ImGuiCol_SeparatorHovered, material.primary);
    SetColor(ImGuiCol_SeparatorActive, material.primary);
    SetColor(ImGuiCol_ResizeGrip, material.primary);
    SetColor(ImGuiCol_ResizeGripHovered, material.primary);
    SetColor(ImGuiCol_ResizeGripActive, material.primary);
    SetColor(ImGuiCol_Tab, material.primary);
    SetColor(ImGuiCol_TabHovered, material.primary);
    SetColor(ImGuiCol_TabActive, material.primary);
    SetColor(ImGuiCol_TabUnfocused, material.primary);
    SetColor(ImGuiCol_TabUnfocusedActive, material.primary);
    SetColor(ImGuiCol_ScrollbarBg, "#222222");
    SetColor(ImGuiCol_ScrollbarGrab, "#444444");
    SetColor(ImGuiCol_ScrollbarGrabHovered, "#666666");
    SetColor(ImGuiCol_ScrollbarGrabActive, "#888888");
}

void ClickGUI::Theme::Update() {
    ImGuiStyle& style = ImGui::GetStyle();
    style.AntiAliasedLines = rendering.antiAliasedLines;
    style.AntiAliasedFill = rendering.antiAliasedFill;
    style.WindowRounding = shape.windowRounding;
    style.ChildRounding = shape.childRounding;
    style.FrameRounding = shape.frameRounding;
    style.PopupRounding = shape.popupRounding;
    style.ScrollbarSize = metrics.scrollbarSize;
    style.ScrollbarRounding = shape.scrollbarRounding;
    style.GrabRounding = shape.grabRounding;
    style.TabRounding = shape.tabRounding;
}

ImFont* ClickGUI::Theme::Get(FontId id) const {
    const size_t idx = static_cast<size_t>(id);
    if (idx >= font_by_id.size()) {
        return nullptr;
    }
    return font_by_id[idx];
}

ImFont* ClickGUI::Theme::Get(const char* id) const {
    if (!id || !*id) {
        return nullptr;
    }
    auto it = fonts_by_id.find(id);
    if (it == fonts_by_id.end()) {
        return nullptr;
    }
    return it->second;
}

void ClickGUI::Theme::SetIds(std::initializer_list<const char*> ids) {
    font_ids.clear();
    font_ids.reserve(ids.size());
    for (const char* id : ids) {
        font_ids.emplace_back(id ? id : "");
    }
    for (size_t i = 0; i < font_tags.size(); ++i) {
        font_tags[i] = (i < font_ids.size()) ? font_ids[i] : "";
    }
}

ImFont* ClickGUI::Theme::Load(const void* data, size_t size, float size_pixels, const ImFontConfig* config, const ImWchar* glyph_ranges, const char* font_name) {
    ImGuiIO& io = ImGui::GetIO();
    ImFontConfig temp_config = config ? *config : ImFontConfig();

    if (!config) {
        temp_config.OversampleH = 2;
        temp_config.OversampleV = 2;
        temp_config.RasterizerMultiply = 1.2f;
    }
    temp_config.SizePixels = size_pixels;
    if (font_name && *font_name) {
        std::strncpy(temp_config.Name, font_name, sizeof(temp_config.Name) - 1);
        temp_config.Name[sizeof(temp_config.Name) - 1] = '\0';
    }

    ImFont* font = io.Fonts->AddFontFromMemoryCompressedTTF(data, size, size_pixels, &temp_config, glyph_ranges);

    if (font) {
        fonts.fonts.push_back(font);
    }
    return font;
}

void ClickGUI::Theme::Build() {
    font_by_id.fill(nullptr);
    fonts_by_id.clear();
    ImVector<ImFont*>& all_fonts = ImGui::GetIO().Fonts->Fonts;
    for (const std::string& id : font_ids) {
        if (id.empty()) {
            continue;
        }
        for (int i = 0; i < all_fonts.Size; ++i) {
            ImFont* font = all_fonts[i];
            if (!font) {
                continue;
            }
            const char* current_name = font->GetDebugName();
            if (current_name && id == current_name) {
                fonts_by_id[id] = font;
                break;
            }
        }
    }

    for (size_t idx = 0; idx < font_by_id.size(); ++idx) {
        const std::string& tag = (idx < font_ids.size()) ? font_ids[idx] : font_tags[idx];
        if (tag.empty()) {
            continue;
        }
        auto it = fonts_by_id.find(tag);
        if (it != fonts_by_id.end()) {
            font_by_id[idx] = it->second;
        }
        if (!font_by_id[idx] && fonts.fonts.size() > idx) {
            font_by_id[idx] = fonts.fonts[idx];
        }
    }

    fonts.Default.value = font_by_id[static_cast<size_t>(FontId::Default)];
    fonts.Montserrat.value = font_by_id[static_cast<size_t>(FontId::Montserrat)];
    fonts.Awesome.value = font_by_id[static_cast<size_t>(FontId::Awesome)];

    ImGui::GetIO().Fonts->Build();
}
