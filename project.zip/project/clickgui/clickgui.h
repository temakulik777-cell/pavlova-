#pragma once
#include <stdint.h>
#include <functional>
#include <memory>
#include <string>
#include <vector>
#include <array>
#include <unordered_map>
#include <initializer_list>

extern int glHeight;
extern int glWidth;
extern uintptr_t base;

#include "imgui/imgui.h"
#include "imgui/box_shadow.h"
#include "imgui/imgui_internal.h"
#include "imgui/backends/imgui_impl_opengl3.h"
#include "imgui/backends/imgui_impl_android.h"
#include "render/post_processing.h"
#include "../assets/images.h"
#include "render/pipeline/pipeline.h"

class VerticalLayout;

class LayoutManager;
class WindowManager;
class WidgetManager;

#include "layouts/layouts.h"

struct ClickGUI {
private:
    ClickGUI();
    ~ClickGUI();

    ClickGUI(const ClickGUI&) = delete;
    ClickGUI& operator=(const ClickGUI&) = delete;

public:
    struct Theme {
        Theme();

        enum class FontId : uint8_t {
            Default = 0,
            Montserrat,
            Awesome,
            Count
        };

        struct FontSlot {
            ImFont* value = nullptr;
        };

        struct FontRegistry {
            FontSlot Default;
            FontSlot Montserrat;
            FontSlot Awesome;
            std::vector<ImFont*> fonts;
        };

        struct Style {
            float CornerRadius = 19.5f;
        };

        struct Rendering {
            bool antiAliasedLines = true;
            bool antiAliasedFill = true;
        };

        struct Shape {
            float windowRounding = 15.0f;
            float childRounding = 15.0f;
            float frameRounding = 10.0f;
            float popupRounding = 15.0f;
            float scrollbarRounding = 10.0f;
            float grabRounding = 10.0f;
            float tabRounding = 10.0f;
        };

        struct Metrics {
            float scrollbarSize = 60.0f;
            float buttonSpacing = 10.0f;
        };

        struct Material {
            const char* primary = "#4B69FE";
            const char* onPrimary = "#FFFFFF";
            const char* secondary = "#4E4E4E";
            const char* onSecondary = "#FFFFFF";
            const char* surface = "#161616";
            const char* surfaceContainer = "#131313FF";
            const char* surfaceVariant = "#1C1C1C";
            const char* surfaceTransparent = "#13131300";
            const char* surfaceVariantTransparent = "#16161664";
            const char* onSurface = "#FFFFFF";
            const char* onSurfaceVariant = "#646464";
            const char* outline = "#4A4A4ABF";
            const char* primaryGlow = "#4B69FE64";
        };

        void SetColor(ImGuiCol idx, const char* hex_color);
        ImVec4 HexToImVec4(const char* hex_color);
        void SetLightMode(bool enabled);
        bool IsLightMode() const { return false; }
        enum class AccentMode : uint8_t {
            Accent = 0,
            AccentGradient = 1,
            User = 2
        };
        enum class AccentGradientDirection : uint8_t {
            Horizontal = 0,
            Vertical = 1
        };
        void SetAccentColor(float r, float g, float b);
        void SetAccentGradientColor(float r, float g, float b);
        void SetUserAccentGradient(float r1, float g1, float b1, float r2, float g2, float b2);
        void SetAccentMode(AccentMode mode);
        void SetAccentGradientDirection(AccentGradientDirection direction);
        void SetAnimatedAccentEnabled(bool enabled);
        void SetAnimatedAccentParams(float color_spacing, float speed, float smoothness, float strength);
        AccentMode GetAccentMode() const { return accentMode; }
        AccentGradientDirection GetAccentGradientDirection() const { return accentGradientDirection; }
        ImVec4 GetAccentColor() const { return ImVec4(accentR, accentG, accentB, 1.0f); }
        ImVec4 GetAccentGradientColor() const { return ImVec4(accentGradientR, accentGradientG, accentGradientB, 1.0f); }
        bool GetAnimatedAccentEnabled() const { return animatedAccentEnabled; }
        float GetAnimatedAccentColorSpacing() const { return animatedAccentColorSpacing; }
        float GetAnimatedAccentSpeed() const { return animatedAccentSpeed; }
        float GetAnimatedAccentSmoothness() const { return animatedAccentSmoothness; }
        float GetAnimatedAccentStrength() const { return animatedAccentStrength; }
        void GetResolvedAccentGradient(ImVec4& out_start, ImVec4& out_end) const;
        ImVec4 GetResolvedAccentColor() const;

        Style style;
        Rendering rendering;
        Shape shape;
        Metrics metrics;
        Material material;

        void ApplyTheme();
        void Update();
        void Build();
        ImFont* Get(FontId id) const;
        ImFont* Get(const char* id) const;
        ImFont* Load(const void* data, size_t size, float size_pixels, const ImFontConfig* config = nullptr, const ImWchar* glyph_ranges = nullptr, const char* font_name = nullptr);
        void SetIds(std::initializer_list<const char*> ids);

    private:
        FontRegistry fonts;
        std::array<ImFont*, static_cast<size_t>(FontId::Count)> font_by_id{};
        std::array<std::string, static_cast<size_t>(FontId::Count)> font_tags;
        std::vector<std::string> font_ids;
        std::unordered_map<std::string, ImFont*> fonts_by_id;
        float accentR = 0.294f;
        float accentG = 0.412f;
        float accentB = 0.996f;
        float accentGradientR = 0.545f;
        float accentGradientG = 0.286f;
        float accentGradientB = 0.996f;
        float userAccentR1 = 0.294f;
        float userAccentG1 = 0.412f;
        float userAccentB1 = 0.996f;
        float userAccentR2 = 0.545f;
        float userAccentG2 = 0.286f;
        float userAccentB2 = 0.996f;
        AccentMode accentMode = AccentMode::User;
        AccentGradientDirection accentGradientDirection = AccentGradientDirection::Horizontal;
        bool animatedAccentEnabled = false;
        float animatedAccentColorSpacing = 0.18f;
        float animatedAccentSpeed = 0.32f;
        float animatedAccentSmoothness = 0.72f;
        float animatedAccentStrength = 1.0f;
        char accentPrimaryHex[10] = "#4B69FE";
        char accentGlowHex[10] = "#4B69FE64";
    };
    struct Scale {
        static constexpr int DefaultWidth = 1180;
        static constexpr int DefaultHeight = 640;
        float Scale = 1.0f;
        int Width = DefaultWidth;
        int Height = DefaultHeight;
        float LastApplied = 0.0f;
        bool Dirty = false;

        void Apply(ClickGUI& gui, float scale);
    };

    struct Animation {
        float Alpha = 0.0f;
        float targetAlpha = 0.0f;
        float animationProgress = 0.0f;
        float targetAnimationProgress = 0.0f;
        bool scalled = true;
        bool menuJustOpened = false;

        void Begin(ImGuiIO& io, bool open);
        void Open();
        void Close();
    };

    struct Settings {
        int* downscaleFactor = nullptr;
        float* cornerRadius = nullptr;
        float* scale = nullptr;
        bool* blurEnabled = nullptr;
        float* scrollbarSize = nullptr;
        std::function<void(float)> updateThemeCallback;
        int width = 0;
        int height = 0;
        ClickGUI* gui = nullptr;
    };

    struct Sidebar {
        int DownscaleFactor = 4;
        float BlurRadius = 1.0f;
        bool ShowIcon = true;
        float TextureScale = 0.85f;
        Blur::Type BlurType = Blur::Type::Yorozka;
        std::string searchPlaceholder;
    };

    struct AppearanceTuning {
        int shadowRings = 16;
        float shadowSmoothness = 0.75f;
    };

    struct AnimationTuning {
        float menuSpeed = 1.0f;
        float tabsSpeed = 1.0f;
        float popupSpeed = 1.0f;
    };

    struct RippleTuning {
        float pressRadius = 1.0f;
        float pressSpeed = 1.0f;
        float pressStrength = 1.0f;
        float pressDuration = 0.283f;
        float dragRadius = 1.0f;
        float dragStrength = 1.0f;
        float motionStrength = 1.0f;
    };

    struct User {
        std::string userName;
        std::string userRank;
    };

    struct Assets {
        struct Icon {
            struct Glow {
                std::string loaded;
                ImageRegion uv{};
                GLuint tex = 0;
            };

            std::string name;
            std::string loaded;
            ImageRegion uv{};
            GLuint tex = 0;
            Glow glow{};
        };

        struct Yorozka : Icon {
            Yorozka() { name = "yorozka"; }
        };

        struct Search : Icon {
            Search() { name = "search"; }
        };

        struct User : Icon {
            User() { name = "user"; }
        };

        struct Cui : Icon {
            Cui() { name = "cui"; }
        };

        bool initialized = false;
        Yorozka yorozka;
        Search search;
        User user;
        Cui cui;
    };

    struct Touch {
        struct Scroll {
            bool isScrolling = false;
            ImVec2 scrollStartPos = ImVec2(0, 0);
            ImVec2 scrollCurrentPos = ImVec2(0, 0);
            ImVec2 scrollVelocity = ImVec2(0, 0);
            ImVec2 lastTouchPos = ImVec2(0, 0);
            float scrollMomentum = 0.0f;
            bool contentInteractionEnabled = true;
            bool isContentAreaScrolled = false;
        };

        bool wasScrolling = false;
        ImVec2 touchStartPos = ImVec2(0, 0);
        bool hasMovedSignificantly = false;
        Scroll scroll;

        void Update(ImGuiIO& io, int touch_count);
    };

    struct RuntimeCache {
        float uiScale = 1.0f;
        float logoWidth = 230.0f;
        float logoHeight = 129.375f;
        float logoOffsetY = 27.0f;
        float tabsOffsetY = 10.0f;
        float panelPadding = 18.0f;
        float moduleWidth = 230.0f;
        float gradientHeight = 50.0f;
        float barsWidth = 26.0f;
        float barsGap = 5.0f;
        float barsTopOffset = 10.0f;
        float lineWidth = 1.0f;
        float sidebarTextureWidth = 457.0f;
        float sidebarTextureHeight = 752.0f;

        ImVec4 primary = ImVec4(0.137f, 0.561f, 0.886f, 1.0f);
        ImVec4 onSurface = ImVec4(1.0f, 1.0f, 1.0f, 1.0f);
        ImVec4 onSurfaceVariant = ImVec4(1.0f, 1.0f, 1.0f, 1.0f);
        ImVec4 surface = ImVec4(0.0f, 0.0f, 0.0f, 1.0f);
        ImVec4 surfaceContainer = ImVec4(0.0f, 0.0f, 0.0f, 1.0f);
        ImVec4 surfaceTransparent = ImVec4(0.0f, 0.0f, 0.0f, 0.0f);
        ImVec4 surfaceVariantTransparent = ImVec4(0.0f, 0.0f, 0.0f, 0.0f);
    };

    static ClickGUI& Get();

    bool open = true;
    bool built = false;
    bool introPlayedOnce = false;
    int width = Scale::DefaultWidth;
    int height = Scale::DefaultHeight;
    
    Scale scale;
    Animation animation;
    Pipeline pipeline;
    Sidebar sidebar;
    AppearanceTuning appearance;
    AnimationTuning animationTuning;
    RippleTuning rippleTuning;
    User userInfo;
    Touch touch;
    Settings settings;
    RuntimeCache cache;
    float watermarkNormX = 0.042f;
    float watermarkNormY = 0.075f;
    float watermarkVisibleWidthNorm = 0.22f;
    float watermarkVisibleHeightNorm = 0.055f;
    float watermarkExpandedWidthNorm = 0.30f;
    float watermarkBgAlphaNoBlur = 1.0f;
    float watermarkScale = 1.0f;
    float watermarkTextAlpha = 0.92f;
    float watermarkSeparatorAlpha = 1.0f;
    float watermarkPaddingScale = 1.0f;
    int watermarkNicknameColorMode = 0; // 0=Default, 1=Theme, 2=User
    float watermarkNicknameColor1[3] = {1.0f, 1.0f, 1.0f};
    float watermarkNicknameColor2[3] = {0.82f, 0.82f, 0.82f};
    uint32_t watermarkInfoMask = (1u << 0); 
    ImVec2 watermarkCaptureMin = ImVec2(0.0f, 0.0f);
    ImVec2 watermarkCaptureMax = ImVec2(0.0f, 0.0f);
    bool watermarkCaptureValid = false;
    float speedGraphNormX = 0.5f;
    float speedGraphNormY = 0.86f;
    float speedGraphVisibleWidthNorm = 0.24f;
    float speedGraphVisibleHeightNorm = 0.10f;
    float speedGraphExpandedWidthNorm = 0.24f;
    float movementRecorderNormX = 0.042f;
    float movementRecorderNormY = 0.165f;
    float movementRecorderVisibleWidthNorm = 0.22f;
    float movementRecorderVisibleHeightNorm = 0.13f;
    float movementRecorderExpandedWidthNorm = 0.22f;
    bool mainWantCaptureMouseSnapshot = false;
    bool overlayWantCaptureMouseSnapshot = false;
    bool menuRippleEnabled = true;
    bool tabMorphEnabled = true;

    std::unique_ptr<WindowManager> windows;
    std::unique_ptr<LayoutManager> layouts;
    std::unique_ptr<WidgetManager> widgets;
    std::unique_ptr<Theme> theme;
    Theme* widgetsThemeBound = nullptr;
    Assets assets;
    struct PostLayoutFadeCache {
        bool sidebar_valid = false;
        bool content_valid = false;
        ImVec2 sidebar_pos = ImVec2(0.0f, 0.0f);
        ImVec2 sidebar_size = ImVec2(0.0f, 0.0f);
        ImVec2 content_pos = ImVec2(0.0f, 0.0f);
        ImVec2 content_size = ImVec2(0.0f, 0.0f);
        GLuint menu_blur_tex = 0;
        ImVec2 menu_blur_pos = ImVec2(0.0f, 0.0f);
        ImVec2 menu_blur_size = ImVec2(1.0f, 1.0f);
        float gradient_h = 0.0f;
        float sidebar_top_alpha = 0.0f;
        float sidebar_bottom_alpha = 0.0f;
        float content_top_alpha = 0.0f;
        float content_bottom_alpha = 0.0f;
        ImVec4 sidebar_overlay = ImVec4(0.0f, 0.0f, 0.0f, 0.0f);
        ImVec4 content_overlay = ImVec4(0.0f, 0.0f, 0.0f, 0.0f);
        float content_rounding = 0.0f;
    } post_layout_fade;
    ImVec2 overlayMenuMin = ImVec2(0.0f, 0.0f);
    ImVec2 overlayMenuMax = ImVec2(0.0f, 0.0f);
    bool overlayMenuValid = false;

    void Init();
    void Update();
    void PostOverlay(int display_w, int display_h);
    void Toggle();
    void Preload();
    bool ShouldForceCaptureMouse(const ImVec2& mouse_pos, bool pointer_down_or_click) const;
    bool ShouldBlockGameInput(const ImVec2& mouse_pos, bool pointer_down_or_click) const;
    void NotifyWatermarkInteraction(const ImVec2& pos, float strength = 0.90f);
    void NotifyWatermarkVisualMotion(const ImVec2& velocity, float amp, float dt);

private:
    void BuildPostOverlayPipeline();

public:
    Pipeline postOverlayPipeline;
    bool postOverlayBuilt = false;
    ImGuiContext* postOverlayContext = nullptr;
    bool postOverlayInitialized = false;
};

using Theme = ClickGUI::Theme;
