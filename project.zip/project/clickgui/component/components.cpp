#include "components.h"

#include "../clickgui.h"
#include "../widgets/wigdets.h"
#include "../render/post_processing.h"
#include "../../assets/images.h"
#include "../../modules/modules.h"
#include "../../axlebolt/player_controller.h"
#include "../imgui/imgui_internal.h"
#include "../imgui/im_anim/im_anim.h"
#include <algorithm>
#include <array>
#include <cfloat>
#include <cstdint>
#include <cmath>
#include <ctime>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <memory>
#include <string>
#include <unistd.h>
#include <vector>

static Blur wblur(Hardware::GPU);
static Blur speed_graph_blur(Hardware::GPU);
static Blur movement_recorder_blur(Hardware::GPU);

static constexpr int kHudBlurPasses = 18;
static constexpr int kHudShadowMaxRings = 24;

static inline float GetScale() {
    const float font_scale = ImGui::GetIO().FontGlobalScale;
    return (font_scale != 0.0f) ? (font_scale / 0.75f) : 1.0f;
}

static inline bool IsValidRegion(const ImageRegion& r) {
    return r.width > 0 && r.height > 0 &&
           r.u_max > r.u_min && r.v_max > r.v_min;
}

static float GetGlyphOffsetY(ImFont* font, float targetSize) {
    if (!font || font->Sources.empty() || font->Sources[0] == nullptr) {
        return 0.0f;
    }
    const ImFontConfig* cfg = font->Sources[0];
    const float base_size = (cfg->SizePixels > 0.0f)
        ? cfg->SizePixels
        : ((font->LegacySize > 0.0f) ? font->LegacySize : std::max(1.0f, targetSize));
    const float scale = targetSize / std::max(1.0f, base_size);
    return cfg->GlyphOffset.y * scale;
}

enum class EdgeStripeSide {
    None,
    Left,
    Right
};

static ImVec4 ResolveAnimatedStripeTint(Theme* theme, float axis_px, float axis_extent_px, bool horizontal, float alpha);
static int AnimatedAccentSegments(Theme* theme, float extent_px, bool horizontal);

static EdgeStripeSide ResolveEdgeStripeSide(float center_norm_x) {
    if (center_norm_x <= 0.38f) {
        return EdgeStripeSide::Left;
    }
    if (center_norm_x >= 0.62f) {
        return EdgeStripeSide::Right;
    }
    return EdgeStripeSide::None;
}

static float ResolveEdgeStripeWidth(float base_ui_scale, float border_w) {
    return std::max(7.0f * base_ui_scale * 1.20f, border_w * 1.2f);
}

static ImDrawFlags BodyRoundingFlagsForStripe(EdgeStripeSide side) {
    switch (side) {
        case EdgeStripeSide::Left: return ImDrawFlags_RoundCornersRight;
        case EdgeStripeSide::Right: return ImDrawFlags_RoundCornersLeft;
        case EdgeStripeSide::None:
        default: return ImDrawFlags_RoundCornersAll;
    }
}

static std::vector<ImVec2> BuildSmoothPolyline(const std::vector<ImVec2>& points, int subdivisions) {
    if (points.size() < 2) {
        return points;
    }
    std::vector<ImVec2> out;
    out.reserve(points.size() * (size_t)std::max(1, subdivisions));
    for (size_t i = 0; i + 1 < points.size(); ++i) {
        const ImVec2& p0 = points[i];
        const ImVec2& p1 = points[i + 1];
        const float dx = p1.x - p0.x;
        const ImVec2 c0(p0.x + dx * 0.35f, p0.y);
        const ImVec2 c1(p1.x - dx * 0.35f, p1.y);
        if (i == 0) {
            out.push_back(p0);
        }
        for (int step = 1; step <= subdivisions; ++step) {
            const float t = (float)step / (float)subdivisions;
            const float u = 1.0f - t;
            out.push_back(ImVec2(
                u * u * u * p0.x + 3.0f * u * u * t * c0.x + 3.0f * u * t * t * c1.x + t * t * t * p1.x,
                u * u * u * p0.y + 3.0f * u * u * t * c0.y + 3.0f * u * t * t * c1.y + t * t * t * p1.y
            ));
        }
    }
    return out;
}

static std::vector<ImVec2> ResamplePolyline(const std::vector<ImVec2>& points, size_t target_count) {
    if (points.size() <= target_count || target_count < 2) {
        return points;
    }

    std::vector<float> seg_len(points.size(), 0.0f);
    float total_len = 0.0f;
    for (size_t i = 1; i < points.size(); ++i) {
        const float dx = points[i].x - points[i - 1].x;
        const float dy = points[i].y - points[i - 1].y;
        total_len += std::sqrt(dx * dx + dy * dy);
        seg_len[i] = total_len;
    }
    if (total_len <= 0.001f) {
        std::vector<ImVec2> out;
        out.reserve(target_count);
        for (size_t i = 0; i < target_count; ++i) {
            const size_t src = (i * (points.size() - 1)) / (target_count - 1);
            out.push_back(points[src]);
        }
        return out;
    }

    std::vector<ImVec2> out;
    out.reserve(target_count);
    out.push_back(points.front());
    size_t seg = 1;
    for (size_t i = 1; i + 1 < target_count; ++i) {
        const float want = total_len * ((float)i / (float)(target_count - 1));
        while (seg + 1 < points.size() && seg_len[seg] < want) {
            ++seg;
        }
        const float len0 = seg_len[seg - 1];
        const float len1 = seg_len[seg];
        const float t = (len1 > len0) ? ((want - len0) / (len1 - len0)) : 0.0f;
        out.push_back(ImVec2(
            points[seg - 1].x + (points[seg].x - points[seg - 1].x) * t,
            points[seg - 1].y + (points[seg].y - points[seg - 1].y) * t
        ));
    }
    out.push_back(points.back());
    return out;
}

static std::vector<float> SmoothSamples(const float* samples, size_t count) {
    std::vector<float> out(count, 0.0f);
    if (!samples || count == 0) {
        return out;
    }
    if (count == 1) {
        out[0] = samples[0];
        return out;
    }
    out[0] = samples[0] * 0.78f + samples[1] * 0.22f;
    if (count > 2) {
        out[1] = samples[0] * 0.18f + samples[1] * 0.56f + samples[2] * 0.26f;
    }
    for (size_t i = 2; i + 2 < count; ++i) {
        out[i] = samples[i - 2] * 0.06f + samples[i - 1] * 0.18f + samples[i] * 0.52f +
                 samples[i + 1] * 0.18f + samples[i + 2] * 0.06f;
    }
    if (count > 2) {
        out[count - 2] = samples[count - 3] * 0.26f + samples[count - 2] * 0.56f + samples[count - 1] * 0.18f;
    }
    out[count - 1] = samples[count - 2] * 0.22f + samples[count - 1] * 0.78f;
    return out;
}

static std::vector<ImVec2> BuildCatmullRomPolyline(const std::vector<ImVec2>& points, int subdivisions) {
    if (points.size() < 2) {
        return points;
    }
    std::vector<ImVec2> out;
    out.reserve(points.size() * (size_t)std::max(1, subdivisions));
    auto get = [&](int idx) -> const ImVec2& {
        if (idx < 0) return points.front();
        if ((size_t)idx >= points.size()) return points.back();
        return points[(size_t)idx];
    };
    for (int i = 0; i < (int)points.size() - 1; ++i) {
        const ImVec2& p0 = get(i - 1);
        const ImVec2& p1 = get(i);
        const ImVec2& p2 = get(i + 1);
        const ImVec2& p3 = get(i + 2);
        if (i == 0) {
            out.push_back(p1);
        }
        for (int step = 1; step <= subdivisions; ++step) {
            const float t = (float)step / (float)subdivisions;
            const float t2 = t * t;
            const float t3 = t2 * t;
            out.push_back(ImVec2(
                0.5f * ((2.0f * p1.x) + (-p0.x + p2.x) * t + (2.0f * p0.x - 5.0f * p1.x + 4.0f * p2.x - p3.x) * t2 + (-p0.x + 3.0f * p1.x - 3.0f * p2.x + p3.x) * t3),
                0.5f * ((2.0f * p1.y) + (-p0.y + p2.y) * t + (2.0f * p0.y - 5.0f * p1.y + 4.0f * p2.y - p3.y) * t2 + (-p0.y + 3.0f * p1.y - 3.0f * p2.y + p3.y) * t3)
            ));
        }
    }
    return out;
}

namespace {
static constexpr int kSpeedGraphShaderMaxPoints = 96;

struct SpeedGraphRenderJob {
    int screen_x = 0;
    int screen_y = 0;
    int display_h = 0;
    int width = 0;
    int height = 0;
    int point_count = 0;
    float line_radius_px = 1.0f;
    float glow_radius_px = 1.0f;
    float glow_alpha = 0.0f;
    float end_cap_alpha = 0.0f;
    ImVec4 color = ImVec4(1, 1, 1, 1);
    ImVec4 color2 = ImVec4(1, 1, 1, 1);
    float band_spacing_px = 0.0f;
    float band_offset_px = 0.0f;
    float band_time = 0.0f;
    float band_smoothness = 0.0f;
    float band_strength = 0.0f;
    std::array<ImVec2, kSpeedGraphShaderMaxPoints> points{};
};

struct SpeedGraphRenderCache {
    bool valid = false;
    int tex_w = 0;
    int tex_h = 0;
    int point_count = 0;
    float line_radius = 0.0f;
    float glow_radius = 0.0f;
    float glow_sigma = 0.0f;
    ImVec4 color = ImVec4(0, 0, 0, 0);
    ImVec4 glow_color = ImVec4(0, 0, 0, 0);
    std::array<ImVec2, kSpeedGraphShaderMaxPoints> points{};
};

static GLuint g_speed_graph_prog = 0;
static GLuint g_speed_graph_fbo = 0;
static GLuint g_speed_graph_tex_rt = 0;
static GLuint g_speed_graph_vao = 0;
static GLuint g_speed_graph_vbo = 0;
static int g_speed_graph_rt_w = 0;
static int g_speed_graph_rt_h = 0;
static GLint g_speed_graph_loc_size = -1;
static GLint g_speed_graph_loc_count = -1;
static GLint g_speed_graph_loc_points = -1;
static GLint g_speed_graph_loc_color = -1;
static GLint g_speed_graph_loc_line_radius = -1;
static GLint g_speed_graph_loc_glow_radius = -1;
static GLint g_speed_graph_loc_glow_alpha = -1;
static GLint g_speed_graph_loc_end_cap_alpha = -1;
static GLint g_speed_graph_loc_color2 = -1;
static GLint g_speed_graph_loc_band_spacing = -1;
static GLint g_speed_graph_loc_band_offset = -1;
static GLint g_speed_graph_loc_band_time = -1;
static GLint g_speed_graph_loc_band_smoothness = -1;
static GLint g_speed_graph_loc_band_strength = -1;
static SpeedGraphRenderCache g_speed_graph_cache = {};

// stripe glow FBO
static GLuint g_stripe_fbo = 0;
static GLuint g_stripe_tex = 0;
static int g_stripe_tex_w = 0;
static int g_stripe_tex_h = 0;

static GLuint CompileLocalShader(GLenum type, const char* src) {
    if (!glCreateShader || !glShaderSource || !glCompileShader || !glGetShaderiv) {
        return 0;
    }
    GLuint shader = glCreateShader(type);
    if (!shader) {
        return 0;
    }
    glShaderSource(shader, 1, &src, nullptr);
    glCompileShader(shader);
    GLint ok = 0;
    glGetShaderiv(shader, GL_COMPILE_STATUS, &ok);
    if (!ok) {
        if (glGetShaderInfoLog) {
            char buf[512]; GLsizei len=0;
            glGetShaderInfoLog(shader, sizeof(buf), &len, buf);
        }
        if (glDeleteShader) glDeleteShader(shader);
        return 0;
    }
    return shader;
}

static GLuint CreateLocalProgram(const char* vs_src, const char* fs_src) {
    if (!glCreateProgram || !glAttachShader || !glLinkProgram || !glGetProgramiv) {
        return 0;
    }
    GLuint vs = CompileLocalShader(GL_VERTEX_SHADER, vs_src);
    GLuint fs = CompileLocalShader(GL_FRAGMENT_SHADER, fs_src);
    if (!vs || !fs) {
        if (vs && glDeleteShader) glDeleteShader(vs);
        if (fs && glDeleteShader) glDeleteShader(fs);
        return 0;
    }
    GLuint prog = glCreateProgram();
    glAttachShader(prog, vs);
    glAttachShader(prog, fs);
    glLinkProgram(prog);
    GLint ok = 0;
    glGetProgramiv(prog, GL_LINK_STATUS, &ok);
    if (glDeleteShader) {
        glDeleteShader(vs);
        glDeleteShader(fs);
    }
    if (!ok) {
        if (glDeleteProgram) {
            glDeleteProgram(prog);
        }
        return 0;
    }
    return prog;
}

static void EnsureSpeedGraphRenderer() {
    if (g_speed_graph_prog != 0) {
        return;
    }
    if (!glCreateProgram || !glGetUniformLocation || !glUseProgram || !glUniform1i ||
        !glUniform2f || !glUniform2fv || !glUniform4f || !glUniform1f ||
        !glGenFramebuffers || !glBindFramebuffer || !glFramebufferTexture2D ||
        !glGenTextures || !glBindTexture || !glTexParameteri || !glTexImage2D ||
        !glGenBuffers || !glBindBuffer || !glBufferData ||
        !glGenVertexArrays || !glBindVertexArray || !glEnableVertexAttribArray ||
        !glVertexAttribPointer || !glDrawArrays || !glViewport) {
        return;
    }

    static const char* kVs = R"GLSL(
        #version 300 es
        precision mediump float;
        layout(location = 0) in vec2 aPos;
        layout(location = 1) in vec2 aUv;
        out vec2 vUv;
        void main() {
            vUv = aUv;
            gl_Position = vec4(aPos, 0.0, 1.0);
        }
    )GLSL";

    static const char* kFs = R"GLSL(
        #version 300 es
        precision highp float;
        in vec2 vUv;
        out vec4 FragColor;
        uniform vec2 uSize;
        uniform int uCount;
        uniform vec2 uPoints[96];
        uniform vec4 uColor;
        uniform vec4 uColor2;
        uniform float uLineRadius;
        uniform float uGlowRadius;
        uniform float uGlowAlpha;
        uniform float uEndCapAlpha;
        uniform float uBandSpacingPx;
        uniform float uBandOffsetPx;
        uniform float uBandTime;
        uniform float uBandSmoothness;
        uniform float uBandStrength;

        float segDist(vec2 p, vec2 a, vec2 b) {
            vec2 ba = b - a;
            float len2 = max(dot(ba, ba), 0.0001);
            float h = dot(p - a, ba) / len2;
            if (h < 0.0 || h > 1.0) {
                return 1e20;
            }
            vec2 n = vec2(-ba.y, ba.x) / max(length(ba), 0.0001);
            return abs(dot(p - a, n));
        }

        void main() {
            vec2 p = vec2(vUv.x * uSize.x, (1.0 - vUv.y) * uSize.y);
            float d = 1e20;
            float joint_d = 1e20;
            float end_d = 1e20;
            for (int i = 0; i < 95; ++i) {
                if (i == 0 && uCount > 0) {
                    end_d = min(end_d, length(p - uPoints[0]));
                }
                if (i == uCount - 1 && i < 96) {
                    end_d = min(end_d, length(p - uPoints[i]));
                }
                if (i > 0 && i < uCount - 1) {
                    joint_d = min(joint_d, length(p - uPoints[i]));
                }
                if (i >= uCount - 1) break;
                d = min(d, segDist(p, uPoints[i], uPoints[i + 1]));
            }
            float aa = 1.0;
            float core_alpha = 1.0 - smoothstep(uLineRadius - aa, uLineRadius + aa, d);
            // fill tiny gaps on bends without restoring rounded end caps
            if (uCount > 2) {
                float joint_alpha = 1.0 - smoothstep(uLineRadius * 0.84 - aa, uLineRadius * 0.84 + aa, joint_d);
                core_alpha = max(core_alpha, joint_alpha * 0.92);
            }
            if (uEndCapAlpha > 0.001) {
                float end_alpha = 1.0 - smoothstep(uLineRadius - aa, uLineRadius + aa, end_d);
                core_alpha = max(core_alpha, end_alpha * uEndCapAlpha);
            }

            // wide soft halo
            float glow_d = min(d, joint_d);
            if (uEndCapAlpha > 0.001) {
                glow_d = min(glow_d, mix(1e20, end_d, uEndCapAlpha));
            }
            float dist_from_edge = max(glow_d - uLineRadius, 0.0);
            float wide  = exp(-dist_from_edge / max((uGlowRadius - uLineRadius) * 0.5, 0.001));
            float narrow = exp(-dist_from_edge / max((uGlowRadius - uLineRadius) * 0.15, 0.001));
            float bloom_alpha = (wide * 0.55 + narrow * 0.70) * uGlowAlpha;

            float alpha = clamp(max(core_alpha, bloom_alpha), 0.0, 1.0);
            float band_wave = 0.5;
            if (uBandStrength > 0.001 && uBandSpacingPx > 0.001) {
                float phase = ((p.x + uBandOffsetPx) / uBandSpacingPx) + uBandTime;
                float tri = abs(mod(phase, 2.0) - 1.0);
                float sine = 0.5 + 0.5 * sin(phase * 6.2831853);
                band_wave = clamp(mix(tri, sine, uBandSmoothness), 0.0, 1.0);
            }
            vec3 band_color = mix(uColor.rgb, uColor2.rgb, band_wave * uBandStrength);
            vec3 color = mix(band_color * 1.15, band_color, clamp(core_alpha * 1.5, 0.0, 1.0));
            FragColor = vec4(color, alpha * uColor.a);
        }
    )GLSL";

    g_speed_graph_prog = CreateLocalProgram(kVs, kFs);
    if (!g_speed_graph_prog) {
        return;
    }

    g_speed_graph_loc_size = glGetUniformLocation(g_speed_graph_prog, "uSize");
    g_speed_graph_loc_count = glGetUniformLocation(g_speed_graph_prog, "uCount");
    g_speed_graph_loc_points = glGetUniformLocation(g_speed_graph_prog, "uPoints");
    g_speed_graph_loc_color = glGetUniformLocation(g_speed_graph_prog, "uColor");
    g_speed_graph_loc_color2 = glGetUniformLocation(g_speed_graph_prog, "uColor2");
    g_speed_graph_loc_line_radius = glGetUniformLocation(g_speed_graph_prog, "uLineRadius");
    g_speed_graph_loc_glow_radius = glGetUniformLocation(g_speed_graph_prog, "uGlowRadius");
    g_speed_graph_loc_glow_alpha = glGetUniformLocation(g_speed_graph_prog, "uGlowAlpha");
    g_speed_graph_loc_end_cap_alpha = glGetUniformLocation(g_speed_graph_prog, "uEndCapAlpha");
    g_speed_graph_loc_band_spacing = glGetUniformLocation(g_speed_graph_prog, "uBandSpacingPx");
    g_speed_graph_loc_band_offset = glGetUniformLocation(g_speed_graph_prog, "uBandOffsetPx");
    g_speed_graph_loc_band_time = glGetUniformLocation(g_speed_graph_prog, "uBandTime");
    g_speed_graph_loc_band_smoothness = glGetUniformLocation(g_speed_graph_prog, "uBandSmoothness");
    g_speed_graph_loc_band_strength = glGetUniformLocation(g_speed_graph_prog, "uBandStrength");

    const float quad[] = {
        -1.0f, -1.0f, 0.0f, 0.0f,
         1.0f, -1.0f, 1.0f, 0.0f,
        -1.0f,  1.0f, 0.0f, 1.0f,
         1.0f,  1.0f, 1.0f, 1.0f,
    };

    glGenVertexArrays(1, &g_speed_graph_vao);
    glGenBuffers(1, &g_speed_graph_vbo);
    glBindVertexArray(g_speed_graph_vao);
    glBindBuffer(GL_ARRAY_BUFFER, g_speed_graph_vbo);
    glBufferData(GL_ARRAY_BUFFER, sizeof(quad), quad, GL_STATIC_DRAW);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 4 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 4 * sizeof(float), (void*)(2 * sizeof(float)));
    glBindVertexArray(0);
    glBindBuffer(GL_ARRAY_BUFFER, 0);

    glGenTextures(1, &g_speed_graph_tex_rt);
    glGenFramebuffers(1, &g_speed_graph_fbo);
}

static void EnsureSpeedGraphTarget(int width, int height) {
    if (width <= 0 || height <= 0) {
        return;
    }
    EnsureSpeedGraphRenderer();
    if (g_speed_graph_prog == 0 || g_speed_graph_tex_rt == 0 || g_speed_graph_fbo == 0) {
        return;
    }
    if (g_speed_graph_rt_w == width && g_speed_graph_rt_h == height) {
        return;
    }
    g_speed_graph_rt_w = width;
    g_speed_graph_rt_h = height;
    glBindTexture(GL_TEXTURE_2D, g_speed_graph_tex_rt);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, nullptr);
    glBindFramebuffer(GL_FRAMEBUFFER, g_speed_graph_fbo);
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, g_speed_graph_tex_rt, 0);
}

// ── stripe glow ──────────────────────────────────────────────────────────────
static GLuint g_stripe_blur_prog = 0;
static constexpr int kStripeGlowTargetCount = 3;
static GLuint g_stripe_blur_fbo[kStripeGlowTargetCount][2] = {};
static GLuint g_stripe_blur_tex[kStripeGlowTargetCount][2] = {};
static int    g_stripe_blur_w[kStripeGlowTargetCount] = {};
static int    g_stripe_blur_h[kStripeGlowTargetCount] = {};
static GLint  g_stripe_loc_tex = -1, g_stripe_loc_dir = -1, g_stripe_loc_sigma = -1;

enum class StripeGlowTargetId : int {
    Watermark = 0,
    SpeedGraph = 1,
    MovementRecorder = 2
};

// speed graph glow FBO (separate)
static GLuint g_sg_glow_fbo[2] = {0, 0};
static GLuint g_sg_glow_tex[2] = {0, 0};
static int    g_sg_glow_w = 0, g_sg_glow_h = 0;

// stripe shape renderer (SDF rounded rect, large left corners)
static GLuint g_stripe_shape_prog = 0;
static GLuint g_stripe_shape_fbo[kStripeGlowTargetCount] = {};
static GLuint g_stripe_shape_tex[kStripeGlowTargetCount] = {};
static int    g_stripe_shape_w[kStripeGlowTargetCount] = {};
static int    g_stripe_shape_h[kStripeGlowTargetCount] = {};
static GLint  g_stripe_shape_loc_size = -1, g_stripe_shape_loc_color = -1;
static GLint  g_stripe_shape_loc_r_left = -1, g_stripe_shape_loc_r_right = -1;
static GLuint g_stripe_tint_prog = 0;
static GLint  g_stripe_tint_loc_size = -1, g_stripe_tint_loc_display = -1;
static GLint  g_stripe_tint_loc_screen = -1, g_stripe_tint_loc_color1 = -1, g_stripe_tint_loc_color2 = -1;
static GLint  g_stripe_tint_loc_side = -1, g_stripe_tint_loc_animated = -1, g_stripe_tint_loc_spacing = -1;
static GLint  g_stripe_tint_loc_time = -1, g_stripe_tint_loc_smoothness = -1, g_stripe_tint_loc_strength = -1;
static GLuint g_stripe_glow_blit_prog = 0;
static GLint  g_stripe_glow_blit_loc_tex = -1, g_stripe_glow_blit_loc_size = -1, g_stripe_glow_blit_loc_display = -1;
static GLint  g_stripe_glow_blit_loc_screen = -1, g_stripe_glow_blit_loc_color1 = -1, g_stripe_glow_blit_loc_color2 = -1;
static GLint  g_stripe_glow_blit_loc_side = -1, g_stripe_glow_blit_loc_animated = -1, g_stripe_glow_blit_loc_spacing = -1;
static GLint  g_stripe_glow_blit_loc_time = -1, g_stripe_glow_blit_loc_smoothness = -1, g_stripe_glow_blit_loc_strength = -1;
static GLint  g_stripe_glow_blit_loc_core_top = -1, g_stripe_glow_blit_loc_core_bottom = -1;
static GLint  g_stripe_glow_blit_loc_top_h = -1, g_stripe_glow_blit_loc_bottom_h = -1, g_stripe_glow_blit_loc_alpha = -1;

struct StripeGlowJob {
    StripeGlowTargetId target = StripeGlowTargetId::Watermark;
    float r, g, b, a;
    float stripe_x, stripe_y, stripe_w, stripe_h;
    int   tex_w, tex_h;
    float sigma;
    float sigma_h; // extra horizontal sigma for wider right glow
};

static void EnsureStripeBlurRenderer() {
    if (g_stripe_blur_prog) return;
    static const char* kVs = R"GLSL(
        #version 300 es
        precision mediump float;
        layout(location=0) in vec2 aPos;
        layout(location=1) in vec2 aUv;
        out vec2 vUv;
        void main() { vUv = aUv; gl_Position = vec4(aPos,0,1); }
    )GLSL";
    static const char* kFs = R"GLSL(
        #version 300 es
        precision mediump float;
        in vec2 vUv;
        out vec4 FragColor;
        uniform sampler2D uTex;
        uniform vec2 uDir;
        uniform float uSigma;
        void main() {
            int r = min(int(ceil(uSigma * 2.5)), 32);
            float wsum = 0.0;
            float asum = 0.0;
            vec3 col = vec3(0.0);
            for (int i = -r; i <= r; ++i) {
                float w = exp(-float(i*i) / (2.0*uSigma*uSigma));
                vec4 s = texture(uTex, vUv + uDir * float(i));
                asum += s.a * w;
                col += s.rgb * w;
                wsum += w;
            }
            // keep color, blur only alpha
            FragColor = vec4(col / max(wsum, 0.001), asum / max(wsum, 0.001));
        }
    )GLSL";
    g_stripe_blur_prog = CreateLocalProgram(kVs, kFs);
    if (!g_stripe_blur_prog) return;
    g_stripe_loc_tex   = glGetUniformLocation(g_stripe_blur_prog, "uTex");
    g_stripe_loc_dir   = glGetUniformLocation(g_stripe_blur_prog, "uDir");
    g_stripe_loc_sigma = glGetUniformLocation(g_stripe_blur_prog, "uSigma");
}

static void EnsureStripeBlurTarget(StripeGlowTargetId target, int w, int h) {
    if (w <= 0 || h <= 0) return;
    EnsureStripeBlurRenderer();
    if (!g_stripe_blur_prog) return;
    const int idx = (int)target;
    if (g_stripe_blur_w[idx] == w && g_stripe_blur_h[idx] == h && g_stripe_blur_tex[idx][0]) return;
    g_stripe_blur_w[idx] = w; g_stripe_blur_h[idx] = h;
    if (!g_stripe_blur_fbo[idx][0]) glGenFramebuffers(2, g_stripe_blur_fbo[idx]);
    if (!g_stripe_blur_tex[idx][0]) glGenTextures(2, g_stripe_blur_tex[idx]);
    for (int i = 0; i < 2; ++i) {
        glBindTexture(GL_TEXTURE_2D, g_stripe_blur_tex[idx][i]);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, nullptr);
        glBindFramebuffer(GL_FRAMEBUFFER, g_stripe_blur_fbo[idx][i]);
        glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, g_stripe_blur_tex[idx][i], 0);
    }
    glBindTexture(GL_TEXTURE_2D, 0);
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
}

struct StripeShapeJob {
    StripeGlowTargetId target = StripeGlowTargetId::Watermark;
    float r, g, b, a;
    float r_left, r_right;
    int tex_w, tex_h;
};

struct StripeTintJob {
    float screen_x, screen_y;
    float width, height;
    float display_w, display_h;
    ImVec4 color1, color2;
    int side = 0;
    int animated = 0;
    float spacing_px = 0.0f;
    float time = 0.0f;
    float smoothness = 0.0f;
    float strength = 0.0f;
};

struct StripeGlowBlitJob {
    GLuint tex = 0;
    float screen_x, screen_y;
    float width, height;
    float display_w, display_h;
    ImVec4 color1, color2;
    int side = 0;
    int animated = 0;
    float spacing_px = 0.0f;
    float time = 0.0f;
    float smoothness = 0.0f;
    float strength = 0.0f;
    float core_top = 0.0f;
    float core_bottom = 1.0f;
    float top_h = 0.0f;
    float bottom_h = 0.0f;
    float alpha = 1.0f;
};

static void EnsureStripeShapeRenderer() {
    if (g_stripe_shape_prog) return;
    static const char* kVs = R"GLSL(
        #version 300 es
        precision mediump float;
        layout(location=0) in vec2 aPos;
        layout(location=1) in vec2 aUv;
        out vec2 vUv;
        void main() { vUv = aUv; gl_Position = vec4(aPos,0,1); }
    )GLSL";
    // SDF rounded rect: large left corners, small right corners
    static const char* kFs = R"GLSL(
        #version 300 es
        precision highp float;
        in vec2 vUv;
        out vec4 FragColor;
        uniform vec2 uSize;
        uniform vec4 uColor;
        uniform float uRLeft;
        uniform float uRRight;
        // left-rounded rect: full rect + rounded left corners via circle SDF
        void main() {
            vec2 p = vUv * uSize; // pixel coords, (0,0) = bottom-left
            vec2 b = uSize;
            float r = uRLeft;
            float alpha = 0.0;
            float aa = 1.0;
            // full rect
            bool in_rect = p.x >= 0.0 && p.x <= b.x && p.y >= 0.0 && p.y <= b.y;
            if (in_rect) {
                alpha = 1.0;
                // cut left corners with circle
                if (p.x < r) {
                    if (p.y < r) {
                        float d = length(p - vec2(r, r)) - r;
                        alpha = 1.0 - smoothstep(-aa, aa, d);
                    } else if (p.y > b.y - r) {
                        float d = length(p - vec2(r, b.y - r)) - r;
                        alpha = 1.0 - smoothstep(-aa, aa, d);
                    }
                }
            }
            FragColor = vec4(uColor.rgb, uColor.a * alpha);
        }
    )GLSL";
    g_stripe_shape_prog = CreateLocalProgram(kVs, kFs);
    if (!g_stripe_shape_prog) return;
    g_stripe_shape_loc_size    = glGetUniformLocation(g_stripe_shape_prog, "uSize");
    g_stripe_shape_loc_color   = glGetUniformLocation(g_stripe_shape_prog, "uColor");
    g_stripe_shape_loc_r_left  = glGetUniformLocation(g_stripe_shape_prog, "uRLeft");
    g_stripe_shape_loc_r_right = glGetUniformLocation(g_stripe_shape_prog, "uRRight");
}

static void EnsureStripeTintRenderer() {
    if (g_stripe_tint_prog) return;
    static const char* kVs = R"GLSL(
        #version 300 es
        precision mediump float;
        layout(location=0) in vec2 aPos;
        layout(location=1) in vec2 aUv;
        out vec2 vUv;
        void main() { vUv = aUv; gl_Position = vec4(aPos, 0.0, 1.0); }
    )GLSL";
    static const char* kFs = R"GLSL(
        #version 300 es
        precision highp float;
        in vec2 vUv;
        out vec4 FragColor;
        uniform vec2 uSize;
        uniform vec2 uDisplay;
        uniform vec2 uScreen;
        uniform vec4 uColor1;
        uniform vec4 uColor2;
        uniform int uSide;
        uniform int uAnimated;
        uniform float uSpacingPx;
        uniform float uTime;
        uniform float uSmoothness;
        uniform float uStrength;
        float sd_box(vec2 p, vec2 c, vec2 b) {
            vec2 d = abs(p - c) - b;
            return length(max(d, 0.0)) + min(max(d.x, d.y), 0.0);
        }
        float shape_alpha(vec2 p) {
            if (uSide == 1) {
                p.x = uSize.x - p.x;
            }
            float r = clamp(uSize.x - 0.35, 1.0, max(1.0, uSize.y * 0.5 - 0.35));
            float d_main = sd_box(p, vec2(0.5 * (r + uSize.x), 0.5 * uSize.y), vec2(0.5 * max(0.0, uSize.x - r), 0.5 * uSize.y));
            float d_mid = 1e6;
            if (uSize.y > r * 2.0) {
                d_mid = sd_box(p, vec2(0.5 * r, 0.5 * uSize.y), vec2(0.5 * r, 0.5 * (uSize.y - 2.0 * r)));
            }
            float d_top = length(p - vec2(r, r)) - r;
            float d_bottom = length(p - vec2(r, uSize.y - r)) - r;
            float d = min(min(d_main, d_mid), min(d_top, d_bottom));
            float aa = max(1.0, fwidth(d) * 1.75);
            return 1.0 - smoothstep(0.0, aa, d);
        }
        float animated_band(float axis_px) {
            float spacing = max(8.0, uSpacingPx);
            float phase = axis_px / spacing;
            float tri = abs(mod(phase + uTime, 2.0) - 1.0);
            float sine = 0.5 + 0.5 * sin((phase + uTime) * 6.28318530718);
            return clamp(mix(tri, sine, clamp(uSmoothness, 0.0, 1.0)), 0.0, 1.0);
        }
        void main() {
            vec2 p = vec2(vUv.x * uSize.x, vUv.y * uSize.y);
            float alpha = shape_alpha(p);
            float axis_px = uScreen.y + p.y;
            float base_t = clamp(axis_px / max(1.0, uDisplay.y), 0.0, 1.0);
            vec3 base_col = mix(uColor1.rgb, uColor2.rgb, base_t);
            vec3 color = base_col;
            if (uAnimated != 0) {
                float band_t = animated_band(axis_px);
                vec3 band_col = mix(uColor1.rgb, uColor2.rgb, band_t);
                color = mix(base_col, band_col, clamp(uStrength, 0.0, 1.0));
            }
            FragColor = vec4(color, alpha * uColor1.a);
        }
    )GLSL";
    g_stripe_tint_prog = CreateLocalProgram(kVs, kFs);
    if (!g_stripe_tint_prog) return;
    g_stripe_tint_loc_size = glGetUniformLocation(g_stripe_tint_prog, "uSize");
    g_stripe_tint_loc_display = glGetUniformLocation(g_stripe_tint_prog, "uDisplay");
    g_stripe_tint_loc_screen = glGetUniformLocation(g_stripe_tint_prog, "uScreen");
    g_stripe_tint_loc_color1 = glGetUniformLocation(g_stripe_tint_prog, "uColor1");
    g_stripe_tint_loc_color2 = glGetUniformLocation(g_stripe_tint_prog, "uColor2");
    g_stripe_tint_loc_side = glGetUniformLocation(g_stripe_tint_prog, "uSide");
    g_stripe_tint_loc_animated = glGetUniformLocation(g_stripe_tint_prog, "uAnimated");
    g_stripe_tint_loc_spacing = glGetUniformLocation(g_stripe_tint_prog, "uSpacingPx");
    g_stripe_tint_loc_time = glGetUniformLocation(g_stripe_tint_prog, "uTime");
    g_stripe_tint_loc_smoothness = glGetUniformLocation(g_stripe_tint_prog, "uSmoothness");
    g_stripe_tint_loc_strength = glGetUniformLocation(g_stripe_tint_prog, "uStrength");
}

static void EnsureStripeGlowBlitRenderer() {
    if (g_stripe_glow_blit_prog) return;
    static const char* kVs = R"GLSL(
        #version 300 es
        precision mediump float;
        layout(location=0) in vec2 aPos;
        layout(location=1) in vec2 aUv;
        out vec2 vUv;
        void main() { vUv = aUv; gl_Position = vec4(aPos, 0.0, 1.0); }
    )GLSL";
    static const char* kFs = R"GLSL(
        #version 300 es
        precision highp float;
        in vec2 vUv;
        out vec4 FragColor;
        uniform sampler2D uTex;
        uniform vec2 uSize;
        uniform vec2 uDisplay;
        uniform vec2 uScreen;
        uniform vec4 uColor1;
        uniform vec4 uColor2;
        uniform int uSide;
        uniform int uAnimated;
        uniform float uSpacingPx;
        uniform float uTime;
        uniform float uSmoothness;
        uniform float uStrength;
        uniform float uCoreTop;
        uniform float uCoreBottom;
        uniform float uTopH;
        uniform float uBottomH;
        uniform float uAlpha;
        float animated_band(float axis_px) {
            float spacing = max(8.0, uSpacingPx);
            float phase = axis_px / spacing;
            float tri = abs(mod(phase + uTime, 2.0) - 1.0);
            float sine = 0.5 + 0.5 * sin((phase + uTime) * 6.28318530718);
            return clamp(mix(tri, sine, clamp(uSmoothness, 0.0, 1.0)), 0.0, 1.0);
        }
        float map_v(float local_y) {
            float top_h = max(0.0, uTopH);
            float bottom_h = max(0.0, uBottomH);
            float core_h = max(0.001, uSize.y - top_h - bottom_h);
            if (local_y <= top_h) {
                float t = clamp(local_y / max(0.001, top_h), 0.0, 1.0);
                return mix(1.0, uCoreTop, t);
            }
            if (local_y <= uSize.y - bottom_h) {
                float t = clamp((local_y - top_h) / core_h, 0.0, 1.0);
                return mix(uCoreTop, uCoreBottom, t);
            }
            float t = clamp((local_y - (uSize.y - bottom_h)) / max(0.001, bottom_h), 0.0, 1.0);
            return mix(uCoreBottom, 0.0, t);
        }
        void main() {
            vec2 p = vec2(vUv.x * uSize.x, vUv.y * uSize.y);
            float axis_px = uScreen.y + p.y;
            float base_t = clamp(axis_px / max(1.0, uDisplay.y), 0.0, 1.0);
            vec3 base_col = mix(uColor1.rgb, uColor2.rgb, base_t);
            vec3 color = base_col;
            if (uAnimated != 0) {
                float band_t = animated_band(axis_px);
                vec3 band_col = mix(uColor1.rgb, uColor2.rgb, band_t);
                color = mix(base_col, band_col, clamp(uStrength, 0.0, 1.0));
            }
            float tex_u = (uSide == 0) ? vUv.x : (1.0 - vUv.x);
            float tex_v = map_v(p.y);
            float mask = texture(uTex, vec2(tex_u, tex_v)).a;
            mask = pow(clamp(mask, 0.0, 1.0), 0.72);
            float glow = uAlpha * 1.30;
            FragColor = vec4(color * mask * glow, mask * glow);
        }
    )GLSL";
    g_stripe_glow_blit_prog = CreateLocalProgram(kVs, kFs);
    if (!g_stripe_glow_blit_prog) return;
    g_stripe_glow_blit_loc_tex = glGetUniformLocation(g_stripe_glow_blit_prog, "uTex");
    g_stripe_glow_blit_loc_size = glGetUniformLocation(g_stripe_glow_blit_prog, "uSize");
    g_stripe_glow_blit_loc_display = glGetUniformLocation(g_stripe_glow_blit_prog, "uDisplay");
    g_stripe_glow_blit_loc_screen = glGetUniformLocation(g_stripe_glow_blit_prog, "uScreen");
    g_stripe_glow_blit_loc_color1 = glGetUniformLocation(g_stripe_glow_blit_prog, "uColor1");
    g_stripe_glow_blit_loc_color2 = glGetUniformLocation(g_stripe_glow_blit_prog, "uColor2");
    g_stripe_glow_blit_loc_side = glGetUniformLocation(g_stripe_glow_blit_prog, "uSide");
    g_stripe_glow_blit_loc_animated = glGetUniformLocation(g_stripe_glow_blit_prog, "uAnimated");
    g_stripe_glow_blit_loc_spacing = glGetUniformLocation(g_stripe_glow_blit_prog, "uSpacingPx");
    g_stripe_glow_blit_loc_time = glGetUniformLocation(g_stripe_glow_blit_prog, "uTime");
    g_stripe_glow_blit_loc_smoothness = glGetUniformLocation(g_stripe_glow_blit_prog, "uSmoothness");
    g_stripe_glow_blit_loc_strength = glGetUniformLocation(g_stripe_glow_blit_prog, "uStrength");
    g_stripe_glow_blit_loc_core_top = glGetUniformLocation(g_stripe_glow_blit_prog, "uCoreTop");
    g_stripe_glow_blit_loc_core_bottom = glGetUniformLocation(g_stripe_glow_blit_prog, "uCoreBottom");
    g_stripe_glow_blit_loc_top_h = glGetUniformLocation(g_stripe_glow_blit_prog, "uTopH");
    g_stripe_glow_blit_loc_bottom_h = glGetUniformLocation(g_stripe_glow_blit_prog, "uBottomH");
    g_stripe_glow_blit_loc_alpha = glGetUniformLocation(g_stripe_glow_blit_prog, "uAlpha");
}

static void EnsureStripeShapeTarget(StripeGlowTargetId target, int w, int h) {
    if (w <= 0 || h <= 0) return;
    EnsureStripeShapeRenderer();
    if (!g_stripe_shape_prog) return;
    const int idx = (int)target;
    if (g_stripe_shape_w[idx] == w && g_stripe_shape_h[idx] == h && g_stripe_shape_tex[idx]) return;
    g_stripe_shape_w[idx] = w; g_stripe_shape_h[idx] = h;
    if (!g_stripe_shape_fbo[idx]) glGenFramebuffers(1, &g_stripe_shape_fbo[idx]);
    if (!g_stripe_shape_tex[idx]) glGenTextures(1, &g_stripe_shape_tex[idx]);
    glBindTexture(GL_TEXTURE_2D, g_stripe_shape_tex[idx]);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, nullptr);
    glBindFramebuffer(GL_FRAMEBUFFER, g_stripe_shape_fbo[idx]);
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, g_stripe_shape_tex[idx], 0);
    glBindTexture(GL_TEXTURE_2D, 0);
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
}

static void StripeShapeCallback(const ImDrawList*, const ImDrawCmd* cmd) {
    if (!cmd || !cmd->UserCallbackData) return;
    std::unique_ptr<StripeShapeJob> job(static_cast<StripeShapeJob*>(cmd->UserCallbackData));
    const int idx = (int)job->target;
    if (!g_stripe_shape_prog || !g_stripe_shape_fbo[idx]) return;

    GLint prev_fbo=0, prev_prog=0, prev_vao=0; GLint prev_vp[4]={};
    GLboolean prev_blend=GL_FALSE, prev_scissor=GL_FALSE, prev_depth=GL_FALSE;
    glGetIntegerv(GL_FRAMEBUFFER_BINDING, &prev_fbo);
    glGetIntegerv(GL_VIEWPORT, prev_vp);
    glGetIntegerv(GL_CURRENT_PROGRAM, &prev_prog);
    glGetIntegerv(GL_VERTEX_ARRAY_BINDING, &prev_vao);
    prev_blend = glIsEnabled(GL_BLEND); prev_scissor = glIsEnabled(GL_SCISSOR_TEST); prev_depth = glIsEnabled(GL_DEPTH_TEST);

    glBindFramebuffer(GL_FRAMEBUFFER, g_stripe_shape_fbo[idx]);
    glViewport(0, 0, job->tex_w, job->tex_h);
    glDisable(GL_SCISSOR_TEST); glDisable(GL_DEPTH_TEST); glDisable(GL_BLEND);
    glClearColor(0,0,0,0); glClear(GL_COLOR_BUFFER_BIT);

    static GLuint s_vao=0, s_vbo=0;
    if (!s_vao) {
        const float q[]={-1,-1,0,0, 1,-1,1,0, -1,1,0,1, 1,1,1,1};
        glGenVertexArrays(1,&s_vao); glGenBuffers(1,&s_vbo);
        glBindVertexArray(s_vao); glBindBuffer(GL_ARRAY_BUFFER,s_vbo);
        glBufferData(GL_ARRAY_BUFFER,sizeof(q),q,GL_STATIC_DRAW);
        glEnableVertexAttribArray(0); glVertexAttribPointer(0,2,GL_FLOAT,GL_FALSE,4*sizeof(float),(void*)0);
        glEnableVertexAttribArray(1); glVertexAttribPointer(1,2,GL_FLOAT,GL_FALSE,4*sizeof(float),(void*)(2*sizeof(float)));
        glBindVertexArray(0);
    }
    glUseProgram(g_stripe_shape_prog);
    glUniform2f(g_stripe_shape_loc_size, (float)job->tex_w, (float)job->tex_h);
    glUniform4f(g_stripe_shape_loc_color, job->r, job->g, job->b, job->a);
    glUniform1f(g_stripe_shape_loc_r_left,  job->r_left);
    glUniform1f(g_stripe_shape_loc_r_right, job->r_right);
    glBindVertexArray(s_vao);
    glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);

    glBindFramebuffer(GL_FRAMEBUFFER, prev_fbo);
    glViewport(prev_vp[0],prev_vp[1],prev_vp[2],prev_vp[3]);
    glUseProgram(prev_prog); glBindVertexArray(prev_vao);
    if (prev_blend) glEnable(GL_BLEND); else glDisable(GL_BLEND);
    if (prev_scissor) glEnable(GL_SCISSOR_TEST); else glDisable(GL_SCISSOR_TEST);
    if (prev_depth) glEnable(GL_DEPTH_TEST); else glDisable(GL_DEPTH_TEST);
}

static void BuildScreenQuad(float x, float y, float w, float h, float display_w, float display_h, float* out_verts) {
    const float left = (x / std::max(1.0f, display_w)) * 2.0f - 1.0f;
    const float right = ((x + w) / std::max(1.0f, display_w)) * 2.0f - 1.0f;
    const float top = 1.0f - (y / std::max(1.0f, display_h)) * 2.0f;
    const float bottom = 1.0f - ((y + h) / std::max(1.0f, display_h)) * 2.0f;
    const float quad[] = {
        left,  top,    0.0f, 0.0f,
        right, top,    1.0f, 0.0f,
        left,  bottom, 0.0f, 1.0f,
        right, bottom, 1.0f, 1.0f
    };
    std::memcpy(out_verts, quad, sizeof(quad));
}

static void StripeTintCallback(const ImDrawList*, const ImDrawCmd* cmd) {
    if (!cmd || !cmd->UserCallbackData) return;
    std::unique_ptr<StripeTintJob> job(static_cast<StripeTintJob*>(cmd->UserCallbackData));
    EnsureStripeTintRenderer();
    if (!g_stripe_tint_prog || !job) return;

    GLint prev_fbo = 0, prev_prog = 0, prev_vao = 0, prev_vbo = 0;
    GLint prev_viewport[4] = {0, 0, 0, 0};
    GLboolean prev_blend = GL_FALSE, prev_scissor = GL_FALSE, prev_depth = GL_FALSE, prev_cull = GL_FALSE, prev_stencil = GL_FALSE;
    glGetIntegerv(GL_FRAMEBUFFER_BINDING, &prev_fbo);
    glGetIntegerv(GL_VIEWPORT, prev_viewport);
    glGetIntegerv(GL_CURRENT_PROGRAM, &prev_prog);
    glGetIntegerv(GL_VERTEX_ARRAY_BINDING, &prev_vao);
    glGetIntegerv(GL_ARRAY_BUFFER_BINDING, &prev_vbo);
    prev_blend = glIsEnabled(GL_BLEND);
    prev_scissor = glIsEnabled(GL_SCISSOR_TEST);
    prev_depth = glIsEnabled(GL_DEPTH_TEST);
    prev_cull = glIsEnabled(GL_CULL_FACE);
    prev_stencil = glIsEnabled(GL_STENCIL_TEST);

    static GLuint s_vao = 0, s_vbo = 0;
    if (!s_vao) {
        glGenVertexArrays(1, &s_vao);
        glGenBuffers(1, &s_vbo);
        glBindVertexArray(s_vao);
        glBindBuffer(GL_ARRAY_BUFFER, s_vbo);
        glBufferData(GL_ARRAY_BUFFER, sizeof(float) * 16, nullptr, GL_DYNAMIC_DRAW);
        glEnableVertexAttribArray(0);
        glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 4 * sizeof(float), (void*)0);
        glEnableVertexAttribArray(1);
        glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 4 * sizeof(float), (void*)(2 * sizeof(float)));
        glBindVertexArray(0);
    }

    float quad[16];
    BuildScreenQuad(job->screen_x, job->screen_y, job->width, job->height, job->display_w, job->display_h, quad);

    glBindFramebuffer(GL_FRAMEBUFFER, prev_fbo);
    glViewport(0, 0, (GLsizei)job->display_w, (GLsizei)job->display_h);
    glEnable(GL_BLEND);
    glBlendEquation(GL_FUNC_ADD);
    glBlendFuncSeparate(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA, GL_ONE, GL_ONE_MINUS_SRC_ALPHA);
    glDisable(GL_SCISSOR_TEST);
    glDisable(GL_DEPTH_TEST);
    glDisable(GL_CULL_FACE);
    glDisable(GL_STENCIL_TEST);

    glUseProgram(g_stripe_tint_prog);
    glUniform2f(g_stripe_tint_loc_size, job->width, job->height);
    glUniform2f(g_stripe_tint_loc_display, job->display_w, job->display_h);
    glUniform2f(g_stripe_tint_loc_screen, job->screen_x, job->screen_y);
    glUniform4f(g_stripe_tint_loc_color1, job->color1.x, job->color1.y, job->color1.z, job->color1.w);
    glUniform4f(g_stripe_tint_loc_color2, job->color2.x, job->color2.y, job->color2.z, job->color2.w);
    glUniform1i(g_stripe_tint_loc_side, job->side);
    glUniform1i(g_stripe_tint_loc_animated, job->animated);
    glUniform1f(g_stripe_tint_loc_spacing, job->spacing_px);
    glUniform1f(g_stripe_tint_loc_time, job->time);
    glUniform1f(g_stripe_tint_loc_smoothness, job->smoothness);
    glUniform1f(g_stripe_tint_loc_strength, job->strength);

    glBindVertexArray(s_vao);
    glBindBuffer(GL_ARRAY_BUFFER, s_vbo);
    glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(quad), quad);
    glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);

    glBindFramebuffer(GL_FRAMEBUFFER, prev_fbo);
    glViewport(prev_viewport[0], prev_viewport[1], prev_viewport[2], prev_viewport[3]);
    glUseProgram(prev_prog);
    glBindVertexArray(prev_vao);
    glBindBuffer(GL_ARRAY_BUFFER, prev_vbo);
    if (prev_blend) glEnable(GL_BLEND); else glDisable(GL_BLEND);
    if (prev_scissor) glEnable(GL_SCISSOR_TEST); else glDisable(GL_SCISSOR_TEST);
    if (prev_depth) glEnable(GL_DEPTH_TEST); else glDisable(GL_DEPTH_TEST);
    if (prev_cull) glEnable(GL_CULL_FACE); else glDisable(GL_CULL_FACE);
    if (prev_stencil) glEnable(GL_STENCIL_TEST); else glDisable(GL_STENCIL_TEST);
}

static void StripeGlowBlitCallback(const ImDrawList*, const ImDrawCmd* cmd) {
    if (!cmd || !cmd->UserCallbackData) return;
    std::unique_ptr<StripeGlowBlitJob> job(static_cast<StripeGlowBlitJob*>(cmd->UserCallbackData));
    EnsureStripeGlowBlitRenderer();
    if (!g_stripe_glow_blit_prog || !job || !job->tex) return;

    GLint prev_fbo = 0, prev_prog = 0, prev_vao = 0, prev_vbo = 0;
    GLint prev_viewport[4] = {0, 0, 0, 0};
    GLboolean prev_blend = GL_FALSE, prev_scissor = GL_FALSE, prev_depth = GL_FALSE, prev_cull = GL_FALSE, prev_stencil = GL_FALSE;
    glGetIntegerv(GL_FRAMEBUFFER_BINDING, &prev_fbo);
    glGetIntegerv(GL_VIEWPORT, prev_viewport);
    glGetIntegerv(GL_CURRENT_PROGRAM, &prev_prog);
    glGetIntegerv(GL_VERTEX_ARRAY_BINDING, &prev_vao);
    glGetIntegerv(GL_ARRAY_BUFFER_BINDING, &prev_vbo);
    prev_blend = glIsEnabled(GL_BLEND);
    prev_scissor = glIsEnabled(GL_SCISSOR_TEST);
    prev_depth = glIsEnabled(GL_DEPTH_TEST);
    prev_cull = glIsEnabled(GL_CULL_FACE);
    prev_stencil = glIsEnabled(GL_STENCIL_TEST);

    static GLuint s_vao = 0, s_vbo = 0;
    if (!s_vao) {
        glGenVertexArrays(1, &s_vao);
        glGenBuffers(1, &s_vbo);
        glBindVertexArray(s_vao);
        glBindBuffer(GL_ARRAY_BUFFER, s_vbo);
        glBufferData(GL_ARRAY_BUFFER, sizeof(float) * 16, nullptr, GL_DYNAMIC_DRAW);
        glEnableVertexAttribArray(0);
        glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 4 * sizeof(float), (void*)0);
        glEnableVertexAttribArray(1);
        glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 4 * sizeof(float), (void*)(2 * sizeof(float)));
        glBindVertexArray(0);
    }

    float quad[16];
    BuildScreenQuad(job->screen_x, job->screen_y, job->width, job->height, job->display_w, job->display_h, quad);

    glBindFramebuffer(GL_FRAMEBUFFER, prev_fbo);
    glViewport(0, 0, (GLsizei)job->display_w, (GLsizei)job->display_h);
    glEnable(GL_BLEND);
    glBlendEquation(GL_FUNC_ADD);
    glBlendFunc(GL_ONE, GL_ONE);
    glDisable(GL_SCISSOR_TEST);
    glDisable(GL_DEPTH_TEST);
    glDisable(GL_CULL_FACE);
    glDisable(GL_STENCIL_TEST);

    glUseProgram(g_stripe_glow_blit_prog);
    glUniform1i(g_stripe_glow_blit_loc_tex, 0);
    glUniform2f(g_stripe_glow_blit_loc_size, job->width, job->height);
    glUniform2f(g_stripe_glow_blit_loc_display, job->display_w, job->display_h);
    glUniform2f(g_stripe_glow_blit_loc_screen, job->screen_x, job->screen_y);
    glUniform4f(g_stripe_glow_blit_loc_color1, job->color1.x, job->color1.y, job->color1.z, 1.0f);
    glUniform4f(g_stripe_glow_blit_loc_color2, job->color2.x, job->color2.y, job->color2.z, 1.0f);
    glUniform1i(g_stripe_glow_blit_loc_side, job->side);
    glUniform1i(g_stripe_glow_blit_loc_animated, job->animated);
    glUniform1f(g_stripe_glow_blit_loc_spacing, job->spacing_px);
    glUniform1f(g_stripe_glow_blit_loc_time, job->time);
    glUniform1f(g_stripe_glow_blit_loc_smoothness, job->smoothness);
    glUniform1f(g_stripe_glow_blit_loc_strength, job->strength);
    glUniform1f(g_stripe_glow_blit_loc_core_top, job->core_top);
    glUniform1f(g_stripe_glow_blit_loc_core_bottom, job->core_bottom);
    glUniform1f(g_stripe_glow_blit_loc_top_h, job->top_h);
    glUniform1f(g_stripe_glow_blit_loc_bottom_h, job->bottom_h);
    glUniform1f(g_stripe_glow_blit_loc_alpha, job->alpha);

    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, job->tex);
    glBindVertexArray(s_vao);
    glBindBuffer(GL_ARRAY_BUFFER, s_vbo);
    glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(quad), quad);
    glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);

    glBindFramebuffer(GL_FRAMEBUFFER, prev_fbo);
    glViewport(prev_viewport[0], prev_viewport[1], prev_viewport[2], prev_viewport[3]);
    glUseProgram(prev_prog);
    glBindVertexArray(prev_vao);
    glBindBuffer(GL_ARRAY_BUFFER, prev_vbo);
    if (prev_blend) glEnable(GL_BLEND); else glDisable(GL_BLEND);
    if (prev_scissor) glEnable(GL_SCISSOR_TEST); else glDisable(GL_SCISSOR_TEST);
    if (prev_depth) glEnable(GL_DEPTH_TEST); else glDisable(GL_DEPTH_TEST);
    if (prev_cull) glEnable(GL_CULL_FACE); else glDisable(GL_CULL_FACE);
    if (prev_stencil) glEnable(GL_STENCIL_TEST); else glDisable(GL_STENCIL_TEST);
}

static void StripeGlowCallback(const ImDrawList*, const ImDrawCmd* cmd) {
    if (!cmd || !cmd->UserCallbackData) return;
    std::unique_ptr<StripeGlowJob> job(static_cast<StripeGlowJob*>(cmd->UserCallbackData));
    const int target_idx = (int)job->target;
    if (!g_stripe_blur_prog || !g_stripe_blur_tex[target_idx][0]) return;

    GLint prev_fbo=0, prev_prog=0, prev_vao=0;
    GLint prev_vp[4]={};
    GLboolean prev_scissor=GL_FALSE, prev_depth=GL_FALSE, prev_blend=GL_FALSE;
    glGetIntegerv(GL_FRAMEBUFFER_BINDING, &prev_fbo);
    glGetIntegerv(GL_VIEWPORT, prev_vp);
    glGetIntegerv(GL_CURRENT_PROGRAM, &prev_prog);
    glGetIntegerv(GL_VERTEX_ARRAY_BINDING, &prev_vao);
    prev_scissor = glIsEnabled(GL_SCISSOR_TEST);
    prev_depth   = glIsEnabled(GL_DEPTH_TEST);
    prev_blend   = glIsEnabled(GL_BLEND);

    glDisable(GL_SCISSOR_TEST);
    glDisable(GL_DEPTH_TEST);
    glDisable(GL_BLEND);

    // step 1: draw solid colored stripe into tex[0] (black background)
    glBindFramebuffer(GL_FRAMEBUFFER, g_stripe_blur_fbo[target_idx][0]);
    glViewport(0, 0, job->tex_w, job->tex_h);
    glClearColor(0, 0, 0, 0);
    glClear(GL_COLOR_BUFFER_BIT);
    {
        // GL scissor Y is flipped vs ImGui Y
        const int sx = (int)std::floor(job->stripe_x);
        const int sy = job->tex_h - (int)std::ceil(job->stripe_y + job->stripe_h);
        const int sw = (int)std::ceil(job->stripe_w);
        const int sh = (int)std::ceil(job->stripe_h);
        glEnable(GL_SCISSOR_TEST);
        glScissor(sx, std::max(0, sy), sw, sh);
        glClearColor(job->r, job->g, job->b, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT);
        glDisable(GL_SCISSOR_TEST);
    }

    // step 2: two-pass gaussian blur
    static GLuint s_quad_vao = 0, s_quad_vbo = 0;
    if (!s_quad_vao) {
        const float q[] = {-1,-1,0,0, 1,-1,1,0, -1,1,0,1, 1,1,1,1};
        glGenVertexArrays(1, &s_quad_vao);
        glGenBuffers(1, &s_quad_vbo);
        glBindVertexArray(s_quad_vao);
        glBindBuffer(GL_ARRAY_BUFFER, s_quad_vbo);
        glBufferData(GL_ARRAY_BUFFER, sizeof(q), q, GL_STATIC_DRAW);
        glEnableVertexAttribArray(0);
        glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 4*sizeof(float), (void*)0);
        glEnableVertexAttribArray(1);
        glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 4*sizeof(float), (void*)(2*sizeof(float)));
        glBindVertexArray(0);
    }

    glUseProgram(g_stripe_blur_prog);
    glUniform1i(g_stripe_loc_tex, 0);
    glUniform1f(g_stripe_loc_sigma, job->sigma);
    glBindVertexArray(s_quad_vao);
    glActiveTexture(GL_TEXTURE0);

    // H+V blur pass
    glBindFramebuffer(GL_FRAMEBUFFER, g_stripe_blur_fbo[target_idx][1]);
    glViewport(0, 0, job->tex_w, job->tex_h);
    glClearColor(0,0,0,0); glClear(GL_COLOR_BUFFER_BIT);
    glBindTexture(GL_TEXTURE_2D, g_stripe_blur_tex[target_idx][0]);
    glUniform2f(g_stripe_loc_dir, 1.0f/job->tex_w, 0.0f);
    glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);

    glBindFramebuffer(GL_FRAMEBUFFER, g_stripe_blur_fbo[target_idx][0]);
    glViewport(0, 0, job->tex_w, job->tex_h);
    glClearColor(0,0,0,0); glClear(GL_COLOR_BUFFER_BIT);
    glBindTexture(GL_TEXTURE_2D, g_stripe_blur_tex[target_idx][1]);
    glUniform2f(g_stripe_loc_dir, 0.0f, 1.0f/job->tex_h);
    glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);

    // extra wide horizontal pass: tex[0] -> tex[1] (result in tex[1])
    glUniform1f(g_stripe_loc_sigma, job->sigma_h);
    glBindFramebuffer(GL_FRAMEBUFFER, g_stripe_blur_fbo[target_idx][1]);
    glViewport(0, 0, job->tex_w, job->tex_h);
    glClearColor(0,0,0,0); glClear(GL_COLOR_BUFFER_BIT);
    glBindTexture(GL_TEXTURE_2D, g_stripe_blur_tex[target_idx][0]);
    glUniform2f(g_stripe_loc_dir, 1.0f/job->tex_w, 0.0f);
    glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
    // final result is in tex[1]

    // restore
    glBindFramebuffer(GL_FRAMEBUFFER, prev_fbo);
    glViewport(prev_vp[0], prev_vp[1], prev_vp[2], prev_vp[3]);
    glUseProgram(prev_prog);
    glBindVertexArray(prev_vao);
    if (prev_blend)   glEnable(GL_BLEND);   else glDisable(GL_BLEND);
    if (prev_scissor) glEnable(GL_SCISSOR_TEST); else glDisable(GL_SCISSOR_TEST);
    if (prev_depth)   glEnable(GL_DEPTH_TEST);   else glDisable(GL_DEPTH_TEST);
}

static void DrawEdgeStripeGlow(ImDrawList* draw_list,
                               const ImVec2& stripe_min,
                               const ImVec2& stripe_max,
                               const ImVec4& stripe_col,
                               EdgeStripeSide side,
                               StripeGlowTargetId target,
                               Theme* theme,
                               float base_ui_scale,
                               int display_w,
                               int display_h) {
    if (!draw_list || side == EdgeStripeSide::None || display_w <= 0 || display_h <= 0 || !post_processing.flags.glow) {
        return;
    }
    const float glow_sigma = 10.0f * base_ui_scale;
    const bool animated_accent = theme && theme->GetAnimatedAccentEnabled() && theme->GetAccentMode() != Theme::AccentMode::Accent;
    const float glow_left_mul = (side == EdgeStripeSide::Right) ? 12.5f : 6.0f;
    const float glow_right_mul = (side == EdgeStripeSide::Left) ? 12.5f : 6.0f;
    const float glow_y = glow_sigma * 6.0f;
    const int sx0 = std::max(0, (int)std::floor(stripe_min.x - glow_sigma * glow_left_mul));
    const int sy0 = std::max(0, (int)std::floor(stripe_min.y - glow_y));
    const int sx1 = std::min(display_w,  (int)std::ceil(stripe_max.x + glow_sigma * glow_right_mul));
    const int sy1 = std::min(display_h, (int)std::ceil(stripe_max.y + glow_y));
    const int sw = sx1 - sx0;
    const int sh = sy1 - sy0;
    if (sw <= 0 || sh <= 0) {
        return;
    }

    const float extra_right = (side == EdgeStripeSide::Left) ? (glow_sigma * 0.9f) : 0.0f;
    const float extra_left = (side == EdgeStripeSide::Right) ? (glow_sigma * 0.9f) : 0.0f;
    const ImVec2 dmin((float)sx0 - extra_left, (float)sy0);
    const ImVec2 dmax((float)sx1 + extra_right, (float)sy1);
    const float stripe_w = stripe_max.x - stripe_min.x;
    const float stripe_h = stripe_max.y - stripe_min.y;
    const float template_core_h = std::ceil(std::max(stripe_w * 4.0f, 26.0f * base_ui_scale));
    const int template_sw = std::max(1, (int)std::ceil(stripe_w + glow_sigma * (6.0f + 12.5f)));
    const int template_sh = std::max(1, (int)std::ceil(template_core_h + glow_y * 2.0f));
    static float s_template_core_top = 0.0f;
    static float s_template_core_bottom = 1.0f;
    static int s_cached_template_sw = -1;
    static int s_cached_template_sh = -1;
    static float s_cached_sigma = -1.0f;
    static float s_cached_sigma_h = -1.0f;
    static float s_cached_r = -1.0f;
    static float s_cached_g = -1.0f;
    static float s_cached_b = -1.0f;
    static StripeGlowTargetId s_template_owner = StripeGlowTargetId::Watermark;
    static bool s_has_template_owner = false;
    const float sigma_h = glow_sigma * 1.08f;
    const bool prefer_watermark_template =
        target == StripeGlowTargetId::Watermark &&
        (!s_has_template_owner || s_template_owner != StripeGlowTargetId::Watermark);
    if (!s_has_template_owner) {
        s_template_owner = target;
        s_has_template_owner = true;
    } else if (prefer_watermark_template) {
        s_template_owner = StripeGlowTargetId::Watermark;
    }
    const bool is_template_owner = s_has_template_owner && s_template_owner == target;
    const bool template_params_dirty =
        s_cached_template_sw != template_sw ||
        s_cached_template_sh != template_sh ||
        std::fabs(s_cached_sigma - glow_sigma) > 0.001f ||
        std::fabs(s_cached_sigma_h - sigma_h) > 0.001f ||
        false;
    const bool template_dirty =
        !g_stripe_blur_tex[(int)StripeGlowTargetId::Watermark][1] ||
        prefer_watermark_template ||
        (is_template_owner && template_params_dirty);
    if (template_dirty && template_sw > 0 && template_sh > 0) {
        auto* job = new StripeGlowJob();
        job->target = StripeGlowTargetId::Watermark;
        job->r = 1.0f;
        job->g = 1.0f;
        job->b = 1.0f;
        job->a = 1.0f;
        job->stripe_x = glow_sigma * 6.0f;
        job->stripe_y = glow_y;
        job->stripe_w = stripe_w;
        job->stripe_h = template_core_h;
        job->tex_w = template_sw;
        job->tex_h = template_sh;
        job->sigma = glow_sigma;
        job->sigma_h = sigma_h;
        EnsureStripeBlurTarget(StripeGlowTargetId::Watermark, template_sw, template_sh);
        s_template_core_top = std::clamp(job->stripe_y / std::max(1.0f, (float)job->tex_h), 0.0f, 1.0f);
        s_template_core_bottom = std::clamp((job->stripe_y + job->stripe_h) / std::max(1.0f, (float)job->tex_h), 0.0f, 1.0f);
        s_cached_template_sw = template_sw;
        s_cached_template_sh = template_sh;
        s_cached_sigma = glow_sigma;
        s_cached_sigma_h = sigma_h;
        s_cached_r = 1.0f;
        s_cached_g = 1.0f;
        s_cached_b = 1.0f;
        draw_list->AddCallback(StripeGlowCallback, job);
    }
    if (g_stripe_blur_tex[(int)StripeGlowTargetId::Watermark][1]) {
        const float top_h = std::max(0.0f, stripe_min.y - dmin.y);
        const float bottom_h = std::max(0.0f, dmax.y - stripe_max.y);
        ImVec4 grad_start, grad_end;
        theme->GetResolvedAccentGradient(grad_start, grad_end);
        auto* blit_job = new StripeGlowBlitJob();
        blit_job->tex = g_stripe_blur_tex[(int)StripeGlowTargetId::Watermark][1];
        blit_job->screen_x = dmin.x;
        blit_job->screen_y = dmin.y;
        blit_job->width = dmax.x - dmin.x;
        blit_job->height = dmax.y - dmin.y;
        blit_job->display_w = (float)display_w;
        blit_job->display_h = (float)display_h;
        blit_job->color1 = ImVec4(grad_start.x, grad_start.y, grad_start.z, stripe_col.w);
        blit_job->color2 = ImVec4(grad_end.x, grad_end.y, grad_end.z, stripe_col.w);
        blit_job->side = (side == EdgeStripeSide::Right) ? 1 : 0;
        blit_job->animated = (theme && theme->GetAnimatedAccentEnabled() && theme->GetAccentMode() != Theme::AccentMode::Accent) ? 1 : 0;
        blit_job->spacing_px = std::max(8.0f, (float)display_h * theme->GetAnimatedAccentColorSpacing());
        blit_job->time = (float)ImGui::GetTime() * theme->GetAnimatedAccentSpeed();
        blit_job->smoothness = theme->GetAnimatedAccentSmoothness();
        blit_job->strength = std::clamp(theme->GetAnimatedAccentStrength(), 0.0f, 1.0f);
        blit_job->core_top = 1.0f - s_template_core_top;
        blit_job->core_bottom = 1.0f - s_template_core_bottom;
        blit_job->top_h = top_h;
        blit_job->bottom_h = bottom_h;
        blit_job->alpha = animated_accent ? (122.0f / 255.0f) : (92.0f / 255.0f);
        draw_list->AddCallback(StripeGlowBlitCallback, blit_job);
        draw_list->AddCallback(ImDrawCallback_ResetRenderState, nullptr);
    }
}

static void DrawAnimatedEdgeStripe(ImDrawList* draw_list,
                                   const ImVec2& stripe_min,
                                   const ImVec2& stripe_max,
                                   EdgeStripeSide side,
                                   StripeGlowTargetId target,
                                   Theme* theme,
                                   float alpha,
                                   bool horizontal_pattern) {
    if (!draw_list || side == EdgeStripeSide::None || !theme) {
        return;
    }
    (void)target;
    (void)horizontal_pattern;
    ImVec4 grad_start, grad_end;
    theme->GetResolvedAccentGradient(grad_start, grad_end);
    auto* job = new StripeTintJob();
    job->screen_x = stripe_min.x;
    job->screen_y = stripe_min.y;
    job->width = std::max(1.0f, stripe_max.x - stripe_min.x);
    job->height = std::max(1.0f, stripe_max.y - stripe_min.y);
    job->display_w = (float)((glWidth > 0) ? glWidth : 1920);
    job->display_h = (float)((glHeight > 0) ? glHeight : 1080);
    job->color1 = ImVec4(grad_start.x, grad_start.y, grad_start.z, alpha);
    job->color2 = ImVec4(grad_end.x, grad_end.y, grad_end.z, alpha);
    job->side = (side == EdgeStripeSide::Right) ? 1 : 0;
    job->animated = (theme->GetAnimatedAccentEnabled() && theme->GetAccentMode() != Theme::AccentMode::Accent) ? 1 : 0;
    job->spacing_px = std::max(8.0f, job->display_h * theme->GetAnimatedAccentColorSpacing());
    job->time = (float)ImGui::GetTime() * theme->GetAnimatedAccentSpeed();
    job->smoothness = theme->GetAnimatedAccentSmoothness();
    job->strength = std::clamp(theme->GetAnimatedAccentStrength(), 0.0f, 1.0f);
    draw_list->AddCallback(StripeTintCallback, job);
    draw_list->AddCallback(ImDrawCallback_ResetRenderState, nullptr);
}
// ─────────────────────────────────────────────────────────────────────────────

static void EnsureSgGlowTarget(int w, int h) {
    if (w <= 0 || h <= 0) return;
    EnsureStripeBlurRenderer();
    if (!g_stripe_blur_prog) return;
    if (g_sg_glow_w == w && g_sg_glow_h == h && g_sg_glow_tex[0]) return;
    g_sg_glow_w = w; g_sg_glow_h = h;
    if (!g_sg_glow_fbo[0]) glGenFramebuffers(2, g_sg_glow_fbo);
    if (!g_sg_glow_tex[0]) glGenTextures(2, g_sg_glow_tex);
    for (int i = 0; i < 2; ++i) {
        glBindTexture(GL_TEXTURE_2D, g_sg_glow_tex[i]);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, nullptr);
        glBindFramebuffer(GL_FRAMEBUFFER, g_sg_glow_fbo[i]);
        glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, g_sg_glow_tex[i], 0);
    }
    glBindTexture(GL_TEXTURE_2D, 0);
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
}

// speed graph glow: blur g_speed_graph_tex_rt via stripe blur pipeline
struct SpeedGraphGlowJob { float sigma; int w, h; int src_w, src_h; float r, g, b; };

static void SpeedGraphGlowCallback(const ImDrawList*, const ImDrawCmd* cmd) {
    if (!cmd || !cmd->UserCallbackData) return;
    std::unique_ptr<SpeedGraphGlowJob> job(static_cast<SpeedGraphGlowJob*>(cmd->UserCallbackData));
    if (!g_stripe_blur_prog || !g_speed_graph_prog) return;

    EnsureSgGlowTarget(job->w, job->h);
    if (!g_sg_glow_tex[0]) return;

    // save only FBO and viewport — blend state is known (ImGui uses SRC_ALPHA/ONE_MINUS_SRC_ALPHA)
    GLint prev_fbo=0; GLint prev_vp[4]={};
    GLint prev_prog=0, prev_vao=0;
    glGetIntegerv(GL_FRAMEBUFFER_BINDING, &prev_fbo);
    glGetIntegerv(GL_VIEWPORT, prev_vp);
    glGetIntegerv(GL_CURRENT_PROGRAM, &prev_prog);
    glGetIntegerv(GL_VERTEX_ARRAY_BINDING, &prev_vao);
    glDisable(GL_SCISSOR_TEST); glDisable(GL_DEPTH_TEST); glDisable(GL_BLEND);

    // H: g_speed_graph_tex_rt -> g_sg_glow_tex[1]
    glUseProgram(g_stripe_blur_prog);
    glUniform1i(g_stripe_loc_tex, 0);
    glUniform1f(g_stripe_loc_sigma, job->sigma);
    glActiveTexture(GL_TEXTURE0);

    static GLuint s_vao=0, s_vbo=0;
    if (!s_vao) {
        const float q[]={-1,-1,0,0, 1,-1,1,0, -1,1,0,1, 1,1,1,1};
        glGenVertexArrays(1,&s_vao); glGenBuffers(1,&s_vbo);
        glBindVertexArray(s_vao); glBindBuffer(GL_ARRAY_BUFFER,s_vbo);
        glBufferData(GL_ARRAY_BUFFER,sizeof(q),q,GL_STATIC_DRAW);
        glEnableVertexAttribArray(0); glVertexAttribPointer(0,2,GL_FLOAT,GL_FALSE,4*sizeof(float),(void*)0);
        glEnableVertexAttribArray(1); glVertexAttribPointer(1,2,GL_FLOAT,GL_FALSE,4*sizeof(float),(void*)(2*sizeof(float)));
        glBindVertexArray(0);
    }
    glBindVertexArray(s_vao);

    // H: speed_graph_tex -> g_sg_glow_fbo[1]
    glBindFramebuffer(GL_FRAMEBUFFER, g_sg_glow_fbo[1]);
    glViewport(0,0,job->w,job->h); glClearColor(0,0,0,0); glClear(GL_COLOR_BUFFER_BIT);
    glBindTexture(GL_TEXTURE_2D, g_speed_graph_tex_rt);
    glUniform2f(g_stripe_loc_dir, 1.0f/job->src_w, 0.0f);
    glDrawArrays(GL_TRIANGLE_STRIP,0,4);

    // V: g_sg_glow_tex[1] -> g_sg_glow_fbo[0]
    glBindFramebuffer(GL_FRAMEBUFFER, g_sg_glow_fbo[0]);
    glViewport(0,0,job->w,job->h); glClearColor(0,0,0,0); glClear(GL_COLOR_BUFFER_BIT);
    glBindTexture(GL_TEXTURE_2D, g_sg_glow_tex[1]);
    glUniform2f(g_stripe_loc_dir, 0.0f, 1.0f/job->src_h);
    glDrawArrays(GL_TRIANGLE_STRIP,0,4);
    // result is in g_sg_glow_tex[0]

    glBindFramebuffer(GL_FRAMEBUFFER, prev_fbo);
    glViewport(prev_vp[0],prev_vp[1],prev_vp[2],prev_vp[3]);
    glUseProgram(prev_prog); glBindVertexArray(prev_vao);
    // restore ImGui blend state
    glEnable(GL_BLEND);
    glBlendEquation(GL_FUNC_ADD);
    glBlendFuncSeparate(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA, GL_ONE, GL_ONE_MINUS_SRC_ALPHA);
    glEnable(GL_SCISSOR_TEST);
}

static void RenderSpeedGraphDirect(const SpeedGraphRenderJob& job) {
    if (job.point_count < 2 || g_speed_graph_prog == 0) {
        return;
    }
    GLint prev_fbo = 0;
    GLint prev_viewport[4] = {0, 0, 0, 0};
    GLint prev_program = 0;
    GLint prev_vao = 0;
    GLint prev_vbo = 0;
    GLboolean prev_blend = GL_FALSE;
    GLboolean prev_scissor = GL_FALSE;
    GLboolean prev_depth = GL_FALSE;
    GLboolean prev_cull = GL_FALSE;
    GLboolean prev_stencil = GL_FALSE;

    glGetIntegerv(GL_FRAMEBUFFER_BINDING, &prev_fbo);
    glGetIntegerv(GL_VIEWPORT, prev_viewport);
    glGetIntegerv(GL_CURRENT_PROGRAM, &prev_program);
    glGetIntegerv(GL_VERTEX_ARRAY_BINDING, &prev_vao);
    glGetIntegerv(GL_ARRAY_BUFFER_BINDING, &prev_vbo);
    prev_blend = glIsEnabled(GL_BLEND);
    prev_scissor = glIsEnabled(GL_SCISSOR_TEST);
    prev_depth = glIsEnabled(GL_DEPTH_TEST);
    prev_cull = glIsEnabled(GL_CULL_FACE);
    prev_stencil = glIsEnabled(GL_STENCIL_TEST);

    glBindFramebuffer(GL_FRAMEBUFFER, prev_fbo);
    glViewport(job.screen_x, job.display_h - job.screen_y - job.height, job.width, job.height);
    glEnable(GL_BLEND);
    glBlendEquation(GL_FUNC_ADD);
    glBlendFuncSeparate(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA, GL_ONE, GL_ONE_MINUS_SRC_ALPHA);
    glEnable(GL_SCISSOR_TEST);
    glScissor(job.screen_x, job.display_h - job.screen_y - job.height, job.width, job.height);
    glDisable(GL_DEPTH_TEST);
    glDisable(GL_CULL_FACE);
    glDisable(GL_STENCIL_TEST);

    glUseProgram(g_speed_graph_prog);
    glUniform2f(g_speed_graph_loc_size, (float)job.width, (float)job.height);
    glUniform1i(g_speed_graph_loc_count, job.point_count);
    glUniform2fv(g_speed_graph_loc_points, job.point_count, &job.points[0].x);
    glUniform4f(g_speed_graph_loc_color, job.color.x, job.color.y, job.color.z, job.color.w);
    glUniform4f(g_speed_graph_loc_color2, job.color2.x, job.color2.y, job.color2.z, job.color2.w);
    glUniform1f(g_speed_graph_loc_line_radius, job.line_radius_px);
    glUniform1f(g_speed_graph_loc_glow_radius, job.glow_radius_px);
    glUniform1f(g_speed_graph_loc_glow_alpha, job.glow_alpha);
    glUniform1f(g_speed_graph_loc_end_cap_alpha, job.end_cap_alpha);
    glUniform1f(g_speed_graph_loc_band_spacing, job.band_spacing_px);
    glUniform1f(g_speed_graph_loc_band_offset, job.band_offset_px);
    glUniform1f(g_speed_graph_loc_band_time, job.band_time);
    glUniform1f(g_speed_graph_loc_band_smoothness, job.band_smoothness);
    glUniform1f(g_speed_graph_loc_band_strength, job.band_strength);

    glBindVertexArray(g_speed_graph_vao);
    glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);

    glBindFramebuffer(GL_FRAMEBUFFER, prev_fbo);
    glViewport(prev_viewport[0], prev_viewport[1], prev_viewport[2], prev_viewport[3]);
    glUseProgram(prev_program);
    glBindVertexArray(prev_vao);
    glBindBuffer(GL_ARRAY_BUFFER, prev_vbo);
    if (prev_blend) glEnable(GL_BLEND); else glDisable(GL_BLEND);
    if (prev_scissor) glEnable(GL_SCISSOR_TEST); else glDisable(GL_SCISSOR_TEST);
    if (prev_depth) glEnable(GL_DEPTH_TEST); else glDisable(GL_DEPTH_TEST);
    if (prev_cull) glEnable(GL_CULL_FACE); else glDisable(GL_CULL_FACE);
    if (prev_stencil) glEnable(GL_STENCIL_TEST); else glDisable(GL_STENCIL_TEST);
}

static void SpeedGraphRenderCallback(const ImDrawList*, const ImDrawCmd* cmd) {
    if (!cmd || !cmd->UserCallbackData) {
        return;
    }
    std::unique_ptr<SpeedGraphRenderJob> job(static_cast<SpeedGraphRenderJob*>(cmd->UserCallbackData));
    if (!job || job->point_count < 2) {
        return;
    }
    EnsureSpeedGraphRenderer();
    if (g_speed_graph_prog == 0) {
        return;
    }
    RenderSpeedGraphDirect(*job);
}

static bool SpeedGraphCacheMatches(const std::vector<ImVec2>& render_points,
                                   int tex_w,
                                   int tex_h,
                                   float line_radius,
                                   float glow_radius,
                                   float glow_sigma,
                                   const ImVec4& color,
                                   const ImVec4& glow_color) {
    if (!g_speed_graph_cache.valid ||
        g_speed_graph_cache.tex_w != tex_w ||
        g_speed_graph_cache.tex_h != tex_h ||
        g_speed_graph_cache.point_count != (int)render_points.size() ||
        std::fabs(g_speed_graph_cache.line_radius - line_radius) > 0.01f ||
        std::fabs(g_speed_graph_cache.glow_radius - glow_radius) > 0.01f ||
        std::fabs(g_speed_graph_cache.glow_sigma - glow_sigma) > 0.01f ||
        std::fabs(g_speed_graph_cache.color.x - color.x) > 0.001f ||
        std::fabs(g_speed_graph_cache.color.y - color.y) > 0.001f ||
        std::fabs(g_speed_graph_cache.color.z - color.z) > 0.001f ||
        std::fabs(g_speed_graph_cache.color.w - color.w) > 0.001f ||
        std::fabs(g_speed_graph_cache.glow_color.x - glow_color.x) > 0.001f ||
        std::fabs(g_speed_graph_cache.glow_color.y - glow_color.y) > 0.001f ||
        std::fabs(g_speed_graph_cache.glow_color.z - glow_color.z) > 0.001f ||
        std::fabs(g_speed_graph_cache.glow_color.w - glow_color.w) > 0.001f) {
        return false;
    }

    for (int i = 0; i < g_speed_graph_cache.point_count; ++i) {
        if (std::fabs(g_speed_graph_cache.points[(size_t)i].x - render_points[(size_t)i].x) > 0.1f ||
            std::fabs(g_speed_graph_cache.points[(size_t)i].y - render_points[(size_t)i].y) > 0.1f) {
            return false;
        }
    }
    return true;
}

static void UpdateSpeedGraphCache(const std::vector<ImVec2>& render_points,
                                  int tex_w,
                                  int tex_h,
                                  float line_radius,
                                  float glow_radius,
                                  float glow_sigma,
                                  const ImVec4& color,
                                  const ImVec4& glow_color) {
    g_speed_graph_cache.valid = true;
    g_speed_graph_cache.tex_w = tex_w;
    g_speed_graph_cache.tex_h = tex_h;
    g_speed_graph_cache.point_count = (int)render_points.size();
    g_speed_graph_cache.line_radius = line_radius;
    g_speed_graph_cache.glow_radius = glow_radius;
    g_speed_graph_cache.glow_sigma = glow_sigma;
    g_speed_graph_cache.color = color;
    g_speed_graph_cache.glow_color = glow_color;
    for (int i = 0; i < g_speed_graph_cache.point_count; ++i) {
        g_speed_graph_cache.points[(size_t)i] = render_points[(size_t)i];
    }
}
} // namespace

static ImVec4 ResolveAccentAtScreenY(Theme* theme, float y_screen) {
    if (!theme) {
        return ImVec4(0.137f, 0.561f, 0.886f, 1.0f);
    }
    ImVec4 start, end;
    theme->GetResolvedAccentGradient(start, end);
    const bool is_gradient = (theme->GetAccentMode() != Theme::AccentMode::Accent);
    if (!is_gradient || theme->GetAccentGradientDirection() == Theme::AccentGradientDirection::Horizontal) {
        return ImVec4(
            start.x + (end.x - start.x) * 0.5f,
            start.y + (end.y - start.y) * 0.5f,
            start.z + (end.z - start.z) * 0.5f,
            1.0f
        );
    }
    const float h = std::max(1.0f, (float)((glHeight > 0) ? glHeight : 1080));
    const float t = std::clamp(y_screen / h, 0.0f, 1.0f);
    return ImVec4(
        start.x + (end.x - start.x) * t,
        start.y + (end.y - start.y) * t,
        start.z + (end.z - start.z) * t,
        1.0f
    );
}

static float AnimatedAccentBlend(Theme* theme, float axis_px, float axis_extent_px, bool horizontal) {
    if (!theme || !theme->GetAnimatedAccentEnabled() || theme->GetAccentMode() == Theme::AccentMode::Accent) {
        return 0.5f;
    }
    const float dim = std::max(1.0f, horizontal
        ? (float)((glWidth > 0) ? glWidth : 1920)
        : (float)((glHeight > 0) ? glHeight : 1080));
    const float spacing = std::max(8.0f, dim * theme->GetAnimatedAccentColorSpacing());
    const float phase = axis_px / spacing;
    const float t = (float)ImGui::GetTime() * theme->GetAnimatedAccentSpeed();
    const float tri = std::fabs(std::fmod(phase + t, 2.0f) - 1.0f);
    const float sine = 0.5f + 0.5f * std::sinf((phase + t) * IM_PI * 2.0f);
    return std::clamp((tri * (1.0f - theme->GetAnimatedAccentSmoothness())) + (sine * theme->GetAnimatedAccentSmoothness()), 0.0f, 1.0f);
}

static ImVec4 ResolveAnimatedStripeTint(Theme* theme, float axis_px, float axis_extent_px, bool horizontal, float alpha) {
    ImVec4 start, end;
    if (!theme) {
        return ImVec4(0.294f, 0.412f, 0.996f, alpha);
    }
    theme->GetResolvedAccentGradient(start, end);
    const float base_t = horizontal ? 0.5f : std::clamp(axis_px / std::max(1.0f, (float)((glHeight > 0) ? glHeight : 1080)), 0.0f, 1.0f);
    ImVec4 y_link(
        start.x + (end.x - start.x) * base_t,
        start.y + (end.y - start.y) * base_t,
        start.z + (end.z - start.z) * base_t,
        1.0f
    );
    if (!theme->GetAnimatedAccentEnabled() || theme->GetAccentMode() == Theme::AccentMode::Accent) {
        y_link.w = alpha;
        return y_link;
    }
    const float band_t = AnimatedAccentBlend(theme, axis_px, axis_extent_px, horizontal);
    ImVec4 band(
        start.x + (end.x - start.x) * band_t,
        start.y + (end.y - start.y) * band_t,
        start.z + (end.z - start.z) * band_t,
        1.0f
    );
    const float strength = std::clamp(theme->GetAnimatedAccentStrength(), 0.0f, 1.5f);
    ImVec4 out(
        y_link.x + (band.x - y_link.x) * strength,
        y_link.y + (band.y - y_link.y) * strength,
        y_link.z + (band.z - y_link.z) * strength,
        alpha
    );
    return out;
}

static int AnimatedAccentSegments(Theme* theme, float extent_px, bool horizontal) {
    if (!theme || !theme->GetAnimatedAccentEnabled() || theme->GetAccentMode() == Theme::AccentMode::Accent) {
        return 1;
    }
    const float dim = std::max(1.0f, horizontal
        ? (float)((glWidth > 0) ? glWidth : 1920)
        : (float)((glHeight > 0) ? glHeight : 1080));
    const float spacing = std::max(8.0f, dim * theme->GetAnimatedAccentColorSpacing());
    return std::clamp((int)std::ceil(extent_px / std::max(8.0f, spacing * 0.33f)), 12, 48);
}

static std::string AnimatedTag(const char* target, float period, float phase_shift) {
    if (!target || !*target) {
        return {};
    }

    auto smooth01 = [](float t) {
        t = std::clamp(t, 0.0f, 1.0f);
        return t * t * (3.0f - 2.0f * t);
    };

    float now = static_cast<float>(ImGui::GetTime());
    float cycle = std::max(0.5f, period);
    float phase = std::fmod(now + phase_shift, cycle) / cycle;

    // Softer + rarer loop: long calm hold, short cute dip, then gentle recover.
    float reveal = 1.0f;
    if (phase < 0.72f) {
        reveal = 1.0f;
    } else if (phase < 0.86f) {
        const float t = smooth01((phase - 0.72f) / 0.14f);
        reveal = 1.0f - t * 0.42f;
    } else {
        const float t = smooth01((phase - 0.86f) / 0.14f);
        reveal = 0.58f + t * 0.42f;
    }
    reveal = std::clamp(reveal, 0.58f, 1.0f);

    std::string target_str(target);
    std::string out = target_str;
    const int len = static_cast<int>(target_str.size());
    const int keep_prefix = (len > 0 && target_str[0] == '.') ? 1 : 0;
    for (int i = keep_prefix; i < len; ++i) {
        float threshold = static_cast<float>((i - keep_prefix) + 1) / static_cast<float>(std::max(1, len - keep_prefix));
        if (reveal < threshold) {
            out[(size_t)i] = '~';
        }
    }
    return out;
}

static int ReadMemAvailableMb() {
    std::ifstream in("/proc/meminfo");
    if (!in.is_open()) {
        return -1;
    }
    std::string key;
    int value_kb = 0;
    std::string unit;
    while (in >> key >> value_kb >> unit) {
        if (key == "MemAvailable:") {
            return value_kb / 1024;
        }
    }
    return -1;
}

[[maybe_unused]] static float ReadCpuLoadPercent() {
    static bool has_prev = false;
    static unsigned long long prev_total = 0;
    static unsigned long long prev_idle = 0;
    static float last_value = 0.0f;

    // Primary source: normalized 1-minute system load.
    {
        std::ifstream loadavg("/proc/loadavg");
        float one_min = 0.0f;
        if (loadavg.is_open() && (loadavg >> one_min)) {
            long cores = sysconf(_SC_NPROCESSORS_ONLN);
            if (cores <= 0) {
                cores = 1;
            }
            const float raw = std::clamp((one_min / (float)cores) * 100.0f, 0.0f, 100.0f);
            last_value += (raw - last_value) * 0.25f;
            return std::clamp(last_value, 0.0f, 100.0f);
        }
    }

    // Fallback source: /proc/stat delta busy time.
    std::ifstream in("/proc/stat");
    if (!in.is_open()) {
        return std::clamp(last_value, 0.0f, 100.0f);
    }
    std::string cpu;
    unsigned long long user = 0, nice = 0, system = 0, idle = 0, iowait = 0, irq = 0, softirq = 0, steal = 0;
    in >> cpu >> user >> nice >> system >> idle >> iowait >> irq >> softirq >> steal;
    if (cpu != "cpu") {
        return std::clamp(last_value, 0.0f, 100.0f);
    }
    const unsigned long long idle_all = idle + iowait;
    const unsigned long long total = user + nice + system + idle + iowait + irq + softirq + steal;
    if (!has_prev) {
        has_prev = true;
        prev_total = total;
        prev_idle = idle_all;
        return std::clamp(last_value, 0.0f, 100.0f);
    }
    const unsigned long long total_d = (total >= prev_total) ? (total - prev_total) : 0;
    const unsigned long long idle_d = (idle_all >= prev_idle) ? (idle_all - prev_idle) : 0;
    prev_total = total;
    prev_idle = idle_all;
    if (total_d == 0) {
        return std::clamp(last_value, 0.0f, 100.0f);
    }
    const float busy = 1.0f - (float)idle_d / (float)total_d;
    const float raw = std::clamp(busy * 100.0f, 0.0f, 100.0f);
    last_value += (raw - last_value) * 0.20f;
    return std::clamp(last_value, 0.0f, 100.0f);
}

static void GetTabListForContent(TabType tab, ModuleEntry*** outList, int* outCount) {
    switch (tab) {
        case TabType::Aimbot:
            *outList = vrt.features.aimbotList.data();
            *outCount = static_cast<int>(vrt.features.aimbotList.size());
            return;
        case TabType::Movement:
            *outList = vrt.features.movementList.data();
            *outCount = static_cast<int>(vrt.features.movementList.size());
            return;
        case TabType::Render:
            *outList = vrt.features.renderList.data();
            *outCount = static_cast<int>(vrt.features.renderList.size());
            return;
        case TabType::Misc:
            *outList = vrt.features.miscList.data();
            *outCount = static_cast<int>(vrt.features.miscList.size());
            return;
        case TabType::Config:
            *outList = vrt.features.configList.data();
            *outCount = static_cast<int>(vrt.features.configList.size());
            return;
        case TabType::HUD:
            *outList = vrt.features.hudList.data();
            *outCount = static_cast<int>(vrt.features.hudList.size());
            return;
        case TabType::CUI:
            *outList = vrt.features.cuiList.data();
            *outCount = static_cast<int>(vrt.features.cuiList.size());
            return;
        default:
            *outList = nullptr;
            *outCount = 0;
            return;
    }
}

static float GetTailGlyphHeight(const char* text, ImFont* font, float font_size) {
    if (!text || text[0] == '\0') {
        return std::max(1.0f, font_size);
    }
    const size_t len = std::strlen(text);
    if (len == 0u) {
        return std::max(1.0f, font_size);
    }
    const unsigned char c = static_cast<unsigned char>(text[len - 1]);
    float ratio = 0.78f;
    if (c >= 'a' && c <= 'z') {
        ratio = 0.72f;
    } else if (c >= 'A' && c <= 'Z') {
        ratio = 0.86f;
    } else if (c >= '0' && c <= '9') {
        ratio = 0.80f;
    }
    (void)font;
    return std::max(1.0f, font_size * ratio);
}

static float DrawModeIndicatorsRow(const char* id_scope,
                                   int* selected_index,
                                   const char* const* items,
                                   int items_count,
                                   Theme* theme,
                                   float ui_scale,
                                   float forced_avail_width = 0.0f,
                                   float* out_row_width = nullptr,
                                   float reference_text_height = 0.0f,
                                   float reference_title_font_size = 0.0f,
                                   bool render = true) {
    if (!selected_index || !items || items_count <= 0) {
        return 0.0f;
    }

    *selected_index = std::clamp(*selected_index, 0, items_count - 1);

    const float spacing = (theme ? theme->metrics.buttonSpacing : 10.0f) * std::max(0.85f, ui_scale);
    const float avail_width = std::max(1.0f, (forced_avail_width > 0.0f) ? forced_avail_width : ImGui::GetContentRegionAvail().x);
    const float text_pad_x = 16.0f * std::max(0.85f, ui_scale);
    const float min_button_width = 34.0f * std::max(0.85f, ui_scale);
    const float title_font_size = (reference_title_font_size > 0.0f) ? reference_title_font_size : ImGui::GetFontSize();
    const float indicator_font_size_base = std::max(1.0f, title_font_size * 0.76f);
    std::vector<float> button_widths(items_count, min_button_width);
    float total_buttons_width = 0.0f;
    float max_text_height = 0.0f;
    ImFont* draw_font = ImGui::GetFont();
    for (int i = 0; i < items_count; ++i) {
        const char* label = items[i] ? items[i] : "";
        const ImVec2 label_size = draw_font
            ? draw_font->CalcTextSizeA(indicator_font_size_base, FLT_MAX, 0.0f, label)
            : ImGui::CalcTextSize(label);
        max_text_height = std::max(max_text_height, label_size.y);
        const float desired_width = std::max(min_button_width, label_size.x + text_pad_x * 2.0f);
        button_widths[i] = desired_width;
        total_buttons_width += desired_width;
    }
    const float total_spacing = spacing * (items_count - 1);
    const float total_required = total_buttons_width + total_spacing;
    if (total_required > avail_width && total_buttons_width > 1.0f) {
        const float scaled_buttons_width = std::max(1.0f, avail_width - total_spacing);
        const float width_scale = std::clamp(scaled_buttons_width / total_buttons_width, 0.35f, 1.0f);
        total_buttons_width = 0.0f;
        for (int i = 0; i < items_count; ++i) {
            button_widths[i] = std::max(1.0f, button_widths[i] * width_scale);
            total_buttons_width += button_widths[i];
        }
    }
    if (out_row_width) {
        *out_row_width = total_buttons_width + total_spacing;
    }
    const float button_height = std::max(ImGui::GetFrameHeight() * 1.20f, max_text_height + ImGui::GetStyle().FramePadding.y * 2.0f);
    const float rounding = ImGui::GetStyle().FrameRounding;
    const ImVec4 base_text_col = ImGui::GetStyle().Colors[ImGuiCol_Text];
    const ImVec4 dark_text_col = ImVec4(0.08f, 0.08f, 0.08f, base_text_col.w);

    const ImVec2 row_start_screen = ImGui::GetCursorScreenPos();
    const ImVec2 row_start_local = ImGui::GetCursorPos();
    if (!render) {
        return button_height;
    }

    ImDrawList* draw_list = ImGui::GetWindowDrawList();
    float current_x = row_start_screen.x;
    ImGui::PushID(id_scope ? id_scope : "mode_indicators");
    for (int i = 0; i < items_count; ++i) {
        ImGui::SetCursorScreenPos(ImVec2(current_x, row_start_screen.y));
        const float button_width = button_widths[i];
        ImGui::PushID(i);
        const bool clicked = ImGui::InvisibleButton("##mode_btn", ImVec2(button_width, button_height));
        const ImVec2 bmin = ImGui::GetItemRectMin();
        const ImVec2 bmax = ImGui::GetItemRectMax();
        const bool hovered = ImGui::IsItemHovered();
        const bool selected = (*selected_index == i);

        const float dt = ImGui::GetIO().DeltaTime;
        const float selected_t = iam_tween_float(ImGui::GetID("mode_btn_anim"), ImGui::GetID("selected"),
                                                 selected ? 1.0f : 0.0f, 0.26f,
                                                 iam_ease_preset(iam_ease_out_cubic), iam_policy_crossfade, dt);
        const float hover_t = iam_tween_float(ImGui::GetID("mode_btn_anim"), ImGui::GetID("hovered"),
                                              hovered ? 1.0f : 0.0f, 0.18f,
                                              iam_ease_preset(iam_ease_out_cubic), iam_policy_crossfade, dt);

        const ImVec4 track_col = WidgetBase::TrackColor(theme);
        const ImVec4 accent_col = WidgetBase::PrimaryMidColor(theme);
        ImVec4 fill = ImVec4(
            track_col.x + (accent_col.x - track_col.x) * selected_t,
            track_col.y + (accent_col.y - track_col.y) * selected_t,
            track_col.z + (accent_col.z - track_col.z) * selected_t,
            track_col.w + (accent_col.w - track_col.w) * selected_t
        );
        fill.w = std::clamp(fill.w * (1.0f + hover_t * 0.08f), 0.0f, 1.0f);
        draw_list->AddRectFilled(bmin, bmax, ImGui::GetColorU32(fill), rounding);

        const char* label = items[i] ? items[i] : "";
        const ImVec2 text_size = draw_font
            ? draw_font->CalcTextSizeA(indicator_font_size_base, FLT_MAX, 0.0f, label)
            : ImGui::CalcTextSize(label);
        const float max_text_width = std::max(1.0f, button_width - text_pad_x * 2.0f);
        const float text_scale = (text_size.x > max_text_width)
            ? std::clamp(max_text_width / std::max(1.0f, text_size.x), 0.56f, 1.0f)
            : 1.0f;
        const float select_text_scale = 0.96f + selected_t * 0.04f;
        const float font_size = indicator_font_size_base * text_scale * select_text_scale;
        const float text_offset_y = GetGlyphOffsetY(ImGui::GetFont(), font_size);
        const ImVec2 text_pos = ImVec2(
            bmin.x + (button_width - text_size.x * text_scale) * 0.5f,
            bmin.y + (button_height - font_size) * 0.5f - text_offset_y
        );
        ImVec4 draw_text_col = base_text_col;
        const float lum = fill.x * 0.299f + fill.y * 0.587f + fill.z * 0.114f;
        if (selected && ((theme && theme->IsLightMode()) || lum > 0.58f)) {
            draw_text_col = dark_text_col;
        }
        draw_list->AddText(ImGui::GetFont(), font_size, text_pos, ImGui::GetColorU32(draw_text_col), label);

        if (clicked) {
            *selected_index = i;
        }
        ImGui::PopID();
        current_x += button_width + spacing;
    }
    ImGui::PopID();
    ImGui::SetCursorPos(row_start_local);
    return button_height;
}

static void DrawModeIndicators(const char* id_scope,
                               int* selected_index,
                               const char* const* items,
                               int items_count,
                               Theme* theme,
                               float ui_scale,
                               float forced_avail_width = 0.0f) {
    const float row_h = DrawModeIndicatorsRow(
        id_scope, selected_index, items, items_count, theme, ui_scale, forced_avail_width
    );
    if (row_h <= 0.0f) {
        return;
    }
    const float gap = 6.0f * std::max(0.85f, ui_scale);
    ImGui::Dummy(ImVec2(0.0f, row_h + gap));
}

void RenderContent(TabType tabType, WidgetManager* widgets, LayoutManager* layouts, const ClickGUI::Settings* settings, int windowWidth, int windowHeight, bool drawHeader, bool drawBody, float forcedAvailWidth)
{
    const int tab_idx = static_cast<int>(tabType);
    const bool tab_idx_valid = (tab_idx >= 0) && (tab_idx < static_cast<int>(sizeof(vrt.features.activeByTab) / sizeof(vrt.features.activeByTab[0])));
    const float left_pad = 0.0f;
    (void)layouts;
    const float forced_avail_width = std::max(0.0f, forcedAvailWidth);
    float header_content_start_x = 0.0f;
    auto with_left_pad = [left_pad](auto&& draw_fn) {
        if (left_pad > 0.0f) {
            ImGui::Indent(left_pad);
        }
        draw_fn();
        if (left_pad > 0.0f) {
            ImGui::Unindent(left_pad);
        }
    };

    auto showSelectMessage = [&with_left_pad]() {
        with_left_pad([]() {
            ImGui::TextUnformatted(vrt.text.messages[0]);
        });
    };

    auto drawSettingsHeader = [&with_left_pad, forced_avail_width, &header_content_start_x]
        (const char* label, const char* description, const ClickGUI::Settings* ctx_settings, bool with_mode_indicators) {
        with_left_pad([label, description, ctx_settings, forced_avail_width, &header_content_start_x, with_mode_indicators]() {
            auto* theme = (ctx_settings && ctx_settings->gui) ? ctx_settings->gui->theme.get() : nullptr;
            ImFont* header_font = ImGui::GetFont();
            const float ui_scale = (ctx_settings && ctx_settings->gui) ? ctx_settings->gui->cache.uiScale : GetScale();
            const float header_left_pad = 0.0f * std::max(0.85f, ui_scale);
            const float header_content_gap = 1.0f * std::max(0.85f, ui_scale);

            const char* safe_label = (label && label[0] != '\0') ? label : "Settings";
            const char* safe_desc = (description && description[0] != '\0') ? description : "";

            const float header_font_size = ImGui::GetFontSize() * 1.10f;
            const float header_start_local_x = ImGui::GetCursorPosX() + header_left_pad;
            header_content_start_x = header_start_local_x;
            ImGui::SetCursorPosX(header_start_local_x);
            ImVec2 header_row_start = ImGui::GetCursorScreenPos();
            const float header_start_screen_x = header_row_start.x;
            const ImVec2 header_text_size = header_font
                ? header_font->CalcTextSizeA(header_font_size, FLT_MAX, 0.0f, safe_label)
                : ImGui::CalcTextSize(safe_label);
            float header_row_h = header_text_size.y;
            float title_x = header_start_screen_x;
            const float title_glyph_off = GetGlyphOffsetY(header_font, header_font_size);
            (void)with_mode_indicators;

            const float header_center_y = header_row_start.y + header_row_h * 0.5f;
            ImVec2 header_pos = ImVec2(
                title_x,
                header_center_y - header_text_size.y * 0.5f - title_glyph_off
            );
            ImGui::GetWindowDrawList()->AddText(
                header_font,
                header_font_size,
                header_pos,
                ImGui::GetColorU32(ImGui::GetStyle().Colors[ImGuiCol_Text]),
                safe_label
            );

            ImGui::SetCursorScreenPos(ImVec2(header_start_screen_x, header_row_start.y + header_row_h));
            ImGui::Dummy(ImVec2(0.0f, header_content_gap));

            if (safe_desc[0] != '\0') {
                ImVec4 desc_col = WidgetBase::DescriptionColor(theme);
                ImGui::PushStyleColor(ImGuiCol_Text, desc_col);
                ImGuiStyle& style = ImGui::GetStyle();
                float desc_font_size = style.FontSizeBase * 0.90f;
                const float desc_start_x = header_start_local_x;
                ImGui::SetCursorPosX(desc_start_x);
                ImGui::PushFont(nullptr, desc_font_size);
                const float wrap_width = (forced_avail_width > 0.0f)
                    ? std::max(1.0f, forced_avail_width - header_left_pad)
                    : ImGui::GetContentRegionAvail().x;
                ImGui::PushTextWrapPos(desc_start_x + wrap_width);
                ImGui::TextUnformatted(safe_desc);
                ImGui::PopTextWrapPos();
                ImGui::SetCursorPosY(ImGui::GetCursorPosY() - ImGui::GetStyle().ItemSpacing.y);
                ImGui::PopFont();
                ImGui::PopStyleColor();
                ImGui::Dummy(ImVec2(0.0f, header_content_gap));
            }

        });
    };

    auto renderSelectedSettings = [&](ModuleEntry* fn) {
        if (!fn || fn->renderSettings == nullptr) {
            if (drawBody) {
                showSelectMessage();
            }
            return;
        }

        if (drawHeader) {
            drawSettingsHeader(fn->name.c_str(), fn->description.c_str(), settings, fn == &vrt.features.aimbot.module);
        }

        if (drawBody) {
            with_left_pad([&]() {
                if (widgets) {
                    widgets->PushScope(fn->name);
                }
                fn->renderSettings(widgets, settings, windowWidth, windowHeight);
                if (widgets) {
                    widgets->PopScope();
                }
            });
        }
    };

    ModuleEntry** list = nullptr;
    int count = 0;
    GetTabListForContent(tabType, &list, &count);
    if (!list || count <= 0) {
        if (drawBody) {
            showSelectMessage();
        }
        return;
    }

    const int activeId = tab_idx_valid ? vrt.features.activeByTab[tab_idx] : -1;
    if (activeId >= 0 && activeId < count) {
        renderSelectedSettings(list[activeId]);
    } else {
        showSelectMessage();
    }
}

static void ModuleAdd(ModuleEntry* entry,
                      int index,
                      Theme* theme,
                      int* activeId,
                      const char* indicator = nullptr) {
    if (!entry) {
        return;
    }

    Module widget(
        entry->name.c_str(),
        entry->description.c_str(),
        indicator,
        &entry->enabled,
        &entry->bound,
        entry->showActiveToggle,
        activeId,
        index,
        &entry->renderSettings,
        nullptr,
        theme
    );
    widget();
}

void RenderModule(TabType tabType, Theme* theme)
{
    auto& f = vrt.features;
    int& activeId = f.activeByTab[static_cast<int>(tabType)];

    switch (tabType) {
        case TabType::Aimbot:
        {
            ModuleAdd(&f.aimbot.module, 0, theme, &activeId);
            return;
        }
        case TabType::Movement:
            ModuleAdd(&f.movement.recorder, 0, theme, &activeId);
            ModuleAdd(&f.movement.noClip, 1, theme, &activeId);
            ModuleAdd(&f.movement.flyHack, 2, theme, &activeId);
            return;
        case TabType::Render:
            post_processing.color_grading.enabled = f.render.colorGrading.enabled;
            ModuleAdd(&f.render.esp, 0, theme, &activeId);
            ModuleAdd(&f.render.colorGrading, 1, theme, &activeId);
            return;
        case TabType::Misc:
            ModuleAdd(&f.misc.radar, 0, theme, &activeId);
            ModuleAdd(&f.misc.recoil, 1, theme, &activeId);
            ModuleAdd(&f.misc.noFlash, 2, theme, &activeId);
            ModuleAdd(&f.misc.autoPistol, 3, theme, &activeId);
            ModuleAdd(&f.misc.fastReload, 4, theme, &activeId);
            ModuleAdd(&f.misc.audio, 5, theme, &activeId);
            return;
        case TabType::Config:
            ModuleAdd(&f.config.module, 0, theme, &activeId);
            return;
        case TabType::HUD:
            ModuleAdd(&f.hud.watermark, 0, theme, &activeId);
            ModuleAdd(&f.hud.speedGraph, 1, theme, &activeId);
            return;
        case TabType::CUI:
            ModuleAdd(&f.cui.clickgui, 0, theme, &activeId);
            ModuleAdd(&f.cui.appearance, 1, theme, &activeId);
            ModuleAdd(&f.cui.animation, 2, theme, &activeId);
            ModuleAdd(&f.cui.devTools, 3, theme, &activeId);
            return;
        default:
            ImGui::TextUnformatted(vrt.text.messages[1]);
            return;
    }
}

struct LogoVisibleAreaRatios {
    float x_min = 0.311367f;
    float y_min = 0.282258f;
    float x_max = 0.663097f;
    float y_max = 0.740783f;
};

SidebarFrame BuildSidebarFrame(const ClickGUI::Settings* settings) {
    SidebarFrame frame;
    frame.settings = settings;
    frame.draw_list = ImGui::GetWindowDrawList();
    frame.window_pos = ImGui::GetWindowPos();
    frame.window_size = ImGui::GetWindowSize();
    frame.content_cursor_pos = ImGui::GetCursorPos();
    frame.ui_scale = GetScale();
    frame.sidebar_width = frame.window_size.x;
    return frame;
}

void RenderLogo(const ClickGUI::Settings* settings) {
    (void)settings;
}

void RenderSidebar(WidgetManager* widgets, int& selectedTab, const ClickGUI::Settings* settings) {
    (void)widgets;
    const float ui_scale = (settings && settings->gui) ? settings->gui->cache.uiScale : GetScale();
    auto* theme = (settings && settings->gui) ? settings->gui->theme.get() : nullptr;
    ImDrawList* draw_list = ImGui::GetWindowDrawList();
    const ImVec2 sidebar_column_cursor = ImGui::GetCursorScreenPos();
    const float sidebar_column_width = std::max(1.0f, ImGui::GetContentRegionAvail().x);

    if (images.Ready() && settings && settings->gui) {
        float sidebar_width = sidebar_column_width;
        const float sidebar_content_left = sidebar_column_cursor.x;
        const float sidebar_content_width = std::max(1.0f, sidebar_width);
        const float logo_w = settings->gui->cache.logoWidth;
        const float logo_h = settings->gui->cache.logoHeight;
        const float logo_offset_y = settings->gui->cache.logoOffsetY;
        const float logo_text_scale = 1.48f;
        ImVec2 logo_layout_size = ImVec2(logo_w, logo_h);
        const float logo_render_scale = 1.48f;
        ImVec2 logo_draw_size = ImVec2(
            logo_layout_size.x * logo_render_scale,
            logo_layout_size.y * logo_render_scale
        );
        const LogoVisibleAreaRatios logo_vis{};
        const float logo_to_text_gap = 1.0f * ui_scale;
        static constexpr std::array<const char*, 3> kLogoTags = {".hvh", ".legit", ".meow"};
        ImFont* logo_tag_font = theme ? theme->Get(ClickGUI::Theme::FontId::Montserrat) : ImGui::GetFont();
        const float logo_tag_font_size_layout = ImGui::GetFontSize() * 1.26f * logo_text_scale;
        float tag_box_w_layout = 0.0f;
        for (const char* line : kLogoTags) {
            tag_box_w_layout = std::max(tag_box_w_layout, logo_tag_font->CalcTextSizeA(logo_tag_font_size_layout, FLT_MAX, 0.0f, line).x);
        }
        const float vis_left_offset_from_logo = (-(logo_draw_size.x - logo_layout_size.x) * 0.5f) + (logo_draw_size.x * logo_vis.x_min);
        const float visible_logo_w = (logo_draw_size.x * (logo_vis.x_max - logo_vis.x_min));
        const float object_w = visible_logo_w + logo_to_text_gap + tag_box_w_layout;
        const float object_left = sidebar_content_left + std::round((sidebar_content_width - object_w) * 0.5f);
        float logo_group_shift_left = 0.0f;
        float logo_group_shift_down = 1.2f * ui_scale;
        const float logo_visible_left = object_left;
        const float text_block_left = object_left + visible_logo_w + logo_to_text_gap;
        float logo_x = logo_visible_left - vis_left_offset_from_logo - logo_group_shift_left;
        ImVec2 cursor_screen = ImGui::GetCursorScreenPos();
        ImGui::SetCursorScreenPos(ImVec2(logo_x, cursor_screen.y));

        ImGui::SetCursorPosY(ImGui::GetCursorPosY() + logo_offset_y + logo_group_shift_down);

        ImVec2 cursor_pos = ImGui::GetCursorScreenPos();
        ImVec2 p_min(
            cursor_pos.x - (logo_draw_size.x - logo_layout_size.x) * 0.5f,
            cursor_pos.y - (logo_draw_size.y - logo_layout_size.y) * 0.5f
        );
        ImVec2 p_max(p_min.x + logo_draw_size.x, p_min.y + logo_draw_size.y);

        const float logo_group_center_y = (p_min.y + p_max.y) * 0.5f;
        ImVec4 logo_color = ResolveAccentAtScreenY(theme, logo_group_center_y);
        if (!post_processing.flags.blur) {
            logo_color.w *= 0.9f;
        }

        if (post_processing.flags.glow) {
            ImVec4 glow_color = logo_color;
            glow_color.w = 0.25f / 0.35f;
            draw_list->PushClipRectFullScreen();
            post_processing.DrawGlowTexture(draw_list, "yorozka", p_min, p_max, glow_color, 0.78f);
            draw_list->PopClipRect();
        }

        ImageRegion uv = settings->gui->assets.yorozka.uv;
        GLuint texture_id = settings->gui->assets.yorozka.tex;
        draw_list->AddImage((void*)(intptr_t)texture_id, p_min, p_max,
                            ImVec2(uv.u_min, uv.v_min), ImVec2(uv.u_max, uv.v_max),
                            ImGui::GetColorU32(logo_color));

        const float vis_top = p_min.y + logo_draw_size.y * logo_vis.y_min;
        const float vis_bottom = p_min.y + logo_draw_size.y * logo_vis.y_max;
        const float vis_h = std::max(1.0f, vis_bottom - vis_top);
        float logo_tag_font_size = ImGui::GetFontSize() * 1.26f * logo_text_scale;
        float tag_box_h = logo_tag_font->CalcTextSizeA(logo_tag_font_size, FLT_MAX, 0.0f, kLogoTags[0]).y;
        if (tag_box_h * 3.0f > vis_h) {
            logo_tag_font_size *= (vis_h / std::max(1.0f, tag_box_h * 3.0f));
            tag_box_h = logo_tag_font->CalcTextSizeA(logo_tag_font_size, FLT_MAX, 0.0f, kLogoTags[0]).y;
        }
        float tag_box_w = 0.0f;
        for (const char* line : kLogoTags) {
            tag_box_w = std::max(tag_box_w, logo_tag_font->CalcTextSizeA(logo_tag_font_size, FLT_MAX, 0.0f, line).x);
        }
        float tag_line_gap = (vis_h - tag_box_h * 3.0f) / 2.0f;
        tag_line_gap = std::clamp(tag_line_gap, 0.5f * ui_scale, 2.0f * ui_scale);
        const float tags_block_h = tag_box_h * 3.0f + tag_line_gap * 2.0f;
        const float tag_box_left = text_block_left;
        const float tag_block_top = std::clamp(vis_bottom - tags_block_h, vis_top, vis_bottom - tag_box_h);
        const ImVec4 tag_text_col = ImVec4(logo_color.x, logo_color.y, logo_color.z, logo_color.w);

        auto draw_logo_text_glow = [&](const char* glow_name, const ImVec2& pos, const ImVec2& text_size) {
            if (!post_processing.flags.glow || !glow_name || !*glow_name) {
                return;
            }
            const float glow_scale = 2.05f;
            const float glow_visible_h = std::max(1.0f, text_size.y * glow_scale);
            const float glow_h = glow_visible_h;
            float glow_w = std::max(1.0f, text_size.x + glow_visible_h * 1.0f);
            glow_w = std::max(glow_w, text_size.x * 1.14f);
            const float glow_y_shift = 2.15f * ui_scale;
            const ImVec2 glow_min(pos.x - (glow_w - text_size.x) * 0.5f,
                                  pos.y - (glow_h - text_size.y) * 0.5f + glow_y_shift);
            const ImVec2 glow_max(glow_min.x + glow_w, glow_min.y + glow_h);

            draw_list->PushClipRectFullScreen();
            post_processing.DrawGlowTexture(
                draw_list,
                glow_name,
                glow_min,
                glow_max,
                ImVec4(tag_text_col.x, tag_text_col.y, tag_text_col.z, 0.18f / 0.35f),
                1.0f
            );
            draw_list->PopClipRect();
        };

        auto draw_tag_row = [&](int row) {
            std::string anim = AnimatedTag(kLogoTags[(size_t)row], 5.80f, 0.95f * (float)row);
            const char* line = anim.empty() ? kLogoTags[(size_t)row] : anim.c_str();
            ImVec2 sz = logo_tag_font->CalcTextSizeA(logo_tag_font_size, FLT_MAX, 0.0f, line);
            float row_y = tag_block_top + row * (tag_box_h + tag_line_gap);
            const float t = (float)ImGui::GetTime();
            const float bob = std::sinf(t * 1.35f + (float)row * 0.8f) * (0.8f * ui_scale);
            ImVec2 pos = ImVec2(tag_box_left + (tag_box_w - sz.x), row_y + (tag_box_h - sz.y) + bob);
            const char* glow_name = (row == 1) ? "text_yor_glow" : "text_project_glow";
            draw_logo_text_glow(glow_name, pos, sz);
            draw_list->AddText(logo_tag_font, logo_tag_font_size, pos,
                               ImGui::GetColorU32(tag_text_col), line);
        };

        draw_tag_row(0);
        draw_tag_row(1);
        draw_tag_row(2);

        float logo_dummy_h = std::max(1.0f, logo_layout_size.y + logo_offset_y);
        ImGui::Dummy(ImVec2(logo_layout_size.x, logo_dummy_h));
    }

    for (int tab_idx = 0; tab_idx < TabsCount(); ++tab_idx) {
        Tabs(selectedTab, tab_idx, settings);
    }
    const float tabs_offset_y = ImGui::GetStyle().ItemSpacing.y;
    ImGui::Dummy(ImVec2(0.0f, tabs_offset_y));

    SidebarFrame frame = BuildSidebarFrame(settings);
    const float sidebar_inner_pad_x = std::max(0.0f, ImGui::GetStyle().WindowPadding.x);
    frame.sidebar_width = sidebar_column_width;
    frame.window_pos.x = sidebar_column_cursor.x - sidebar_inner_pad_x;
    if (settings && settings->gui) {
        auto& user = settings->gui->userInfo;
        auto& assets = settings->gui->assets;
        RenderUserInfo(frame, selectedTab, user.userName.c_str(), user.userRank.c_str(),
                       assets.user, assets.cui);
        RenderTasksTab(frame);
    }
}

struct TasksBarLayout {
    ImVec2 pos = ImVec2(0.0f, 0.0f);
    ImVec2 size = ImVec2(0.0f, 0.0f);
    float bottom_pad = 18.0f;
    float gap_to_user = 10.0f;
};

static TasksBarLayout BuildTasksBarLayout(const SidebarFrame& frame) {
    TasksBarLayout l;
    const float sidebar_content_left = frame.window_pos.x;
    const float sidebar_content_width = std::max(1.0f, frame.sidebar_width);
    const float pad_x = 22.0f * frame.ui_scale;
    l.bottom_pad = 22.0f * frame.ui_scale;
    l.gap_to_user = 12.0f * frame.ui_scale;
    l.size = ImVec2(
        std::max(1.0f, sidebar_content_width - (pad_x * 2.0f)),
        45.0f * frame.ui_scale
    );
    l.pos = ImVec2(
        sidebar_content_left + pad_x,
        frame.window_pos.y + frame.window_size.y - l.bottom_pad - l.size.y
    );
    return l;
}

void RenderTasksTab(const SidebarFrame& frame) {
    const ClickGUI::Settings* settings = frame.settings;
    auto* theme = (settings && settings->gui) ? settings->gui->theme.get() : nullptr;
    ImDrawList* draw_list = frame.draw_list;
    if (!draw_list) {
        return;
    }
    TasksBarLayout tasks_layout = BuildTasksBarLayout(frame);
    const ImVec2 card_size = tasks_layout.size;
    const ImVec2 card_pos = tasks_layout.pos;
    const ImVec2 card_min = card_pos;
    const ImVec2 card_max = ImVec2(card_pos.x + card_size.x, card_pos.y + card_size.y);

    // Фон таскбара как у неактивных табов
    ImVec4 card_bg;
    if (post_processing.flags.blur) {
        if (theme && theme->IsLightMode()) {
            card_bg = theme->HexToImVec4(theme->material.onSurfaceVariant);
            card_bg.w = 0.12f;
        } else {
            card_bg = ImVec4(1.0f, 1.0f, 1.0f, 0.050f);
        }
    } else if (theme) {
        const ImU32 main_col = GetTabMainAreaColor();
        card_bg = (main_col != 0)
            ? ImGui::ColorConvertU32ToFloat4(main_col)
            : theme->HexToImVec4(theme->material.surfaceVariant);
    } else {
        card_bg = ImVec4(0.110f, 0.110f, 0.110f, 1.0f);
    }
    const float corner_radius = std::max(0.0f, ImGui::GetStyle().FrameRounding);
    draw_list->AddRectFilled(card_min, card_max, ImGui::GetColorU32(card_bg), corner_radius, ImDrawFlags_RoundCornersAll);

    const float border_half = 0.0f;

    ImFont* text_font = theme ? theme->Get(ClickGUI::Theme::FontId::Montserrat) : nullptr;
    if (!text_font) {
        text_font = ImGui::GetFont();
    }
    ImFont* icon_font = theme ? theme->Get(ClickGUI::Theme::FontId::Awesome) : nullptr;
    if (!icon_font) {
        icon_font = text_font;
    }

    const float text_size_px = text_font->LegacySize * 0.74f * frame.ui_scale;
    const float count_size_px = text_size_px * 1.18f;
    const float icon_size_px = text_size_px * 0.92f;
    const float inner_pad_x = 12.0f * frame.ui_scale;
    const float icon_gap = 8.0f * frame.ui_scale;
    const float counter_pad_r = 12.0f * frame.ui_scale;
    const ImVec2 content_min = ImVec2(card_pos.x + border_half, card_pos.y + border_half);
    const ImVec2 content_max = ImVec2(card_pos.x + card_size.x - border_half, card_pos.y + card_size.y - border_half);
    const float content_h = std::max(1.0f, content_max.y - content_min.y);
    const char* task_icon = "\xef\x82\xae"; // fa-tasks
    const char* task_text = "Заданий";
    const int active_tasks = 0;
    char task_count_buf[16];
    std::snprintf(task_count_buf, sizeof(task_count_buf), "%d", std::max(0, active_tasks));
    const char* task_count = task_count_buf;
    const ImVec2 icon_sz = icon_font->CalcTextSizeA(icon_size_px, FLT_MAX, 0.0f, task_icon);
    const ImVec2 txt_sz = text_font->CalcTextSizeA(text_size_px, FLT_MAX, 0.0f, task_text);
    const ImVec2 cnt_sz = text_font->CalcTextSizeA(count_size_px, FLT_MAX, 0.0f, task_count);

    ImVec4 inactive_text_col = ImGui::GetStyle().Colors[ImGuiCol_Text];
    inactive_text_col.w = 0.55f;
    if (theme && theme->IsLightMode()) {
        inactive_text_col = theme->HexToImVec4(theme->material.onSurfaceVariant);
        inactive_text_col.w = 0.88f;
    }
    ImVec4 label_col = inactive_text_col;
    if (active_tasks > 0) {
        label_col = ResolveAccentAtScreenY(theme, (card_min.y + card_max.y) * 0.5f);
        label_col.w = 0.90f;
    }
    const ImU32 label_col_u32 = ImGui::GetColorU32(label_col);
    const float y_icon = content_min.y + (content_h - icon_sz.y) * 0.5f - GetGlyphOffsetY(icon_font, icon_size_px);
    const float y_text = content_min.y + (content_h - txt_sz.y) * 0.5f - GetGlyphOffsetY(text_font, text_size_px);
    const float y_count = content_min.y + (content_h - cnt_sz.y) * 0.5f - GetGlyphOffsetY(text_font, count_size_px);
    // Счётчик слева, текст "Заданий" после счётчика, иконка справа
    const float x_count = content_min.x + inner_pad_x;
    const float x_text = x_count + cnt_sz.x + icon_gap;
    const float x_icon = content_max.x - counter_pad_r - icon_sz.x;

    ImVec4 accent_start = ResolveAccentAtScreenY(theme, card_min.y);
    ImVec4 accent_end = ResolveAccentAtScreenY(theme, card_max.y);
    accent_start.w = 1.0f;
    accent_end.w = 1.0f;
    const ImU32 accent_col_1 = ImGui::GetColorU32(accent_start);
    const ImU32 accent_col_2 = ImGui::GetColorU32(accent_end);

    const int icon_vtx_start = draw_list->VtxBuffer.Size;
    draw_list->AddText(icon_font, icon_size_px, ImVec2(x_icon, y_icon), IM_COL32_WHITE, task_icon);
    const int icon_vtx_end = draw_list->VtxBuffer.Size;
    if (icon_vtx_end > icon_vtx_start) {
        ImGui::ShadeVertsLinearColorGradientKeepAlpha(
            draw_list, icon_vtx_start, icon_vtx_end,
            ImVec2(x_icon, y_icon), ImVec2(x_icon + std::max(1.0f, icon_sz.x), y_icon),
            accent_col_1, accent_col_2
        );
    }
    draw_list->AddText(text_font, text_size_px, ImVec2(x_text, y_text), label_col_u32, task_text);
    const int count_vtx_start = draw_list->VtxBuffer.Size;
    draw_list->AddText(text_font, count_size_px, ImVec2(x_count, y_count), IM_COL32_WHITE, task_count);
    const int count_vtx_end = draw_list->VtxBuffer.Size;
    if (count_vtx_end > count_vtx_start) {
        ImGui::ShadeVertsLinearColorGradientKeepAlpha(
            draw_list, count_vtx_start, count_vtx_end,
            ImVec2(x_count, y_count), ImVec2(x_count + std::max(1.0f, cnt_sz.x), y_count),
            accent_col_1, accent_col_2
        );
    }

    ImGui::SetCursorPos(ImVec2(card_pos.x - frame.window_pos.x, card_pos.y - frame.window_pos.y));
    ImGui::InvisibleButton("##tasks_tab", card_size);
}

void RenderUserInfo(const SidebarFrame& frame,
                    int& selectedTab,
                    const char* userName,
                    const char* userRank,
                    const ClickGUI::Assets::Icon& user,
                    const ClickGUI::Assets::Icon& cui) {
    const ClickGUI::Settings* settings = frame.settings;
    auto* theme = (settings && settings->gui) ? settings->gui->theme.get() : nullptr;
    ImDrawList* draw_list = frame.draw_list;
    ImVec2 window_pos = frame.window_pos;
    ImVec2 window_size = frame.window_size;

    float user_info_padding_bottom = 22.0f * frame.ui_scale;
    float user_to_text_spacing = 15.0f * frame.ui_scale;
    float text_spacing = 1.0f * frame.ui_scale;

    ImVec2 user_icon_size = ImVec2(43.0f * frame.ui_scale, 43.0f * frame.ui_scale);
    ImVec2 cui_icon_size = ImVec2(49.0f * frame.ui_scale, 49.0f * frame.ui_scale);

    ImFont* user_font = theme ? theme->Get(ClickGUI::Theme::FontId::Montserrat) : nullptr;
    float username_font_size = user_font ? user_font->LegacySize * 0.64f * frame.ui_scale : ImGui::GetFontSize() * 0.64f * frame.ui_scale;
    float rank_font_size = user_font ? user_font->LegacySize * 0.58f * frame.ui_scale : ImGui::GetFontSize() * 0.58f * frame.ui_scale;

    float username_height = username_font_size;
    float rank_height = rank_font_size;
    float total_text_height = username_height + text_spacing + rank_height;

    const bool has_user = (user.tex != 0);
    ImageRegion hud_uv = images.RegionForName("hud");
    GLuint hud_tex = IsValidRegion(hud_uv) ? images.TextureForRegion(hud_uv) : 0;
    const bool has_cui = (hud_tex != 0);

    static float cui_diagonal_stretch_u = 0.8f;
    static float cui_diagonal_stretch_v = 1.0f;
    ImVec2 cui_icon_size_stretched = ImVec2(cui_icon_size.x * cui_diagonal_stretch_u, cui_icon_size.y * cui_diagonal_stretch_v);
    float max_element_height = std::max({total_text_height, user_icon_size.y, cui_icon_size_stretched.y});

    const TasksBarLayout tasks_layout = BuildTasksBarLayout(frame);
    const float user_bottom_pad = user_info_padding_bottom + tasks_layout.size.y + tasks_layout.gap_to_user;
    ImVec2 user_info_pos = ImVec2(window_pos.x,
                                  window_pos.y + window_size.y - max_element_height - user_bottom_pad);

    const float content_left = tasks_layout.pos.x;
    const float content_right = tasks_layout.pos.x + tasks_layout.size.x;
    float user_icon_x = content_left;

    float shared_center_y = user_info_pos.y + (max_element_height * 0.5f);
    ImVec2 user_icon_pos = ImVec2(user_icon_x, shared_center_y - (user_icon_size.y * 0.5f));
    float text_base_y = shared_center_y - (total_text_height * 0.5f);

    float text_start_x = user_icon_x + user_icon_size.x + user_to_text_spacing;
    float user_off_y = GetGlyphOffsetY(user_font ? user_font : ImGui::GetFont(), username_font_size);
    float rank_off_y = GetGlyphOffsetY(user_font ? user_font : ImGui::GetFont(), rank_font_size);
    ImVec2 username_pos = ImVec2(text_start_x, text_base_y - user_off_y);
    ImVec2 rank_pos = ImVec2(text_start_x, text_base_y + username_height + text_spacing - rank_off_y);

    float cui_icon_right = content_right;
    ImVec2 cui_icon_pos = ImVec2(cui_icon_right - cui_icon_size_stretched.x,
                                 shared_center_y - (cui_icon_size_stretched.y * 0.5f));

    if (has_user) {
        ImVec4 user_icon_color = ImVec4(1.0f, 1.0f, 1.0f, 1.0f);
        PostProcessing::UserIcon user_icon(
            user.tex,
            user_icon_pos,
            user_icon_size,
            ImVec2(user.uv.u_min, user.uv.v_min),
            ImVec2(user.uv.u_max, user.uv.v_max),
            user.uv.atlas,
            user_icon_color
        );
        post_processing.Apply(user_icon, draw_list);
    }

    ImVec4 rank_text_color = ImGui::GetStyle().Colors[ImGuiCol_Text];
    rank_text_color.w = 0.55f;
    if (theme && theme->IsLightMode()) {
        rank_text_color = theme->HexToImVec4(theme->material.onSurfaceVariant);
        rank_text_color.w = 0.88f;
    }
    float name_color1[3] = {0.90f, 0.90f, 0.90f};
    float name_color2[3] = {0.72f, 0.72f, 0.72f};
    if (has_user) {
        getTwoBrightestColorsFromRegion(
            user.uv.atlas,
            ImVec2(user.uv.u_min, user.uv.v_min),
            ImVec2(user.uv.u_max, user.uv.v_max),
            name_color1,
            name_color2
        );
    }

    const char* user_name = userName ? userName : "";
    const char* user_rank = userRank ? userRank : "";
    const ImU32 user_name_base_col = IM_COL32_WHITE;
    const int username_vtx_start = draw_list->VtxBuffer.Size;
    draw_list->AddText(user_font ? user_font : ImGui::GetFont(),
                       username_font_size,
                       username_pos, user_name_base_col, user_name);
    const int username_vtx_end = draw_list->VtxBuffer.Size;
    if (username_vtx_end > username_vtx_start && user_name[0] != '\0') {
        const ImU32 grad_col_1 = ImGui::GetColorU32(ImVec4(name_color1[0], name_color1[1], name_color1[2], 1.0f));
        const ImU32 grad_col_2 = ImGui::GetColorU32(ImVec4(name_color2[0], name_color2[1], name_color2[2], 1.0f));
        const ImVec2 text_size = ImGui::CalcTextSize(user_name);
        const ImVec2 grad_p0 = username_pos;
        const ImVec2 grad_p1 = ImVec2(username_pos.x + std::max(1.0f, text_size.x), username_pos.y);
        ImGui::ShadeVertsLinearColorGradientKeepAlpha(draw_list, username_vtx_start, username_vtx_end,
                                                      grad_p0, grad_p1, grad_col_1, grad_col_2);
    }
    draw_list->AddText(user_font ? user_font : ImGui::GetFont(),
                       rank_font_size,
                       rank_pos, ImGui::GetColorU32(rank_text_color), user_rank);

    float u_center = has_cui ? (hud_uv.u_min + hud_uv.u_max) * 0.5f : 0.0f;
    float v_center = has_cui ? (hud_uv.v_min + hud_uv.v_max) * 0.5f : 0.0f;
    float u_half_range = has_cui ? (hud_uv.u_max - hud_uv.u_min) * 0.5f * cui_diagonal_stretch_u : 0.0f;
    float v_half_range = has_cui ? (hud_uv.v_max - hud_uv.v_min) * 0.5f * cui_diagonal_stretch_v : 0.0f;

    ImVec2 cui_uv_min_stretched = ImVec2(u_center - u_half_range, v_center - v_half_range);
    ImVec2 cui_uv_max_stretched = ImVec2(u_center + u_half_range, v_center + v_half_range);

    if (has_cui) {
        bool isCuiSelected = (selectedTab == static_cast<int>(TabType::CUI));

        float dt = ImGui::GetIO().DeltaTime;
        if (dt <= 0.0f) dt = 1.0f / 60.0f;
        if (dt > 0.1f) dt = 0.1f;

        ImGuiID cuiIconId = ImGui::GetID("cui_icon");
        ImGuiID cuiAlphaChannelId = ImGui::GetID("cui_alpha");
        ImGuiID cuiScaleChannelId = ImGui::GetID("cui_scale");
        ImGuiID cuiPositionChannelId = ImGui::GetID("cui_position");
        ImGuiID cuiGlowChannelId = ImGui::GetID("cui_glow");

        float targetAlpha = isCuiSelected ? 1.0f : 0.3f;
        float currentAlpha = iam_tween_float(cuiIconId, cuiAlphaChannelId, targetAlpha, 0.6f,
            iam_ease_preset(iam_ease_out_elastic), iam_policy_crossfade, dt);

        float targetScale = isCuiSelected ? 1.15f : 1.0f;
        float currentScale = iam_tween_float(cuiIconId, cuiScaleChannelId, targetScale, 0.6f,
            iam_ease_preset(iam_ease_out_back), iam_policy_crossfade, dt);

        float targetPositionOffset = 0.0f;
        float currentPositionOffset = iam_tween_float(cuiIconId, cuiPositionChannelId, targetPositionOffset, 0.6f,
            iam_ease_preset(iam_ease_out_bounce), iam_policy_crossfade, dt);

        float targetGlowIntensity = post_processing.flags.glow ? (isCuiSelected ? 1.00f : 0.80f) : 0.0f;
        float currentGlowIntensity = iam_tween_float(cuiIconId, cuiGlowChannelId, targetGlowIntensity, 0.9f,
            iam_ease_preset(iam_ease_out_cubic), iam_policy_crossfade, dt);

        ImVec4 inactive_color = ImVec4(1.0f, 1.0f, 1.0f, 0.3f);
        if (theme && theme->IsLightMode()) {
            inactive_color = theme->HexToImVec4(theme->material.onSurfaceVariant);
            inactive_color.w = 0.88f;
        }
        ImVec2 scaledIconSize = ImVec2(cui_icon_size_stretched.x * currentScale, cui_icon_size_stretched.y * currentScale);
        ImVec2 scaledIconMin = ImVec2(
            cui_icon_pos.x + (cui_icon_size_stretched.x - scaledIconSize.x) * 0.5f,
            cui_icon_pos.y + (cui_icon_size_stretched.y - scaledIconSize.y) * 0.5f + currentPositionOffset
        );
        ImVec2 scaledIconMax = ImVec2(
            scaledIconMin.x + scaledIconSize.x,
            scaledIconMin.y + scaledIconSize.y
        );
        const float cui_center_y = (scaledIconMin.y + scaledIconMax.y) * 0.5f;
        ImVec4 active_color = ResolveAccentAtScreenY(theme, cui_center_y);
        active_color.w = 0.8f;
        float cui_t = ImClamp((currentAlpha - 0.3f) / (1.0f - 0.3f), 0.0f, 1.0f);
        ImVec4 icon_color = ImLerp(inactive_color, active_color, cui_t);
        ImU32 icon_u32 = ImGui::GetColorU32(icon_color);

        if (post_processing.flags.glow) {
            float iconGlowIntensity = std::max(0.0f, currentGlowIntensity);
            float glowAlphaScale = 1.0f;

            ImVec4 glowColorForEffect;
            if (theme) {
                ImVec4 themeGlowColor = isCuiSelected
                    ? ResolveAccentAtScreenY(theme, cui_center_y)
                    : theme->HexToImVec4(theme->material.onSurfaceVariant);
                glowColorForEffect = ImVec4(themeGlowColor.x, themeGlowColor.y, themeGlowColor.z, glowAlphaScale);
            } else {
                ImVec4 fallback = isCuiSelected ? active_color : inactive_color;
                glowColorForEffect = ImVec4(fallback.x, fallback.y, fallback.z, glowAlphaScale);
            }

            if (hud_tex != 0 && iconGlowIntensity > 0.01f) {
                const float glow_expand_x = 10.0f * frame.ui_scale;
                const float glow_expand_y = 6.0f * frame.ui_scale;
                ImVec2 glow_min = ImVec2(scaledIconMin.x - glow_expand_x, scaledIconMin.y - glow_expand_y);
                ImVec2 glow_max = ImVec2(scaledIconMax.x + glow_expand_x, scaledIconMax.y + glow_expand_y);
                const float cui_glow_size_scale = 0.7f; // reduce glow size by 0.3 for CUI only
                const ImVec2 glow_center = ImVec2((glow_min.x + glow_max.x) * 0.5f, (glow_min.y + glow_max.y) * 0.5f);
                const ImVec2 glow_half = ImVec2((glow_max.x - glow_min.x) * 0.5f * cui_glow_size_scale,
                                                (glow_max.y - glow_min.y) * 0.5f * cui_glow_size_scale);
                glow_min = ImVec2(glow_center.x - glow_half.x, glow_center.y - glow_half.y);
                glow_max = ImVec2(glow_center.x + glow_half.x, glow_center.y + glow_half.y);
                draw_list->PushClipRectFullScreen();
                post_processing.DrawGlowTexture(
                    draw_list, "hud",
                    glow_min, glow_max, glowColorForEffect, iconGlowIntensity);
                draw_list->PopClipRect();
            }
        }

        draw_list->AddImage(
            (void*)(intptr_t)hud_tex,
            scaledIconMin,
            scaledIconMax,
            cui_uv_min_stretched,
            cui_uv_max_stretched,
            icon_u32
        );

        ImGui::SetCursorScreenPos(cui_icon_pos);
        if (ImGui::InvisibleButton("##cui_icon_click", cui_icon_size_stretched)) {
            selectedTab = static_cast<int>(TabType::CUI);
        }
    }
}

void RenderWatermark(const RenderContext& ctx) {
    if (!ctx.gui || !ctx.fg_draw_list) {
        return;
    }

    ClickGUI* gui = ctx.gui;
    ImDrawList* draw_list = ctx.fg_draw_list;
    Theme* theme = gui->theme.get();
    if (!theme) {
        return;
    }

    const float base_ui_scale = (ctx.gui && ctx.gui->cache.uiScale > 0.0f)
        ? ctx.gui->cache.uiScale
        : GetScale();
    const float wm_scale = std::clamp(gui->watermarkScale, 0.75f, 1.85f);
    const float pad_scale = std::clamp(gui->watermarkPaddingScale, 0.70f, 1.75f);
    const float ui_scale = base_ui_scale * 1.20f * wm_scale; // watermark is 20% larger than base
    const float pad_x = 18.0f * ui_scale * pad_scale;
    const float pad_y = 12.0f * ui_scale * pad_scale;
    const float margin = std::max(16.0f * ui_scale, ctx.gl_height * 0.075f);
    const float rounding = std::max(8.0f, theme->style.CornerRadius);

    ImFont* text_font = theme->Get(Theme::FontId::Montserrat);
    if (!text_font) {
        text_font = ImGui::GetFont();
    }
    ImFont* icon_font = theme->Get(Theme::FontId::Awesome);
    if (!icon_font) {
        icon_font = text_font;
    }

    const float text_size_px = text_font->LegacySize * 0.64f * ui_scale;
    const float icon_size_px = text_size_px * 0.68f;
    const char* project_text = "Проект «Йор»";
    const char* clock_icon = "\xef\x80\x97";
    const char* user_icon = "\xef\x80\x87";

    const uint32_t wm_mask = gui->watermarkInfoMask;
    const bool show_nick = true;
    const bool show_time = (wm_mask & (1u << 0)) != 0u;
    const bool show_ram = (wm_mask & (1u << 1)) != 0u;
    const bool show_gpu = (wm_mask & (1u << 2)) != 0u;

    char time_buf[6] = {'0', '0', ':', '0', '0', '\0'};
    std::time_t now = std::time(nullptr);
    std::tm tm_now{};
#if defined(_WIN32)
    localtime_s(&tm_now, &now);
#else
    localtime_r(&now, &tm_now);
#endif
    std::snprintf(time_buf, sizeof(time_buf), "%02d:%02d", tm_now.tm_hour, tm_now.tm_min);
    const ImGuiIO& io = ctx.io ? *ctx.io : ImGui::GetIO();
    (void)io;

    char ram_buf[32] = {'\0'};
    const int mem_mb = ReadMemAvailableMb();
    if (mem_mb >= 0) {
        std::snprintf(ram_buf, sizeof(ram_buf), "RAM %dMB", mem_mb);
    }
    char gpu_buf[24] = {'\0'};
    const float fps = (io.Framerate > 1.0f) ? io.Framerate : 60.0f;
    const float gpu_est = std::clamp((60.0f / fps) * 100.0f, 0.0f, 100.0f);
    std::snprintf(gpu_buf, sizeof(gpu_buf), "GPU %.0f%%", gpu_est);

    struct WatermarkInfoBlock {
        std::string text;
        bool with_clock_icon = false;
    };
    std::vector<WatermarkInfoBlock> info_blocks;
    info_blocks.reserve(5);
    auto append_info = [&](const char* s, bool with_clock_icon) {
        if (!s || s[0] == '\0') return;
        info_blocks.push_back({std::string(s), with_clock_icon});
    };
    if (show_time) append_info(time_buf, true);
    if (show_ram && ram_buf[0] != '\0') append_info(ram_buf, false);
    if (show_gpu) append_info(gpu_buf, false);

    const char* user_name_raw = show_nick
        ? (gui->userInfo.userName.empty() ? vrt.text.globals[5] : gui->userInfo.userName.c_str())
        : "";
    const float menu_t = std::clamp(gui->animation.animationProgress, 0.0f, 1.0f);
    const float user_phase = 1.0f - menu_t;
    const float user_phase_visible = show_nick ? user_phase : 0.0f;
    auto resolve_watermark_nick_pair = [&](float axis_px, float axis_extent_px, bool horizontal, float alpha) -> ImVec4 {
        const int mode = std::clamp(gui->watermarkNicknameColorMode, 0, 2);
        if (mode == 0) {
            ImVec4 base = theme->IsLightMode()
                ? theme->HexToImVec4(theme->material.onSurface)
                : ImVec4(1.0f, 1.0f, 1.0f, 0.92f);
            base.w = alpha;
            return base;
        }
        ImVec4 start;
        ImVec4 end;
        if (mode == 2) {
            start = ImVec4(gui->watermarkNicknameColor1[0], gui->watermarkNicknameColor1[1], gui->watermarkNicknameColor1[2], 1.0f);
            end = ImVec4(gui->watermarkNicknameColor2[0], gui->watermarkNicknameColor2[1], gui->watermarkNicknameColor2[2], 1.0f);
        } else {
            theme->GetResolvedAccentGradient(start, end);
        }
        float blend_t = horizontal ? 0.5f : std::clamp(axis_px / std::max(1.0f, (float)((glHeight > 0) ? glHeight : 1080)), 0.0f, 1.0f);
        if (theme->GetAnimatedAccentEnabled()) {
            blend_t = AnimatedAccentBlend(theme, axis_px, axis_extent_px, horizontal);
        }
        return ImVec4(
            ImLerp(start.x, end.x, blend_t),
            ImLerp(start.y, end.y, blend_t),
            ImLerp(start.z, end.z, blend_t),
            alpha
        );
    };

    auto split_glyphs = [](const char* text) {
        std::vector<std::string> glyphs;
        if (!text || !*text) {
            return glyphs;
        }
        const char* p = text;
        while (*p) {
            unsigned int cp = 0;
            const int adv = ImTextCharFromUtf8(&cp, p, nullptr);
            if (adv <= 0) {
                break;
            }
            glyphs.emplace_back(p, p + adv);
            p += adv;
        }
        return glyphs;
    };

    static const std::vector<std::string> project_glyphs = split_glyphs(project_text);
    static std::string cached_user_name;
    static std::vector<std::string> cached_user_glyphs;
    if (cached_user_name != user_name_raw) {
        cached_user_name = user_name_raw;
        cached_user_glyphs = split_glyphs(cached_user_name.c_str());
    }
    const auto& user_glyphs = cached_user_glyphs;
    const int project_len = (int)project_glyphs.size();
    const int user_len = (int)user_glyphs.size();
    static const std::vector<std::string> none_glyphs = split_glyphs("None");
    const int none_len = (int)none_glyphs.size();

    const float project_letters_f = user_phase * (float)project_len;
    const int project_visible_count = std::clamp((int)std::floor(project_letters_f), 0, project_len);
    const float project_next_alpha = std::clamp(project_letters_f - (float)project_visible_count, 0.0f, 1.0f);
    std::string project_prefix;
    project_prefix.reserve(std::strlen(project_text));
    for (int i = 0; i < project_visible_count; ++i) {
        project_prefix += project_glyphs[(size_t)i];
    }
    const std::string project_next = (project_visible_count < project_len) ? project_glyphs[(size_t)project_visible_count] : std::string();

    const float user_letters_f = user_phase * (float)user_len;
    const int user_visible_count = std::clamp((int)std::floor(user_letters_f), 0, user_len);
    const float user_next_alpha = std::clamp(user_letters_f - (float)user_visible_count, 0.0f, 1.0f);
    std::string user_prefix;
    user_prefix.reserve(std::strlen(user_name_raw));
    for (int i = 0; i < user_visible_count; ++i) {
        user_prefix += user_glyphs[(size_t)i];
    }
    const std::string user_next = (user_visible_count < user_len) ? user_glyphs[(size_t)user_visible_count] : std::string();
    const float none_letters_f = menu_t * (float)none_len;
    const int none_visible_count = std::clamp((int)std::floor(none_letters_f), 0, none_len);
    const float none_next_alpha = std::clamp(none_letters_f - (float)none_visible_count, 0.0f, 1.0f);
    std::string none_prefix;
    none_prefix.reserve(8u);
    for (int i = 0; i < none_visible_count; ++i) {
        none_prefix += none_glyphs[(size_t)i];
    }
    const std::string none_next = (none_visible_count < none_len) ? none_glyphs[(size_t)none_visible_count] : std::string();

    const ImVec2 project_full_sz = text_font->CalcTextSizeA(text_size_px, FLT_MAX, 0.0f, project_text);
    const ImVec2 user_name_full_sz = text_font->CalcTextSizeA(text_size_px, FLT_MAX, 0.0f, user_name_raw);
    const ImVec2 project_prefix_sz = project_prefix.empty()
        ? ImVec2(0.0f, 0.0f)
        : text_font->CalcTextSizeA(text_size_px, FLT_MAX, 0.0f, project_prefix.c_str());
    const ImVec2 user_name_prefix_sz = user_prefix.empty()
        ? ImVec2(0.0f, 0.0f)
        : text_font->CalcTextSizeA(text_size_px, FLT_MAX, 0.0f, user_prefix.c_str());
    const float project_anim_w = project_full_sz.x * user_phase;
    const ImVec2 project_sz(project_anim_w, project_full_sz.y);
    const ImVec2 user_icon_sz = icon_font->CalcTextSizeA(icon_size_px, FLT_MAX, 0.0f, user_icon);
    const float info_icon_gap = 7.0f * ui_scale;
    const float user_icon_block_w = (user_name_raw && user_name_raw[0] != '\0')
        ? (user_icon_sz.x + info_icon_gap)
        : 0.0f;
    const float user_full_w = user_name_full_sz.x + user_icon_block_w;
    const float user_anim_w = user_full_w * user_phase_visible;
    const ImVec2 user_sz(user_anim_w, std::max(user_name_full_sz.y, user_icon_sz.y));
    std::vector<ImVec2> info_sizes;
    info_sizes.reserve(info_blocks.size());
    float info_total_w = 0.0f;
    float info_max_h = 0.0f;
    const float info_sep_gap = 8.0f * ui_scale;
    const float sep_w_for_info = std::max(1.0f, gui->cache.lineWidth * 1.25f);
    const ImVec2 clock_icon_sz = icon_font->CalcTextSizeA(icon_size_px, FLT_MAX, 0.0f, clock_icon);
    for (const WatermarkInfoBlock& block : info_blocks) {
        ImVec2 sz = text_font->CalcTextSizeA(text_size_px, FLT_MAX, 0.0f, block.text.c_str());
        if (block.with_clock_icon) {
            sz.x += clock_icon_sz.x + info_icon_gap;
            sz.y = std::max(sz.y, clock_icon_sz.y);
        }
        info_sizes.push_back(sz);
        info_total_w += sz.x;
        info_max_h = std::max(info_max_h, sz.y);
    }
    if (info_blocks.size() > 1) {
        const float sep_between_blocks = sep_w_for_info + info_sep_gap * 2.0f;
        info_total_w += sep_between_blocks * (float)(info_blocks.size() - 1);
    }
    const ImVec2 none_full_sz = text_font->CalcTextSizeA(text_size_px, FLT_MAX, 0.0f, "None");
    const float none_anim_w = none_full_sz.x * menu_t;
    const ImVec2 info_sz = info_blocks.empty()
        ? ImVec2(none_anim_w, none_full_sz.y)
        : ImVec2(info_total_w, info_max_h);

    const float border_w = std::max(1.0f, gui->cache.lineWidth * 1.25f);
    const float sep_w = border_w;
    const float sep_h = std::max(10.0f * ui_scale, std::max(project_sz.y, std::max(user_sz.y, info_sz.y)) * 0.72f);
    const float block_gap = 10.0f * ui_scale;
    const float info_block_w = info_sz.x;
    const float info_section_phase = info_blocks.empty() ? 0.0f : 1.0f;
    const float right_phase = std::max(user_phase_visible, info_section_phase);
    const float sep2_phase = std::min(user_phase_visible, info_section_phase);
    const float sep1_phase = std::min(user_phase, right_phase);
    const float lead_gap = block_gap * sep1_phase;
    const float sep1_w = sep_w * sep1_phase;
    const float after_sep1_gap = block_gap * sep1_phase;
    const float after_user_gap = block_gap * sep2_phase;
    const float sep2_w = sep_w * sep2_phase;
    const float after_sep2_gap = block_gap * sep2_phase;
    const float full_sep2_offset = (sep_w + (block_gap * 2.0f) + user_full_w);
    const float full_content_w = project_full_sz.x + block_gap + full_sep2_offset + (sep_w + block_gap) + info_block_w;
    const float content_w = project_anim_w + lead_gap + sep1_w + after_sep1_gap +
                            user_anim_w + after_user_gap + sep2_w + after_sep2_gap + info_block_w;
    const float content_h = std::max(std::max(project_sz.y, user_sz.y), info_sz.y);
    const float stripe_w = ResolveEdgeStripeWidth(base_ui_scale, border_w);
    const float body_w = content_w + pad_x * 2.0f;
    const float overlay_h = content_h + pad_y * 2.0f;
    const float stripe_overlap = std::max(1.35f, 1.05f * ui_scale);
    const float stripe_outer_w = std::max(1.0f, stripe_w - stripe_overlap);
    const float expanded_body_w = full_content_w + pad_x * 2.0f;
    const float stripe_extra_w = stripe_outer_w;
    const float expanded_total_w = expanded_body_w + stripe_extra_w;
    const float watermark_max_x = std::max(0.0f, (float)ctx.gl_width - expanded_total_w);
    const float watermark_max_y = std::max(0.0f, (float)ctx.gl_height - overlay_h);
    float left = std::clamp(std::clamp(gui->watermarkNormX, 0.0f, 1.0f) * watermark_max_x, 0.0f, watermark_max_x);
    float top = std::clamp(std::clamp(gui->watermarkNormY, 0.0f, 1.0f) * watermark_max_y, 0.0f, watermark_max_y);
    if (!std::isfinite(left) || !std::isfinite(top)) {
        left = margin;
        top = margin;
    }
    const float center_norm_x = ((left + expanded_total_w * 0.5f) / std::max(1.0f, (float)ctx.gl_width));
    const EdgeStripeSide stripe_side = ResolveEdgeStripeSide(center_norm_x);
    const bool show_stripe = stripe_side != EdgeStripeSide::None;
    const float total_w = body_w + (show_stripe ? stripe_extra_w : 0.0f);
    const ImVec2 panel_min(left, top);
    const ImVec2 panel_max(panel_min.x + total_w, panel_min.y + overlay_h);
    const ImVec2 wm_pos = (stripe_side == EdgeStripeSide::Left)
        ? ImVec2(left + stripe_extra_w, top)
        : ImVec2(left, top);
    const ImVec2 wm_size(body_w, overlay_h);
    const ImVec2 wm_max(wm_pos.x + wm_size.x, wm_pos.y + wm_size.y);
    const ImVec2 stripe_min = (stripe_side == EdgeStripeSide::Left)
        ? panel_min
        : ImVec2(wm_max.x - stripe_overlap, top);
    const ImVec2 stripe_max = (stripe_side == EdgeStripeSide::Left)
        ? ImVec2(wm_pos.x + stripe_overlap, wm_max.y)
        : panel_max;
    if (post_processing.flags.shadow) {
        ImColor shadow_col(0.0f, 0.0f, 0.0f, post_processing.flags.blur ? 0.18f : 0.24f);
        if (theme->IsLightMode()) {
            ImVec4 glow = theme->HexToImVec4(theme->material.onSurfaceVariant);
            glow.w = post_processing.flags.blur ? 0.10f : 0.13f;
            shadow_col = ImColor(glow.x, glow.y, glow.z, glow.w);
        }
        const float shadow_inset = std::max(0.85f, 1.0f * ui_scale);
        const float shadow_rounding = rounding + std::max(0.7f, 0.9f * ui_scale);
        drawRoundedRectShadow(
            ImVec2(panel_min.x + shadow_inset, panel_min.y + shadow_inset),
            ImVec2(panel_max.x - shadow_inset, panel_max.y - shadow_inset),
            shadow_rounding,
            shadow_col,
            1.0f,
            std::clamp(gui->appearance.shadowRings + 1, 7, kHudShadowMaxRings),
            std::clamp(gui->appearance.shadowSmoothness * 1.08f, 0.40f, 1.75f),
            true
        );
    }
    gui->watermarkCaptureMin = panel_min;
    gui->watermarkCaptureMax = panel_max;
    gui->watermarkCaptureValid = true;
    const ImVec2 wm_center((panel_min.x + panel_max.x) * 0.5f, (panel_min.y + panel_max.y) * 0.5f);
    static ImVec2 s_prev_wm_center(0.0f, 0.0f);
    static ImVec2 s_prev_wm_size(0.0f, 0.0f);
    static bool s_has_prev_wm = false;
    const float dt = std::max(1e-4f, io.DeltaTime);
    if (s_has_prev_wm && !gui->open) {
        const ImVec2 vel((wm_center.x - s_prev_wm_center.x) / dt, (wm_center.y - s_prev_wm_center.y) / dt);
        const float wv = (wm_size.x - s_prev_wm_size.x) / dt;
        const float hv = (wm_size.y - s_prev_wm_size.y) / dt;
        const float speed = std::sqrt(vel.x * vel.x + vel.y * vel.y);
        float amp = std::clamp(speed / 1450.0f, 0.0f, 0.82f);
        amp = std::max(amp, std::clamp((std::fabs(wv) + std::fabs(hv) * 0.4f) / 1800.0f, 0.0f, 0.78f));
        if (amp > 0.012f) {
            gui->NotifyWatermarkVisualMotion(vel, amp, dt);
        }
    }
    s_prev_wm_center = wm_center;
    s_prev_wm_size = wm_size;
    s_has_prev_wm = true;

    if (ctx.gl_width > 0 && ctx.gl_height > 0) {
        const float visible_total_w = total_w;
        gui->watermarkVisibleWidthNorm = std::clamp(visible_total_w / (float)ctx.gl_width, 0.03f, 0.98f);
        gui->watermarkVisibleHeightNorm = std::clamp(overlay_h / (float)ctx.gl_height, 0.02f, 0.80f);
        gui->watermarkExpandedWidthNorm = std::clamp(expanded_total_w / (float)ctx.gl_width, gui->watermarkVisibleWidthNorm, 0.99f);
    }

    if (ImGui::IsMouseClicked(0) &&
        io.MousePos.x >= panel_min.x && io.MousePos.x <= panel_max.x &&
        io.MousePos.y >= panel_min.y && io.MousePos.y <= panel_max.y) {
        if (gui->open && ctx.gl_width > 0 && ctx.gl_height > 0) {
            const float expanded_w = std::max(
                panel_max.x - panel_min.x,
                std::clamp(gui->watermarkExpandedWidthNorm, 0.03f, 0.99f) * (float)ctx.gl_width
            );
            const float expanded_h = std::max(
                panel_max.y - panel_min.y,
                std::clamp(gui->watermarkVisibleHeightNorm, 0.02f, 0.80f) * (float)ctx.gl_height
            );
            gui->watermarkCaptureMin = panel_min;
            gui->watermarkCaptureMax = ImVec2(panel_min.x + expanded_w, panel_min.y + expanded_h);
            gui->watermarkCaptureValid = true;
        }
        gui->NotifyWatermarkInteraction(io.MousePos, 0.96f);
        gui->Toggle();
    }

    const bool blur_enabled = post_processing.flags.blur;
    if (blur_enabled) {
        const float blur_x0_f = panel_min.x;
        const float blur_y0_f = panel_min.y;
        const float blur_x1_f = panel_max.x;
        const float blur_y1_f = panel_max.y;
        const int blur_x0 = std::max(0, (int)std::floor(blur_x0_f));
        const int blur_y0 = std::max(0, (int)std::floor(blur_y0_f));
        const int blur_x1 = std::min(ctx.gl_width, (int)std::ceil(blur_x1_f));
        const int blur_y1 = std::min(ctx.gl_height, (int)std::ceil(blur_y1_f));
        const int blur_w = std::max(0, blur_x1 - blur_x0);
        const int blur_h = std::max(0, blur_y1 - blur_y0);
        if (blur_w > 0 && blur_h > 0) {
            const float tx0 = std::clamp(blur_x0_f, 0.0f, (float)ctx.gl_width);
            const float ty0 = std::clamp(blur_y0_f, 0.0f, (float)ctx.gl_height);
            const float tx1 = std::clamp(blur_x1_f, 0.0f, (float)ctx.gl_width);
            const float ty1 = std::clamp(blur_y1_f, 0.0f, (float)ctx.gl_height);
            const float blur_radius = std::max(0.1f, gui->sidebar.BlurRadius);
            const float ds_scale = 27.0f;
            const float pad_f = std::max(8.0f, ((blur_radius * 2.0f) + 6.0f) * ds_scale + 12.0f);
            const int pad = std::max(1, (int)std::ceil(pad_f));
            const int cap_x0 = std::max(0, blur_x0 - pad);
            const int cap_y0 = std::max(0, blur_y0 - pad);
            const int cap_x1 = std::min(ctx.gl_width, blur_x0 + blur_w + pad);
            const int cap_y1 = std::min(ctx.gl_height, blur_y0 + blur_h + pad);
            const int cap_w = std::max(0, cap_x1 - cap_x0);
            const int cap_h = std::max(0, cap_y1 - cap_y0);
            if (cap_w > 0 && cap_h > 0) {
                const int frame = ImGui::GetFrameCount();
                static int s_last_wm_blur_frame = -10000;
                static int s_prev_cap_x0 = -1, s_prev_cap_y1 = -1, s_prev_cap_w = -1, s_prev_cap_h = -1;
                const bool rect_changed =
                    (s_prev_cap_x0 != cap_x0) || (s_prev_cap_y1 != cap_y1) ||
                    (s_prev_cap_w != cap_w) || (s_prev_cap_h != cap_h);
                const int wm_blur_interval = (gui && gui->open) ? 8 : 3;
                const bool need_refresh = rect_changed || (wblur.tex == 0) || ((frame - s_last_wm_blur_frame) >= wm_blur_interval);
                if (need_refresh) {
                    s_last_wm_blur_frame = frame;
                    s_prev_cap_x0 = cap_x0; s_prev_cap_y1 = cap_y1;
                    s_prev_cap_w = cap_w;   s_prev_cap_h = cap_h;
                    struct WmBlurJob { int x, y, w, h; float r; Blur::Type t; };
                    auto* job = new WmBlurJob{cap_x0, ctx.gl_height - cap_y1, cap_w, cap_h, blur_radius, gui->sidebar.BlurType};
                    draw_list->AddCallback([](const ImDrawList*, const ImDrawCmd* cmd) {
                        auto* j = static_cast<WmBlurJob*>(cmd->UserCallbackData);
                        wblur.backend = Hardware::GPU;
                        wblur.type = j->t;
                wblur.process(j->x, j->y, j->w, j->h, j->r, kHudBlurPasses);
                        delete j;
                    }, job);
                }
                if (wblur.tex != 0) {
                    const float u0 = std::clamp((tx0 - (float)cap_x0) / (float)cap_w, 0.0f, 1.0f);
                    const float u1 = std::clamp((tx1 - (float)cap_x0) / (float)cap_w, 0.0f, 1.0f);
                    const float v_top = std::clamp(1.0f - ((ty0 - (float)cap_y0) / (float)cap_h), 0.0f, 1.0f);
                    const float v_bottom = std::clamp(1.0f - ((ty1 - (float)cap_y0) / (float)cap_h), 0.0f, 1.0f);
                    draw_list->AddImageRounded(
                        (void*)(intptr_t)wblur.tex,
                        ImVec2(tx0, ty0), ImVec2(tx1, ty1),
                        ImVec2(u0, v_top), ImVec2(u1, v_bottom),
                        IM_COL32(255, 255, 255, 255), rounding, ImDrawFlags_RoundCornersAll
                    );
                }
            }
        } else {
            wblur.reset();
        }
    } else {
        wblur.reset();
    }

    const float shared_border_alpha = blur_enabled ? 0.018f : 0.014f;
    const bool light_mode_wm = theme->IsLightMode();
    ImVec4 bg_col = blur_enabled
        ? gui->cache.surfaceTransparent
        : ImVec4(0.07f, 0.07f, 0.07f, 1.0f);
    if (blur_enabled) {
        if (light_mode_wm) {
            bg_col = theme->HexToImVec4(theme->material.surfaceVariant);
            bg_col.w = 0.42f;
        } else {
            const float sidebar_darkness = 0.93f;
            bg_col.x = std::clamp(bg_col.x * sidebar_darkness, 0.0f, 1.0f);
            bg_col.y = std::clamp(bg_col.y * sidebar_darkness, 0.0f, 1.0f);
            bg_col.z = std::clamp(bg_col.z * sidebar_darkness, 0.0f, 1.0f);
            bg_col.w = std::min(1.0f, 0.4f);
        }
    } else {
        bg_col.w = std::clamp(gui->watermarkBgAlphaNoBlur, 0.10f, 1.0f);
    }
    ImVec4 border_col = ImVec4(1.0f, 1.0f, 1.0f, shared_border_alpha);
    if (light_mode_wm) {
        border_col = theme->HexToImVec4(theme->material.onSurfaceVariant);
        border_col.w = blur_enabled ? 0.26f : 0.22f;
    }
    ImVec4 stripe_col = ResolveAnimatedStripeTint(theme, stripe_min.y, std::max(1.0f, stripe_max.y - stripe_min.y), false, blur_enabled ? 0.85f : 1.0f);

    const ImDrawFlags body_round_flags = BodyRoundingFlagsForStripe(stripe_side);
    draw_list->AddRectFilled(wm_pos, wm_max,
                             ImGui::GetColorU32(bg_col), rounding, body_round_flags);

    if (blur_enabled) {
        ImVec4 overlay = ImGui::ColorConvertU32ToFloat4(ctx.main_area_color);
        const ImVec4 side_ref = ImGui::ColorConvertU32ToFloat4(ctx.sidebar_color);
        overlay.x = std::clamp((overlay.x * 0.92f + side_ref.x * 0.08f) * 1.10f, 0.0f, 1.0f);
        overlay.y = std::clamp((overlay.y * 0.92f + side_ref.y * 0.08f) * 1.10f, 0.0f, 1.0f);
        overlay.z = std::clamp((overlay.z * 0.92f + side_ref.z * 0.08f) * 1.10f, 0.0f, 1.0f);
        overlay.w = light_mode_wm ? 0.20f : 0.14f;
        draw_list->AddRectFilled(wm_pos, wm_max, ImGui::GetColorU32(overlay), rounding, body_round_flags);
    }

    DrawEdgeStripeGlow(draw_list, stripe_min, stripe_max, stripe_col, stripe_side, StripeGlowTargetId::Watermark, theme, base_ui_scale, ctx.gl_width, ctx.gl_height);
    if (show_stripe) {
        DrawAnimatedEdgeStripe(draw_list, stripe_min, stripe_max, stripe_side, StripeGlowTargetId::Watermark, theme, stripe_col.w, false);
    }

    float x = wm_pos.x + (wm_size.x - content_w) * 0.5f;

    ImVec4 main_text = light_mode_wm
        ? theme->HexToImVec4(theme->material.onSurface)
        : ImVec4(1.0f, 1.0f, 1.0f, 0.92f);
    const float text_alpha_scale = std::clamp(gui->watermarkTextAlpha, 0.25f, 1.0f);
    main_text.w = (light_mode_wm ? 0.99f : main_text.w) * text_alpha_scale;
    ImVec4 accent_text = light_mode_wm
        ? WidgetBase::PrimaryMidColor(theme)
        : (blur_enabled ? ImVec4(0.82f, 0.92f, 1.0f, 0.95f) : ImVec4(0.70f, 0.86f, 1.0f, 1.0f));
    if (light_mode_wm) {
        accent_text.w = 0.88f;
    }

    const float text_off = GetGlyphOffsetY(text_font, text_size_px);
    const float icon_off = GetGlyphOffsetY(icon_font, icon_size_px);
    const float project_y = wm_pos.y + (wm_size.y - project_sz.y) * 0.5f - text_off;
    const float user_y = wm_pos.y + (wm_size.y - user_sz.y) * 0.5f - text_off;
    const float info_y = wm_pos.y + (wm_size.y - info_sz.y) * 0.5f - text_off;
    const float sep_y1 = wm_pos.y + (wm_size.y - sep_h) * 0.5f;
    const float sep_y2 = sep_y1 + sep_h;
    const float sep_alpha_mul = 1.95f * std::clamp(gui->watermarkSeparatorAlpha, 0.10f, 2.0f);
    const ImU32 sep1_col = ImGui::GetColorU32(ImVec4(border_col.x, border_col.y, border_col.z, std::clamp(border_col.w * sep1_phase * sep_alpha_mul, 0.0f, 1.0f)));
    const ImU32 sep2_col = ImGui::GetColorU32(ImVec4(border_col.x, border_col.y, border_col.z, std::clamp(border_col.w * sep2_phase * sep_alpha_mul, 0.0f, 1.0f)));

    const float glyph_fall = 2.0f * ui_scale;
    const float project_bold_offset = std::max(0.35f, 0.55f * ui_scale);
    ImVec2 project_clip_min(x, wm_pos.y);
    ImVec2 project_clip_max(x + project_anim_w, wm_max.y);
    if (project_clip_max.x > project_clip_min.x) {
        draw_list->PushClipRect(project_clip_min, project_clip_max, true);
        if (!project_prefix.empty()) {
            draw_list->AddText(text_font, text_size_px, ImVec2(project_clip_min.x, project_y), ImGui::GetColorU32(main_text), project_prefix.c_str());
            draw_list->AddText(text_font, text_size_px, ImVec2(project_clip_min.x + project_bold_offset, project_y), ImGui::GetColorU32(main_text), project_prefix.c_str());
        }
        if (!project_next.empty() && project_next_alpha > 0.001f) {
            ImVec4 next_col = main_text;
            next_col.w *= project_next_alpha;
            const float y_off = (1.0f - project_next_alpha) * glyph_fall;
            draw_list->AddText(text_font, text_size_px,
                               ImVec2(project_clip_min.x + project_prefix_sz.x, project_y + y_off),
                               ImGui::GetColorU32(next_col),
                               project_next.c_str());
            draw_list->AddText(text_font, text_size_px,
                               ImVec2(project_clip_min.x + project_prefix_sz.x + project_bold_offset, project_y + y_off),
                               ImGui::GetColorU32(next_col),
                               project_next.c_str());
        }
        draw_list->PopClipRect();
    }
    x += project_anim_w;
    if (sep1_phase > 0.001f) {
        x += lead_gap;
        const float sep1_x = std::floor(x) + 0.5f;
        draw_list->AddLine(ImVec2(sep1_x, sep_y1), ImVec2(sep1_x, sep_y2), sep1_col, sep_w);
        x = sep1_x + sep1_w + after_sep1_gap;
    }
    if (user_phase_visible > 0.001f) {
        ImVec2 user_clip_min(x, wm_pos.y);
        ImVec2 user_clip_max(user_clip_min.x + user_anim_w, wm_max.y);
        if (user_clip_max.x > user_clip_min.x) {
            draw_list->PushClipRect(user_clip_min, user_clip_max, true);
            const float user_icon_y = wm_pos.y + (wm_size.y - user_icon_sz.y) * 0.5f - icon_off;
            const float user_text_x = user_clip_min.x + user_icon_block_w;
            const float visible_name_span = std::max(1.0f, std::min(user_name_full_sz.x, std::max(1.0f, user_anim_w - user_icon_block_w)));
            const ImVec4 user_icon_col = resolve_watermark_nick_pair(user_clip_min.x + user_icon_sz.x * 0.5f, visible_name_span, true, main_text.w);
            draw_list->AddText(icon_font, icon_size_px, ImVec2(user_clip_min.x, user_icon_y), ImGui::GetColorU32(user_icon_col), user_icon);
            const int user_vtx_start = draw_list->VtxBuffer.Size;
            draw_list->AddText(text_font, text_size_px, ImVec2(user_text_x, user_y), IM_COL32_WHITE, user_prefix.c_str());
            if (!user_next.empty() && user_next_alpha > 0.001f) {
                ImVec4 next_col = ImVec4(1.0f, 1.0f, 1.0f, 1.0f);
                next_col.w *= user_next_alpha;
                const float y_off = (1.0f - user_next_alpha) * glyph_fall;
                draw_list->AddText(text_font, text_size_px,
                                   ImVec2(user_text_x + user_name_prefix_sz.x, user_y + y_off),
                                   ImGui::GetColorU32(next_col),
                                   user_next.c_str());
            }
            const int user_vtx_end = draw_list->VtxBuffer.Size;
            if (user_vtx_end > user_vtx_start) {
                const ImVec4 nick_col_1 = resolve_watermark_nick_pair(user_text_x, visible_name_span, true, 1.0f);
                const ImVec4 nick_col_2 = resolve_watermark_nick_pair(user_text_x + visible_name_span, visible_name_span, true, 1.0f);
                const ImU32 grad_col_1 = ImGui::GetColorU32(ImVec4(nick_col_1.x, nick_col_1.y, nick_col_1.z, 1.0f));
                const ImU32 grad_col_2 = ImGui::GetColorU32(ImVec4(nick_col_2.x, nick_col_2.y, nick_col_2.z, 1.0f));
                const ImVec2 grad_p0 = ImVec2(user_text_x, user_y);
                const ImVec2 grad_p1 = ImVec2(user_text_x + visible_name_span, user_y);
                ImGui::ShadeVertsLinearColorGradientKeepAlpha(draw_list, user_vtx_start, user_vtx_end,
                                                              grad_p0, grad_p1, grad_col_1, grad_col_2);
            }
            draw_list->PopClipRect();
        }
        x += user_anim_w;
    }
    if (sep2_phase > 0.001f) {
        x += after_user_gap;
        const float sep2_x = std::floor(x) + 0.5f;
        draw_list->AddLine(ImVec2(sep2_x, sep_y1), ImVec2(sep2_x, sep_y2), sep2_col, sep_w);
        x = sep2_x + sep2_w + after_sep2_gap;
    }
    if (!info_blocks.empty()) {
        for (size_t i = 0; i < info_blocks.size(); ++i) {
            const WatermarkInfoBlock& block = info_blocks[i];
            const ImVec2 sz = info_sizes[i];
            float text_x = x;
            if (block.with_clock_icon) {
                const float icon_y = wm_pos.y + (wm_size.y - clock_icon_sz.y) * 0.5f - icon_off;
                draw_list->AddText(icon_font, icon_size_px, ImVec2(x, icon_y), ImGui::GetColorU32(main_text), clock_icon);
                text_x += clock_icon_sz.x + info_icon_gap;
            }
            draw_list->AddText(text_font, text_size_px, ImVec2(text_x, info_y), ImGui::GetColorU32(main_text), block.text.c_str());
            x += sz.x;
            if (i + 1 < info_blocks.size()) {
                x += info_sep_gap;
                const float info_sep_x = std::floor(x) + 0.5f;
                draw_list->AddLine(ImVec2(info_sep_x, sep_y1), ImVec2(info_sep_x, sep_y2), sep2_col, sep_w);
                x += sep_w + info_sep_gap;
            }
        }
    } else if (none_anim_w > 0.001f) {
        ImVec2 none_clip_min(x, wm_pos.y);
        ImVec2 none_clip_max(x + none_anim_w, wm_max.y);
        if (none_clip_max.x > none_clip_min.x) {
            draw_list->PushClipRect(none_clip_min, none_clip_max, true);
            if (!none_prefix.empty()) {
                draw_list->AddText(text_font, text_size_px, ImVec2(none_clip_min.x, info_y), ImGui::GetColorU32(main_text), none_prefix.c_str());
            }
            if (!none_next.empty() && none_next_alpha > 0.001f) {
                const ImVec2 none_prefix_sz = none_prefix.empty()
                    ? ImVec2(0.0f, 0.0f)
                    : text_font->CalcTextSizeA(text_size_px, FLT_MAX, 0.0f, none_prefix.c_str());
                ImVec4 next_col = main_text;
                next_col.w *= none_next_alpha;
                const float y_off = (1.0f - none_next_alpha) * glyph_fall;
                draw_list->AddText(
                    text_font,
                    text_size_px,
                    ImVec2(none_clip_min.x + none_prefix_sz.x, info_y + y_off),
                    ImGui::GetColorU32(next_col),
                    none_next.c_str()
                );
            }
            draw_list->PopClipRect();
        }
    }
}

void RenderSpeedGraph(const RenderContext& ctx) {
    if (!ctx.gui || !ctx.fg_draw_list || !ctx.gui->theme) {
        return;
    }

    auto& speed_module = vrt.features.hud.speedGraph;
    if (!speed_module.enabled) {
        return;
    }

    static bool s_logged_render = false;
    if (!s_logged_render) {
        s_logged_render = true;
        Axlebolt::PlayerControllerHook::Log("[hud] RenderSpeedGraph first render enabled=%d", speed_module.enabled ? 1 : 0);
    }

    ClickGUI* gui = ctx.gui;
    Theme* theme = gui->theme.get();
    ImDrawList* draw_list = ctx.fg_draw_list;

    std::array<float, Axlebolt::PlayerControllerHook::kHistoryCapacity> history{};
    float current_speed = 0.0f;
    float peak_speed = 0.0f;
    const size_t sample_count = Axlebolt::PlayerControllerHook::CopyHistoryForSpeedGraph(history, current_speed, peak_speed);

    const float base_ui_scale = (gui->cache.uiScale > 0.0f) ? gui->cache.uiScale : GetScale();
    const float ui_scale = base_ui_scale * 1.02f;
    const float card_w = 340.0f * ui_scale;
    const float card_h = 110.0f * ui_scale;
    const float speed_graph_max_x = std::max(0.0f, (float)ctx.gl_width - card_w);
    const float speed_graph_max_y = std::max(0.0f, (float)ctx.gl_height - card_h);
    const float left = std::clamp(std::clamp(gui->speedGraphNormX, 0.0f, 1.0f) * speed_graph_max_x, 0.0f, speed_graph_max_x);
    const float top = std::clamp(std::clamp(gui->speedGraphNormY, 0.0f, 1.0f) * speed_graph_max_y, 0.0f, speed_graph_max_y);
    const float snapped_left = std::round(left);
    const float snapped_top = std::round(top);
    const float snapped_card_w = std::round(card_w);
    const float snapped_card_h = std::round(card_h);
    const float rounding = std::max(8.0f, theme->style.CornerRadius);
    const float border_w = std::max(1.0f, gui->cache.lineWidth * 1.15f);
    const float stripe_w = ResolveEdgeStripeWidth(base_ui_scale, border_w);
    const float center_norm_x = ((snapped_left + snapped_card_w * 0.5f) / std::max(1.0f, (float)ctx.gl_width));
    const EdgeStripeSide stripe_side = ResolveEdgeStripeSide(center_norm_x);
    const bool show_stripe = stripe_side != EdgeStripeSide::None;
    const float total_w = snapped_card_w + (show_stripe ? stripe_w : 0.0f);
    const float panel_min_x = (stripe_side == EdgeStripeSide::Right) ? (snapped_left - stripe_w) : snapped_left;
    const ImVec2 card_min((stripe_side == EdgeStripeSide::Left) ? (snapped_left + stripe_w) : snapped_left, snapped_top);
    const ImVec2 card_max(card_min.x + snapped_card_w, card_min.y + snapped_card_h);
    const ImVec2 panel_min(panel_min_x, snapped_top);
    const ImVec2 panel_max(panel_min.x + total_w, card_max.y);
    const ImVec2 stripe_min = (stripe_side == EdgeStripeSide::Left)
        ? panel_min
        : ImVec2(card_max.x, card_min.y);
    const ImVec2 stripe_max = (stripe_side == EdgeStripeSide::Left)
        ? ImVec2(card_min.x, card_max.y)
        : panel_max;
    gui->speedGraphVisibleWidthNorm = std::clamp(total_w / std::max(1.0f, (float)ctx.gl_width), 0.06f, 0.98f);
    gui->speedGraphVisibleHeightNorm = std::clamp(card_h / std::max(1.0f, (float)ctx.gl_height), 0.04f, 0.45f);
    gui->speedGraphExpandedWidthNorm = gui->speedGraphVisibleWidthNorm;

    if (post_processing.flags.shadow) {
        ImColor shadow_col(0.0f, 0.0f, 0.0f, post_processing.flags.blur ? 0.18f : 0.24f);
        if (theme->IsLightMode()) {
            ImVec4 glow = theme->HexToImVec4(theme->material.onSurfaceVariant);
            glow.w = post_processing.flags.blur ? 0.10f : 0.13f;
            shadow_col = ImColor(glow.x, glow.y, glow.z, glow.w);
        }
        const float shadow_inset = std::max(0.85f, 1.0f * ui_scale);
        const float shadow_rounding = rounding + std::max(0.7f, 0.9f * ui_scale);
        drawRoundedRectShadow(
            ImVec2(panel_min.x + shadow_inset, panel_min.y + shadow_inset),
            ImVec2(panel_max.x - shadow_inset, panel_max.y - shadow_inset),
            shadow_rounding,
            shadow_col,
            1.0f,
            std::clamp(gui->appearance.shadowRings + 1, 7, kHudShadowMaxRings),
            std::clamp(gui->appearance.shadowSmoothness * 1.08f, 0.40f, 1.75f),
            true
        );
    }

    if (post_processing.flags.blur && ctx.gl_width > 0 && ctx.gl_height > 0) {
        const int blur_x0 = std::max(0, (int)std::floor(panel_min.x));
        const int blur_y0 = std::max(0, (int)std::floor(panel_min.y));
        const int blur_x1 = std::min(ctx.gl_width, (int)std::ceil(panel_max.x));
        const int blur_y1 = std::min(ctx.gl_height, (int)std::ceil(panel_max.y));
        const int blur_w = std::max(0, blur_x1 - blur_x0);
        const int blur_h = std::max(0, blur_y1 - blur_y0);
        if (blur_w > 0 && blur_h > 0) {
            const float blur_radius = std::max(0.1f, gui->sidebar.BlurRadius);
            struct SgBlurJob { int x, y, w, h; float r; Blur::Type t; };
            auto* job = new SgBlurJob{blur_x0, ctx.gl_height - blur_y1, blur_w, blur_h, blur_radius, gui->sidebar.BlurType};
            draw_list->AddCallback([](const ImDrawList*, const ImDrawCmd* cmd) {
                auto* j = static_cast<SgBlurJob*>(cmd->UserCallbackData);
                speed_graph_blur.backend = Hardware::GPU;
                speed_graph_blur.type = j->t;
                speed_graph_blur.process(j->x, j->y, j->w, j->h, j->r, kHudBlurPasses);
                delete j;
            }, job);
            if (speed_graph_blur.tex != 0) {
                draw_list->AddImageRounded(
                    (void*)(intptr_t)speed_graph_blur.tex,
                    panel_min, panel_max,
                    ImVec2(0.0f, 1.0f), ImVec2(1.0f, 0.0f),
                    IM_COL32(255, 255, 255, 255), rounding, ImDrawFlags_RoundCornersAll
                );
            }
        }
    }

    const bool light_mode = theme->IsLightMode();
    ImVec4 bg_col = post_processing.flags.blur
        ? gui->cache.surfaceTransparent
        : ImVec4(0.07f, 0.07f, 0.07f, 0.92f);
    if (post_processing.flags.blur) {
        if (light_mode) {
            bg_col = theme->HexToImVec4(theme->material.surfaceVariant);
            bg_col.w = 0.40f;
        } else {
            bg_col.x = std::clamp(bg_col.x * 0.92f, 0.0f, 1.0f);
            bg_col.y = std::clamp(bg_col.y * 0.92f, 0.0f, 1.0f);
            bg_col.z = std::clamp(bg_col.z * 0.92f, 0.0f, 1.0f);
            bg_col.w = 0.46f;
        }
    }
    const ImDrawFlags body_round_flags = BodyRoundingFlagsForStripe(stripe_side);
    draw_list->AddRectFilled(card_min, card_max, ImGui::GetColorU32(bg_col), rounding, body_round_flags);

    if (post_processing.flags.blur) {
        ImVec4 overlay = ImGui::ColorConvertU32ToFloat4(ctx.main_area_color);
        const ImVec4 side_ref = ImGui::ColorConvertU32ToFloat4(ctx.sidebar_color);
        overlay.x = std::clamp((overlay.x * 0.92f + side_ref.x * 0.08f) * 1.10f, 0.0f, 1.0f);
        overlay.y = std::clamp((overlay.y * 0.92f + side_ref.y * 0.08f) * 1.10f, 0.0f, 1.0f);
        overlay.z = std::clamp((overlay.z * 0.92f + side_ref.z * 0.08f) * 1.10f, 0.0f, 1.0f);
        overlay.w = light_mode ? 0.20f : 0.14f;
        draw_list->AddRectFilled(card_min, card_max, ImGui::GetColorU32(overlay), rounding, body_round_flags);
    }

    const ImVec4 stripe_col = ResolveAnimatedStripeTint(theme, stripe_min.y, std::max(1.0f, stripe_max.y - stripe_min.y), false, post_processing.flags.blur ? 0.85f : 1.0f);
    DrawEdgeStripeGlow(draw_list, stripe_min, stripe_max, stripe_col, stripe_side, StripeGlowTargetId::SpeedGraph, theme, base_ui_scale, ctx.gl_width, ctx.gl_height);
    if (show_stripe) {
        DrawAnimatedEdgeStripe(draw_list, stripe_min, stripe_max, stripe_side, StripeGlowTargetId::SpeedGraph, theme, stripe_col.w, false);
    }

    ImFont* title_font = theme->Get(Theme::FontId::Montserrat);
    if (!title_font) {
        title_font = ImGui::GetFont();
    }

    const float pad_x = 16.0f * ui_scale;
    const float pad_y = 12.0f * ui_scale;
    const float title_size = title_font->LegacySize * 0.58f * ui_scale;
    const float value_size = title_font->LegacySize * 0.78f * ui_scale;
    const float caption_size = title_font->LegacySize * 0.46f * ui_scale;
    const float title_off = GetGlyphOffsetY(title_font, title_size);
    const float value_off = GetGlyphOffsetY(title_font, value_size);
    const float caption_off = GetGlyphOffsetY(title_font, caption_size);

    const ImVec4 accent = ResolveAccentAtScreenY(theme, (card_min.y + card_max.y) * 0.5f);
    const ImVec4 text_main = light_mode
        ? theme->HexToImVec4(theme->material.onSurface)
        : ImVec4(1.0f, 1.0f, 1.0f, 0.94f);
    const ImVec4 text_dim = light_mode
        ? theme->HexToImVec4(theme->material.onSurfaceVariant)
        : ImVec4(1.0f, 1.0f, 1.0f, 0.54f);

    static float s_display_speed = 0.0f;
    static float s_display_peak = 0.0f;
    const float dt = std::clamp(ImGui::GetIO().DeltaTime, 1.0f / 240.0f, 0.05f);
    const float text_lerp = 1.0f - std::exp(-dt * 10.0f);
    s_display_speed += (current_speed - s_display_speed) * text_lerp;
    s_display_peak += (peak_speed - s_display_peak) * text_lerp;

    char speed_buf[32];
    char peak_buf[32];
    std::snprintf(speed_buf, sizeof(speed_buf), "%.1f", s_display_speed);
    std::snprintf(peak_buf, sizeof(peak_buf), "Peak %.1f", s_display_peak);
    const ImVec2 peak_size = title_font->CalcTextSizeA(caption_size, FLT_MAX, 0.0f, peak_buf);
    const ImVec2 unit_size = title_font->CalcTextSizeA(caption_size, FLT_MAX, 0.0f, "u/s");
    const ImVec2 speed_size = title_font->CalcTextSizeA(value_size, FLT_MAX, 0.0f, speed_buf);

    const float header_gap = 6.0f * ui_scale;
    const float unit_gap_x = 6.0f * ui_scale;
    const float graph_gap = 8.0f * ui_scale;
    const float title_y = card_min.y + pad_y;
    const ImVec2 title_pos(card_min.x + pad_x, title_y - title_off);
    draw_list->AddText(title_font, title_size, title_pos, ImGui::GetColorU32(text_dim), "Speed Graph");
    const float stat_row_y = title_y + title_size + header_gap;
    const float speed_row_visual_top = stat_row_y - value_off;
    const float speed_row_visual_bottom = speed_row_visual_top + value_size;
    const float title_row_visual_top = title_y - caption_off + (title_size - caption_size) * 0.5f;
    const float title_row_visual_bottom = title_row_visual_top + caption_size;
    draw_list->AddText(
        title_font,
        value_size,
        ImVec2(card_min.x + pad_x, stat_row_y - value_off),
        ImGui::GetColorU32(text_main),
        speed_buf
    );
    const float unit_y = stat_row_y + (value_size - caption_size) * 0.58f - caption_off;
    draw_list->AddText(
        title_font,
        caption_size,
        ImVec2(card_min.x + pad_x + speed_size.x + unit_gap_x, unit_y),
        ImGui::GetColorU32(text_dim),
        "u/s"
    );
    const float peak_x = card_max.x - pad_y - peak_size.x;
    const float peak_y = title_y + (title_size - caption_size) * 0.5f - caption_off;
    draw_list->AddText(
        title_font,
        caption_size,
        ImVec2(peak_x, peak_y),
        ImGui::GetColorU32(text_dim),
        peak_buf
    );

    const float header_bottom = std::max(speed_row_visual_bottom, title_row_visual_bottom);
    const float graph_left = card_min.x + ((stripe_side == EdgeStripeSide::Left) ? pad_x : 0.0f);
    const float graph_right = card_max.x - ((stripe_side == EdgeStripeSide::Right) ? pad_y : 0.0f);
    const ImVec2 graph_min(graph_left, header_bottom + graph_gap);
    const ImVec2 graph_max(graph_right, card_max.y - 14.0f * ui_scale);
    const float graph_w = std::max(1.0f, graph_max.x - graph_min.x);
    const float graph_h = std::max(1.0f, graph_max.y - graph_min.y);

    const float line_thickness = 3.4f * ui_scale;
    const float line_radius = line_thickness * 0.5f;
    const float bloom_radius = (post_processing.flags.glow ? 22.0f : 6.5f) * ui_scale;
    const float graph_pad_x = 0.0f;
    const float graph_pad_y = std::max(2.0f * ui_scale, line_radius + 1.25f * ui_scale);
    const float usable_w = std::max(1.0f, graph_w - graph_pad_x * 2.0f);
    const float usable_h = std::max(1.0f, graph_h - graph_pad_y * 2.0f);
    const float motion_gain = 1.12f;
    const float graph_tick = 1.0f / 36.0f;
    static float s_graph_update_accum = 0.0f;
    static int s_cached_graph_tex_w = 0;
    static int s_cached_graph_tex_h = 0;
    static size_t s_cached_sample_count = 0;
    static std::array<float, Axlebolt::PlayerControllerHook::kHistoryCapacity> s_cached_history{};
    static std::vector<ImVec2> s_prev_render_points;
    static std::vector<ImVec2> s_target_render_points;
    static std::vector<ImVec2> s_display_render_points;

    const size_t points = std::max<size_t>(sample_count, 2);
    s_graph_update_accum += dt;
    bool graph_geometry_dirty = s_cached_graph_tex_w != (int)std::round(graph_w) ||
                                s_cached_graph_tex_h != (int)std::round(graph_h) ||
                                s_cached_sample_count != sample_count ||
                                s_target_render_points.size() < 2;
    bool graph_data_dirty = graph_geometry_dirty;
    if (!graph_data_dirty) {
        for (size_t i = 0; i < sample_count; ++i) {
            if (std::fabs(s_cached_history[i] - history[i]) > 0.01f) {
                graph_data_dirty = true;
                break;
            }
        }
    }

    const bool should_refresh_graph = graph_geometry_dirty || (graph_data_dirty && s_graph_update_accum >= graph_tick);
    if (should_refresh_graph) {
        s_graph_update_accum = 0.0f;
        float max_speed = std::max(peak_speed, 1.0f);
        for (size_t i = 0; i < sample_count; ++i) {
            max_speed = std::max(max_speed, history[i]);
            s_cached_history[i] = history[i];
        }
        s_cached_sample_count = sample_count;
        s_cached_graph_tex_w = (int)std::round(graph_w);
        s_cached_graph_tex_h = (int)std::round(graph_h);

        const std::vector<float> smoothed_history = SmoothSamples(history.data(), sample_count);
        std::vector<ImVec2> polyline;
        polyline.reserve(points);
        for (size_t i = 0; i < points; ++i) {
            const float sample = (i < sample_count) ? smoothed_history[i] : s_display_speed;
            const float t = (points > 1) ? ((float)i / (float)(points - 1)) : 0.0f;
            const float normalized = std::clamp(sample / std::max(1.0f, max_speed), 0.0f, 1.0f);
            const float boosted = std::clamp(normalized * motion_gain, 0.0f, 1.0f);
            const float x = graph_min.x + graph_pad_x + usable_w * t;
            const float y = graph_max.y - graph_pad_y - usable_h * boosted;
            polyline.push_back(ImVec2(x, y));
        }

        const std::vector<ImVec2> smooth = BuildCatmullRomPolyline(polyline, 4);
        if (smooth.size() >= 2) {
            std::vector<ImVec2> next_target = ResamplePolyline(
                smooth,
                std::min<size_t>(smooth.size(), kSpeedGraphShaderMaxPoints));
            if (next_target.size() >= 2) {
                if (s_target_render_points.size() == next_target.size()) {
                    s_prev_render_points = s_display_render_points.empty() ? s_target_render_points : s_display_render_points;
                } else {
                    s_prev_render_points = next_target;
                }
                s_target_render_points = std::move(next_target);
                if (s_display_render_points.size() != s_target_render_points.size()) {
                    s_display_render_points = s_target_render_points;
                }
            }
        } else {
            s_prev_render_points.clear();
            s_target_render_points.clear();
            s_display_render_points.clear();
        }
    }

    float interp_t = std::clamp(s_graph_update_accum / std::max(graph_tick, 1e-4f), 0.0f, 1.0f);
    interp_t = interp_t * interp_t * (3.0f - 2.0f * interp_t);
    if (s_target_render_points.size() >= 2) {
        if (s_prev_render_points.size() != s_target_render_points.size()) {
            s_prev_render_points = s_target_render_points;
        }
        s_display_render_points.resize(s_target_render_points.size());
        for (size_t i = 0; i < s_target_render_points.size(); ++i) {
            s_display_render_points[i].x = ImLerp(s_prev_render_points[i].x, s_target_render_points[i].x, interp_t);
            s_display_render_points[i].y = ImLerp(s_prev_render_points[i].y, s_target_render_points[i].y, interp_t);
        }
    }

    const std::vector<ImVec2>& render_points = s_display_render_points;
    if (render_points.size() >= 2) {
        const float glow_pad = std::ceil(std::max(6.0f * ui_scale, bloom_radius * 2.2f + line_radius * 1.5f));
        float min_y = render_points[0].y;
        float max_y = render_points[0].y;
        for (const ImVec2& p : render_points) {
            min_y = std::min(min_y, p.y);
            max_y = std::max(max_y, p.y);
        }
        const float y_span = max_y - min_y;
        const float idle_end_caps = (sample_count <= 2 || y_span <= std::max(3.25f * ui_scale, line_radius * 2.1f)) ? 1.0f : 0.0f;
        std::unique_ptr<SpeedGraphRenderJob> job = std::make_unique<SpeedGraphRenderJob>();
        job->screen_x = std::max(0, (int)std::floor(graph_min.x - glow_pad));
        job->screen_y = std::max(0, (int)std::floor(graph_min.y - glow_pad));
        job->display_h = ctx.gl_height;
        const int screen_x1 = std::min(ctx.gl_width, (int)std::ceil(graph_max.x + glow_pad));
        const int screen_y1 = std::min(ctx.gl_height, (int)std::ceil(graph_max.y + glow_pad));
        job->width = std::max(2, screen_x1 - job->screen_x);
        job->height = std::max(2, screen_y1 - job->screen_y);
        job->point_count = (int)render_points.size();
        job->line_radius_px = std::max(0.8f, line_radius);
        job->glow_radius_px = std::max(job->line_radius_px + 1.0f, bloom_radius);
        job->glow_alpha = post_processing.flags.glow ? 0.56f : 0.0f;
        job->end_cap_alpha = idle_end_caps;
        ImVec4 grad_start, grad_end;
        theme->GetResolvedAccentGradient(grad_start, grad_end);
        job->color = ImVec4(grad_start.x, grad_start.y, grad_start.z, 0.98f);
        job->color2 = ImVec4(grad_end.x, grad_end.y, grad_end.z, 0.98f);
        job->band_spacing_px = theme->GetAnimatedAccentEnabled()
            ? std::max(12.0f, graph_w * theme->GetAnimatedAccentColorSpacing())
            : 0.0f;
        job->band_offset_px = (float)job->screen_x;
        job->band_time = (float)ImGui::GetTime() * theme->GetAnimatedAccentSpeed();
        job->band_smoothness = theme->GetAnimatedAccentSmoothness();
        job->band_strength = theme->GetAnimatedAccentEnabled()
            ? std::clamp(theme->GetAnimatedAccentStrength(), 0.0f, 1.0f)
            : 0.0f;
        for (int i = 0; i < job->point_count; ++i) {
            job->points[(size_t)i] = ImVec2(
                render_points[(size_t)i].x - (float)job->screen_x,
                render_points[(size_t)i].y - (float)job->screen_y
            );
        }
        const ImVec2 glow_clip_min((float)job->screen_x, (float)job->screen_y);
        const ImVec2 glow_clip_max((float)(job->screen_x + job->width), (float)(job->screen_y + job->height));
        draw_list->PushClipRect(glow_clip_min, glow_clip_max, true);
        draw_list->AddCallback(SpeedGraphRenderCallback, job.release());
        draw_list->AddCallback(ImDrawCallback_ResetRenderState, nullptr);
        draw_list->PopClipRect();
    } else if (s_target_render_points.size() >= 2) {
        draw_list->PushClipRect(graph_min, graph_max, true);
        draw_list->AddPolyline(
            s_target_render_points.data(),
            (int)s_target_render_points.size(),
            ImGui::GetColorU32(ImVec4(accent.x, accent.y, accent.z, 0.98f)),
            ImDrawFlags_None,
            line_thickness
        );
        draw_list->PopClipRect();
    }
}

static constexpr int kRecorderVizOcclusionMask =
    1 |
    (1 << 15) |
    (1 << 24) |
    (1 << 25);

static bool RecorderWorldToScreen(const RenderContext& ctx, const Vector3& world, ImVec2& out_screen) {
    using namespace Axlebolt::PlayerControllerHook;
    if (ctx.gl_width <= 0 || ctx.gl_height <= 0 || !EnsureRecorderWorldVizApi()) {
        return false;
    }
    void* camera = RecorderVizGetMainCamera();
    if (!camera) {
        return false;
    }
    Matrix4x4 view{};
    Matrix4x4 proj{};
    if (!RecorderVizGetViewProjection(camera, view, proj)) {
        return false;
    }
    const float vx = view(0, 0) * world.x + view(1, 0) * world.y + view(2, 0) * world.z + view(3, 0);
    const float vy = view(0, 1) * world.x + view(1, 1) * world.y + view(2, 1) * world.z + view(3, 1);
    const float vz = view(0, 2) * world.x + view(1, 2) * world.y + view(2, 2) * world.z + view(3, 2);
    const float vw = view(0, 3) * world.x + view(1, 3) * world.y + view(2, 3) * world.z + view(3, 3);

    const float cx = proj(0, 0) * vx + proj(1, 0) * vy + proj(2, 0) * vz + proj(3, 0) * vw;
    const float cy = proj(0, 1) * vx + proj(1, 1) * vy + proj(2, 1) * vz + proj(3, 1) * vw;
    const float cz = proj(0, 2) * vx + proj(1, 2) * vy + proj(2, 2) * vz + proj(3, 2) * vw;
    const float cw = proj(0, 3) * vx + proj(1, 3) * vy + proj(2, 3) * vz + proj(3, 3) * vw;

    if (!std::isfinite(cx) || !std::isfinite(cy) || !std::isfinite(cz) || !std::isfinite(cw)) {
        return false;
    }
    if (std::fabs(cw) <= 0.0001f || cw <= 0.0f) {
        return false;
    }
    const float inv_w = 1.0f / cw;
    const float ndc_x = cx * inv_w;
    const float ndc_y = cy * inv_w;
    const float ndc_z = cz * inv_w;
    if (!std::isfinite(ndc_x) || !std::isfinite(ndc_y) || !std::isfinite(ndc_z)) {
        return false;
    }
    constexpr float kEdgeFadeMargin = 28.0f;
    const float sx = (ndc_x * 0.5f + 0.5f) * (float)ctx.gl_width;
    const float sy = (1.0f - (ndc_y * 0.5f + 0.5f)) * (float)ctx.gl_height;
    if (sx < -kEdgeFadeMargin || sx > (float)ctx.gl_width + kEdgeFadeMargin ||
        sy < -kEdgeFadeMargin || sy > (float)ctx.gl_height + kEdgeFadeMargin) {
        return false;
    }
    out_screen.x = sx;
    out_screen.y = sy;
    return std::isfinite(out_screen.x) && std::isfinite(out_screen.y) &&
           out_screen.x >= -kEdgeFadeMargin && out_screen.x <= (float)ctx.gl_width + kEdgeFadeMargin &&
           out_screen.y >= -kEdgeFadeMargin && out_screen.y <= (float)ctx.gl_height + kEdgeFadeMargin;
}

static float RecorderScreenEdgeAlpha(const RenderContext& ctx, const ImVec2& p) {
    const float margin_x = std::clamp((float)ctx.gl_width * 0.018f, 12.0f, 24.0f);
    const float margin_y = std::clamp((float)ctx.gl_height * 0.022f, 14.0f, 28.0f);
    const float left = std::clamp((p.x - margin_x) / margin_x, 0.0f, 1.0f);
    const float right = std::clamp((((float)ctx.gl_width - margin_x) - p.x) / margin_x, 0.0f, 1.0f);
    const float top = std::clamp((p.y - margin_y) / margin_y, 0.0f, 1.0f);
    const float bottom = std::clamp((((float)ctx.gl_height - margin_y) - p.y) / margin_y, 0.0f, 1.0f);
    const float t = std::min(std::min(left, right), std::min(top, bottom));
    return t * t * (3.0f - 2.0f * t);
}

static void DrawRecorderFadedSegment(ImDrawList* draw_list,
                                     const RenderContext& ctx,
                                     ImVec2 a,
                                     ImVec2 b,
                                     const ImVec4& color_a,
                                     const ImVec4& color_b,
                                     float line_thickness,
                                     float glow_extra,
                                     float shadow_extra) {
    if (!draw_list) {
        return;
    }
    const float dx = b.x - a.x;
    const float dy = b.y - a.y;
    const float length = std::sqrt(dx * dx + dy * dy);
    const int steps = std::clamp((int)std::ceil(length / 28.0f), 1, 12);
    for (int i = 0; i < steps; ++i) {
        const float t0 = (float)i / (float)steps;
        const float t1 = (float)(i + 1) / (float)steps;
        const ImVec2 p0(ImLerp(a.x, b.x, t0), ImLerp(a.y, b.y, t0));
        const ImVec2 p1(ImLerp(a.x, b.x, t1), ImLerp(a.y, b.y, t1));
        const ImVec2 mid(ImLerp(p0.x, p1.x, 0.5f), ImLerp(p0.y, p1.y, 0.5f));
        const float edge_alpha = RecorderScreenEdgeAlpha(ctx, mid);
        if (edge_alpha <= 0.001f) {
            continue;
        }
        const float blend_t = (t0 + t1) * 0.5f;
        ImVec4 seg(
            ImLerp(color_a.x, color_b.x, blend_t),
            ImLerp(color_a.y, color_b.y, blend_t),
            ImLerp(color_a.z, color_b.z, blend_t),
            ImLerp(color_a.w, color_b.w, blend_t)
        );
        seg.w *= edge_alpha;
        const ImVec4 shadow(0.0f, 0.0f, 0.0f, seg.w * 0.22f);
        const ImVec4 glow(seg.x, seg.y, seg.z, seg.w * 0.72f);
        draw_list->AddLine(p0, p1, ImGui::GetColorU32(shadow), line_thickness + shadow_extra);
        draw_list->AddLine(p0, p1, ImGui::GetColorU32(glow), line_thickness + glow_extra);
        draw_list->AddLine(p0, p1, ImGui::GetColorU32(seg), line_thickness);
    }
}

static void DrawRecorderGradientCircle(ImDrawList* draw_list,
                                       const RenderContext& ctx,
                                       Theme* theme,
                                       const ImVec2& center,
                                       float radius,
                                       float thickness,
                                       float alpha,
                                       bool horizontal_gradient) {
    if (!draw_list || !theme || alpha <= 0.001f) {
        return;
    }
    constexpr int kSegments = 40;
    const float glow_r = radius + thickness * 1.9f;
    const ImVec4 glow_col = ResolveAnimatedStripeTint(
        theme,
        horizontal_gradient ? center.x : center.y,
        horizontal_gradient ? std::max(1.0f, (float)ctx.gl_width) : std::max(1.0f, (float)ctx.gl_height),
        horizontal_gradient,
        alpha * 0.24f
    );
    draw_list->AddCircleFilled(center, glow_r, ImGui::GetColorU32(glow_col), kSegments);

    for (int i = 0; i < kSegments; ++i) {
        const float t0 = (float)i / (float)kSegments;
        const float t1 = (float)(i + 1) / (float)kSegments;
        const float a0 = t0 * IM_PI * 2.0f;
        const float a1 = t1 * IM_PI * 2.0f;
        const ImVec2 p0(center.x + std::cos(a0) * radius, center.y + std::sin(a0) * radius);
        const ImVec2 p1(center.x + std::cos(a1) * radius, center.y + std::sin(a1) * radius);
        const ImVec2 mid((p0.x + p1.x) * 0.5f, (p0.y + p1.y) * 0.5f);
        const float edge_alpha = RecorderScreenEdgeAlpha(ctx, mid);
        if (edge_alpha <= 0.001f) {
            continue;
        }
        const ImVec4 col0 = ResolveAnimatedStripeTint(
            theme,
            horizontal_gradient ? p0.x : p0.y,
            horizontal_gradient ? std::max(1.0f, (float)ctx.gl_width) : std::max(1.0f, (float)ctx.gl_height),
            horizontal_gradient,
            alpha * edge_alpha
        );
        const ImVec4 col1 = ResolveAnimatedStripeTint(
            theme,
            horizontal_gradient ? p1.x : p1.y,
            horizontal_gradient ? std::max(1.0f, (float)ctx.gl_width) : std::max(1.0f, (float)ctx.gl_height),
            horizontal_gradient,
            alpha * edge_alpha
        );
        draw_list->AddLine(p0, p1, ImGui::GetColorU32(ImVec4(col0.x, col0.y, col0.z, col0.w * 0.68f)), thickness + std::max(1.0f, thickness * 0.9f));
        draw_list->AddLine(p0, p1, ImGui::GetColorU32(col1), thickness);
    }
}

static Vector3 RecorderCameraPosition() {
    using namespace Axlebolt::PlayerControllerHook;
    if (!EnsureRecorderWorldVizApi() || !g_component_get_transform || !g_transform_get_position_injected) {
        return {};
    }
    void* camera = RecorderVizGetMainCamera();
    if (!camera) {
        return {};
    }
    void* transform = g_component_get_transform(camera);
    if (!transform) {
        return {};
    }
    Vector3 position{};
    g_transform_get_position_injected(transform, position);
    return position;
}

static Vector3 RecorderCameraForward() {
    using namespace Axlebolt::PlayerControllerHook;
    if (!EnsureRecorderWorldVizApi() || !g_component_get_transform || !g_transform_get_rotation_injected) {
        return Vector3::forward();
    }
    void* camera = RecorderVizGetMainCamera();
    if (!camera) {
        return Vector3::forward();
    }
    void* transform = g_component_get_transform(camera);
    if (!transform) {
        return Vector3::forward();
    }
    Quaternion rotation{};
    g_transform_get_rotation_injected(transform, rotation);
    Vector3 forward = (rotation * Vector3::forward()).normalized();
    if (!std::isfinite(forward.x) || !std::isfinite(forward.y) || !std::isfinite(forward.z) || forward.sqrMagnitude() <= 0.0001f) {
        return Vector3::forward();
    }
    return forward;
}

static float RecorderCameraDepth(const Vector3& camera_position, const Vector3& camera_forward, const Vector3& point) {
    return Vector3::Dot(point - camera_position, camera_forward);
}

static bool RecorderClipSegmentToNearPlane(const Vector3& camera_position,
                                           const Vector3& camera_forward,
                                           float near_plane,
                                           Vector3& a,
                                           Vector3& b) {
    const float da = RecorderCameraDepth(camera_position, camera_forward, a);
    const float db = RecorderCameraDepth(camera_position, camera_forward, b);
    if (da < near_plane && db < near_plane) {
        return false;
    }
    if (da >= near_plane && db >= near_plane) {
        return true;
    }
    const float denom = (db - da);
    if (std::fabs(denom) <= 0.00001f) {
        return false;
    }
    const float t = std::clamp((near_plane - da) / denom, 0.0f, 1.0f);
    const Vector3 clipped = Vector3::Lerp(a, b, t);
    if (da < near_plane) {
        a = clipped;
    } else {
        b = clipped;
    }
    return true;
}

static bool RecorderPointOccluded(const Vector3& camera_position, const Vector3& point) {
    using namespace Axlebolt::PlayerControllerHook;
    if (!EnsureRecorderWorldVizApi()) {
        return false;
    }
    const Vector3 start = camera_position + Vector3(0.0f, 0.04f, 0.0f);
    const Vector3 end = point + Vector3(0.0f, 0.06f, 0.0f);
    return RecorderVizLinecast(start, end, kRecorderVizOcclusionMask);
}

static void DrawRecorderWorldCircle(ImDrawList* draw_list, const RenderContext& ctx, const Vector3& center,
                                    float radius, ImU32 color, float thickness) {
    constexpr int kSegments = 36;
    std::array<ImVec2, kSegments + 1> points{};
    int valid_count = 0;
    float edge_alpha = 1.0f;
    for (int i = 0; i <= kSegments; ++i) {
        const float a = ((float)i / (float)kSegments) * IM_PI * 2.0f;
        const Vector3 world(center.x + std::cos(a) * radius, center.y + 0.03f, center.z + std::sin(a) * radius);
        ImVec2 screen{};
        if (!RecorderWorldToScreen(ctx, world, screen)) {
            return;
        }
        edge_alpha = std::min(edge_alpha, RecorderScreenEdgeAlpha(ctx, screen));
        points[(size_t)valid_count++] = screen;
    }
    if (valid_count >= 3 && edge_alpha > 0.001f) {
        ImVec4 c = ImGui::ColorConvertU32ToFloat4(color);
        c.w *= edge_alpha;
        draw_list->AddPolyline(points.data(), valid_count, ImGui::GetColorU32(c), ImDrawFlags_Closed, thickness);
    }
}

static void DrawRecorderGradientWorldRing(ImDrawList* draw_list,
                                          const RenderContext& ctx,
                                          Theme* theme,
                                          const Vector3& center,
                                          float radius,
                                          float thickness,
                                          float alpha,
                                          bool horizontal_gradient,
                                          bool glow_enabled) {
    if (!draw_list || !theme || alpha <= 0.001f) {
        return;
    }
    constexpr int kSegments = 40;
    std::array<ImVec2, kSegments + 1> points{};
    std::array<ImVec4, kSegments + 1> colors{};
    int valid_count = 0;
    for (int i = 0; i <= kSegments; ++i) {
        const float a = ((float)i / (float)kSegments) * IM_PI * 2.0f;
        const Vector3 world(center.x + std::cos(a) * radius, center.y + 0.03f, center.z + std::sin(a) * radius);
        ImVec2 screen{};
        if (!RecorderWorldToScreen(ctx, world, screen)) {
            return;
        }
        const float edge_alpha = RecorderScreenEdgeAlpha(ctx, screen);
        if (edge_alpha <= 0.001f) {
            return;
        }
        points[(size_t)valid_count] = screen;
        colors[(size_t)valid_count] = ResolveAnimatedStripeTint(
            theme,
            horizontal_gradient ? screen.x : screen.y,
            horizontal_gradient ? std::max(1.0f, (float)ctx.gl_width) : std::max(1.0f, (float)ctx.gl_height),
            horizontal_gradient,
            alpha * edge_alpha
        );
        ++valid_count;
    }

    if (valid_count < 3) {
        return;
    }

    if (glow_enabled) {
        for (int ring = 0; ring < 2; ++ring) {
            const float mul = (ring == 0) ? 1.7f : 1.25f;
            for (int i = 1; i < valid_count; ++i) {
                ImVec4 glow = colors[(size_t)i];
                glow.w *= (ring == 0) ? 0.16f : 0.24f;
                draw_list->AddLine(points[(size_t)i - 1], points[(size_t)i], ImGui::GetColorU32(glow), thickness * mul);
            }
        }
    }

    for (int i = 1; i < valid_count; ++i) {
        draw_list->AddLine(points[(size_t)i - 1], points[(size_t)i], ImGui::GetColorU32(colors[(size_t)i]), thickness);
    }
}

static void DrawRecorderShaderPolyline(ImDrawList* draw_list,
                                       Theme* theme,
                                       const RenderContext& ctx,
                                       const std::vector<ImVec2>& points,
                                       float alpha,
                                       float ui_scale,
                                       bool glow_enabled,
                                       bool horizontal_gradient,
                                       float end_cap_alpha = 1.0f,
                                       float band_spacing_scale = 1.0f) {
    if (!draw_list || !theme || points.size() < 2 || alpha <= 0.001f) {
        return;
    }
    EnsureSpeedGraphRenderer();
    if (g_speed_graph_prog == 0) {
        return;
    }

    std::vector<ImVec2> filtered;
    filtered.reserve(points.size());
    for (const ImVec2& p : points) {
        if (filtered.empty()) {
            filtered.push_back(p);
            continue;
        }
        const float dx = filtered.back().x - p.x;
        const float dy = filtered.back().y - p.y;
        if ((dx * dx + dy * dy) > 1.0f) {
            filtered.push_back(p);
        }
    }
    if (filtered.size() < 2) {
        return;
    }

    float min_x = filtered[0].x;
    float min_y = filtered[0].y;
    float max_x = filtered[0].x;
    float max_y = filtered[0].y;
    for (const ImVec2& p : filtered) {
        min_x = std::min(min_x, p.x);
        min_y = std::min(min_y, p.y);
        max_x = std::max(max_x, p.x);
        max_y = std::max(max_y, p.y);
    }

    const float path_line_thickness = std::max(3.0f, 4.2f * ui_scale);
    const float line_radius = path_line_thickness * 0.5f;
    const float glow_radius = std::max(line_radius + 1.0f, 22.0f * ui_scale);
    const float glow_pad = std::ceil(std::max(6.0f * ui_scale, glow_radius * 2.25f));

    std::unique_ptr<SpeedGraphRenderJob> job = std::make_unique<SpeedGraphRenderJob>();
    job->screen_x = std::max(0, (int)std::floor(min_x - glow_pad));
    job->screen_y = std::max(0, (int)std::floor(min_y - glow_pad));
    job->display_h = ctx.gl_height;
    const int screen_x1 = std::min(ctx.gl_width, (int)std::ceil(max_x + glow_pad));
    const int screen_y1 = std::min(ctx.gl_height, (int)std::ceil(max_y + glow_pad));
    job->width = std::max(2, screen_x1 - job->screen_x);
    job->height = std::max(2, screen_y1 - job->screen_y);
    job->point_count = (int)std::min<size_t>(filtered.size(), kSpeedGraphShaderMaxPoints);
    job->line_radius_px = std::max(1.2f, line_radius);
    job->glow_radius_px = glow_radius;
    job->glow_alpha = glow_enabled ? (0.56f * alpha) : 0.0f;
    job->end_cap_alpha = end_cap_alpha;
    theme->GetResolvedAccentGradient(job->color, job->color2);
    job->color.w = 0.98f * alpha;
    job->color2.w = 0.98f * alpha;
    const float axis_extent = horizontal_gradient
        ? std::max(24.0f, (float)ctx.gl_width)
        : std::max(24.0f, (float)ctx.gl_height);
    job->band_spacing_px = theme->GetAnimatedAccentEnabled()
        ? std::max(12.0f, axis_extent * theme->GetAnimatedAccentColorSpacing() * std::clamp(band_spacing_scale, 0.25f, 2.0f))
        : 0.0f;
    job->band_offset_px = (float)job->screen_x;
    job->band_time = (float)ImGui::GetTime() * theme->GetAnimatedAccentSpeed();
    job->band_smoothness = theme->GetAnimatedAccentSmoothness();
    job->band_strength = theme->GetAnimatedAccentEnabled()
        ? std::clamp(theme->GetAnimatedAccentStrength(), 0.0f, 1.0f)
        : 0.0f;

    const size_t stride = std::max<size_t>(1, filtered.size() / (size_t)job->point_count);
    int out_i = 0;
    for (size_t src = 0; src < filtered.size() && out_i < job->point_count; src += stride, ++out_i) {
        job->points[(size_t)out_i] = ImVec2(
            filtered[src].x - (float)job->screen_x,
            filtered[src].y - (float)job->screen_y
        );
    }
    job->point_count = std::max(2, std::min(out_i, job->point_count));
    draw_list->PushClipRect(
        ImVec2((float)job->screen_x, (float)job->screen_y),
        ImVec2((float)(job->screen_x + job->width), (float)(job->screen_y + job->height)),
        true
    );
    draw_list->AddCallback(SpeedGraphRenderCallback, job.release());
    draw_list->AddCallback(ImDrawCallback_ResetRenderState, nullptr);
    draw_list->PopClipRect();
}

static void DrawRecorderShaderWorldRing(ImDrawList* draw_list,
                                        Theme* theme,
                                        const RenderContext& ctx,
                                        const Vector3& center,
                                        float radius,
                                        float alpha,
                                        float ui_scale,
                                        bool glow_enabled,
                                        float band_spacing_scale) {
    if (!draw_list || !theme || alpha <= 0.001f) {
        return;
    }
    constexpr int kSegments = 40;
    std::vector<ImVec2> ring_points;
    ring_points.reserve(kSegments + 1);
    for (int i = 0; i <= kSegments; ++i) {
        const float a = ((float)i / (float)kSegments) * IM_PI * 2.0f;
        const Vector3 world(center.x + std::cos(a) * radius, center.y + 0.03f, center.z + std::sin(a) * radius);
        ImVec2 screen{};
        if (!RecorderWorldToScreen(ctx, world, screen)) {
            return;
        }
        if (RecorderScreenEdgeAlpha(ctx, screen) <= 0.001f) {
            return;
        }
        ring_points.push_back(screen);
    }
    DrawRecorderShaderPolyline(
        draw_list,
        theme,
        ctx,
        ring_points,
        alpha,
        ui_scale,
        glow_enabled,
        true,
        0.0f,
        band_spacing_scale
    );
}

static void BuildRecorderHexShape(const Vector3& center,
                                  const Vector3& dir_hint,
                                  float radius,
                                  std::vector<Vector3>& out_main,
                                  std::vector<Vector3>& out_left_leg,
                                  Vector3& out_tip) {
    Vector3 dir = dir_hint;
    dir.y = 0.0f;
    if (dir.sqrMagnitude() <= 0.0001f) {
        dir = Vector3(0.0f, 0.0f, 1.0f);
    } else {
        dir = dir.normalized();
    }
    const Vector3 right(dir.z, 0.0f, -dir.x);
    auto P = [&](float forward, float side) {
        return center + dir * forward + right * side + Vector3(0.0f, 0.03f, 0.0f);
    };

    out_main.clear();
    out_left_leg.clear();
    out_main.reserve(6);
    out_left_leg.reserve(3);

    const Vector3 back_left    = P(-radius * 0.56f, -radius * 0.34f);
    const Vector3 back_right   = P(-radius * 0.56f,  radius * 0.34f);
    const Vector3 upper_right  = P(-radius * 0.08f,  radius * 0.64f);
    const Vector3 front_right  = P( radius * 0.40f,  radius * 0.34f);
    const Vector3 tip_base     = P( radius * 0.40f,  0.0f);
    out_tip                    = P( radius * 0.82f,  0.0f);
    const Vector3 front_left   = P( radius * 0.40f, -radius * 0.34f);
    const Vector3 upper_left   = P(-radius * 0.08f, -radius * 0.64f);

    out_main.push_back(back_left);
    out_main.push_back(back_right);
    out_main.push_back(upper_right);
    out_main.push_back(front_right);
    out_main.push_back(tip_base);
    out_main.push_back(out_tip);

    out_left_leg.push_back(front_left);
    out_left_leg.push_back(upper_left);
    out_left_leg.push_back(back_left);
}

static bool TrimRecorderSegmentToMarkerCircle(Vector3& a,
                                              Vector3& b,
                                              const Vector3& center,
                                              float radius,
                                              bool trim_start) {
    const ImVec2 pa(a.x - center.x, a.z - center.z);
    const ImVec2 pb(b.x - center.x, b.z - center.z);
    const ImVec2 d(pb.x - pa.x, pb.y - pa.y);
    const float A = d.x * d.x + d.y * d.y;
    if (A <= 0.000001f) {
        return false;
    }
    const float B = 2.0f * (pa.x * d.x + pa.y * d.y);
    const float C = pa.x * pa.x + pa.y * pa.y - radius * radius;
    const float disc = B * B - 4.0f * A * C;
    if (disc < 0.0f) {
        return false;
    }
    const float sqrt_disc = std::sqrt(disc);
    const float t0 = (-B - sqrt_disc) / (2.0f * A);
    const float t1 = (-B + sqrt_disc) / (2.0f * A);
    const bool a_inside = (pa.x * pa.x + pa.y * pa.y) < (radius * radius);
    const bool b_inside = (pb.x * pb.x + pb.y * pb.y) < (radius * radius);
    float t = -1.0f;
    if (trim_start) {
        if (a_inside && !b_inside) {
            t = std::max(t0, t1);
        } else if (!a_inside && !b_inside && t0 >= 0.0f && t0 <= 1.0f) {
            t = t0;
        }
    } else {
        if (!a_inside && b_inside) {
            t = std::min(std::max(t0, 0.0f), std::max(t1, 0.0f));
            if (!(t >= 0.0f && t <= 1.0f)) {
                t = std::min(t0, t1);
            }
        } else if (!a_inside && !b_inside && t1 >= 0.0f && t1 <= 1.0f) {
            t = t1;
        }
    }
    if (!(t >= 0.0f && t <= 1.0f)) {
        return false;
    }
    const Vector3 hit = Vector3::Lerp(a, b, t);
    if (trim_start) {
        a = hit;
    } else {
        b = hit;
    }
    return true;
}

static ImVec4 DimRecorderColor(const ImVec4& color, float dim_rgb, float alpha_mul) {
    return ImVec4(
        color.x * dim_rgb,
        color.y * dim_rgb,
        color.z * dim_rgb,
        color.w * alpha_mul
    );
}

static void RenderMovementRecorderWorldViz(const RenderContext& ctx,
                                           ImDrawList* draw_list,
                                           Theme* theme,
                                           const Axlebolt::PlayerControllerHook::RecorderSnapshot& snapshot,
                                           float ui_scale) {
    using namespace Axlebolt::PlayerControllerHook;
    if (!draw_list || !theme || !snapshot.viz_has_path) {
        return;
    }
    if (!EnsureRecorderWorldVizApi()) {
        return;
    }
    const bool playback_visible = snapshot.mode == RecorderMode::Playback;
    const bool recording_visible = snapshot.mode == RecorderMode::Recording;
    const bool seeking_visible = snapshot.mode == RecorderMode::SeekingStart;
    const bool draw_start_target = true;
    const float path_alpha = std::clamp(snapshot.viz_alpha, 0.0f, 1.0f);
    const bool draw_path = path_alpha > 0.001f && snapshot.viz_points.size() >= 2;
    const float reveal_norm = (recording_visible ? 1.0f : path_alpha);
    const float reveal_time = snapshot.viz_points.empty()
        ? 0.0f
        : ImLerp(0.0f, snapshot.viz_points.back().time, reveal_norm);

    const Vector3 render_current_position = snapshot.has_late_current_position
        ? snapshot.late_current_position
        : snapshot.current_position;
    const bool have_render_current_position = snapshot.has_late_current_position || snapshot.has_current_position;

    const Vector3 camera_position = RecorderCameraPosition();
    const Vector3 camera_forward = RecorderCameraForward();
    const bool have_camera = std::fabs(camera_position.x) > 0.0001f || std::fabs(camera_position.y) > 0.0001f || std::fabs(camera_position.z) > 0.0001f;
    const bool start_occluded = have_camera && RecorderPointOccluded(camera_position, snapshot.viz_start_position);
    ImVec4 grad_a, grad_b;
    theme->GetResolvedAccentGradient(grad_a, grad_b);
    const float alpha_scale = post_processing.flags.blur ? 0.92f : 1.0f;
    const bool glow_enabled = post_processing.flags.glow;
    const float line_thickness = std::max(1.8f, 2.6f * ui_scale);
    const float recorder_band_spacing_scale = 0.86f;

    const float marker_radius = std::max(0.22f, snapshot.start_radius);
    size_t progress_index = 0;
    std::vector<float> cumulative(snapshot.viz_points.size(), 0.0f);
    if (draw_path) {
        for (size_t i = 1; i < snapshot.viz_points.size(); ++i) {
            cumulative[i] = cumulative[i - 1] + Vector3::Distance(snapshot.viz_points[i - 1].world_position, snapshot.viz_points[i].world_position);
            if (snapshot.viz_points[i].time >= snapshot.viz_progress_time && progress_index == 0) {
                progress_index = i;
            }
        }
        if (progress_index == 0 && snapshot.viz_points.size() > 1) {
            progress_index = snapshot.viz_points.size() - 1;
        }
    }
    const float progress_dist = (!cumulative.empty() ? cumulative[progress_index] : 0.0f);

    if (draw_start_target) {
        float start_alpha_mul = 1.0f;
        if (recording_visible || playback_visible) {
            start_alpha_mul = 1.0f - std::clamp(progress_dist / std::max(0.25f, marker_radius * 0.95f), 0.0f, 1.0f);
        }
        const float start_shape_alpha = (start_occluded ? 0.20f : 0.92f) * alpha_scale * start_alpha_mul;
        DrawRecorderShaderWorldRing(
            draw_list,
            theme,
            ctx,
            snapshot.viz_start_position,
            marker_radius,
            start_shape_alpha,
            ui_scale,
            glow_enabled,
            recorder_band_spacing_scale
        );
    }

    if (draw_path) {
        struct PathSeg { ImVec2 a; ImVec2 b; float alpha; };
        std::vector<PathSeg> recorder_segments;
        std::vector<ImVec2> jump_markers;
        recorder_segments.reserve(snapshot.viz_points.size());
        jump_markers.reserve(16);
        const float trail_window = 5.0f;
        const float lookahead_window = 7.5f;
        for (size_t i = 1; i < snapshot.viz_points.size(); ++i) {
            const auto& a = snapshot.viz_points[i - 1];
            const auto& b = snapshot.viz_points[i];
            if (!recording_visible && b.time > (reveal_time + 0.0001f)) {
                break;
            }
            Vector3 world_a = a.world_position;
            Vector3 world_b = b.world_position;
            const float start_da_sq =
                (world_a.x - snapshot.viz_start_position.x) * (world_a.x - snapshot.viz_start_position.x) +
                (world_a.z - snapshot.viz_start_position.z) * (world_a.z - snapshot.viz_start_position.z);
            const float start_db_sq =
                (world_b.x - snapshot.viz_start_position.x) * (world_b.x - snapshot.viz_start_position.x) +
                (world_b.z - snapshot.viz_start_position.z) * (world_b.z - snapshot.viz_start_position.z);
            if (start_da_sq < marker_radius * marker_radius && start_db_sq < marker_radius * marker_radius) {
                continue;
            }
            if (i == 1 || start_da_sq < marker_radius * marker_radius || start_db_sq < marker_radius * marker_radius) {
                TrimRecorderSegmentToMarkerCircle(world_a, world_b, snapshot.viz_start_position, marker_radius, true);
            }
            const Vector3& end_center = snapshot.viz_points.back().world_position;
            const float end_da_sq =
                (world_a.x - end_center.x) * (world_a.x - end_center.x) +
                (world_a.z - end_center.z) * (world_a.z - end_center.z);
            const float end_db_sq =
                (world_b.x - end_center.x) * (world_b.x - end_center.x) +
                (world_b.z - end_center.z) * (world_b.z - end_center.z);
            if (end_da_sq < marker_radius * marker_radius && end_db_sq < marker_radius * marker_radius) {
                continue;
            }
            if (i == snapshot.viz_points.size() - 1 || end_da_sq < marker_radius * marker_radius || end_db_sq < marker_radius * marker_radius) {
                TrimRecorderSegmentToMarkerCircle(world_a, world_b, snapshot.viz_points.back().world_position, marker_radius, false);
            }
            const float seg_mid_dist = (cumulative[i - 1] + cumulative[i]) * 0.5f;
            const float signed_dist = seg_mid_dist - progress_dist;
            float seg_alpha = 1.0f;
            if (signed_dist < 0.0f) {
                seg_alpha = 1.0f - std::clamp((-signed_dist) / std::max(0.001f, trail_window), 0.0f, 1.0f);
            } else {
                seg_alpha = 1.0f - std::clamp(signed_dist / std::max(0.001f, lookahead_window), 0.0f, 1.0f);
            }
            if (signed_dist >= 0.0f) {
                const float emerge = std::clamp((signed_dist - marker_radius * 0.55f) / std::max(0.12f, marker_radius * 0.55f), 0.0f, 1.0f);
                seg_alpha *= emerge;
            }
            if (seg_alpha <= 0.001f) {
                continue;
            }
            if (have_camera && !RecorderClipSegmentToNearPlane(camera_position, camera_forward, 0.08f, world_a, world_b)) {
                continue;
            }
            ImVec2 sa{};
            ImVec2 sb{};
            if (!RecorderWorldToScreen(ctx, world_a, sa) || !RecorderWorldToScreen(ctx, world_b, sb)) {
                continue;
            }
            const float edge_alpha = std::min(RecorderScreenEdgeAlpha(ctx, sa), RecorderScreenEdgeAlpha(ctx, sb));
            if (edge_alpha <= 0.001f) {
                continue;
            }
            recorder_segments.push_back({sa, sb, seg_alpha});

            if ((b.flags & 0x2u) != 0) {
                jump_markers.push_back(sb);
            }
        }

        for (const PathSeg& seg : recorder_segments) {
            std::vector<ImVec2> seg_points{seg.a, seg.b};
            DrawRecorderShaderPolyline(
                draw_list,
                theme,
                ctx,
                seg_points,
                path_alpha * seg.alpha * alpha_scale,
                ui_scale,
                glow_enabled,
                true,
                0.0f,
                recorder_band_spacing_scale
            );
        }

        for (const ImVec2& jump_p : jump_markers) {
            const float jump_alpha = 0.88f * path_alpha;
            const float jump_r = std::max(2.6f, 3.8f * ui_scale);
            if (glow_enabled) {
                draw_list->AddCircleFilled(jump_p, jump_r * 1.9f, ImGui::GetColorU32(ImVec4(grad_b.x, grad_b.y, grad_b.z, jump_alpha * 0.26f)), 20);
            }
            draw_list->AddCircleFilled(jump_p, jump_r, ImGui::GetColorU32(ImVec4(1.0f, 1.0f, 1.0f, jump_alpha)), 20);
            draw_list->AddCircle(jump_p, jump_r * 1.55f, ImGui::GetColorU32(ImVec4(grad_b.x, grad_b.y, grad_b.z, jump_alpha)), 20, std::max(1.0f, 1.4f * ui_scale));
        }

        const Vector3 end_world = snapshot.viz_points.back().world_position;
        const bool end_occluded = have_camera && RecorderPointOccluded(camera_position, end_world);
        const float end_shape_alpha = (end_occluded ? 0.14f : 0.88f) * path_alpha * alpha_scale;
        DrawRecorderShaderWorldRing(
            draw_list,
            theme,
            ctx,
            end_world,
            marker_radius,
            end_shape_alpha,
            ui_scale,
            glow_enabled,
            recorder_band_spacing_scale
        );
    }

    if (have_render_current_position) {
        ImVec2 current_screen{};
        if (RecorderWorldToScreen(ctx, render_current_position, current_screen)) {
            const float edge_alpha = RecorderScreenEdgeAlpha(ctx, current_screen);
            if (edge_alpha > 0.001f) {
            const bool occluded = have_camera && RecorderPointOccluded(camera_position, render_current_position);
            const float pulse = 0.5f + 0.5f * std::sin((float)ImGui::GetTime() * 5.0f);
            const float r = std::max(4.0f, (5.5f + pulse * 2.5f) * ui_scale);
            const ImU32 halo = ImGui::GetColorU32(ImVec4(grad_b.x, grad_b.y, grad_b.z, (occluded ? 0.10f : 0.24f) * edge_alpha));
            const ImU32 fill = ImGui::GetColorU32(ImVec4(1.0f, 1.0f, 1.0f, (occluded ? 0.20f : 0.88f) * edge_alpha));
            if (glow_enabled) {
                draw_list->AddCircleFilled(current_screen, r * 1.8f, halo, 24);
            }
            draw_list->AddCircleFilled(current_screen, r, fill, 24);
            draw_list->AddCircle(current_screen, r * 1.45f, ImGui::GetColorU32(ImVec4(grad_a.x, grad_a.y, grad_a.z, (occluded ? 0.18f : 0.78f) * edge_alpha)), 24, std::max(1.0f, 1.35f * ui_scale));
            }
        }
    }

    if (snapshot.mode == RecorderMode::SeekingStart && have_render_current_position && draw_start_target) {
        ImVec2 from{};
        ImVec2 to{};
        if (RecorderWorldToScreen(ctx, render_current_position, from) && RecorderWorldToScreen(ctx, snapshot.viz_start_position, to)) {
            const float edge_alpha = std::min(RecorderScreenEdgeAlpha(ctx, from), RecorderScreenEdgeAlpha(ctx, to));
            if (edge_alpha > 0.001f) {
                const ImU32 seek_col = ImGui::GetColorU32(ImVec4(grad_a.x, grad_a.y, grad_a.z, 0.58f * alpha_scale * edge_alpha));
                draw_list->AddLine(from, to, seek_col, std::max(1.0f, 1.5f * ui_scale));
            }
        }
    }
}

void RenderMovementRecorder(const RenderContext& ctx) {
    if (!ctx.gui || !ctx.fg_draw_list || !ctx.gui->theme) {
        return;
    }

    auto& recorder_module = vrt.features.movement.recorder;
    if (!recorder_module.enabled) {
        return;
    }

    ClickGUI* gui = ctx.gui;
    Theme* theme = gui->theme.get();
    ImDrawList* draw_list = ctx.fg_draw_list;
    const auto snapshot = Axlebolt::PlayerControllerHook::GetRecorderSnapshot();

    const float base_ui_scale = (gui->cache.uiScale > 0.0f) ? gui->cache.uiScale : GetScale();
    const float ui_scale = base_ui_scale * 1.01f;
    RenderMovementRecorderWorldViz(ctx, draw_list, theme, snapshot, ui_scale);
    const float card_w = 320.0f * ui_scale;
    const float card_h = 146.0f * ui_scale;
    const float recorder_max_x = std::max(0.0f, (float)ctx.gl_width - card_w);
    const float recorder_max_y = std::max(0.0f, (float)ctx.gl_height - card_h);
    const float left = std::clamp(std::clamp(gui->movementRecorderNormX, 0.0f, 1.0f) * recorder_max_x, 0.0f, recorder_max_x);
    const float top = std::clamp(std::clamp(gui->movementRecorderNormY, 0.0f, 1.0f) * recorder_max_y, 0.0f, recorder_max_y);
    const float snapped_left = std::round(left);
    const float snapped_top = std::round(top);
    const float rounding = std::max(8.0f, theme->style.CornerRadius);
    const float border_w = std::max(1.0f, gui->cache.lineWidth * 1.10f);
    const float stripe_w = ResolveEdgeStripeWidth(base_ui_scale, border_w);
    const float center_norm_x = ((snapped_left + card_w * 0.5f) / std::max(1.0f, (float)ctx.gl_width));
    const EdgeStripeSide stripe_side = ResolveEdgeStripeSide(center_norm_x);
    const bool show_stripe = stripe_side != EdgeStripeSide::None;
    const float total_w = card_w + (show_stripe ? stripe_w : 0.0f);
    const float panel_min_x = (stripe_side == EdgeStripeSide::Right) ? (snapped_left - stripe_w) : snapped_left;
    const ImVec2 card_min((stripe_side == EdgeStripeSide::Left) ? (snapped_left + stripe_w) : snapped_left, snapped_top);
    const ImVec2 card_max(card_min.x + card_w, card_min.y + card_h);
    const ImVec2 panel_min(panel_min_x, snapped_top);
    const ImVec2 panel_max(panel_min.x + total_w, card_max.y);
    const ImVec2 stripe_min = (stripe_side == EdgeStripeSide::Left)
        ? panel_min
        : ImVec2(card_max.x, card_min.y);
    const ImVec2 stripe_max = (stripe_side == EdgeStripeSide::Left)
        ? ImVec2(card_min.x, card_max.y)
        : panel_max;

    gui->movementRecorderVisibleWidthNorm = std::clamp(total_w / std::max(1.0f, (float)ctx.gl_width), 0.06f, 0.98f);
    gui->movementRecorderVisibleHeightNorm = std::clamp(card_h / std::max(1.0f, (float)ctx.gl_height), 0.04f, 0.45f);
    gui->movementRecorderExpandedWidthNorm = gui->movementRecorderVisibleWidthNorm;

    if (post_processing.flags.shadow) {
        ImColor shadow_col(0.0f, 0.0f, 0.0f, post_processing.flags.blur ? 0.18f : 0.24f);
        drawRoundedRectShadow(
            ImVec2(panel_min.x + std::max(0.85f, 1.0f * ui_scale), panel_min.y + std::max(0.85f, 1.0f * ui_scale)),
            ImVec2(panel_max.x - std::max(0.85f, 1.0f * ui_scale), panel_max.y - std::max(0.85f, 1.0f * ui_scale)),
            rounding + std::max(0.7f, 0.9f * ui_scale),
            shadow_col,
            1.0f,
            std::clamp(gui->appearance.shadowRings + 1, 7, kHudShadowMaxRings),
            std::clamp(gui->appearance.shadowSmoothness * 1.08f, 0.40f, 1.75f),
            true
        );
    }

    if (post_processing.flags.blur && ctx.gl_width > 0 && ctx.gl_height > 0) {
        const int blur_x0 = std::max(0, (int)std::floor(panel_min.x));
        const int blur_y0 = std::max(0, (int)std::floor(panel_min.y));
        const int blur_x1 = std::min(ctx.gl_width, (int)std::ceil(panel_max.x));
        const int blur_y1 = std::min(ctx.gl_height, (int)std::ceil(panel_max.y));
        const int blur_w = std::max(0, blur_x1 - blur_x0);
        const int blur_h = std::max(0, blur_y1 - blur_y0);
        if (blur_w > 0 && blur_h > 0) {
            const float blur_radius = std::max(0.1f, gui->sidebar.BlurRadius);
            struct MrBlurJob { int x, y, w, h; float r; Blur::Type t; };
            auto* job = new MrBlurJob{blur_x0, ctx.gl_height - blur_y1, blur_w, blur_h, blur_radius, gui->sidebar.BlurType};
            draw_list->AddCallback([](const ImDrawList*, const ImDrawCmd* cmd) {
                auto* j = static_cast<MrBlurJob*>(cmd->UserCallbackData);
                movement_recorder_blur.backend = Hardware::GPU;
                movement_recorder_blur.type = j->t;
                movement_recorder_blur.process(j->x, j->y, j->w, j->h, j->r, kHudBlurPasses);
                delete j;
            }, job);
            if (movement_recorder_blur.tex != 0) {
                draw_list->AddImageRounded(
                    (void*)(intptr_t)movement_recorder_blur.tex,
                    panel_min, panel_max,
                    ImVec2(0.0f, 1.0f), ImVec2(1.0f, 0.0f),
                    IM_COL32(255, 255, 255, 255), rounding, ImDrawFlags_RoundCornersAll
                );
            }
        }
    }

    const bool light_mode = theme->IsLightMode();
    ImVec4 bg_col = post_processing.flags.blur
        ? gui->cache.surfaceTransparent
        : ImVec4(0.07f, 0.07f, 0.07f, 0.92f);
    if (post_processing.flags.blur) {
        bg_col.w = light_mode ? 0.40f : 0.46f;
    }
    const ImDrawFlags body_round_flags = BodyRoundingFlagsForStripe(stripe_side);
    draw_list->AddRectFilled(card_min, card_max, ImGui::GetColorU32(bg_col), rounding, body_round_flags);
    if (post_processing.flags.blur) {
        ImVec4 overlay = ImGui::ColorConvertU32ToFloat4(ctx.main_area_color);
        const ImVec4 side_ref = ImGui::ColorConvertU32ToFloat4(ctx.sidebar_color);
        overlay.x = std::clamp((overlay.x * 0.92f + side_ref.x * 0.08f) * 1.10f, 0.0f, 1.0f);
        overlay.y = std::clamp((overlay.y * 0.92f + side_ref.y * 0.08f) * 1.10f, 0.0f, 1.0f);
        overlay.z = std::clamp((overlay.z * 0.92f + side_ref.z * 0.08f) * 1.10f, 0.0f, 1.0f);
        overlay.w = light_mode ? 0.20f : 0.14f;
        draw_list->AddRectFilled(card_min, card_max, ImGui::GetColorU32(overlay), rounding, body_round_flags);
    }

    ImVec4 stripe_col = ResolveAnimatedStripeTint(theme, stripe_min.y, std::max(1.0f, stripe_max.y - stripe_min.y), false, post_processing.flags.blur ? 0.85f : 1.0f);
    DrawEdgeStripeGlow(draw_list, stripe_min, stripe_max, stripe_col, stripe_side, StripeGlowTargetId::MovementRecorder, theme, base_ui_scale, ctx.gl_width, ctx.gl_height);
    if (show_stripe) {
        DrawAnimatedEdgeStripe(draw_list, stripe_min, stripe_max, stripe_side, StripeGlowTargetId::MovementRecorder, theme, stripe_col.w, false);
    }

    ImFont* title_font = theme->Get(Theme::FontId::Montserrat);
    if (!title_font) {
        title_font = ImGui::GetFont();
    }

    const ImVec4 accent = ResolveAccentAtScreenY(theme, (card_min.y + card_max.y) * 0.5f);
    const ImVec4 text_main = light_mode
        ? theme->HexToImVec4(theme->material.onSurface)
        : ImVec4(1.0f, 1.0f, 1.0f, 0.94f);
    const ImVec4 text_dim = light_mode
        ? theme->HexToImVec4(theme->material.onSurfaceVariant)
        : ImVec4(1.0f, 1.0f, 1.0f, 0.54f);

    const float pad_x = 16.0f * ui_scale;
    const float pad_y = 12.0f * ui_scale;
    const float title_size = title_font->LegacySize * 0.56f * ui_scale;
    const float row_size = title_font->LegacySize * 0.46f * ui_scale;
    const float info_size = title_font->LegacySize * 0.41f * ui_scale;
    const float title_off = GetGlyphOffsetY(title_font, title_size);
    const float row_off = GetGlyphOffsetY(title_font, row_size);
    const float info_off = GetGlyphOffsetY(title_font, info_size);

    char status_buf[96];
    std::snprintf(
        status_buf,
        sizeof(status_buf),
        "%s%s%s",
        Axlebolt::PlayerControllerHook::RecorderModeName(snapshot.mode),
        (snapshot.active_slot >= 0) ? " / " : "",
        (snapshot.active_slot >= 0) ? (snapshot.active_slot == 0 ? "Slot 1" :
                                      snapshot.active_slot == 1 ? "Slot 2" :
                                      snapshot.active_slot == 2 ? "Slot 3" : "Slot 4") : ""
    );

    const ImVec2 title_pos(card_min.x + pad_x, card_min.y + pad_y - title_off);
    draw_list->AddText(title_font, title_size, title_pos, ImGui::GetColorU32(text_dim), "Movement Recorder");
    draw_list->AddText(
        title_font,
        info_size,
        ImVec2(card_max.x - pad_x - title_font->CalcTextSizeA(info_size, FLT_MAX, 0.0f, status_buf).x, title_pos.y - info_off),
        ImGui::GetColorU32(ImVec4(accent.x, accent.y, accent.z, 0.92f)),
        status_buf
    );

    const float info_row_y = title_pos.y + title_size + 8.0f * ui_scale;
    char metric_buf[96];
    std::snprintf(metric_buf, sizeof(metric_buf), "Path %s  |  Slot %zu", vrt.features.movement.recorderShowPath.value ? "On" : "Off", snapshot.selected_slot + 1);
    draw_list->AddText(
        title_font,
        info_size,
        ImVec2(card_min.x + pad_x, info_row_y - info_off),
        ImGui::GetColorU32(text_dim),
        metric_buf
    );

    if (snapshot.mode == Axlebolt::PlayerControllerHook::RecorderMode::SeekingStart) {
        char seek_buf[64];
        std::snprintf(seek_buf, sizeof(seek_buf), "Dist %.2f", snapshot.distance_to_start);
        draw_list->AddText(
            title_font,
            info_size,
            ImVec2(card_max.x - pad_x - title_font->CalcTextSizeA(info_size, FLT_MAX, 0.0f, seek_buf).x, info_row_y - info_off),
            ImGui::GetColorU32(text_main),
            seek_buf
        );
    }

    const float list_top = card_min.y + 48.0f * ui_scale;
    const float row_h = 21.0f * ui_scale;
    for (size_t i = 0; i < Axlebolt::PlayerControllerHook::kRecorderSlotCount; ++i) {
        const float y = list_top + row_h * (float)i;
        const bool active = snapshot.active_slot == (int)i;
        const bool selected = snapshot.selected_slot == i;
        ImVec4 row_bg = light_mode
            ? ImVec4(0.0f, 0.0f, 0.0f, active ? 0.10f : (selected ? 0.06f : 0.03f))
            : ImVec4(1.0f, 1.0f, 1.0f, active ? 0.085f : (selected ? 0.055f : 0.028f));
        draw_list->AddRectFilled(
            ImVec2(card_min.x + 10.0f * ui_scale, y),
            ImVec2(card_max.x - 10.0f * ui_scale, y + row_h - 3.0f * ui_scale),
            ImGui::GetColorU32(row_bg),
            0.0f,
            ImDrawFlags_None
        );

        char slot_buf[96];
        if (snapshot.valid[i]) {
            std::snprintf(slot_buf, sizeof(slot_buf), "Slot %zu   %.2fs   %zuf   %uj", i + 1, snapshot.duration[i], snapshot.frames[i], snapshot.jumps[i]);
        } else {
            std::snprintf(slot_buf, sizeof(slot_buf), "Slot %zu   empty", i + 1);
        }
        draw_list->AddText(
            title_font,
            row_size,
            ImVec2(card_min.x + pad_x, y + 3.0f * ui_scale - row_off),
            ImGui::GetColorU32(active ? text_main : text_dim),
            slot_buf
        );
    }
}
