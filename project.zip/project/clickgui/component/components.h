#pragma once

#include "../imgui/imgui.h"
#include "../../assets/images.h"
#include "../clickgui.h"
#include "../render/pipeline/render_context.h"
#include "../../clickgui/widgets/wigdets.h"
#include "../../clickgui/layouts/layouts.h"

enum class TabType {
    Aimbot,
    Movement,
    Render,
    Misc,
    Config,
    HUD,
    CUI
};

struct SidebarFrame {
    const ClickGUI::Settings* settings = nullptr;
    ImDrawList* draw_list = nullptr;
    ImVec2 window_pos = ImVec2(0.0f, 0.0f);
    ImVec2 window_size = ImVec2(0.0f, 0.0f);
    ImVec2 content_cursor_pos = ImVec2(0.0f, 0.0f);
    float ui_scale = 1.0f;
    float sidebar_width = 0.0f;
};

SidebarFrame BuildSidebarFrame(const ClickGUI::Settings* settings);
void RenderLogo(const ClickGUI::Settings* settings);
void RenderSidebar(WidgetManager* widgets, int& selectedTab, const ClickGUI::Settings* settings);
void RenderTasksTab(const SidebarFrame& frame);
void RenderUserInfo(const SidebarFrame& frame,
                    int& selectedTab,
                    const char* userName,
                    const char* userRank,
                    const ClickGUI::Assets::Icon& user,
                    const ClickGUI::Assets::Icon& cui);
void RenderWatermark(const RenderContext& ctx);
void RenderSpeedGraph(const RenderContext& ctx);
void RenderMovementRecorder(const RenderContext& ctx);
void RenderContent(TabType tabType, WidgetManager* widgets, LayoutManager* layouts, const ClickGUI::Settings* settings = nullptr, int windowWidth = 0, int windowHeight = 0, bool drawHeader = true, bool drawBody = true, float forcedAvailWidth = 0.0f);
void RenderModule(TabType tabType, Theme* theme);
