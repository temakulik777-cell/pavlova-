#include "clickgui.h"
#include "widgets/wigdets.h"
#include "windows/windows.h"
#include <memory>
#include "../good_luck/oxo/oxorany.h"
#include "../axlebolt/player_controller.h"
#include "../unity_engine/Input/Touch.h"
#include "../unity_engine/Il2Cpp/Utils/Il2CppUtils.h"
#include "component/components.h"
#include "component/lolw/oshi_no_ko.h"
#include "../assets/images.h"
#include "../assets/fonts/AWESOME.h"
#include "../assets/fonts/montserrat.h"
#include "../assets/fonts/montserrat_regular.h"
#include "render/pipeline/render_context.h"
#include "imgui/im_anim/im_anim.h"
#include "imgui/box_shadow.h"
#include <memory>
#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstring>

static inline float GetScale() {
    const float font_scale = ImGui::GetIO().FontGlobalScale;
    return (font_scale != 0.0f) ? (font_scale / 0.75f) : 1.0f;
}

static inline float GetEffectiveCornerRadius(const ClickGUI* gui) {
    if (!gui || !gui->theme) {
        return 19.5f;
    }
    const float raw = std::max(0.0f, gui->theme->style.CornerRadius);
    
    const float ui_scale = (gui->cache.uiScale > 0.0f) ? gui->cache.uiScale : GetScale();
    const float k = std::clamp(ui_scale / 1.30f, 0.45f, 2.25f);
    return raw * k;
}

static inline bool IsValidRegion(const ImageRegion& r) {
    return r.width > 0 && r.height > 0 &&
           r.u_max > r.u_min && r.v_max > r.v_min;
}

static inline float ContentOverlayLighten(float v) {
    return std::clamp(v * 1.5f, 0.0f, 1.0f);
}

static void SyncRuntimeTextGlobals(ClickGUI& gui) {
    const char* search = "Search";
    const char* user = "User";
    const char* rank = "Rank";
    if (vrt.text.globals && vrt.text.globalsCount > 2 && vrt.text.globals[2]) {
        search = vrt.text.globals[2];
    }
    if (vrt.text.globals && vrt.text.globalsCount > 3 && vrt.text.globals[3]) {
        user = vrt.text.globals[3];
    }
    if (vrt.text.globals && vrt.text.globalsCount > 4 && vrt.text.globals[4]) {
        rank = vrt.text.globals[4];
    }
    gui.sidebar.searchPlaceholder = search;
    gui.userInfo.userName = user;
    gui.userInfo.userRank = rank;
}

void ClickGUI::Animation::Begin(ImGuiIO& io, bool open) {
    iam_update_begin_frame();

    targetAlpha = open ? 1.0f : 0.0f;
    targetAnimationProgress = open ? 1.0f : 0.0f;
    menuJustOpened = open;
    Alpha = targetAlpha;

    const float menu_speed = std::clamp(ClickGUI::Get().animationTuning.menuSpeed, 0.2f, 4.0f);
    const float menu_duration = 0.55f / menu_speed;
    int anim_ease = iam_ease_out_cubic;
    animationProgress = iam_tween_float(ImGui::GetID("menu_animation"), ImGui::GetID("progress"),
                                        targetAnimationProgress, menu_duration,
                                        iam_ease_preset(anim_ease), iam_policy_crossfade,
                                        io.DeltaTime);

    static int gc_counter = 0;
    if (++gc_counter >= 60) {
        iam_gc(600);
        gc_counter = 0;
    }
}

void ClickGUI::Animation::Open() {
    scalled = false;
    menuJustOpened = true;
    targetAlpha = 1.0f;
    targetAnimationProgress = 1.0f;
}

void ClickGUI::Animation::Close() {
    targetAlpha = 0.0f;
    targetAnimationProgress = 0.0f;
    menuJustOpened = false;
}

ClickGUI::~ClickGUI() {
}

ClickGUI& ClickGUI::Get() {
    static ClickGUI clickgui;
    return clickgui;
}

ClickGUI::ClickGUI() {
    scale.Scale = 1.3f;
    scale.Width = Scale::DefaultWidth;
    scale.Height = Scale::DefaultHeight;
    animation.Alpha = 0.0f;
    animation.scalled = false;
    sidebar.DownscaleFactor = 40;
    theme = std::make_unique<Theme>();
    theme->style.CornerRadius = 19.5f;
    sidebar.searchPlaceholder = "Search";
    userInfo.userName = "User";
    userInfo.userRank = "Rank";
    settings.updateThemeCallback = [this](float new_scale) {
        scale.Apply(*this, new_scale);
    };
}

void ClickGUI::Preload() {
    auto ensure_icon = [](ClickGUI::Assets::Icon& icon) {
        if (icon.loaded == icon.name && icon.tex != 0) {
            return;
        }
        icon.uv = images.RegionForName(icon.name.c_str());
        if (IsValidRegion(icon.uv)) {
            icon.tex = images.TextureForRegion(icon.uv);
            icon.loaded = (icon.tex != 0) ? icon.name : std::string();
        } else {
            icon.tex = 0;
            icon.loaded.clear();
        }
    };

    ensure_icon(assets.yorozka);
    ensure_icon(assets.search);
    ensure_icon(assets.user);
    ensure_icon(assets.cui);

    if (theme) {
        float user_color1[3] = {0.294f, 0.412f, 0.996f};
        float user_color2[3] = {0.545f, 0.286f, 0.996f};
        if (assets.user.tex != 0 && IsValidRegion(assets.user.uv)) {
            getTwoBrightestColorsFromRegion(
                assets.user.uv.atlas,
                ImVec2(assets.user.uv.u_min, assets.user.uv.v_min),
                ImVec2(assets.user.uv.u_max, assets.user.uv.v_max),
                user_color1,
                user_color2
            );
        }
        theme->SetUserAccentGradient(
            user_color1[0], user_color1[1], user_color1[2],
            user_color2[0], user_color2[1], user_color2[2]
        );
    }

    const float ui_scale = GetScale();
    cache.uiScale = ui_scale;
    const float default_logo_w = 230.0f * ui_scale;
    const float default_logo_h = 129.375f * ui_scale;
    cache.logoHeight = default_logo_h;
    if (IsValidRegion(assets.yorozka.uv) && assets.yorozka.uv.width > 0 && assets.yorozka.uv.height > 0) {
        const float aspect = (float)assets.yorozka.uv.width / (float)assets.yorozka.uv.height;
        cache.logoWidth = cache.logoHeight * aspect;
    } else {
        cache.logoWidth = default_logo_w;
    }
    cache.logoOffsetY = 27.0f * ui_scale;
    cache.tabsOffsetY = 10.0f * ui_scale;
    cache.panelPadding = 18.0f * ui_scale;
    cache.moduleWidth = 230.0f * ui_scale;
    cache.gradientHeight = 50.0f * ui_scale;
    cache.barsWidth = 26.0f * ui_scale;
    cache.barsGap = 5.0f * ui_scale;
    cache.barsTopOffset = 10.0f * ui_scale;
    cache.lineWidth = std::max(1.0f, 1.5f * ImGui::GetIO().FontGlobalScale);
    const float tex_scale = sidebar.TextureScale * ui_scale;
    cache.sidebarTextureWidth = 457.0f * tex_scale;
    cache.sidebarTextureHeight = 752.0f * tex_scale;

    if (theme) {
        cache.primary = theme->GetResolvedAccentColor();
        cache.onSurface = theme->HexToImVec4(theme->material.onSurface);
        cache.onSurfaceVariant = theme->HexToImVec4(theme->material.onSurfaceVariant);
        cache.surface = theme->HexToImVec4(theme->material.surface);
        cache.surfaceContainer = theme->HexToImVec4(theme->material.surfaceContainer);
        cache.surfaceTransparent = theme->HexToImVec4(theme->material.surfaceTransparent);
        cache.surfaceVariantTransparent = theme->HexToImVec4(theme->material.surfaceVariantTransparent);
    }

    assets.initialized = true;
}

void ClickGUI::Init() {
    SyncRuntimeTextGlobals(*this);
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.DisplaySize = ImVec2((float)glWidth, (float)glHeight);
    io.IniFilename = NULL;
    ImGui_ImplAndroid_Init(NULL);
    ImGui_ImplOpenGL3_Init(oxorany("#version 300 es"));
    io.BackendFlags |= ImGuiBackendFlags_HasSetMousePos;
    io.BackendFlags &= ~ImGuiBackendFlags_HasMouseCursors;
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
    io.ConfigFlags |= ImGuiConfigFlags_IsTouchScreen;
    io.ConfigFlags |= ImGuiConfigFlags_NoMouseCursorChange; 
    io.FontGlobalScale = 1.0f;

    ImFontConfig default_cfg;
    default_cfg.OversampleH = 2;
    default_cfg.OversampleV = 2;
    default_cfg.RasterizerMultiply = 1.2f;
    default_cfg.SizePixels = 35.0f;
    default_cfg.GlyphOffset.y = 2.5f;

    ImFontConfig montserrat_cfg;
    montserrat_cfg.OversampleH = 2;
    montserrat_cfg.OversampleV = 2;
    montserrat_cfg.RasterizerMultiply = 1.2f;
    montserrat_cfg.SizePixels = 35.0f;
    montserrat_cfg.GlyphOffset.y = 2.5f;

    static const ImWchar awesome_icons_ranges[] = { 0xe000, 0xf8ff, 0 };
    ImFontConfig awesome_cfg;
    awesome_cfg.PixelSnapH = true;
    awesome_cfg.GlyphOffset.y = -0.6f;
    awesome_cfg.GlyphMinAdvanceX = 13.0f;
    awesome_cfg.OversampleH = 2;
    awesome_cfg.OversampleV = 1;
    awesome_cfg.SizePixels = 31.0f;

    theme->SetIds({"default", "montserrat", "awesome"});
    theme->Load((void*)montserrat_data, montserrat_size, default_cfg.SizePixels, &default_cfg, nullptr, "default");
    theme->Load((void*)montserrat_regular_data, montserrat_regular_size, montserrat_cfg.SizePixels, &montserrat_cfg, nullptr, "montserrat");
    theme->Load((void*)AWESOME_DATA, AWESOME_SIZE, awesome_cfg.SizePixels, &awesome_cfg, awesome_icons_ranges, "awesome");

    theme->ApplyTheme();
    theme->Build();
    images.Init();
    if (open) {
        OshiNoKoIntro::Begin();
        introPlayedOnce = true;
    }
    ImGuiStyle& style = ImGui::GetStyle();
    style.AntiAliasedLines = theme->rendering.antiAliasedLines;
    style.AntiAliasedFill = theme->rendering.antiAliasedFill;

}

void ClickGUI::Update() {
    SyncRuntimeTextGlobals(*this);
    if (!windows) { windows = std::make_unique<WindowManager>(); }
    if (!layouts) { layouts = std::make_unique<LayoutManager>(); layouts->Init(); }
    if (!widgets) { widgets = std::make_unique<WidgetManager>(); widgets->Init(); }
    if (!windows || !layouts || !widgets) { return; }
    if (!open && animation.Alpha <= 0.0f && animation.animationProgress <= 0.0f) {
        // still run overlay (watermark, speedgraph etc.)
        if (!postOverlayBuilt) BuildPostOverlayPipeline();
        RenderContext overlay_ctx; overlay_ctx.gui = this;
        overlay_ctx.io = &ImGui::GetIO();
        overlay_ctx.gl_width = glWidth; overlay_ctx.gl_height = glHeight;
        overlay_ctx.bg_draw_list = ImGui::GetBackgroundDrawList();
        overlay_ctx.fg_draw_list = ImGui::GetForegroundDrawList();
        UpdateMenuRippleInput(this, overlay_ctx.io->DeltaTime, overlay_ctx.io->MousePos,
            overlay_ctx.io->MouseDown[0], overlay_ctx.io->MouseClicked[0], overlay_ctx.io->MouseReleased[0]);
        postOverlayPipeline.Execute(overlay_ctx);
        mainWantCaptureMouseSnapshot = overlay_ctx.io->WantCaptureMouse;
        return;
    }
    if (scale.Dirty || scale.LastApplied == 0.0f) { scale.Apply(*this, scale.Scale); scale.Dirty = false; }
    const float ui_scale = GetScale();
    if (images.Ready() && (!assets.initialized || std::fabs(cache.uiScale - ui_scale) > 0.0001f)) {
        Preload();
    }
    if (open && OshiNoKoIntro::Active()) {
        OshiNoKoIntro::Tick(*this);
        RenderContext intro_ctx;
        intro_ctx.gui = this;
        intro_ctx.io = &ImGui::GetIO();
        intro_ctx.gl_width = glWidth;
        intro_ctx.gl_height = glHeight;
        intro_ctx.bg_draw_list = ImGui::GetBackgroundDrawList();
        intro_ctx.fg_draw_list = ImGui::GetForegroundDrawList();
        OshiNoKoIntro::Render(intro_ctx);
        return;
    }

    if (!built) {
        pipeline.Clear();

        pipeline.AddPass([](RenderContext& ctx) {
            if (!ctx.gui) {
                return;
            }

            ClickGUI* gui = ctx.gui;
            gui->sidebar.BlurType = Blur::Type::Yorozka;
            ImGuiIO& io = ImGui::GetIO();
            ctx.io = &io;
            ctx.gl_width = glWidth;
            ctx.gl_height = glHeight;

            gui->animation.Begin(io, gui->open);
            ctx.ui_scale = gui->cache.uiScale;
            ctx.anim_raw = gui->animation.animationProgress;
            ctx.anim_t = std::clamp(ctx.anim_raw, 0.0f, 1.0f);
            ctx.alpha_t = (ctx.anim_t > 0.001f) ? 1.0f : 0.0f;
            ctx.visual_t = ctx.alpha_t;
            ctx.blur_enabled = post_processing.flags.blur;
            ctx.blur_alpha = 0.0f;
            ctx.menu_visible = false;

            ctx.should_render_transparent = gui->animation.scalled;
            const ImVec4 transparent_bg = gui->cache.surfaceTransparent;
            const ImVec4 semi_transparent_bg = gui->cache.surfaceVariantTransparent;
            const ImVec4 full_opaque_bg = gui->cache.surfaceContainer;
            const ImVec4 full_bg = gui->cache.surface;

            ImVec4 sidebar_color = ctx.should_render_transparent
                ? transparent_bg
                : semi_transparent_bg;
            
            const float sidebar_darkness = 0.93f;
            sidebar_color.x = std::clamp(sidebar_color.x * sidebar_darkness, 0.0f, 1.0f);
            sidebar_color.y = std::clamp(sidebar_color.y * sidebar_darkness, 0.0f, 1.0f);
            sidebar_color.z = std::clamp(sidebar_color.z * sidebar_darkness, 0.0f, 1.0f);
            if (!ctx.blur_enabled && !ctx.should_render_transparent) {
                sidebar_color.x = std::clamp(sidebar_color.x * 0.88f, 0.0f, 1.0f);
                sidebar_color.y = std::clamp(sidebar_color.y * 0.88f, 0.0f, 1.0f);
                sidebar_color.z = std::clamp(sidebar_color.z * 0.88f, 0.0f, 1.0f);
            }
            ctx.sidebar_color = ImGui::GetColorU32(sidebar_color);

            ctx.main_area_color = ctx.should_render_transparent
                ? ImGui::GetColorU32(transparent_bg)
                : ImGui::GetColorU32(full_opaque_bg);
            if (!ctx.blur_enabled) {
                ImVec4 side = ImGui::ColorConvertU32ToFloat4(ctx.sidebar_color);
                ImVec4 main = ImGui::ColorConvertU32ToFloat4(ctx.main_area_color);
                std::swap(side.x, main.x);
                std::swap(side.y, main.y);
                std::swap(side.z, main.z);
                ctx.sidebar_color = ImGui::GetColorU32(side);
                ctx.main_area_color = ImGui::GetColorU32(main);
            }

            ctx.bg_color = ctx.should_render_transparent
                ? ImGui::GetColorU32(transparent_bg)
                : ImGui::GetColorU32(full_bg);

            const float corner_radius = GetEffectiveCornerRadius(gui);
            const float widget_rounding = std::clamp(corner_radius * 0.50f, 2.0f, 10.0f);
            ImGuiStyle& imgui_style = ImGui::GetStyle();
            imgui_style.WindowRounding = corner_radius;
            imgui_style.ChildRounding = corner_radius;
            imgui_style.FrameRounding = widget_rounding;
            imgui_style.PopupRounding = corner_radius;
            imgui_style.TabRounding = corner_radius;
            imgui_style.ScrollbarRounding = corner_radius;
            imgui_style.GrabRounding = widget_rounding;

            int currentWindowWidth = gui->width;
            int currentWindowHeight = gui->height;

            ctx.clamped_window_width = std::min(currentWindowWidth, glWidth);
            ctx.clamped_window_height = std::min(currentWindowHeight, glHeight);

            const float targetX = (glWidth - ctx.clamped_window_width) / 2.0f;
            const float targetY = (glHeight - ctx.clamped_window_height) / 2.0f;
            const float startX = glWidth + (ctx.clamped_window_width * 0.35f);
            float animatedX = startX + (targetX - startX) * ctx.anim_raw;
            float animatedY = targetY;
            ctx.scale_effect = 1.0f;

            ctx.clamped_window_pos = ImVec2(animatedX, animatedY);
            const float menu_left = ctx.clamped_window_pos.x;
            const float menu_top = ctx.clamped_window_pos.y;
            const float menu_right = menu_left + ctx.clamped_window_width;
            const float menu_bottom = menu_top + ctx.clamped_window_height;
            ctx.menu_visible = (menu_right > 0.0f) && (menu_left < (float)glWidth) &&
                               (menu_bottom > 0.0f) && (menu_top < (float)glHeight);
            if (ctx.blur_enabled) {
                ctx.blur_alpha = ctx.menu_visible ? 1.0f : 0.0f;
            } else {
                ctx.blur_alpha = 0.0f;
            }

            int actualThemeWidth = gui->width > 0 ? gui->width : static_cast<int>(gui->scale.Width * gui->scale.Scale);
            int actualThemeHeight = gui->height > 0 ? gui->height : static_cast<int>(gui->scale.Height * gui->scale.Scale);

            ctx.final_clamped_window_width = std::min(actualThemeWidth, glWidth);
            ctx.final_clamped_window_height = std::min(actualThemeHeight, glHeight);
            gui->overlayMenuMin = ctx.clamped_window_pos;
            gui->overlayMenuMax = ImVec2(
                ctx.clamped_window_pos.x + (float)ctx.clamped_window_width,
                ctx.clamped_window_pos.y + (float)ctx.final_clamped_window_height
            );
            gui->overlayMenuValid = ctx.menu_visible && gui->open;

            ctx.window_padding_x = imgui_style.WindowPadding.x;
            float available_width = ctx.final_clamped_window_width + (ctx.window_padding_x * 2.0f);
            ctx.sidebar_width = std::round(available_width * 0.25f);

            ctx.bg_draw_list = ImGui::GetBackgroundDrawList();
            ctx.fg_draw_list = ImGui::GetForegroundDrawList();
        }, "FrameSetup");

        pipeline.AddPass([](RenderContext& ctx) {
            if (!ctx.gui || !ctx.bg_draw_list) {
                return;
            }

            ClickGUI* gui = ctx.gui;
            const ImVec2 menu_min = ctx.clamped_window_pos;
            const ImVec2 menu_max = ImVec2(
                ctx.clamped_window_pos.x + ctx.clamped_window_width,
                ctx.clamped_window_pos.y + ctx.final_clamped_window_height
            );
            const float shadow_alpha = ctx.blur_enabled
                ? std::clamp(ctx.blur_alpha, 0.0f, 1.0f)
                : std::clamp(ctx.visual_t, 0.0f, 1.0f);
            const float corner_radius = GetEffectiveCornerRadius(gui);
            DrawMenuShadowBox(menu_min, menu_max, corner_radius, shadow_alpha, gui, ctx.blur_enabled);

            if (ctx.blur_enabled) {
                const float blur_alpha = ctx.blur_alpha;
                ImVec4 colorWithAlpha = gui->cache.onSurface;
                colorWithAlpha.w *= blur_alpha;
                const float menu_x0 = ctx.clamped_window_pos.x;
                const float menu_y0 = ctx.clamped_window_pos.y;
                const float menu_x1 = menu_x0 + (float)ctx.clamped_window_width;
                const float menu_y1 = menu_y0 + (float)ctx.final_clamped_window_height;
                const float clip_x0 = std::max(0.0f, menu_x0);
                const float clip_y0 = std::max(0.0f, menu_y0);
                const float clip_x1 = std::min((float)ctx.gl_width, menu_x1);
                const float clip_y1 = std::min((float)ctx.gl_height, menu_y1);
                const int blur_w = (int)std::floor(clip_x1 - clip_x0);
                const int blur_h = (int)std::floor(clip_y1 - clip_y0);

                if (blur_alpha > 0.001f && blur_w > 0 && blur_h > 0) {
                    post_processing.RenderBlur(
                        ctx.bg_draw_list,
                        ImVec2(clip_x0, clip_y0),
                        blur_w,
                        blur_h,
                        blur_alpha,
                        gui->animation.scalled,
                        corner_radius,
                        gui->sidebar.DownscaleFactor,
                        gui->sidebar.BlurRadius,
                        gui->sidebar.BlurType,
                        colorWithAlpha,
                        ImDrawFlags_RoundCornersAll
                    );
                    gui->post_layout_fade.menu_blur_tex = post_processing.blur ? post_processing.blur->tex : 0;
                    gui->post_layout_fade.menu_blur_pos = ImVec2(clip_x0, clip_y0);
                    gui->post_layout_fade.menu_blur_size = ImVec2((float)blur_w, (float)blur_h);
                } else {
                    gui->post_layout_fade.menu_blur_tex = 0;
                }
                
                ImVec4 mainAreaColorVec4 = ImGui::ColorConvertU32ToFloat4(ctx.main_area_color);
                mainAreaColorVec4.x = std::clamp(mainAreaColorVec4.x * 0.84f, 0.0f, 1.0f);
                mainAreaColorVec4.y = std::clamp(mainAreaColorVec4.y * 0.84f, 0.0f, 1.0f);
                mainAreaColorVec4.z = std::clamp(mainAreaColorVec4.z * 0.84f, 0.0f, 1.0f);
                mainAreaColorVec4.w *= (blur_alpha * 0.58f);
                ctx.bg_draw_list->AddRectFilled(
                    menu_min,
                    menu_max,
                    ImGui::ColorConvertFloat4ToU32(mainAreaColorVec4),
                    corner_radius,
                    ImDrawFlags_RoundCornersAll
                );
            } else {
                gui->post_layout_fade.menu_blur_tex = 0;
            }
        }, "Background");

        pipeline.AddPass([](RenderContext& ctx) {
            if (!ctx.gui) {
                return;
            }

            ClickGUI* gui = ctx.gui;
            const float corner_radius = GetEffectiveCornerRadius(gui);

            const float blur_alpha = ctx.blur_alpha;

            ImGuiWindowFlags base_flags = ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoMove |
                ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoTitleBar;
            if (ctx.blur_enabled) {
                base_flags |= ImGuiWindowFlags_NoBackground;
                ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0.0f, 0.0f, 0.0f, 0.0f));
            }
            gui->windows->hello("world!!", gui->width, gui->height, ctx.scale_effect,
                glWidth, glHeight, ctx.clamped_window_pos, base_flags);
            if (ctx.blur_enabled) {
                ImGui::PopStyleColor();
            }

            ctx.win_draw_list = ImGui::GetWindowDrawList();
            ctx.window_pos = ImGui::GetWindowPos();
            ctx.window_size = ImGui::GetWindowSize();
            ImVec4 parentPanelNonBlurColor = ImGui::ColorConvertU32ToFloat4(ctx.main_area_color);
            if (!ctx.blur_enabled) {
                const ImVec4 side_ref = ImGui::ColorConvertU32ToFloat4(ctx.sidebar_color);
                parentPanelNonBlurColor.x = std::clamp((parentPanelNonBlurColor.x * 0.92f + side_ref.x * 0.08f) * 1.16f, 0.0f, 1.0f);
                parentPanelNonBlurColor.y = std::clamp((parentPanelNonBlurColor.y * 0.92f + side_ref.y * 0.08f) * 1.16f, 0.0f, 1.0f);
                parentPanelNonBlurColor.z = std::clamp((parentPanelNonBlurColor.z * 0.92f + side_ref.z * 0.08f) * 1.16f, 0.0f, 1.0f);
                parentPanelNonBlurColor.w = std::clamp(ctx.visual_t, 0.0f, 1.0f);
            }

            ImVec4 sidebarColorVec4 = ImGui::ColorConvertU32ToFloat4(ctx.sidebar_color);
            if (ctx.blur_enabled) {
                const float target_sidebar_alpha = std::min(1.0f, 0.8f * blur_alpha);
                const float base_main_alpha = std::clamp(blur_alpha * 0.70f, 0.0f, 0.98f);
                float extra_alpha = 0.0f;
                if (target_sidebar_alpha > base_main_alpha) {
                    extra_alpha = (target_sidebar_alpha - base_main_alpha) / std::max(0.001f, 1.0f - base_main_alpha);
                }
                
                ImVec4 pane_base = ImGui::ColorConvertU32ToFloat4(ctx.main_area_color);
                sidebarColorVec4.x = ContentOverlayLighten(pane_base.x * 0.81f);
                sidebarColorVec4.y = ContentOverlayLighten(pane_base.y * 0.81f);
                sidebarColorVec4.z = ContentOverlayLighten(pane_base.z * 0.81f);
                sidebarColorVec4.w = std::clamp(extra_alpha * 1.18f, 0.0f, 1.0f);
            } else {
                
                sidebarColorVec4.w = std::clamp(ctx.visual_t, 0.0f, 1.0f);
            }
            ImU32 sidebarColorWithAlpha = ImGui::ColorConvertFloat4ToU32(sidebarColorVec4);

            ImDrawList* sidebar_overlay_list = (ctx.blur_enabled && ctx.bg_draw_list)
                ? ctx.bg_draw_list
                : ctx.win_draw_list;
            if (!ctx.blur_enabled && ctx.win_draw_list) {
                ImVec4 mainAreaColorVec4 = parentPanelNonBlurColor;
                ctx.win_draw_list->AddRectFilled(
                    ImVec2(ctx.clamped_window_pos.x, ctx.clamped_window_pos.y),
                    ImVec2(ctx.clamped_window_pos.x + ctx.clamped_window_width,
                           ctx.clamped_window_pos.y + ctx.final_clamped_window_height),
                    ImGui::ColorConvertFloat4ToU32(mainAreaColorVec4),
                    corner_radius,
                    ImDrawFlags_RoundCornersAll
                );
            }

            if (sidebar_overlay_list) {
                if (ctx.blur_enabled) {
                    
                    sidebar_overlay_list->AddRectFilled(
                        ImVec2(ctx.clamped_window_pos.x + ctx.sidebar_width, ctx.clamped_window_pos.y),
                        ImVec2(ctx.clamped_window_pos.x + ctx.clamped_window_width, ctx.clamped_window_pos.y + ctx.final_clamped_window_height),
                        sidebarColorWithAlpha,
                        corner_radius,
                        ImDrawFlags_RoundCornersRight
                    );
                } else {
                    sidebar_overlay_list->AddRectFilled(
                        ImVec2(ctx.clamped_window_pos.x, ctx.clamped_window_pos.y),
                        ImVec2(ctx.clamped_window_pos.x + ctx.sidebar_width, ctx.clamped_window_pos.y + ctx.final_clamped_window_height),
                        sidebarColorWithAlpha,
                        corner_radius,
                        ImDrawFlags_RoundCornersAll
                    );
                }

            }

            ImGui::PushStyleVar(ImGuiStyleVar_Alpha, ctx.visual_t);
            const float frame_dt = ImGui::GetIO().DeltaTime;

                auto hLayout = gui->layouts->GetTabbedHorizontalLayout(150.0f);
                if (hLayout) {
                    if (!tabMorphFx.active) {
                        tabMorphFx.module_valid = false;
                        tabMorphFx.content_valid = false;
                    }
                    const bool popup_blocks_input = ComboPopupBlocksInput() || ColorPickerPopupBlocksInput();
                    gui->post_layout_fade.sidebar_valid = false;
                    gui->post_layout_fade.content_valid = false;
                gui->post_layout_fade.sidebar_top_alpha = 0.0f;
                gui->post_layout_fade.sidebar_bottom_alpha = 0.0f;
                gui->post_layout_fade.content_top_alpha = 0.0f;
                gui->post_layout_fade.content_bottom_alpha = 0.0f;
                gui->post_layout_fade.gradient_h = 0.0f;
                gui->post_layout_fade.content_overlay = ImVec4(0.0f, 0.0f, 0.0f, 0.0f);
                gui->post_layout_fade.content_rounding = 0.0f;
                ImVec2 prev_cell_padding = ImGui::GetStyle().CellPadding;
                ImGui::GetStyle().CellPadding = ImVec2(0.0f, prev_cell_padding.y);
                hLayout->SetBaseWindowWidth(static_cast<float>(ctx.final_clamped_window_width));
                hLayout->SetWindowInfo(ctx.clamped_window_pos, ImVec2(ctx.clamped_window_width, ctx.clamped_window_height));
                hLayout->SetCornerRadius(corner_radius);
                float tabs_width = ctx.sidebar_width;
                float module_width = gui->cache.moduleWidth;
                float inter_gap = 0.0f;
                float module_right_padding = gui->cache.panelPadding;
                float module_left_padding = gui->cache.panelPadding;
                hLayout->SetTabsColumnWidth(tabs_width);
                hLayout->SetSidebarColumnWidth(module_width + module_left_padding + module_right_padding + inter_gap);
                hLayout->Begin();
                static int selectedTab = 0;
                static int lastTab = 0;
                static int lastActiveModuleByTab[7] = {-999, -999, -999, -999, -999, -999, -999};
                static double lastTabSwitchAt = 0.0;
                static bool restoreModuleScroll[7] = {false};
                static bool restoreContentScroll[7] = {false};
                static int restoreModuleScrollFrames[7] = {0};
                static int restoreContentScrollFrames[7] = {0};
                static float restoreModuleScrollTarget[7] = {0.0f};
                static float restoreContentScrollTarget[7] = {0.0f};
                static float savedModuleScrollByTab[7] = {0.0f};
                static float savedContentScrollByTab[7] = {0.0f};
                static float savedContentScrollByModule[7][64] = {};
                static int suppressModuleSwitchAnimFrames[7] = {0};
                static int sidebarPreviewTab = -1;
                static bool tabSwitchPending = false;
                static int pendingTab = -1;
                static bool moduleSwitchPending = false;
                static int pendingModuleTab = -1;
                static int pendingModule = -1;
                static bool moduleSmoothRestorePending = false;
                static bool moduleSmoothRestoreWaitingCapture = false;
                static bool moduleSmoothRestoreResetDone = false;
                static float moduleSmoothRestoreTarget = 0.0f;
                static float moduleSmoothRestoreStart = 0.0f;
                static bool moduleSmoothRestoreStartReady = false;
                static float moduleSmoothRestoreT = 0.0f;
                static bool preMorphToTopPending = false;
                static float preMorphToTopT = 0.0f;
                static int preMorphToTopFrames = 0;
                static float preMorphModuleStart = 0.0f;
                static float preMorphContentStart = 0.0f;
                static float lastSidebarScrollY = 0.0f;
                static float lastContentScrollY = 0.0f;
                static float preMorphModuleY = 0.0f;
                static float preMorphContentY = 0.0f;
                static float preMorphModulePrevY = 0.0f;
                static float preMorphContentPrevY = 0.0f;
                static bool contentSmoothRestorePending = false;
                static bool contentSmoothRestoreWaitingCapture = false;
                static bool contentSmoothRestoreResetDone = false;
                static float contentSmoothRestoreTarget = 0.0f;
                static float contentSmoothRestoreStart = 0.0f;
                static bool contentSmoothRestoreStartReady = false;
                static float contentSmoothRestoreT = 0.0f;
                const float tab_fade_t = std::clamp(tabMorphFx.progress, 0.0f, 1.0f);
                const float tab_fade_eased = tab_fade_t * tab_fade_t * tab_fade_t *
                    (tab_fade_t * (tab_fade_t * 6.0f - 15.0f) + 10.0f);
                const float tab_fade_alpha = tabMorphFx.active
                    ? std::clamp(tab_fade_eased, 0.0f, 1.0f)
                    : 1.0f;
                const float sidebar_fade_alpha = (tabMorphFx.active && !tabMorphFx.is_module_switch) ? tab_fade_alpha : 1.0f;
                const float content_fade_alpha = tabMorphFx.active ? tab_fade_alpha : 1.0f;
                ClickGUI::Settings& settings = gui->settings;
                settings.scale = &gui->scale.Scale;
                settings.width = gui->scale.Width;
                settings.height = gui->scale.Height;
                settings.blurEnabled = &post_processing.flags.blur;
                settings.cornerRadius = &gui->theme->style.CornerRadius;
                settings.downscaleFactor = &gui->sidebar.DownscaleFactor;
                settings.scrollbarSize = &gui->theme->metrics.scrollbarSize;
                settings.gui = gui;
                if (gui->widgets && gui->widgetsThemeBound != gui->theme.get()) {
                    gui->widgets->SetTheme(gui->theme.get());
                    gui->widgetsThemeBound = gui->theme.get();
                }

                auto vLayout = gui->layouts->Type<VerticalLayout>();
                if (vLayout) {
                    vLayout->Begin();
                    if (!ctx.blur_enabled) {
                        ImVec4 col = parentPanelNonBlurColor;
                        col.w = 1.0f;
                        SetTabMainAreaColor(ImGui::ColorConvertFloat4ToU32(col));
                    } else {
                        SetTabMainAreaColor(0);
                    }
                    if (sidebarPreviewTab >= 0) {
                        int sidebar_tab = sidebarPreviewTab;
                        RenderSidebar(gui->widgets.get(), sidebar_tab, &settings);
                    } else {
                        RenderSidebar(gui->widgets.get(), selectedTab, &settings);
                    }
                    vLayout->End();
                }

                selectedTab = std::clamp(selectedTab, 0, 6);
                const bool tab_switched = (selectedTab != lastTab);
                if (tab_switched) {
                    const int requested_tab = selectedTab;
                    const int prev_tab = lastTab;
                    if (!gui->tabMorphEnabled) {
                        suppressModuleSwitchAnimFrames[requested_tab] = 3;
                        restoreModuleScroll[requested_tab] = true;
                        restoreContentScroll[requested_tab] = true;
                        restoreModuleScrollFrames[requested_tab] = 2;
                        restoreContentScrollFrames[requested_tab] = 2;
                        restoreModuleScrollTarget[requested_tab] = savedModuleScrollByTab[requested_tab];
                        restoreContentScrollTarget[requested_tab] = savedContentScrollByTab[requested_tab];
                        selectedTab = requested_tab;
                        lastTab = requested_tab;
                    } else {
                        suppressModuleSwitchAnimFrames[requested_tab] = 3;
                        moduleSmoothRestorePending = false;
                        contentSmoothRestorePending = false;
                        moduleSmoothRestoreWaitingCapture = false;
                        moduleSmoothRestoreResetDone = false;
                        moduleSmoothRestoreTarget = 0.0f;
                        moduleSmoothRestoreStart = 0.0f;
                        moduleSmoothRestoreStartReady = false;
                        moduleSmoothRestoreT = 0.0f;
                        contentSmoothRestoreWaitingCapture = false;
                        contentSmoothRestoreResetDone = false;
                        contentSmoothRestoreTarget = 0.0f;
                        contentSmoothRestoreStart = 0.0f;
                        contentSmoothRestoreStartReady = false;
                        contentSmoothRestoreT = 0.0f;
                        preMorphToTopPending = false;
                        preMorphToTopT = 0.0f;
                        preMorphToTopFrames = 0;
                        moduleSwitchPending = false;
                        pendingModuleTab = -1;
                        pendingModule = -1;
                        tabSwitchPending = true;
                        pendingTab = requested_tab;
                        sidebarPreviewTab = requested_tab;
                        selectedTab = prev_tab;
                        tabMorphFx.active = true;
                        tabMorphFx.progress = 1.0f;
                        tabMorphFx.start_requested = false;
                        tabMorphFx.start_delay_frames = 0;
                        tabMorphFx.recapture_pending = false;
                        tabMorphFx.recapture_frames = 0;
                        tabMorphFx.primed = false;
                        tabMorphFx.rects_frozen = false;
                        tabMorphFx.play_dir = -1.0f;
                        tabMorphFx.speed_boost = 1.0f;
                        tabMorphFx.force_motion = 1.0f;
                        tabMorphFx.switch_dir = (requested_tab >= prev_tab) ? 1.0f : -1.0f;
                        tabMorphFx.animate_module = true;
                        tabMorphFx.animate_content = true;
                        tabMorphFx.is_module_switch = false;
                        tabMorphFx.switch_module_tab = -1;
                        tabMorphFx.from_tab = prev_tab;
                        tabMorphFx.to_tab = requested_tab;
                        tabMorphFx.from_module = -1;
                        tabMorphFx.to_module = -1;
                    }
                }
                if (suppressModuleSwitchAnimFrames[selectedTab] > 0) {
                    --suppressModuleSwitchAnimFrames[selectedTab];
                }
                if (tabMorphFx.active) {
                    const float morph_dt = std::min(frame_dt, 1.0f / 60.0f);
                    const float fade_speed = tabMorphFx.is_module_switch ? 7.0f : 6.25f;
                    tabMorphFx.progress = std::clamp(tabMorphFx.progress + morph_dt * fade_speed * tabMorphFx.play_dir, 0.0f, 1.0f);
                    if (tabMorphFx.play_dir < 0.0f && tabMorphFx.progress <= 0.001f) {
                        if (tabSwitchPending && pendingTab >= 0 && pendingTab <= 6) {
                            selectedTab = pendingTab;
                            lastTab = pendingTab;
                            restoreModuleScroll[selectedTab] = true;
                            restoreContentScroll[selectedTab] = true;
                            restoreModuleScrollFrames[selectedTab] = 2;
                            restoreContentScrollFrames[selectedTab] = 2;
                            restoreModuleScrollTarget[selectedTab] = savedModuleScrollByTab[selectedTab];
                            restoreContentScrollTarget[selectedTab] = savedContentScrollByTab[selectedTab];
                            suppressModuleSwitchAnimFrames[selectedTab] = std::max(suppressModuleSwitchAnimFrames[selectedTab], 2);
                            tabSwitchPending = false;
                            pendingTab = -1;
                            sidebarPreviewTab = -1;
                        }
                        if (moduleSwitchPending && pendingModuleTab >= 0 && pendingModuleTab <= 6) {
                            vrt.features.activeByTab[pendingModuleTab] = pendingModule;
                            restoreModuleScroll[pendingModuleTab] = false;
                            restoreContentScroll[pendingModuleTab] = true;
                            restoreModuleScrollFrames[pendingModuleTab] = 0;
                            restoreContentScrollFrames[pendingModuleTab] = 2;
                            const int module_idx = std::clamp(pendingModule, 0, 63);
                            restoreContentScrollTarget[pendingModuleTab] = savedContentScrollByModule[pendingModuleTab][module_idx];
                            lastActiveModuleByTab[pendingModuleTab] = pendingModule;
                            suppressModuleSwitchAnimFrames[pendingModuleTab] = std::max(suppressModuleSwitchAnimFrames[pendingModuleTab], 2);
                            moduleSwitchPending = false;
                            pendingModuleTab = -1;
                            pendingModule = -1;
                        }
                        tabMorphFx.play_dir = 1.0f;
                        tabMorphFx.progress = 0.0f;
                    } else if (tabMorphFx.play_dir > 0.0f && tabMorphFx.progress >= 0.999f) {
                        tabMorphFx.active = false;
                        tabMorphFx.animate_module = true;
                        tabMorphFx.animate_content = true;
                        tabMorphFx.speed_boost = 1.0f;
                        tabMorphFx.play_dir = 1.0f;
                        tabMorphFx.from_tab = -1;
                        tabMorphFx.to_tab = -1;
                        tabMorphFx.is_module_switch = false;
                        tabMorphFx.switch_module_tab = -1;
                        tabMorphFx.from_module = -1;
                        tabMorphFx.to_module = -1;
                        if (!tabSwitchPending) {
                            sidebarPreviewTab = -1;
                        }
                    }
                }
                tabMorphFx.force_motion = std::max(0.0f, tabMorphFx.force_motion - frame_dt * 3.8f);
                TabType currentTab = static_cast<TabType>(selectedTab);
                {
                    int& activeByTab = vrt.features.activeByTab[selectedTab];
                    int moduleCount = 0;
                    switch (currentTab) {
                        case TabType::Aimbot: moduleCount = static_cast<int>(vrt.features.aimbotList.size()); break;
                        case TabType::Movement: moduleCount = static_cast<int>(vrt.features.movementList.size()); break;
                        case TabType::Render: moduleCount = static_cast<int>(vrt.features.renderList.size()); break;
                        case TabType::Misc: moduleCount = static_cast<int>(vrt.features.miscList.size()); break;
                        case TabType::Config: moduleCount = static_cast<int>(vrt.features.configList.size()); break;
                        case TabType::HUD: moduleCount = static_cast<int>(vrt.features.hudList.size()); break;
                        case TabType::CUI: moduleCount = static_cast<int>(vrt.features.cuiList.size()); break;
                        default: moduleCount = 0; break;
                    }
                    if (moduleCount > 0) {
                        if (activeByTab < 0 || activeByTab >= moduleCount) {
                            activeByTab = 0;
                        }
                    } else {
                        activeByTab = -1;
                    }
                    if (tab_switched && activeByTab >= 0) {
                        contentSmoothRestoreTarget = 0.0f;
                    }
                }

                hLayout->NextColumn();

                auto sidebarSizedLayout = gui->layouts->GetSidebarLayout();
                if (sidebarSizedLayout) {
                    float top_padding = gui->cache.panelPadding;
                    float left_padding = gui->cache.panelPadding;
                    
                    float right_padding = gui->cache.panelPadding * 1.35f;
                    float bottom_padding = gui->cache.panelPadding;
                    ImVec2 avail = ImGui::GetContentRegionAvail();
                    float childHeight = ImMax(0.0f, avail.y - top_padding - bottom_padding);
                    float childWidth = ImMax(0.0f, avail.x - left_padding - right_padding);
                    sidebarSizedLayout->SetChildSize(ImVec2(childWidth, childHeight));
                    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + top_padding);
                    ImGui::SetCursorPosX(ImGui::GetCursorPosX() + left_padding);
                    bool blur_main_area = ctx.blur_enabled;
                    if (blur_main_area) {
                        ImGui::PushStyleColor(ImGuiCol_ChildBg, ImVec4(0.0f, 0.0f, 0.0f, 0.0f));
                    }
                    bool module_scroll_restored_this_frame = false;
                    float module_scroll_restore_target = 0.0f;
                    if (restoreModuleScroll[selectedTab]) {
                        module_scroll_restore_target = restoreModuleScrollTarget[selectedTab];
                        sidebarSizedLayout->SyncScrollState(module_scroll_restore_target);
                        sidebarSizedLayout->ForceScrollRestore(module_scroll_restore_target);
                        ImGui::SetNextWindowScroll(ImVec2(0.0f, module_scroll_restore_target));
                        module_scroll_restored_this_frame = true;
                    }
                    if (moduleSmoothRestorePending && moduleSmoothRestoreStartReady &&
                        moduleSmoothRestoreT <= 0.0001f) {
                        sidebarSizedLayout->SyncScrollState(moduleSmoothRestoreStart);
                        sidebarSizedLayout->ForceScrollRestore(moduleSmoothRestoreStart);
                        ImGui::SetNextWindowScroll(ImVec2(0.0f, moduleSmoothRestoreStart));
                        module_scroll_restored_this_frame = true;
                    }
                    if (preMorphToTopPending) {
                        sidebarSizedLayout->SyncScrollState(preMorphModuleY);
                        sidebarSizedLayout->ForceScrollRestore(preMorphModuleY);
                        ImGui::SetNextWindowScroll(ImVec2(0.0f, preMorphModuleY));
                        module_scroll_restored_this_frame = true;
                    }
                    sidebarSizedLayout->Begin();

                    ImGui::PopStyleVar();
                    settings.gui = gui;
                    ImGui::PushStyleVar(ImGuiStyleVar_Alpha, ctx.visual_t);

                    bool disableInteraction = false;

                    if (preMorphToTopPending) {
                        ImGui::SetScrollY(preMorphModuleY);
                        module_scroll_restored_this_frame = true;
                    }
                    if (tabMorphFx.active && moduleSmoothRestorePending) {
                        ImGui::SetScrollY(0.0f);
                        module_scroll_restored_this_frame = true;
                    }

                    if (!tabMorphFx.active && !preMorphToTopPending && moduleSmoothRestorePending) {
                        if (!moduleSmoothRestoreStartReady) {
                            moduleSmoothRestoreStart = ImGui::GetScrollY();
                            moduleSmoothRestoreStartReady = true;
                        }
                        const float restore_speed = std::clamp(gui->animationTuning.tabsSpeed, 0.2f, 4.0f) * 2.2f;
                        moduleSmoothRestoreT = std::min(1.0f, moduleSmoothRestoreT + frame_dt * restore_speed);
                        const float t = moduleSmoothRestoreT;
                        const float tt = t * t * t * (t * (t * 6.0f - 15.0f) + 10.0f); 
                        const float y = moduleSmoothRestoreStart +
                                        (moduleSmoothRestoreTarget - moduleSmoothRestoreStart) * tt;
                        ImGui::SetScrollY(y);
                        module_scroll_restored_this_frame = true;
                        if (moduleSmoothRestoreT >= 0.999f) {
                            moduleSmoothRestorePending = false;
                            moduleSmoothRestoreWaitingCapture = false;
                            moduleSmoothRestoreResetDone = false;
                            moduleSmoothRestoreStartReady = false;
                            moduleSmoothRestoreT = 0.0f;
                        }
                    }

                    if (sidebarSizedLayout->GetIsScrolling() || fabsf(sidebarSizedLayout->GetScrollMomentum()) > 0.1f) {
                        disableInteraction = true;
                    }
                    if ((ComboPopupBlocksInput() || ColorPickerPopupBlocksInput()) && post_processing.flags.blur) {
                        disableInteraction = true;
                    }

                    if (disableInteraction) {
                        ImGui::PushItemFlag(ImGuiItemFlags_Disabled, true);
                    }

                    ImGui::PushStyleVar(ImGuiStyleVar_Alpha, sidebar_fade_alpha);
                    RenderModule(currentTab, gui->theme.get());
                    ImGui::PopStyleVar();
                    ImGui::Dummy(ImVec2(0.0f, gui->cache.gradientHeight * 0.5f));
                    if (module_scroll_restored_this_frame) {
                        if (--restoreModuleScrollFrames[selectedTab] <= 0) {
                            restoreModuleScroll[selectedTab] = false;
                            restoreModuleScrollFrames[selectedTab] = 0;
                        }
                    }

                    const int activeModuleNow = vrt.features.activeByTab[selectedTab];
                    const bool module_switch_pending_for_tab =
                        moduleSwitchPending && (pendingModuleTab == selectedTab);
                    const bool module_switched = (lastActiveModuleByTab[selectedTab] != -999) &&
                                                 (activeModuleNow != lastActiveModuleByTab[selectedTab]) &&
                                                 !module_switch_pending_for_tab;
                    if (module_switched && !tab_switched && suppressModuleSwitchAnimFrames[selectedTab] == 0 && gui->tabMorphEnabled) {
                        const int prevModule = lastActiveModuleByTab[selectedTab];
                        moduleSmoothRestorePending = false;
                        moduleSmoothRestoreWaitingCapture = false;
                        moduleSmoothRestoreResetDone = false;
                        moduleSmoothRestoreTarget = 0.0f;
                        moduleSmoothRestoreStart = 0.0f;
                        moduleSmoothRestoreStartReady = false;
                        moduleSmoothRestoreT = 0.0f;
                        contentSmoothRestorePending = false;
                        contentSmoothRestoreWaitingCapture = false;
                        contentSmoothRestoreResetDone = false;
                        contentSmoothRestoreTarget = 0.0f;
                        contentSmoothRestoreStart = 0.0f;
                        contentSmoothRestoreStartReady = false;
                        contentSmoothRestoreT = 0.0f;
                        moduleSwitchPending = false;
                        pendingModuleTab = -1;
                        pendingModule = -1;
                        restoreModuleScroll[selectedTab] = false;
                        restoreContentScroll[selectedTab] = false;
                        restoreModuleScrollFrames[selectedTab] = 0;
                        restoreContentScrollFrames[selectedTab] = 0;
                        restoreContentScrollTarget[selectedTab] = 0.0f;
                        moduleSwitchPending = true;
                        pendingModuleTab = selectedTab;
                        pendingModule = activeModuleNow;
                        if (prevModule >= 0) {
                            vrt.features.activeByTab[selectedTab] = prevModule;
                        }
                        tabMorphFx.force_motion = 1.0f;
                        tabMorphFx.switch_dir = (activeModuleNow >= prevModule) ? 1.0f : -1.0f;
                        tabMorphFx.animate_module = false;
                        tabMorphFx.animate_content = true;
                        tabMorphFx.is_module_switch = true;
                        tabMorphFx.switch_module_tab = selectedTab;
                        tabMorphFx.from_module = prevModule;
                        tabMorphFx.to_module = activeModuleNow;
                        tabMorphFx.start_requested = false;
                        tabMorphFx.start_delay_frames = 0;
                        tabMorphFx.active = true;
                        tabMorphFx.progress = 1.0f;
                        tabMorphFx.play_dir = -1.0f;
                        tabMorphFx.primed = false;
                        tabMorphFx.rects_frozen = false;
                        tabMorphFx.recapture_pending = false;
                        tabMorphFx.recapture_frames = 0;
                    }
module_switch_done:
                    
                    
                    lastActiveModuleByTab[selectedTab] = vrt.features.activeByTab[selectedTab];

                    if (disableInteraction) {
                        ImGui::PopItemFlag();
                    }

                    float sidebar_scroll = module_scroll_restored_this_frame
                        ? module_scroll_restore_target
                        : ImGui::GetScrollY();
                    float sidebar_scroll_max = ImGui::GetScrollMaxY();
                    lastSidebarScrollY = sidebar_scroll;
                    if (module_scroll_restored_this_frame && sidebar_scroll > sidebar_scroll_max) {
                        sidebar_scroll = sidebar_scroll_max;
                    }
                    savedModuleScrollByTab[selectedTab] = sidebar_scroll;
                    gui->post_layout_fade.sidebar_valid = false;
                    gui->post_layout_fade.sidebar_top_alpha = 0.0f;
                    gui->post_layout_fade.sidebar_bottom_alpha = 0.0f;
                    const ImVec2 module_pos = ImGui::GetWindowPos();
                    const ImVec2 module_size = ImGui::GetWindowSize();
                    const ImVec2 module_max = ImVec2(module_pos.x + module_size.x, module_pos.y + module_size.y);
                    tabMorphFx.module_min = module_pos;
                    tabMorphFx.module_max = module_max;
                    tabMorphFx.module_valid = (module_size.x > 1.0f && module_size.y > 1.0f);

                    sidebarSizedLayout->End();
                    if (blur_main_area) {
                        ImGui::PopStyleColor();
                    }
                }

                hLayout->NextColumn();

                auto contentLayout = gui->layouts->GetContentLayout();
                if (contentLayout) {
                    float top_padding = gui->cache.panelPadding;
                    float left_padding = 0.0f;
                    float right_padding = gui->cache.panelPadding;
                    float bottom_padding = gui->cache.panelPadding;
                    const float pane_inner_pad_x = 28.0f * gui->cache.uiScale;
                    const float pane_inner_pad_y = 20.0f * gui->cache.uiScale;

                    ImVec2 avail = ImGui::GetContentRegionAvail();
                    ImVec2 col_screen = ImGui::GetCursorScreenPos();
                    ImVec2 pane_outer_min = ImVec2(col_screen.x + left_padding, col_screen.y + top_padding);
                    ImVec2 pane_outer_size = ImVec2(
                        ImMax(0.0f, avail.x - left_padding - right_padding),
                        ImMax(0.0f, avail.y - top_padding - bottom_padding)
                    );
                    contentLayout->SetChildFlags(ImGuiChildFlags_AlwaysUseWindowPadding);
                    bool blur_main_area = ctx.blur_enabled;
                    
                    ImDrawList* pane_outer_dl = ImGui::GetWindowDrawList();
                    ImVec2 pane_pos = pane_outer_min;
                    ImVec2 pane_size = pane_outer_size;
                    float pane_rounding = corner_radius;
                    ImVec4 pane_color = ImGui::ColorConvertU32ToFloat4(ctx.main_area_color);
                    const float pane_shadow_alpha = blur_main_area
                        ? std::clamp(blur_alpha, 0.0f, 1.0f)
                        : std::clamp(ctx.visual_t, 0.0f, 1.0f);

                    if (blur_main_area) {
                        const float target_sidebar_alpha = std::min(1.0f, 0.8f * blur_alpha);
                        const float base_main_alpha = std::clamp(blur_alpha * 0.70f, 0.0f, 0.98f);
                        float extra_alpha = 0.0f;
                        if (target_sidebar_alpha > base_main_alpha) {
                            extra_alpha = (target_sidebar_alpha - base_main_alpha) / std::max(0.001f, 1.0f - base_main_alpha);
                        }
                        pane_color.x = ContentOverlayLighten(pane_color.x * 0.81f);
                        pane_color.y = ContentOverlayLighten(pane_color.y * 0.81f);
                        pane_color.z = ContentOverlayLighten(pane_color.z * 0.81f);
                        pane_color.w = std::clamp(extra_alpha * 0.72f, 0.0f, 1.0f);
                    } else {
                        // non-blur: контент лайаут = цвет сайдбара
                        pane_color = ImGui::ColorConvertU32ToFloat4(ctx.sidebar_color);
                        pane_color.w = std::max(0.92f * ctx.visual_t, pane_color.w * ctx.visual_t);
                    }
                    pane_color.w *= content_fade_alpha;

                    pane_outer_dl->PushClipRectFullScreen();
                    if (post_processing.flags.shadow && pane_shadow_alpha > 0.0001f) {
                        const float tuned_child_shadow_alpha = std::clamp(pane_shadow_alpha * 0.70f, 0.0f, 1.0f);
                        ImColor pane_shadow_col(0.0f, 0.0f, 0.0f, 0.20f);
                        if (blur_main_area) {
                            ImVec4 glow = ImVec4(1.0f, 1.0f, 1.0f, 0.22f);
                            if (gui->theme && gui->theme->IsLightMode()) {
                                glow = ImVec4(0.0f, 0.0f, 0.0f, 0.16f);
                            } else if (gui->theme) {
                                glow = gui->theme->HexToImVec4(gui->theme->material.surfaceVariant);
                                glow.w = 0.22f;
                            }
                            pane_shadow_col = ImColor(glow.x, glow.y, glow.z, glow.w);
                        }
                        drawRoundedRectShadow(
                            pane_pos,
                            ImVec2(pane_pos.x + pane_size.x, pane_pos.y + pane_size.y),
                            pane_rounding,
                            pane_shadow_col,
                            tuned_child_shadow_alpha,
                            std::clamp(gui->appearance.shadowRings, 6, 32),
                            std::clamp(gui->appearance.shadowSmoothness, 0.35f, 1.60f),
                            true
                        );
                    }
                    pane_outer_dl->AddRectFilled(
                        pane_pos,
                        ImVec2(pane_pos.x + pane_size.x, pane_pos.y + pane_size.y),
                        ImGui::GetColorU32(pane_color),
                        pane_rounding,
                        ImDrawFlags_RoundCornersAll
                    );

                    float border_alpha = 0.0f;
                    float border_w = std::max(1.0f, gui->cache.lineWidth * 1.45f);
                    float border_half = border_w * 0.5f;
                    ImVec2 border_min = ImVec2(std::floor(pane_pos.x + border_half) + 0.5f,
                                               std::floor(pane_pos.y + border_half) + 0.5f);
                    ImVec2 border_max = ImVec2(std::ceil(pane_pos.x + pane_size.x - border_half) - 0.5f,
                                               std::ceil(pane_pos.y + pane_size.y - border_half) - 0.5f);
                    border_min.x = std::floor(border_min.x) + 0.5f;
                    border_min.y = std::floor(border_min.y) + 0.5f;
                    border_max.x = std::ceil(border_max.x) - 0.5f;
                    border_max.y = std::ceil(border_max.y) - 0.5f;
                    pane_outer_dl->PopClipRect();

                    
                    const float child_inset = std::max(1.0f, border_w);
                    ImVec2 child_min = ImVec2(border_min.x + child_inset, border_min.y + child_inset);
                    ImVec2 child_max = ImVec2(border_max.x - child_inset, border_max.y - child_inset);
                    ImVec2 child_size = ImVec2(
                        ImMax(0.0f, child_max.x - child_min.x),
                        ImMax(0.0f, child_max.y - child_min.y)
                    );
                    
                    gui->post_layout_fade.content_pos = border_min;
                    gui->post_layout_fade.content_size = ImVec2(
                        ImMax(0.0f, border_max.x - border_min.x),
                        ImMax(0.0f, border_max.y - border_min.y)
                    );
                    gui->post_layout_fade.content_rounding = std::max(0.0f, pane_rounding - border_half);
                    if (child_size.x > 1.0f && child_size.y > 1.0f) {
                        contentLayout->SetChildSize(child_size);
                        ImGui::SetCursorScreenPos(child_min);
                    } else {
                        contentLayout->SetChildSize(pane_outer_size);
                        ImGui::SetCursorScreenPos(pane_outer_min);
                        gui->post_layout_fade.content_pos = pane_pos;
                        gui->post_layout_fade.content_size = pane_size;
                        gui->post_layout_fade.content_rounding = std::max(0.0f, pane_rounding - border_w);
                    }

                    if (blur_main_area) {
                        ImGui::PushStyleColor(ImGuiCol_ChildBg, ImVec4(0.0f, 0.0f, 0.0f, 0.0f));
                    }
                    ImGui::PushStyleVar(ImGuiStyleVar_Alpha, content_fade_alpha);
                    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(pane_inner_pad_x, 0.0f));
                    contentLayout->SetScrollable(true);

                    const ImVec2 header_pos = ImVec2(child_min.x + pane_inner_pad_x, child_min.y + pane_inner_pad_y);
                    const float header_forced_width = std::max(1.0f, child_size.x - pane_inner_pad_x * 2.0f);
                    ImGui::SetCursorScreenPos(header_pos);
                    const ImVec2 header_start = header_pos;
                    RenderContent(currentTab, gui->widgets.get(), gui->layouts.get(), &settings,
                                  ctx.clamped_window_width, ctx.clamped_window_height, true, false, header_forced_width);
                    const float header_h = std::max(0.0f, ImGui::GetCursorScreenPos().y - child_min.y);

                    const float body_h = std::max(1.0f, child_size.y - header_h - pane_inner_pad_y);
                    contentLayout->SetChildSize(ImVec2(child_size.x, body_h));
                    ImGui::SetCursorScreenPos(ImVec2(child_min.x, child_min.y + header_h));
                    bool content_scroll_restored_this_frame = false;
                    float content_scroll_restore_target = 0.0f;
                    const int active_module_for_content = vrt.features.activeByTab[selectedTab];
                    if (restoreContentScroll[selectedTab]) {
                        content_scroll_restore_target = restoreContentScrollTarget[selectedTab];
                        contentLayout->SyncScrollState(content_scroll_restore_target);
                        contentLayout->ForceScrollRestore(content_scroll_restore_target);
                        ImGui::SetNextWindowScroll(ImVec2(0.0f, content_scroll_restore_target));
                        content_scroll_restored_this_frame = true;
                    }
                    if (contentSmoothRestorePending && contentSmoothRestoreStartReady &&
                        contentSmoothRestoreT <= 0.0001f) {
                        contentLayout->SyncScrollState(contentSmoothRestoreStart);
                        contentLayout->ForceScrollRestore(contentSmoothRestoreStart);
                        ImGui::SetNextWindowScroll(ImVec2(0.0f, contentSmoothRestoreStart));
                        content_scroll_restored_this_frame = true;
                    }
                    if (preMorphToTopPending) {
                        contentLayout->SyncScrollState(preMorphContentY);
                        contentLayout->ForceScrollRestore(preMorphContentY);
                        ImGui::SetNextWindowScroll(ImVec2(0.0f, preMorphContentY));
                        content_scroll_restored_this_frame = true;
                    }
                    
                    
                    contentLayout->Begin();

                    bool disableInteraction = false;
                    if (preMorphToTopPending) {
                        ImGui::SetScrollY(preMorphContentY);
                        content_scroll_restored_this_frame = true;
                    }
                    if (tabMorphFx.active && contentSmoothRestorePending) {
                        ImGui::SetScrollY(0.0f);
                        content_scroll_restored_this_frame = true;
                    }
                    if (!tabMorphFx.active && !preMorphToTopPending && contentSmoothRestorePending) {
                        if (!contentSmoothRestoreStartReady) {
                            contentSmoothRestoreStart = ImGui::GetScrollY();
                            contentSmoothRestoreStartReady = true;
                        }
                        const float restore_speed = std::clamp(gui->animationTuning.tabsSpeed, 0.2f, 4.0f) * 2.2f;
                        contentSmoothRestoreT = std::min(1.0f, contentSmoothRestoreT + frame_dt * restore_speed);
                        const float t = contentSmoothRestoreT;
                        const float tt = t * t * t * (t * (t * 6.0f - 15.0f) + 10.0f); 
                        const float y = contentSmoothRestoreStart +
                                        (contentSmoothRestoreTarget - contentSmoothRestoreStart) * tt;
                        ImGui::SetScrollY(y);
                        content_scroll_restored_this_frame = true;
                        if (contentSmoothRestoreT >= 0.999f) {
                            contentSmoothRestorePending = false;
                            contentSmoothRestoreWaitingCapture = false;
                            contentSmoothRestoreResetDone = false;
                            contentSmoothRestoreStartReady = false;
                            contentSmoothRestoreT = 0.0f;
                        }
                    }
                    if (contentLayout->GetIsScrolling() || fabsf(contentLayout->GetScrollMomentum()) > 0.1f) {
                        disableInteraction = true;
                    }
                    if ((ComboPopupBlocksInput() || ColorPickerPopupBlocksInput()) && post_processing.flags.blur) {
                        disableInteraction = true;
                    }

                    if (disableInteraction) {
                        ImGui::PushItemFlag(ImGuiItemFlags_Disabled, true);
                    }

                    RenderContent(currentTab, gui->widgets.get(), gui->layouts.get(), &settings,
                                  ctx.clamped_window_width, ctx.clamped_window_height, false, true);
                    ImGui::Dummy(ImVec2(0.0f, 0.0f));
                    if (content_scroll_restored_this_frame) {
                        if (--restoreContentScrollFrames[selectedTab] <= 0) {
                            restoreContentScroll[selectedTab] = false;
                            restoreContentScrollFrames[selectedTab] = 0;
                        }
                    }

                    float content_scroll = content_scroll_restored_this_frame
                        ? content_scroll_restore_target
                        : ImGui::GetScrollY();
                    float content_scroll_max = ImGui::GetScrollMaxY();
                    lastContentScrollY = content_scroll;
                    if (content_scroll_restored_this_frame && content_scroll > content_scroll_max) {
                        content_scroll = content_scroll_max;
                    }
                    savedContentScrollByTab[selectedTab] = content_scroll;
                    if (active_module_for_content >= 0 && active_module_for_content < 64) {
                        savedContentScrollByModule[selectedTab][active_module_for_content] = content_scroll;
                    }
                    if (disableInteraction) {
                        ImGui::PopItemFlag();
                    }

                    gui->post_layout_fade.content_valid = false;
                    gui->post_layout_fade.gradient_h = 0.0f;
                    gui->post_layout_fade.content_top_alpha = 0.0f;
                    gui->post_layout_fade.content_bottom_alpha = 0.0f;
                    gui->post_layout_fade.content_overlay = ImVec4(0.0f, 0.0f, 0.0f, 0.0f);
                    const ImVec2 content_pos2 = gui->post_layout_fade.content_pos;
                    const ImVec2 content_size2 = gui->post_layout_fade.content_size;
                    const ImVec2 content_max2 = ImVec2(content_pos2.x + content_size2.x, content_pos2.y + content_size2.y);
                    tabMorphFx.content_min = content_pos2;
                    tabMorphFx.content_max = content_max2;
                    tabMorphFx.content_valid = (content_size2.x > 1.0f && content_size2.y > 1.0f);

                    contentLayout->End();
                    ImGui::PopStyleVar();
                    ImGui::PopStyleVar();
                    if (blur_main_area) {
                        ImGui::PopStyleColor();
                    }
                }

                hLayout->End();
                ImGui::GetStyle().CellPadding = prev_cell_padding;
            }

            ImGui::PopStyleVar();
            gui->windows->End();
        }, "Window");

        built = true;
    }

    RenderContext context; context.gui = this;
    context.io = &ImGui::GetIO();
    context.gl_width = glWidth;
    context.gl_height = glHeight;
    context.bg_draw_list = ImGui::GetBackgroundDrawList();
    context.fg_draw_list = ImGui::GetForegroundDrawList();
    {
        ImGuiIO& io = ImGui::GetIO();
        UpdateMenuRippleInput(this, io.DeltaTime, io.MousePos, io.MouseDown[0], io.MouseClicked[0], io.MouseReleased[0]);
    }
    pipeline.Execute(context);

    if (!postOverlayBuilt) {
        BuildPostOverlayPipeline();
    }
    postOverlayPipeline.Execute(context);
    mainWantCaptureMouseSnapshot = ImGui::GetIO().WantCaptureMouse;
}

void ClickGUI::BuildPostOverlayPipeline() {
    postOverlayPipeline.Clear();
    postOverlayPipeline.AddPass([](RenderContext& ctx) {
        if (OshiNoKoIntro::Active()) {
            return;
        }
        if (!ctx.gui) {
            return;
        }
        tabMorphFx.start_requested = false;
        tabMorphFx.recapture_pending = false;
        tabMorphFx.primed = false;
        tabMorphFx.module_valid = false;
        tabMorphFx.content_valid = false;
    }, "TabMorph");
    postOverlayPipeline.AddPass([](RenderContext& ctx) {
        if (OshiNoKoIntro::Active()) {
            return;
        }
        if (!ctx.gui) {
            return;
        }
        struct RippleJob { ClickGUI* gui; int w, h; };
        auto* rjob = new RippleJob{ctx.gui, ctx.gl_width, ctx.gl_height};
        ctx.fg_draw_list->AddCallback([](const ImDrawList*, const ImDrawCmd* cmd) {
            auto* j = static_cast<RippleJob*>(cmd->UserCallbackData);
            RenderMenuRippleOverlay(j->gui, j->w, j->h);
            RenderPopupRippleOverlay(j->gui, j->w, j->h);
            delete j;
        }, rjob);
        ctx.fg_draw_list->AddCallback(ImDrawCallback_ResetRenderState, nullptr);
    }, "MenuRipple");
    postOverlayPipeline.AddPass([](RenderContext& ctx) {
        if (OshiNoKoIntro::Active()) {
            return;
        }
        static int s_dbg_wm_call_budget = 12;
        if (s_dbg_wm_call_budget-- > 0) {
        }
        RenderWatermark(ctx);
        static int s_dbg_wm_after_budget = 12;
        if (s_dbg_wm_after_budget-- > 0) {
        }
        struct WmRippleJob { ClickGUI* gui; int w, h; };
        auto* wrjob = new WmRippleJob{ctx.gui, ctx.gl_width, ctx.gl_height};
        ctx.fg_draw_list->AddCallback([](const ImDrawList*, const ImDrawCmd* cmd) {
            auto* j = static_cast<WmRippleJob*>(cmd->UserCallbackData);
            RenderWatermarkRippleOverlay(j->gui, j->w, j->h);
            delete j;
        }, wrjob);
        ctx.fg_draw_list->AddCallback(ImDrawCallback_ResetRenderState, nullptr);
    }, "Watermark");
    postOverlayPipeline.AddPass([](RenderContext& ctx) {
        if (OshiNoKoIntro::Active()) {
            return;
        }
        static int s_dbg_sg_call_budget = 12;
        if (s_dbg_sg_call_budget-- > 0) {
        }
        RenderSpeedGraph(ctx);
        static int s_dbg_sg_after_budget = 12;
        if (s_dbg_sg_after_budget-- > 0) {
        }
    }, "SpeedGraph");
    postOverlayPipeline.AddPass([](RenderContext& ctx) {
        if (OshiNoKoIntro::Active()) {
            return;
        }
        RenderMovementRecorder(ctx);
    }, "MovementRecorder");
    postOverlayPipeline.AddPass([](RenderContext& ctx) {
        if (OshiNoKoIntro::Active()) {
            return;
        }
        if (!ctx.gui) {
            return;
        }
        if (ComboOverlayNeedsPostRenderCapture()) {
            ComboOverlayPostRenderCapture(ctx.gl_width, ctx.gl_height);
        }
        if (ColorPickerPopupNeedsPostRenderCapture()) {
            ColorPickerPopupPostRenderCapture(ctx.gl_width, ctx.gl_height);
        }
        ComboOverlayRenderPostPass();
        ColorPickerPopupRenderPostPass();
    }, "ComboOverlayCapture");
    postOverlayBuilt = true;
}

void ClickGUI::PostOverlay(int display_w, int display_h) {
    UpdateMenuRippleInput(this, ImGui::GetIO().DeltaTime, ImGui::GetIO().MousePos,
        ImGui::GetIO().MouseDown[0], ImGui::GetIO().MouseClicked[0], ImGui::GetIO().MouseReleased[0]);
    RenderTabMorphOverlay(this, display_w, display_h);
}

enum class TouchScreenKeyboardStatus : int {
    Visible = 0,
    Done = 1,
    Canceled = 2,
    LostFocus = 3
};

static bool Input = true;
static void* Keyboard = nullptr;
static std::string LastText = "";

static void 
     *(*Open) 
     (Il2CppString*, int,
     bool, bool, bool, bool, 
     Il2CppString*, int) = nullptr;
               
static Il2CppString
     *(*GetText)
     (void *) = nullptr;
     
static TouchScreenKeyboardStatus 
     (*GetStatus)
     (void *) = nullptr;
     
static void 
     (*Destroy) 
     (void *) = nullptr;

bool SearchKeyboard = false;
static void FindKeyboard() {
    if (!SearchKeyboard) {
        Open = (decltype(Open)) (base + 
            vMemory::UnityEngine::TouchScreenKeyboard::Open);
        Destroy = (decltype(Destroy)) (base + 
            vMemory::UnityEngine::TouchScreenKeyboard::Destroy);
        GetText = (decltype(GetText)) (base + 
            vMemory::UnityEngine::TouchScreenKeyboard::get_text);
        GetStatus = (decltype(GetStatus)) (base +
            vMemory::UnityEngine::TouchScreenKeyboard::get_status);
        SearchKeyboard = true;
    }
}

static void CloseKeyboard() {
    if (Keyboard && Destroy) { 
       Destroy(Keyboard); 
       Keyboard = nullptr;
    } Input = true;
    LastText.clear();
}

void ClickGUI::Touch::Update(
    ImGuiIO& io, int touch_count) {
   
    GetTouchSystem.Update(io, touch_count);
    ImVector<ImGuiID> unused_touches;
    GetTouchSystem.GetUnusedTouchIDs(unused_touches);

    if (unused_touches.Size > 0) {
        ImVec2 touch_pos = GetTouchSystem.GetTouchPosition(unused_touches[0]);
        io.MousePos = touch_pos;
        TouchPhase phase = GetTouchSystem.GetTouchPhase(unused_touches[0]);
        if (phase == TouchPhase_Began) {
            io.MouseDown[0] = true;
            io.MouseClicked[0] = true;
            io.MouseClickedPos[0] = touch_pos;
        } else if (phase == TouchPhase_Moved || phase == TouchPhase_Stationary) {
            io.MouseDown[0] = true;
        } else if (phase == TouchPhase_Ended || phase == TouchPhase_Canceled) {
            io.MouseDown[0] = false;
            io.MouseReleased[0] = true;
        }
    } else {
        io.MouseDown[0] = false;
    }
}

void ClickGUI::Toggle() {
    open = !open;
    if (open) {
        if (!introPlayedOnce) {
            OshiNoKoIntro::Begin();
            introPlayedOnce = true;
        }
        animation.Open();
    } else {
        OshiNoKoIntro::End();
        animation.Close();
    }
}

bool ClickGUI::ShouldForceCaptureMouse(const ImVec2& mouse_pos, bool pointer_down_or_click) const {
    ImVec2 pmin(0.0f, 0.0f), pmax(0.0f, 0.0f);
    const bool popup_visible = ColorPickerPopupGetVisualRect(&pmin, &pmax) ||
                               ComboPopupGetVisualRect(&pmin, &pmax);
    if (pointer_down_or_click && popup_visible) {
        return true; 
    }
    if (pointer_down_or_click && watermarkCaptureValid) {
        if (mouse_pos.x >= watermarkCaptureMin.x && mouse_pos.x <= watermarkCaptureMax.x &&
            mouse_pos.y >= watermarkCaptureMin.y && mouse_pos.y <= watermarkCaptureMax.y) {
            return true;
        }
    }
    return false;
}

bool ClickGUI::ShouldBlockGameInput(const ImVec2& mouse_pos, bool pointer_down_or_click) const {
    return mainWantCaptureMouseSnapshot || overlayWantCaptureMouseSnapshot ||
           ShouldForceCaptureMouse(mouse_pos, pointer_down_or_click);
}

void ClickGUI::NotifyWatermarkInteraction(const ImVec2& pos, float strength) {
    NotifyWatermarkRippleInteraction(this, pos, strength);
}

void ClickGUI::NotifyWatermarkVisualMotion(const ImVec2& velocity, float amp, float dt) {
    NotifyWatermarkRippleVisualMotion(this, velocity, amp, dt);
}

void ClickGUI::Scale::Apply(ClickGUI& gui, float new_scale) {
    new_scale = std::clamp(new_scale, 0.5f, 2.0f);
    Scale = new_scale;

    ImGuiStyle& style = ImGui::GetStyle();
    if (LastApplied == 0.0f) {
        LastApplied = 1.0f;
    }

    if (LastApplied != new_scale) {
        
        
        if (LastApplied != 0.0f && std::fabs(LastApplied - 1.0f) > 1e-4f) {
            style.ScaleAllSizes(1.0f / LastApplied);
        }
        if (gui.theme) {
            gui.theme->Update();
        }
        style.ScaleAllSizes(new_scale);
        ImGui::GetIO().FontGlobalScale = new_scale * 0.75f;
        LastApplied = new_scale;
    }

    gui.height = static_cast<int>(Height * new_scale);
    gui.width = static_cast<int>(Width * new_scale);

    if (gui.theme) {
        gui.theme->Update();
    }
}
