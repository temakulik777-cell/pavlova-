#pragma once
#include <memory>
#include <vector>
#include <functional>
#include <cstdint>
#include <cfloat>

#include "../../v_memory.h"
#include <type_traits>
#include <string>
#include <unordered_map>
#include <any>
#include "../clickgui.h"
#include "imgui/imgui.h"
#include "imgui/im_anim/im_anim.h"

namespace WidgetActivity {
extern bool g_active;
extern bool g_has_value;

void BeginCapture();
float WidgetUiScale();
void SetActive(bool active);
bool ConsumeOrFallback(bool fallback);
}

namespace WidgetBase {
struct AccentGradient {
    ImVec4 start = ImVec4(0.294f, 0.412f, 0.996f, 1.0f);
    ImVec4 end = ImVec4(0.294f, 0.412f, 0.996f, 1.0f);
    bool gradient = false;
};

ImVec4 AlphaAware(ImVec4 c);
ImVec2 ScaledGlyphOffset(const ImFont* font, float size);
float CalcWrappedTextHeight(const char* text, float font_size, float wrap_width);
ImVec4 DescriptionColor(Theme* theme);
ImVec4 TrackColor(Theme* theme);
ImVec4 PrimaryColor(Theme* theme);
AccentGradient PrimaryGradient(Theme* theme);
ImVec4 PrimaryMidColor(Theme* theme);
ImVec4 AccentColorAtY(Theme* theme, float y_screen);
void AddAccentRect(ImDrawList* dl, const ImVec2& min, const ImVec2& max,
                   const AccentGradient& grad, Theme* theme, float rounding = 0.0f,
                   ImDrawFlags flags = ImDrawFlags_RoundCornersAll);
void ShadeVertsAccent(ImDrawList* dl, int vtx_start, int vtx_end,
                      const ImVec2& p0, const ImVec2& p1,
                      Theme* theme, float alpha = 1.0f);
ImVec4 OutlineColor(Theme* theme);
float ClampNorm(float v, float min_v, float max_v);
float Unnorm(float t, float min_v, float max_v);
}

bool Checkbox(const char* label, const char* description, bool* value, Theme* theme);
bool Checkbox(const char* label, const char* description, bool* value, Theme* theme, bool* out_active);
bool SliderFloat(const char* label, const char* description, float* value, float min, float max, Theme* theme);
bool SliderFloat(const char* label, const char* description, float* value, float min, float max, Theme* theme, bool* out_active);
bool SliderInt(const char* label, const char* description, int* value, int min, int max, Theme* theme);
bool SliderInt(const char* label, const char* description, int* value, int min, int max, Theme* theme, bool* out_active);
bool Combo(const char* label, const char* description, int* value, const char* const items[], int items_count, Theme* theme);
bool Combo(const char* label, const char* description, int* value, const char* const items[], int items_count, Theme* theme, bool* out_active);
bool MultiCombo(const char* label, const char* description, uint32_t* values_mask, const char* const items[], int items_count, Theme* theme);
bool MultiCombo(const char* label, const char* description, uint32_t* values_mask, const char* const items[], int items_count, Theme* theme, bool* out_active);
bool ColorPicker3(const char* label, const char* description, float* r, float* g, float* b, float min, float max, Theme* theme);
bool ColorPicker3(const char* label, const char* description, float* r, float* g, float* b, float min, float max, Theme* theme, bool* out_active);
bool ColorPicker3(const char* label, const char* description,
                  float* r1, float* g1, float* b1,
                  float* r2, float* g2, float* b2,
                  float min, float max, Theme* theme);
bool ColorPicker3(const char* label, const char* description,
                  float* r1, float* g1, float* b1,
                  float* r2, float* g2, float* b2,
                  float min, float max, Theme* theme, bool* out_active);
bool CurveGraph(const char* label, const char* description, float* values, int count, const char* const names[],
                const float* mins, const float* maxs, Theme* theme);
bool CurveGraph(const char* label, const char* description, float* values, int count, const char* const names[],
                const float* mins, const float* maxs, Theme* theme, bool* out_active);
bool ScreenPositionGrid(const char* label, const char* description,
                        float* norm_x, float* norm_y,
                        float screen_aspect, float object_width_norm, float object_height_norm, float expanded_width_norm,
                        Theme* theme);
bool ScreenPositionGrid(const char* label, const char* description,
                        float* norm_x, float* norm_y,
                        float screen_aspect, float object_width_norm, float object_height_norm, float expanded_width_norm,
                        Theme* theme, bool* out_active);
bool ActionButton(const char* label, Theme* theme, bool* out_active);
bool ActionButtonQuad(const std::array<const char*, 4>& labels, Theme* theme, std::array<bool, 4>* out_active);
void SectionSeparator(const char* text = "Settings");
bool ComboOverlayNeedsPostRenderCapture();
void ComboOverlayPostRenderCapture(int display_w, int display_h);
void ComboOverlayRenderPostPass();
bool ComboPopupBlocksInput();
bool ComboPopupGetVisualRect(ImVec2* out_min, ImVec2* out_max);
bool ColorPickerPopupNeedsPostRenderCapture();
void ColorPickerPopupPostRenderCapture(int display_w, int display_h);
void ColorPickerPopupRenderPostPass();
bool ColorPickerPopupBlocksInput();
bool ColorPickerPopupGetVisualRect(ImVec2* out_min, ImVec2* out_max);

class WidgetRenderer {
public:
    virtual ~WidgetRenderer() = default;
    virtual bool Render(bool* out_active) = 0;
};

class CheckboxRenderer final : public WidgetRenderer {
public:
    CheckboxRenderer(const char* label, const char* description, bool* value, Theme* theme);
    bool Render(bool* out_active) override;

private:
    const char* label_;
    const char* description_;
    bool* value_;
    Theme* theme_;
};

class SliderFloatRenderer final : public WidgetRenderer {
public:
    SliderFloatRenderer(const char* label, const char* description, float* value, float min, float max, Theme* theme);
    bool Render(bool* out_active) override;

private:
    const char* label_;
    const char* description_;
    float* value_;
    float min_;
    float max_;
    Theme* theme_;
};

class SliderIntRenderer final : public WidgetRenderer {
public:
    SliderIntRenderer(const char* label, const char* description, int* value, int min, int max, Theme* theme);
    bool Render(bool* out_active) override;

private:
    const char* label_;
    const char* description_;
    int* value_;
    int min_;
    int max_;
    Theme* theme_;
};

class ComboRenderer final : public WidgetRenderer {
public:
    ComboRenderer(const char* label, const char* description, int* value, const char* const items[], int items_count, Theme* theme);
    bool Render(bool* out_active) override;

private:
    const char* label_;
    const char* description_;
    int* value_;
    const char* const* items_;
    int items_count_;
    Theme* theme_;
};

class ColorPicker3Renderer final : public WidgetRenderer {
public:
    ColorPicker3Renderer(const char* label, const char* description, float* r, float* g, float* b,
                         float min, float max, Theme* theme);
    bool Render(bool* out_active) override;

private:
    const char* label_;
    const char* description_;
    float* r_;
    float* g_;
    float* b_;
    float min_;
    float max_;
    Theme* theme_;
};

class CurveGraphRenderer final : public WidgetRenderer {
public:
    CurveGraphRenderer(const char* label, const char* description, float* values, int count,
                       const char* const names[], const float* mins, const float* maxs, Theme* theme);
    bool Render(bool* out_active) override;

private:
    const char* label_;
    const char* description_;
    float* values_;
    int count_;
    const char* const* names_;
    const float* mins_;
    const float* maxs_;
    Theme* theme_;
};


extern int ActiveWidgetsCount;


template<typename T>
class Widgets {
protected:
    std::string name;
    T* value_ptr;

public:
    Widgets(const std::string& widgetName, T* valuePtr);
    T GetValue() const;
    void SetValue(const T& value);
    static inline std::unordered_map<void*, bool> widgetStates;
    static void UpdateActivity(void* widgetId, bool isActive) {
        extern int ActiveWidgetsCount; 
        bool prevState = widgetStates[widgetId];
        widgetStates[widgetId] = isActive;

        if (isActive && !prevState) {
            
            ActiveWidgetsCount++;
        } else if (!isActive && prevState) {
            
            ActiveWidgetsCount = (ActiveWidgetsCount > 0) ? ActiveWidgetsCount - 1 : 0;
        }
    }

    static void RemoveActivity(void* widgetId) {
        extern int ActiveWidgetsCount; 
        if (widgetStates.count(widgetId) && widgetStates[widgetId]) {
            ActiveWidgetsCount = (ActiveWidgetsCount > 0) ? ActiveWidgetsCount - 1 : 0;
        }
        widgetStates.erase(widgetId);
    }
};



template<typename T>
class WidgetReference {
private:
    T* value_ptr;

public:
    WidgetReference(T* ptr);
    
    
    operator T&();
    operator const T&() const;
    
    
    T& operator*();
    const T& operator*() const;
    
    T* operator->();
    const T* operator->() const;
    
    
    WidgetReference& operator=(const T& value);
    WidgetReference& operator=(T&& value);
};


class WidgetManager {
private:
    
    std::unordered_map<std::string, std::any> widget_values;
    Theme* theme = nullptr;
    std::string scope_prefix;
    static inline WidgetManager* s_active_instance = nullptr;

    std::string ScopedKey(const std::string& name) const {
        if (scope_prefix.empty()) {
            return name;
        }
        return scope_prefix + "::" + name;
    }

    void AddItemSpacing() {
        const float spacing = std::max(8.0f, ImGui::GetStyle().ItemSpacing.y);
        ImGui::Dummy(ImVec2(0.0f, spacing));
    }

    void RenderWidget(WidgetRenderer& renderer) {
        bool active = false;
        renderer.Render(&active);
        WidgetActivity::SetActive(active);
    }

    template<typename T, typename DrawFn>
    WidgetReference<T> DrawValue(const std::string& name, T defaultValue, DrawFn draw) {
        AddItemSpacing();
        const std::string scoped_name = ScopedKey(name);
        T* value_ptr = nullptr;
        auto it = widget_values.find(scoped_name);
        if (it != widget_values.end()) {
            value_ptr = &std::any_cast<T&>(it->second);
        } else {
            widget_values[scoped_name] = defaultValue;
            value_ptr = &std::any_cast<T&>(widget_values[scoped_name]);
        }

        WidgetActivity::BeginCapture();
        draw(name.c_str(), value_ptr);
        Widgets<T>::UpdateActivity(value_ptr, WidgetActivity::ConsumeOrFallback(ImGui::IsItemActive()));
        return WidgetReference<T>(value_ptr);
    }

    WidgetReference<float> addSlider(const std::string& name, float defaultValue, float min, float max,
                                     const char* description = nullptr) {
        return DrawValue<float>(name, defaultValue, [this, description, min, max](const char* label, float* value) {
            SliderFloatRenderer renderer(label, description, value, min, max, this->theme);
            RenderWidget(renderer);
        });
    }

    WidgetReference<int> addSlider(const std::string& name, int defaultValue, int min, int max,
                                   const char* description = nullptr) {
        return DrawValue<int>(name, defaultValue, [this, description, min, max](const char* label, int* value) {
            SliderIntRenderer renderer(label, description, value, min, max, this->theme);
            RenderWidget(renderer);
        });
    }

    WidgetReference<double> addSlider(const std::string& name, double defaultValue, double min, double max,
                                      const char* description = nullptr) {
        return DrawValue<double>(name, defaultValue, [this, description, min, max](const char* label, double* value) {
            float tmp = static_cast<float>(*value);
            SliderFloatRenderer renderer(label, description, &tmp, static_cast<float>(min), static_cast<float>(max), this->theme);
            RenderWidget(renderer);
            *value = static_cast<double>(tmp);
        });
    }

public:
    WidgetManager();
    void Init();
    void SetTheme(Theme* themePtr) { theme = themePtr; }
    void PushScope(const std::string& scope) { scope_prefix = scope; }
    void PopScope() { scope_prefix.clear(); }
    void ResetScopeValues(const std::string& scope) {
        if (scope.empty()) {
            return;
        }
        const std::string prefix = scope + "::";
        for (auto it = widget_values.begin(); it != widget_values.end(); ) {
            if (it->first.rfind(prefix, 0) == 0) {
                it = widget_values.erase(it);
            } else {
                ++it;
            }
        }
    }
    static void ResetScopeValuesGlobal(const std::string& scope) {
        if (s_active_instance) {
            s_active_instance->ResetScopeValues(scope);
        }
    }
    

    
    
    void add(const std::string& name, std::function<void()> callback) {
        AddItemSpacing();
        bool active = false;
        if (ActionButton(name.c_str(), theme, &active)) {
            if (callback) {
                callback();
            }
        }

        const ImGuiID id = ImHashStr(name.c_str());
        Widgets<bool>::UpdateActivity(reinterpret_cast<void*>(static_cast<uintptr_t>(id)), active);
    }

    void addActionQuad(const std::array<const char*, 4>& labels,
                       const std::array<std::function<void()>, 4>& callbacks) {
        AddItemSpacing();
        std::array<bool, 4> clicked = {false, false, false, false};
        if (ActionButtonQuad(labels, theme, &clicked)) {
            for (size_t i = 0; i < callbacks.size(); ++i) {
                if (clicked[i] && callbacks[i]) {
                    callbacks[i]();
                }
            }
        }

        for (size_t i = 0; i < labels.size(); ++i) {
            if (!labels[i]) {
                continue;
            }
            const ImGuiID id = ImHashStr(labels[i]);
            Widgets<bool>::UpdateActivity(reinterpret_cast<void*>(static_cast<uintptr_t>(id)), clicked[i]);
        }
    }

    
    template<typename T>
    typename std::enable_if_t<std::is_same_v<T, bool>, WidgetReference<bool>>
    add(const std::string& name, T defaultValue) {
        return DrawValue<bool>(name, defaultValue, [this](const char* label, bool* value) {
            CheckboxRenderer renderer(label, nullptr, value, this->theme);
            RenderWidget(renderer);
        });
    }

    WidgetReference<bool> add(const std::string& name, bool defaultValue, const char* description) {
        return DrawValue<bool>(name, defaultValue, [this, description](const char* label, bool* value) {
            CheckboxRenderer renderer(label, description, value, this->theme);
            RenderWidget(renderer);
        });
    }

    
    template<typename T>
    typename std::enable_if_t<std::is_same_v<T, float>, WidgetReference<float>>
    add(const std::string& name, T defaultValue) {
        return addSlider(name, defaultValue, 0.0f, 100.0f, nullptr);
    }

    template<typename T>
    typename std::enable_if_t<std::is_same_v<T, float>, WidgetReference<float>>
    add(const std::string& name, T defaultValue, float min, float max, const char* description = nullptr) {
        return addSlider(name, defaultValue, min, max, description);
    }

    
    template<typename T>
    typename std::enable_if_t<std::is_same_v<T, int>, WidgetReference<int>>
    add(const std::string& name, T defaultValue) {
        return addSlider(name, defaultValue, 0, 100, nullptr);
    }

    template<typename T>
    typename std::enable_if_t<std::is_same_v<T, int>, WidgetReference<int>>
    add(const std::string& name, T defaultValue, int min, int max, const char* description = nullptr) {
        return addSlider(name, defaultValue, min, max, description);
    }

    WidgetReference<int> add(const std::string& name, int defaultValue,
                             const char* const items[], int items_count,
                             const char* description = nullptr) {
        return DrawValue<int>(name, defaultValue, [this, description, items, items_count](const char* label, int* value) {
            ComboRenderer renderer(label, description, value, items, items_count, this->theme);
            RenderWidget(renderer);
        });
    }

    WidgetReference<int> addCombo(const std::string& name, int defaultValue,
                                  const char* const items[], int items_count,
                                  const char* description = nullptr) {
        return add(name, defaultValue, items, items_count, description);
    }

    uint32_t addMultiCombo(const std::string& name, uint32_t defaultMask,
                           const char* const items[], int items_count,
                           const char* description = nullptr) {
        AddItemSpacing();
        const std::string scoped_name = ScopedKey(name);
        uint32_t* value_ptr = nullptr;
        auto it = widget_values.find(scoped_name);
        if (it != widget_values.end()) {
            value_ptr = &std::any_cast<uint32_t&>(it->second);
        } else {
            widget_values[scoped_name] = defaultMask;
            value_ptr = &std::any_cast<uint32_t&>(widget_values[scoped_name]);
        }

        WidgetActivity::BeginCapture();
        bool active = false;
        MultiCombo(name.c_str(), description, value_ptr, items, items_count, theme, &active);
        Widgets<bool>::UpdateActivity(value_ptr, WidgetActivity::ConsumeOrFallback(active));
        return *value_ptr;
    }

    bool addColorPicker3(const std::string& name, float* r, float* g, float* b,
                         float min, float max, const char* description = nullptr) {
        AddItemSpacing();
        ColorPicker3Renderer renderer(name.c_str(), description, r, g, b, min, max, theme);
        bool active = false;
        bool changed = renderer.Render(&active);
        void* id = r ? static_cast<void*>(r) : static_cast<void*>(this);
        Widgets<bool>::UpdateActivity(id, active);
        return changed;
    }

    bool add(const std::string& name, float* r, float* g, float* b,
             float min, float max, const char* description = nullptr) {
        return addColorPicker3(name, r, g, b, min, max, description);
    }

    bool addColorPicker3(const std::string& name,
                         float* r1, float* g1, float* b1,
                         float* r2, float* g2, float* b2,
                         float min, float max, const char* description = nullptr) {
        AddItemSpacing();
        bool active = false;
        bool changed = ColorPicker3(name.c_str(), description, r1, g1, b1, r2, g2, b2, min, max, theme, &active);
        void* id = r1 ? static_cast<void*>(r1) : static_cast<void*>(this);
        Widgets<bool>::UpdateActivity(id, active);
        return changed;
    }

    bool add(const std::string& name,
             float* r1, float* g1, float* b1,
             float* r2, float* g2, float* b2,
             float min, float max, const char* description = nullptr) {
        return addColorPicker3(name, r1, g1, b1, r2, g2, b2, min, max, description);
    }

    bool addCurveGraph(const std::string& name, float* values, int count, const char* const names[],
                       const float* mins, const float* maxs, const char* description = nullptr) {
        const float ui_scale = WidgetActivity::WidgetUiScale();
        const float base_spacing = 10.0f * ui_scale;
        const float curve_desc_gap = 8.0f * ui_scale;
        ImGui::Dummy(ImVec2(0.0f, std::max(0.0f, base_spacing - curve_desc_gap)));
        CurveGraphRenderer renderer(name.c_str(), description, values, count, names, mins, maxs, theme);
        bool active = false;
        bool changed = renderer.Render(&active);
        void* id = values ? static_cast<void*>(values) : static_cast<void*>(this);
        Widgets<bool>::UpdateActivity(id, active);
        return changed;
    }

    bool add(const std::string& name, float* values, int count, const char* const names[],
             const float* mins, const float* maxs, const char* description = nullptr) {
        return addCurveGraph(name, values, count, names, mins, maxs, description);
    }

    bool addScreenPosGrid(const std::string& name, float* norm_x, float* norm_y,
                          float screen_aspect, float object_width_norm, float object_height_norm, float expanded_width_norm,
                          const char* description = nullptr) {
        const float ui_scale = WidgetActivity::WidgetUiScale();
        const float base_spacing = 10.0f * ui_scale;
        const float graph_desc_gap = 8.0f * ui_scale;
        ImGui::Dummy(ImVec2(0.0f, std::max(0.0f, base_spacing - graph_desc_gap)));
        bool active = false;
        bool changed = ScreenPositionGrid(
            name.c_str(), description, norm_x, norm_y,
            screen_aspect, object_width_norm, object_height_norm, expanded_width_norm, theme, &active
        );
        void* id = norm_x ? static_cast<void*>(norm_x) : static_cast<void*>(this);
        Widgets<bool>::UpdateActivity(id, active);
        return changed;
    }

    bool add(const std::string& name, float* norm_x, float* norm_y,
             float screen_aspect, const char* description = nullptr,
             float object_width_norm = 0.26f, float object_height_norm = 0.075f, float expanded_width_norm = 0.38f) {
        return addScreenPosGrid(
            name, norm_x, norm_y,
            screen_aspect, object_width_norm, object_height_norm, expanded_width_norm, description
        );
    }

    
    template<typename T>
    typename std::enable_if_t<std::is_same_v<T, double>, WidgetReference<double>>
    add(const std::string& name, T defaultValue) {
        return addSlider(name, defaultValue, 0.0, 100.0, nullptr);
    }

    template<typename T>
    typename std::enable_if_t<std::is_same_v<T, double>, WidgetReference<double>>
    add(const std::string& name, T defaultValue, double min, double max, const char* description = nullptr) {
        return addSlider(name, defaultValue, min, max, description);
    }

    
    void add(const std::string& name, const char* text) {
        AddItemSpacing();
        if (std::string(text) == "Text") {
            ImGui::Text("%s", name.c_str());
        } else {
            ImGui::Text("%s", (std::string(name) + ": " + std::string(text)).c_str());
        }

        const ImGuiID id = ImHashStr(name.c_str());
        Widgets<bool>::UpdateActivity(reinterpret_cast<void*>(static_cast<uintptr_t>(id)), ImGui::IsItemActive());
    }

    
    void add(const std::string& name, const std::string& text) {
        AddItemSpacing();
        if (text == "Text") {
            ImGui::Text("%s", name.c_str());
        } else {
            ImGui::Text("%s", (name + ": " + text).c_str());
        }

        const ImGuiID id = ImHashStr(name.c_str());
        Widgets<bool>::UpdateActivity(reinterpret_cast<void*>(static_cast<uintptr_t>(id)), ImGui::IsItemActive());
    }

    
    void add(std::nullptr_t) {
        AddItemSpacing();
        ImGui::Separator();

        const uintptr_t id = reinterpret_cast<uintptr_t>(this) ^ 0xABCDu;
        Widgets<bool>::UpdateActivity(reinterpret_cast<void*>(id), ImGui::IsItemActive());
    }

    
    template<typename T>
    T& getValue(const std::string& name) {
        return std::any_cast<T&>(widget_values.at(ScopedKey(name)));
    }

    
    template<typename T>
    void setValue(const std::string& name, const T& value) {
        const std::string scoped_name = ScopedKey(name);
        if (widget_values.find(scoped_name) != widget_values.end()) {
            widget_values[scoped_name] = value;
        }
    }
};


class Module {
private:
    std::string functionName;
    std::string functionDescription;
    std::string indicatorLabel;
    bool* isActive;
    bool* isBound;
    bool showActiveToggle = true;
    int* activeSettingsIndex = nullptr;
    int settingsIndex = -1;
    ModuleCallback* settingsSlot;
    Theme* theme;

    
    mutable ImVec4 currentButtonColor;  
    mutable ImVec4 targetButtonColor;   
    mutable float colorInterpolationValue = 0.0f;  
    mutable bool lastActiveState = false;  
    mutable ImVec4 currentBindColor;
    mutable ImVec4 targetBindColor;
    bool skipIntroAnimation = true;

    
    static inline Module* activeCogWidget = nullptr;

private:
    
    void DrawTitle(float availableWidth);
    void DrawDescription(float availableWidth);
    float CalculateWrappedTextHeight(float fontSize, float availableWidth);
    void DrawActiveInactiveButton(float width, float heightScale = 1.0f, ImDrawFlags cornerFlags = ImDrawFlags_RoundCornersAll);
    void DrawResetButton(float width, float heightScale = 1.0f, ImDrawFlags cornerFlags = ImDrawFlags_RoundCornersAll);
    ImFont* GetAwesomeFont(float& iconFontSizeValue);
    float GetButtonHeight();
    float GetButtonWidthForLabel(const char* label);
    void GetButtonColors(bool isActive, ImVec4& outColor, ImVec4& outHoveredColor, ImVec4& outActiveColor);
    void HandleSettingsButtonClick();
    void HandleResetButtonClick();

public:
    Module(const char* name, const char* description, const char* indicator, bool* active, bool* bound, bool showActiveToggleValue, int* activeSettingsIndexPtr, int settingsIndexValue, ModuleCallback* settingsSlotPtr = nullptr, ModuleCallback settings = nullptr, Theme* themePtr = nullptr);

    std::string GetName() const;

    void Draw();

    static Module* GetActiveCogWidget() {
        return activeCogWidget;
    }

    void operator()() {
        Draw();
    }
};

void Tabs(int& selectedTab, const ClickGUI::Settings* settings = nullptr);
void Tabs(int& selectedTab, int tabIndex, const ClickGUI::Settings* settings = nullptr);
int TabsCount();
void SetTabMainAreaColor(ImU32 color);
ImU32 GetTabMainAreaColor();
