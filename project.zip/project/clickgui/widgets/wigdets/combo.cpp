#include "../wigdets.h"
#include "imgui/imgui_internal.h"
#include "imgui/im_anim/im_anim.h"
#include "../../imgui/box_shadow.h"
#include <algorithm>
#include <cfloat>
#include <cmath>
#include <cstdio>
#include <vector>

static ImVec4 ComboDescColor(Theme* theme) {
    return WidgetBase::DescriptionColor(theme);
}

static ImVec4 ComboTrackColor(Theme* theme) {
    if (post_processing.flags.blur) {
        if (theme && theme->IsLightMode()) {
            ImVec4 c = theme->HexToImVec4(theme->material.onSurfaceVariant);
            c.w = 0.12f;
            return c;
        }
        return ImVec4(1.0f, 1.0f, 1.0f, 0.050f);
    }
    if (theme) {
        return theme->HexToImVec4(theme->material.surfaceVariant);
    }
    return ImVec4(0.11f, 0.11f, 0.11f, 1.0f);
}

static ImVec4 ComboPopupBgColor(Theme* theme) {
    if (theme) {
        return theme->HexToImVec4(theme->material.surfaceVariant);
    }
    return ImVec4(0.11f, 0.11f, 0.11f, 1.0f);
}

static ImVec4 ComboSelectedColor(Theme* theme) {
    return WidgetBase::PrimaryMidColor(theme);
}

static ImVec4 ComboItemBgColor(Theme* theme) {
    if (theme) {
        return theme->HexToImVec4(theme->material.surfaceContainer);
    }
    return ImVec4(0.08f, 0.08f, 0.08f, 1.0f);
}

static ImVec4 ComboPopupItemTextColor(Theme* theme, const ImVec4& item_bg, bool selected, const ImVec4& fallback) {
    if (!selected) {
        return fallback;
    }
    const float lum = item_bg.x * 0.299f + item_bg.y * 0.587f + item_bg.z * 0.114f;
    if ((theme && theme->IsLightMode()) || lum > 0.58f) {
        return ImVec4(0.08f, 0.08f, 0.08f, fallback.w > 0.0f ? fallback.w : 1.0f);
    }
    return fallback;
}

static void DrawPopupShadowBox(const ImVec2& min, const ImVec2& max, float rounding, float alpha_mul, Theme* theme, bool blur_mode) {
    if (!post_processing.flags.shadow || alpha_mul <= 0.0001f) {
        return;
    }
    const ClickGUI& gui = ClickGUI::Get();
    const int shadow_rings = std::clamp(gui.appearance.shadowRings, 6, 32);
    const float shadow_smooth = std::clamp(gui.appearance.shadowSmoothness, 0.35f, 1.60f);
    const float tuned_alpha = std::clamp(alpha_mul * 0.72f, 0.0f, 1.0f);
    if (blur_mode) {
        ImVec4 glow = ImVec4(1.0f, 1.0f, 1.0f, 0.22f);
        if (theme && theme->IsLightMode()) {
            glow = ImVec4(0.0f, 0.0f, 0.0f, 0.16f);
        } else if (theme) {
            glow = theme->HexToImVec4(theme->material.surfaceVariant);
            glow.w = 0.22f;
        }
        drawRoundedRectShadow(min, max, rounding, ImColor(glow.x, glow.y, glow.z, glow.w), tuned_alpha, shadow_rings, shadow_smooth, true);
    } else {
        drawRoundedRectShadow(min, max, rounding, ImColor(0.0f, 0.0f, 0.0f, 0.20f), tuned_alpha, shadow_rings, shadow_smooth, true);
    }
}

static Blur s_combo_popup_blur(Hardware::GPU);

static void DrawComboPopupBlur(ImDrawList* draw_list,
                               const ImVec2& window_pos,
                               const ImVec2& window_size,
                               float alpha,
                               float corner_radius,
                               int downscale_factor,
                               float blur_radius,
                               Blur::Type blur_type) {
    if (!draw_list || alpha <= 0.001f || window_size.x <= 1.0f || window_size.y <= 1.0f) {
        return;
    }
    if (glWidth <= 0 || glHeight <= 0) {
        return;
    }
    const float x0 = window_pos.x;
    const float y0 = window_pos.y;
    const float x1 = window_pos.x + window_size.x;
    const float y1 = window_pos.y + window_size.y;
    const float ds_scale = (float)std::max(1, downscale_factor);
    const float pad_f = std::max(8.0f, ((blur_radius * 2.0f) + 6.0f) * ds_scale + 12.0f);
    const int pad = std::max(1, (int)std::ceil(pad_f));
    const int cap_x0 = std::max(0, (int)std::floor(x0) - pad);
    const int cap_y0 = std::max(0, (int)std::floor(y0) - pad);
    const int cap_x1 = std::min(glWidth, (int)std::ceil(x1) + pad);
    const int cap_y1 = std::min(glHeight, (int)std::ceil(y1) + pad);
    const int cap_w = std::max(0, cap_x1 - cap_x0);
    const int cap_h = std::max(0, cap_y1 - cap_y0);
    if (cap_w <= 0 || cap_h <= 0) {
        return;
    }
    const int read_x = cap_x0;
    const int read_y = glHeight - cap_y1;

    struct ComboBlurJob { int x, y, w, h; float r; int ds; Blur::Type t; };
    auto* job = new ComboBlurJob{read_x, read_y, cap_w, cap_h, blur_radius, std::max(1, downscale_factor), blur_type};
    draw_list->AddCallback([](const ImDrawList*, const ImDrawCmd* cmd) {
        auto* j = static_cast<ComboBlurJob*>(cmd->UserCallbackData);
        s_combo_popup_blur.backend = Hardware::GPU;
        s_combo_popup_blur.type = j->t;
        s_combo_popup_blur.process(j->x, j->y, j->w, j->h, j->r, j->ds);
        delete j;
    }, job);

    const float u0 = std::clamp((x0 - (float)cap_x0) / (float)cap_w, 0.0f, 1.0f);
    const float u1 = std::clamp((x1 - (float)cap_x0) / (float)cap_w, 0.0f, 1.0f);
    const float v_top = std::clamp(1.0f - ((y0 - (float)cap_y0) / (float)cap_h), 0.0f, 1.0f);
    const float v_bottom = std::clamp(1.0f - ((y1 - (float)cap_y0) / (float)cap_h), 0.0f, 1.0f);
    const ImU32 tint = ImGui::GetColorU32(ImVec4(1.0f, 1.0f, 1.0f, std::clamp(alpha, 0.0f, 1.0f)));
    draw_list->AddImageRounded(
        (void*)(intptr_t)s_combo_popup_blur.tex,
        window_pos, ImVec2(window_pos.x + window_size.x, window_pos.y + window_size.y),
        ImVec2(u0, v_top), ImVec2(u1, v_bottom),
        tint, corner_radius, ImDrawFlags_RoundCornersAll
    );
}

struct ComboPopupState {
    ImGuiID owner = 0;
    bool open = false;
    int opened_frame = -1;
};
static ComboPopupState s_popup;

struct ComboOverlayState {
    bool request_capture = false;
    bool has_capture = false;
    int capture_w = 0;
    int capture_h = 0;
};

static ComboOverlayState s_overlay;

struct ComboOverlayFrameData {
    bool valid = false;
    ImGuiID combo_id = 0;
    std::string label;
    const char* const* items = nullptr;
    int items_count = 0;
    int* value_ptr = nullptr;
    uint32_t* values_mask_ptr = nullptr;
    bool multi_mode = false;
    Theme* theme = nullptr;
};

static ComboOverlayFrameData s_frame_data;
static bool s_popup_blocks_input = false;
static int s_popup_blocks_frame = -1;
static bool s_popup_visual_valid = false;
static ImVec2 s_popup_visual_min = ImVec2(0.0f, 0.0f);
static ImVec2 s_popup_visual_max = ImVec2(0.0f, 0.0f);
static ImVec2 GetScaledDisplayOffset(const ImFont* font, float size);

static bool ComboItemSelected(bool multi_mode, int i, const int* value, const uint32_t* values_mask) {
    if (multi_mode) {
        if (!values_mask || i < 0 || i >= 32) {
            return false;
        }
        return ((*values_mask) & (1u << i)) != 0u;
    }
    return value && (*value == i);
}

static bool ComboToggleOrSelect(bool multi_mode, int i, int* value, uint32_t* values_mask) {
    if (i < 0) {
        return false;
    }
    if (multi_mode) {
        if (!values_mask || i >= 32) {
            return false;
        }
        const uint32_t bit = (1u << i);
        const uint32_t before = *values_mask;
        *values_mask ^= bit;
        return *values_mask != before;
    }
    if (!value) {
        return false;
    }
    const bool changed = (*value != i);
    *value = i;
    return changed;
}

static std::string BuildMultiComboPreview(uint32_t values_mask, const char* const items[], int items_count) {
    int selected_count = 0;
    for (int i = 0; i < items_count && i < 32; ++i) {
        if ((values_mask & (1u << i)) != 0u) {
            ++selected_count;
        }
    }
    if (selected_count <= 0) {
        return "None";
    }
    if (selected_count == items_count) {
        return "All";
    }

    std::string out;
    for (int i = 0; i < items_count && i < 32; ++i) {
        if ((values_mask & (1u << i)) == 0u) {
            continue;
        }
        const char* item = items[i] ? items[i] : "";
        if (!out.empty()) {
            out += ", ";
        }
        out += item;
        if (out.size() > 36u) {
            return std::to_string(selected_count) + " selected";
        }
    }
    return out.empty() ? "None" : out;
}

bool ComboOverlayNeedsPostRenderCapture() {
    return post_processing.flags.blur && s_overlay.request_capture;
}

void ComboOverlayPostRenderCapture(int display_w, int display_h) {
    (void)display_w;
    (void)display_h;
    if (!post_processing.flags.blur || !s_overlay.request_capture) {
        s_overlay.has_capture = false;
        return;
    }
    s_overlay.has_capture = false;
}

void ComboOverlayRenderPostPass() {
    if (!s_frame_data.valid ||
        !s_frame_data.items || s_frame_data.items_count <= 0) {
        s_popup_visual_valid = false;
        return;
    }

    ImGuiID combo_id = s_frame_data.combo_id;
    const int items_count = s_frame_data.items_count;
    const bool multi_mode = s_frame_data.multi_mode;
    int* value = s_frame_data.value_ptr;
    uint32_t* values_mask = s_frame_data.values_mask_ptr;
    if ((!multi_mode && !value) || (multi_mode && !values_mask)) {
        s_popup_visual_valid = false;
        return;
    }
    Theme* theme = s_frame_data.theme;
    const char* label = s_frame_data.label.c_str();

    float target_open = (s_popup.owner == combo_id && s_popup.open) ? 1.0f : 0.0f;
    float dt = ImGui::GetIO().DeltaTime;
    const float popup_speed = std::clamp(ClickGUI::Get().animationTuning.popupSpeed, 0.2f, 4.0f);
    const float popup_anim_duration = 0.42f / popup_speed;
    float popup_progress = iam_tween_float(combo_id, ImHashStr("combo_progress"),
                                           target_open, popup_anim_duration,
                                           iam_ease_preset(iam_ease_out_cubic),
                                           iam_policy_crossfade, dt);
    const float popup_alpha = (popup_progress > 0.001f) ? 1.0f : 0.0f;
    ClickGUI& gui = ClickGUI::Get();
    const float blur_alpha = (gui.animation.animationProgress > 0.001f) ? 1.0f : 0.0f;

    if (target_open <= 0.0f && popup_alpha <= 0.001f && s_popup.owner == combo_id) {
        s_popup.owner = 0;
        s_overlay.has_capture = false;
        s_overlay.request_capture = false;
        s_frame_data.valid = false;
        s_frame_data.items = nullptr;
        s_frame_data.items_count = 0;
        s_frame_data.value_ptr = nullptr;
        s_frame_data.values_mask_ptr = nullptr;
        s_frame_data.multi_mode = false;
        s_popup_visual_valid = false;
        return;
    }
    if (popup_alpha <= 0.001f) {
        s_popup_visual_valid = false;
        return;
    }

    ImGuiViewport* vp = ImGui::GetMainViewport();
    const int columns = std::clamp(items_count, 1, 3);
    const float scale = 1.0f;
    const float spacing = 16.0f;
    const float pad = 22.0f;
    const float title_h = 28.0f;
    const int rows = (items_count + columns - 1) / columns;

    float base_w = std::clamp(vp->Size.x * 0.78f, 760.0f, 1120.0f);
    float cell_h = std::max(ImGui::GetFrameHeight() * 1.85f, 48.0f);
    float content_h = rows * cell_h + std::max(0, rows - 1) * spacing;
    float base_h = pad + title_h + spacing + content_h + spacing + pad;
    float max_h = vp->Size.y * 0.86f;
    if (base_h > max_h) {
        base_h = max_h;
    }

    ImVec2 wnd_size(base_w, base_h);
    ImVec2 center(vp->GetCenter().x - wnd_size.x * 0.5f,
                  vp->GetCenter().y - wnd_size.y * 0.5f);
    ImVec2 start_pos(center.x, vp->Pos.y + vp->Size.y + 32.0f);
    ImVec2 wnd_pos = ImLerp(start_pos, center, popup_progress);

    ImDrawList* bg = ImGui::GetForegroundDrawList();
    bool use_post_blur = post_processing.flags.blur && blur_alpha > 0.001f;
    const float overlay_alpha = use_post_blur ? 0.40f : 0.22f;
    const float popup_rounding = 16.0f;
    ImVec2 wnd_max = ImVec2(wnd_pos.x + wnd_size.x, wnd_pos.y + wnd_size.y);
    s_popup_visual_valid = true;
    s_popup_visual_min = wnd_pos;
    s_popup_visual_max = wnd_max;

    DrawPopupShadowBox(wnd_pos, wnd_max, popup_rounding, popup_alpha, theme, use_post_blur);

    if (use_post_blur) {
        const int popup_downscale = 15;
        DrawComboPopupBlur(
            bg,
            wnd_pos,
            wnd_size,
            popup_alpha,
            popup_rounding,
            popup_downscale,
            std::max(0.1f, gui.sidebar.BlurRadius),
            gui.sidebar.BlurType
        );
    }

    if (use_post_blur) {
        const bool light_mode = theme && theme->IsLightMode();
        const ImVec4 overlay_col = light_mode
            ? ImVec4(1.0f, 1.0f, 1.0f, overlay_alpha * 0.68f)
            : ImVec4(0.0f, 0.0f, 0.0f, overlay_alpha);
        ImU32 overlay = ImGui::GetColorU32(overlay_col);
        bg->AddRectFilled(wnd_pos, wnd_max, overlay, popup_rounding, ImDrawFlags_RoundCornersAll);

        ImVec4 popup_tint = ComboPopupBgColor(theme);
        popup_tint.w = std::clamp((0.08f + 0.06f * blur_alpha), 0.0f, 1.0f);
        bg->AddRectFilled(wnd_pos, wnd_max, ImGui::GetColorU32(popup_tint), popup_rounding, ImDrawFlags_RoundCornersAll);
    }

    if (s_popup.owner == combo_id && s_popup.open && ImGui::IsMouseClicked(0) &&
        ImGui::GetFrameCount() > s_popup.opened_frame) {
        ImVec2 mp = ImGui::GetMousePos();
        bool inside = (mp.x >= wnd_pos.x && mp.x <= wnd_pos.x + wnd_size.x &&
                       mp.y >= wnd_pos.y && mp.y <= wnd_pos.y + wnd_size.y);
        if (!inside) {
            s_popup.open = false;
        }
    }
    if (s_popup.owner == combo_id && s_popup.open && ImGui::IsKeyPressed(ImGuiKey_Escape)) {
        s_popup.open = false;
    }

    char wnd_name[64];
    std::snprintf(wnd_name, sizeof(wnd_name), "##combo_center_window_%08X", combo_id);

    ImVec4 popup_bg = ComboPopupBgColor(theme);
    if (!post_processing.flags.blur) {
        popup_bg = ComboItemBgColor(theme);
    }
    if (use_post_blur) {
        popup_bg.w = 0.0f;
    }
    ImVec4 text_col = ImGui::GetStyle().Colors[ImGuiCol_Text];

    ImGui::SetNextWindowPos(wnd_pos, ImGuiCond_Always);
    ImGui::SetNextWindowSize(wnd_size, ImGuiCond_Always);
    ImGui::SetNextWindowBgAlpha(popup_bg.w);
    if (s_popup.owner == combo_id && s_popup.open) {
        ImGui::SetNextWindowFocus();
    }

    ImGui::PushStyleColor(ImGuiCol_WindowBg, popup_bg);
    ImGui::PushStyleColor(ImGuiCol_Text, text_col);
    ImGui::PushStyleColor(ImGuiCol_Border, ImVec4(0, 0, 0, 0));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, popup_rounding);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0.0f);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(pad, pad));

    if (ImGui::Begin(wnd_name, nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoMove)) {
        ImGui::BringWindowToDisplayFront(ImGui::GetCurrentWindow());
        // draw title via foreground
        {
            ImVec2 tp = ImGui::GetCursorScreenPos();
            ImGui::GetForegroundDrawList()->AddText(tp, ImGui::GetColorU32(text_col), label);
            ImGui::Dummy(ImGui::CalcTextSize(label));
        }
        float spacing_s = spacing;
        ImGui::Dummy(ImVec2(0.0f, spacing_s));

        float avail_w = ImGui::GetContentRegionAvail().x;
        float item_w = (avail_w - spacing_s * (columns - 1)) / columns;
        float item_h = cell_h;
        ImVec2 grid_start = ImGui::GetCursorScreenPos();

        ImVec4 sel_col = ComboSelectedColor(theme);
        ImVec4 item_col = ComboItemBgColor(theme);
        if (post_processing.flags.blur) {
            item_col = ComboTrackColor(theme);
        } else {
            item_col = ComboPopupBgColor(theme);
        }
        ImDrawList* wnd_dl = ImGui::GetForegroundDrawList();

        for (int row = 0; row < rows; ++row) {
            for (int col = 0; col < columns; ++col) {
                int i = row * columns + col;
                if (i >= items_count) {
                    break;
                }

                ImGui::PushID(i);
                ImVec2 p(grid_start.x + col * (item_w + spacing_s), grid_start.y + row * (item_h + spacing_s));
                ImGui::SetCursorScreenPos(p);
                ImGui::InvisibleButton("##combo_item", ImVec2(item_w, item_h));
                if (ImGui::IsItemClicked()) {
                    ComboToggleOrSelect(multi_mode, i, value, values_mask);
                    if (!multi_mode) {
                        s_popup.open = false;
                    }
                }

                bool selected = ComboItemSelected(multi_mode, i, value, values_mask);
                ImVec4 c = selected ? sel_col : item_col;
                if (selected) {
                    WidgetBase::AccentGradient grad = WidgetBase::PrimaryGradient(theme);
                    grad.start.w = c.w;
                    grad.end.w = c.w;
                    if (grad.gradient) {
                        WidgetBase::AddAccentRect(wnd_dl, p, ImVec2(p.x + item_w, p.y + item_h), grad, theme, 11.0f);
                    } else {
                        wnd_dl->AddRectFilled(p, ImVec2(p.x + item_w, p.y + item_h), ImGui::GetColorU32(c), 11.0f);
                    }
                } else {
                    wnd_dl->AddRectFilled(p, ImVec2(p.x + item_w, p.y + item_h), ImGui::GetColorU32(c), 11.0f);
                }

                const char* txt = s_frame_data.items[i] ? s_frame_data.items[i] : "";
                float fsize = ImGui::GetFontSize() * 1.08f;
                ImVec2 tsize = ImGui::GetFont()->CalcTextSizeA(fsize, FLT_MAX, 0.0f, txt);
                ImVec2 off_item = GetScaledDisplayOffset(ImGui::GetFont(), fsize);
                float tx = p.x + (item_w - tsize.x) * 0.5f - off_item.x;
                float ty = p.y + (item_h - tsize.y) * 0.5f - off_item.y;
                const ImVec4 item_text_col = ComboPopupItemTextColor(theme, c, selected, text_col);
                wnd_dl->AddText(ImGui::GetFont(), fsize, ImVec2(tx, ty), ImGui::GetColorU32(item_text_col), txt);
                ImGui::PopID();
            }
        }
    }
    ImGui::End();
    ImGui::PopStyleVar(3);
    ImGui::PopStyleColor(3);

}

bool ComboPopupBlocksInput() {
    return s_popup_blocks_input || (s_popup.owner != 0 && s_popup.open) ||
           s_overlay.request_capture || s_frame_data.valid;
}

bool ComboPopupGetVisualRect(ImVec2* out_min, ImVec2* out_max) {
    if (!s_popup_visual_valid) {
        return false;
    }
    if (out_min) {
        *out_min = s_popup_visual_min;
    }
    if (out_max) {
        *out_max = s_popup_visual_max;
    }
    return true;
}

static ImVec2 GetScaledDisplayOffset(const ImFont* font, float size) {
    if (!font || font->Sources.empty() || font->Sources[0] == nullptr) {
        return ImVec2(0.0f, 0.0f);
    }
    const ImFontConfig* cfg = font->Sources[0];
    float base_size = cfg->SizePixels > 0.0f ? cfg->SizePixels : 1.0f;
    float k = size / base_size;
    return ImVec2(cfg->GlyphOffset.x * k, cfg->GlyphOffset.y * k);
}

static bool ComboInternal(const char* label, const char* description,
                          int* value, uint32_t* values_mask,
                          const char* const items[], int items_count,
                          Theme* theme, bool* out_active) {
    const bool multi_mode = (values_mask != nullptr);
    if (!label || !items || items_count <= 0 || (!multi_mode && !value) || (multi_mode && !values_mask)) {
        if (out_active) {
            *out_active = false;
        }
        return false;
    }

    if (multi_mode) {
        if (items_count < 32) {
            const uint32_t allowed = (1u << items_count) - 1u;
            *values_mask &= allowed;
        }
    } else {
        *value = std::clamp(*value, 0, items_count - 1);
    }

    ImDrawList* dl = ImGui::GetWindowDrawList();
    ImGuiStyle& style = ImGui::GetStyle();
    ImVec2 start = ImGui::GetCursorScreenPos();
    float full_w = ImGui::GetContentRegionAvail().x;
    const float ui_scale = WidgetActivity::WidgetUiScale();
    if (full_w < 1.0f) {
        full_w = 1.0f;
    }

    float base = style.FontSizeBase;
    const float desc_offset = std::max(1.0f, style.ItemInnerSpacing.y * 0.55f);
    ImVec2 label_size = ImGui::CalcTextSize(label);
    float desc_height = 0.0f;
    float desc_width = 0.0f;
    if (description && description[0] != '\0') {
        ImGui::PushFont(nullptr, base * 0.85f);
        ImVec2 desc_size = ImGui::CalcTextSize(description);
        ImGui::PopFont();
        desc_height = desc_size.y + desc_offset;
        desc_width = desc_size.x;
    }

    float row_h = label_size.y + desc_height;
    float box_h = ImGui::GetFrameHeight() * 1.20f * 1.22f;
    if (row_h < box_h) {
        row_h = box_h;
    }

    ImGui::Dummy(ImVec2(full_w, row_h));
    dl->AddText(start, ImGui::GetColorU32(style.Colors[ImGuiCol_Text]), label);

    if (description && description[0] != '\0') {
        ImVec4 desc_color = ComboDescColor(theme);
        ImGui::PushFont(nullptr, base * 0.85f);
        dl->AddText(ImVec2(start.x, start.y + label_size.y + desc_offset),
                    ImGui::GetColorU32(desc_color), description);
        ImGui::PopFont();
    }

    std::string current_item_storage;
    const char* current_item = nullptr;
    if (multi_mode) {
        current_item_storage = BuildMultiComboPreview(*values_mask, items, items_count);
        current_item = current_item_storage.c_str();
    } else {
        current_item = items[*value] ? items[*value] : "";
    }
    ImVec2 txt_size = ImGui::CalcTextSize(current_item);
    float text_pad_x = 16.0f * ui_scale;
    float box_w = txt_size.x + text_pad_x * 2.0f; // no *1.10 by request
    box_w = std::max(box_w, 88.0f * ui_scale);
    float reserve_left = std::max(label_size.x, desc_width) + (12.0f * ui_scale);
    float max_box_w = std::max(88.0f * ui_scale, full_w - reserve_left);
    max_box_w = std::clamp(max_box_w, 56.0f * ui_scale, full_w);
    box_w = std::min(box_w, max_box_w);

    float box_x = start.x + full_w - box_w;
    float box_y = start.y + (row_h - box_h) * 0.5f;
    ImVec2 box_min(box_x, box_y);
    ImVec2 box_max(box_x + box_w, box_y + box_h);

    ImVec4 track = ComboTrackColor(theme);
    const float rr = std::max(0.0f, style.FrameRounding);
    dl->AddRectFilled(box_min, box_max, ImGui::GetColorU32(track), rr);
    ImVec2 off_main = GetScaledDisplayOffset(ImGui::GetFont(), ImGui::GetFontSize());
    const float text_region_pad = std::max(12.0f * ui_scale, (box_h - txt_size.y) * 0.5f);
    const float text_region_min_x = box_min.x + text_region_pad;
    const float text_region_max_x = box_max.x - text_region_pad;
    const float text_region_w = std::max(1.0f, text_region_max_x - text_region_min_x);
    float txt_y = box_min.y + (box_h - txt_size.y) * 0.5f - off_main.y;
    const bool preview_overflow = txt_size.x > (text_region_w - 0.5f);
    if (!preview_overflow) {
        const float txt_x = text_region_min_x + (text_region_w - txt_size.x) * 0.5f - off_main.x;
        dl->AddText(ImVec2(txt_x, txt_y), ImGui::GetColorU32(style.Colors[ImGuiCol_Text]), current_item);
    } else {
        const float speed = 34.0f * ui_scale;
        const float gap = std::max(24.0f * ui_scale, text_region_w * 0.18f);
        const float cycle = txt_size.x + gap;
        const float phase = std::fmod((float)ImGui::GetTime() * speed, std::max(1.0f, cycle));
        const float start_x = text_region_min_x - phase - off_main.x;
        dl->PushClipRect(ImVec2(text_region_min_x, box_min.y), ImVec2(text_region_max_x, box_max.y), true);
        dl->AddText(ImVec2(start_x, txt_y), ImGui::GetColorU32(style.Colors[ImGuiCol_Text]), current_item);
        dl->AddText(ImVec2(start_x + cycle, txt_y), ImGui::GetColorU32(style.Colors[ImGuiCol_Text]), current_item);
        dl->PopClipRect();

        const float fade_w = std::min(18.0f * ui_scale, text_region_w * 0.24f);
        ImVec4 fade_col = track;
        fade_col.w = std::clamp(std::max(fade_col.w, 0.82f), 0.0f, 1.0f);
        ImVec4 fade_col_0 = fade_col;
        fade_col_0.w = 0.0f;
        dl->AddRectFilledMultiColor(
            ImVec2(text_region_min_x, box_min.y),
            ImVec2(text_region_min_x + fade_w, box_max.y),
            ImGui::GetColorU32(fade_col),
            ImGui::GetColorU32(fade_col_0),
            ImGui::GetColorU32(fade_col_0),
            ImGui::GetColorU32(fade_col)
        );
        dl->AddRectFilledMultiColor(
            ImVec2(text_region_max_x - fade_w, box_min.y),
            ImVec2(text_region_max_x, box_max.y),
            ImGui::GetColorU32(fade_col_0),
            ImGui::GetColorU32(fade_col),
            ImGui::GetColorU32(fade_col),
            ImGui::GetColorU32(fade_col_0)
        );
    }

    bool changed = false;
    ImGui::PushID(label);
    float text_w = std::max(label_size.x, desc_width);
    float text_h = label_size.y + desc_height;
    if (text_w < 1.0f) {
        text_w = 1.0f;
    }
    if (text_h < 1.0f) {
        text_h = 1.0f;
    }

    ImGui::SetCursorScreenPos(start);
    bool text_clicked = ImGui::InvisibleButton("##combo_text_btn", ImVec2(text_w, text_h));
    bool text_active = ImGui::IsItemActive();

    ImGui::SetCursorScreenPos(box_min);
    bool box_clicked = ImGui::InvisibleButton("##combo_btn", ImVec2(box_w, box_h));
    bool box_active = ImGui::IsItemActive();
    ImGuiID combo_id = ImGui::GetItemID();

    if (text_clicked || box_clicked) {
        if (s_popup.owner == combo_id && s_popup.open) {
            s_popup.open = false;
        } else {
            s_popup.owner = combo_id;
            s_popup.open = true;
            s_popup.opened_frame = ImGui::GetFrameCount();
        }
    }

    float target_open = (s_popup.owner == combo_id && s_popup.open) ? 1.0f : 0.0f;
    float dt = ImGui::GetIO().DeltaTime;
    const float popup_speed = std::clamp(ClickGUI::Get().animationTuning.popupSpeed, 0.2f, 4.0f);
    const float popup_anim_duration = 0.42f / popup_speed;

    float popup_progress = iam_tween_float(combo_id, ImHashStr("combo_progress"),
                                        target_open, popup_anim_duration,
                                        iam_ease_preset(iam_ease_out_cubic),
                                        iam_policy_crossfade, dt);
    const float popup_alpha = (popup_progress > 0.001f) ? 1.0f : 0.0f;

    const int frame_now = ImGui::GetFrameCount();
    if (s_popup_blocks_frame != frame_now) {
        s_popup_blocks_frame = frame_now;
        s_popup_blocks_input = false;
    }
    if ((s_popup.owner == combo_id) && (target_open > 0.001f || popup_alpha > 0.001f || s_popup.open)) {
        s_popup_blocks_input = true;
    }

    s_overlay.request_capture = (target_open > 0.001f || popup_alpha > 0.001f);
    if (s_popup.owner == combo_id) {
        s_frame_data.valid = true;
        s_frame_data.combo_id = combo_id;
        s_frame_data.label = label;
        s_frame_data.items = items;
        s_frame_data.items_count = items_count;
        s_frame_data.value_ptr = value;
        s_frame_data.values_mask_ptr = values_mask;
        s_frame_data.multi_mode = multi_mode;
        s_frame_data.theme = theme;
    }

    if (target_open <= 0.0f && popup_alpha <= 0.001f && s_popup.owner == combo_id) {
        s_popup.owner = 0;
        s_overlay.has_capture = false;
        s_frame_data.valid = false;
        s_frame_data.items = nullptr;
        s_frame_data.items_count = 0;
        s_frame_data.value_ptr = nullptr;
        s_frame_data.values_mask_ptr = nullptr;
        s_frame_data.multi_mode = false;
        s_popup_blocks_input = false;
        s_popup_visual_valid = false;
    }

    // Popup is rendered in post-overlay pass for both blur and non-blur modes.

    bool popup_owns = (s_popup.owner == combo_id);
    bool widget_active = text_active || box_active || (popup_owns && s_popup.open);
    if (out_active) {
        *out_active = widget_active;
    }

    ImGui::PopID();
    return changed;
}

bool Combo(const char* label, const char* description, int* value,
           const char* const items[], int items_count, Theme* theme) {
    return Combo(label, description, value, items, items_count, theme, nullptr);
}

bool Combo(const char* label, const char* description, int* value,
           const char* const items[], int items_count, Theme* theme, bool* out_active) {
    return ComboInternal(label, description, value, nullptr, items, items_count, theme, out_active);
}

bool MultiCombo(const char* label, const char* description, uint32_t* values_mask,
                const char* const items[], int items_count, Theme* theme) {
    return MultiCombo(label, description, values_mask, items, items_count, theme, nullptr);
}

bool MultiCombo(const char* label, const char* description, uint32_t* values_mask,
                const char* const items[], int items_count, Theme* theme, bool* out_active) {
    return ComboInternal(label, description, nullptr, values_mask, items, items_count, theme, out_active);
}
