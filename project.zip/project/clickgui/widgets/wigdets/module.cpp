#include "../wigdets.h"
#include "../../render/post_processing.h"
#include <algorithm>
#include <cfloat>
#include <cmath>
#include <limits>
#include <unordered_map>
#include <vector>

static void ResetModuleDefaultsByName(const std::string& module_name) {
    auto& f = vrt.features;
    ClickGUI& gui = ClickGUI::Get();
    if (module_name == "Aimbot") {
        f.aimbot.mode = 0;
        f.aimbot.fov.value = 90.0f;
        f.aimbot.silentAim.value = false;
        f.aimbot.smoothAim.value = false;
        f.aimbot.smoothFactor.value = 5.0f;
        f.aimbot.silentAutoShot.value = false;
        f.aimbot.silentReaction.value = 0.10f;
        f.aimbot.rotationCompensate.value = false;
        f.aimbot.rotationSpeed.value = 35.0f;
        f.aimbot.aiRotationAdaptive.value = false;
        f.aimbot.aiRotationConfidence.value = 0.65f;
        return;
    }
    if (module_name == "Movement") {
        return;
    }
    if (module_name == "Movement Recorder") {
        f.movement.recorderAutoReturn.value = true;
        f.movement.recorderStartRadius.value = 0.40f;
        f.movement.recorderSeekSpeed.value = 3.6f;
        gui.movementRecorderNormX = 0.042f;
        gui.movementRecorderNormY = 0.165f;
        gui.movementRecorderVisibleWidthNorm = 0.22f;
        gui.movementRecorderVisibleHeightNorm = 0.13f;
        gui.movementRecorderExpandedWidthNorm = 0.22f;
        return;
    }
    if (module_name == "ESP") {
        f.render.boxEsp.value = false;
        f.render.skeletonEsp.value = false;
        f.render.nameEsp.value = false;
        f.render.healthBar.value = false;
        f.render.renderDistance.value = 100.0f;
        return;
    }
    if (module_name == "Color Grading") {
        post_processing.color_grading.enabled = true;
        post_processing.color_grading.preset_index = 0;
        post_processing.color_grading.current = post_processing.color_grading.presets[0];
        return;
    }
    if (module_name == "Audio") {
        f.misc.masterVolume.value = 1.0f;
        return;
    }
    if (module_name == "Config") {
        return;
    }
    if (module_name == "HUD") {
        return;
    }
    if (module_name == "Watermark") {
        gui.watermarkNormX = 0.042f;
        gui.watermarkNormY = 0.075f;
        gui.watermarkBgAlphaNoBlur = 1.0f;
        gui.watermarkScale = 1.0f;
        gui.watermarkTextAlpha = 0.92f;
        gui.watermarkSeparatorAlpha = 1.0f;
        gui.watermarkPaddingScale = 1.0f;
        gui.watermarkNicknameColorMode = 0;
        gui.watermarkNicknameColor1[0] = 1.0f;
        gui.watermarkNicknameColor1[1] = 1.0f;
        gui.watermarkNicknameColor1[2] = 1.0f;
        gui.watermarkNicknameColor2[0] = 0.82f;
        gui.watermarkNicknameColor2[1] = 0.82f;
        gui.watermarkNicknameColor2[2] = 0.82f;
        gui.watermarkInfoMask = (1u << 0);
        return;
    }
    if (module_name == "Speed Graph") {
        gui.speedGraphNormX = 0.5f;
        gui.speedGraphNormY = 0.86f;
        gui.speedGraphVisibleWidthNorm = 0.24f;
        gui.speedGraphVisibleHeightNorm = 0.10f;
        gui.speedGraphExpandedWidthNorm = 0.24f;
        return;
    }
    if (module_name == "Theme") {
        gui.scale.Scale = 1.3f;
        gui.scale.Dirty = true;
        if (gui.theme) {
            gui.theme->style.CornerRadius = 19.5f;
            gui.theme->SetAccentMode(ClickGUI::Theme::AccentMode::User);
            gui.theme->SetAccentGradientDirection(ClickGUI::Theme::AccentGradientDirection::Horizontal);
            gui.theme->ApplyTheme();
            gui.Preload();
        }
        return;
    }
    if (module_name == "Appearance") {
        post_processing.flags.blur = false;
        post_processing.flags.glow = false;
        post_processing.flags.shadow = true;
        post_processing.flags.glow_alpha_scale = 0.6f;
        gui.tabMorphEnabled = true;
        gui.sidebar.DownscaleFactor = 40;
        gui.sidebar.BlurRadius = 1.0f;
        gui.appearance.shadowRings = 16;
        gui.appearance.shadowSmoothness = 0.75f;
        return;
    }
    if (module_name == "Animation") {
        gui.animationTuning.menuSpeed = 1.0f;
        gui.animationTuning.tabsSpeed = 1.0f;
        gui.animationTuning.popupSpeed = 1.0f;
        gui.menuRippleEnabled = true;
        gui.rippleTuning.pressRadius = 1.0f;
        gui.rippleTuning.pressSpeed = 1.0f;
        gui.rippleTuning.pressStrength = 1.0f;
        gui.rippleTuning.pressDuration = 0.283f;
        gui.rippleTuning.dragRadius = 1.0f;
        gui.rippleTuning.dragStrength = 1.0f;
        gui.rippleTuning.motionStrength = 1.0f;
        return;
    }
}

static ImVec4 WidgetAlpha(ImVec4 c) {
    if (post_processing.flags.blur) {
        c.w = 0.6f;
    }
    return c;
}

static ImVec4 WidgetInactiveTrack(Theme* theme) {
    if (post_processing.flags.blur) {
        if (theme && theme->IsLightMode()) {
            ImVec4 c = theme->HexToImVec4(theme->material.onSurfaceVariant);
            c.w = 0.12f;
            return c;
        }
        return ImVec4(1.0f, 1.0f, 1.0f, 0.050f);
    }
    if (theme) {
        return theme->HexToImVec4(theme->material.surfaceVariant);
    }
    return ImVec4(0.110f, 0.110f, 0.110f, 1.0f);
}

static ImVec4 ResolveButtonTextColor(Theme* theme, const ImVec4& button_color, const ImVec4& fallback) {
    const float lum = button_color.x * 0.299f + button_color.y * 0.587f + button_color.z * 0.114f;
    const float effective_lum = lum * button_color.w + 0.09f * (1.0f - button_color.w);
    if ((theme && theme->IsLightMode()) || effective_lum > 0.58f) {
        return ImVec4(0.08f, 0.08f, 0.08f, fallback.w);
    }
    return fallback;
}

static float SweepNorm(float phase) {
    const float p = std::clamp(phase, 0.0f, 1.0f);
    if (p < 0.5f) {
        const float u = p * 2.0f;
        return u * u * (3.0f - 2.0f * u);
    }
    const float u = (p - 0.5f) * 2.0f;
    return 1.0f - (u * u * (3.0f - 2.0f * u));
}

static ImVec4 LerpVec4Local(const ImVec4& a, const ImVec4& b, float t) {
    return ImVec4(
        a.x + (b.x - a.x) * t,
        a.y + (b.y - a.y) * t,
        a.z + (b.z - a.z) * t,
        a.w + (b.w - a.w) * t
    );
}

static float LumaLocal(const ImVec4& c) {
    return c.x * 0.299f + c.y * 0.587f + c.z * 0.114f;
}

struct ResetButtonAnimState {
    float t = 0.0f;
    bool playing = false;
    double started = 0.0;
    float hover = 0.0f;
    float press = 0.0f;
};

std::string Module::GetName() const {
    return functionName;
}

void Module::Draw() {
    float availableWidth = ImGui::GetContentRegionAvail().x;
    ImVec2 widgetStart = ImGui::GetCursorScreenPos();
    const ImGuiStyle& style = ImGui::GetStyle();
    const float base_item_spacing = std::max(8.0f, style.ItemSpacing.y);
    const float title_to_desc_gap = base_item_spacing * 0.55f;
    const float desc_to_buttons_gap = base_item_spacing * 0.70f;
    const float module_to_module_gap = base_item_spacing * 1.25f;

    
    ImGui::PushID(isActive);
    ImGui::PushID(functionName.c_str());
    ImGui::BeginGroup();

    
    DrawTitle(availableWidth);
    ImVec2 after_title = ImGui::GetCursorScreenPos();
    ImGui::SetCursorScreenPos(ImVec2(after_title.x, after_title.y + title_to_desc_gap));

    
    DrawDescription(availableWidth);
    ImVec2 after_desc = ImGui::GetCursorScreenPos();
    ImGui::SetCursorScreenPos(ImVec2(after_desc.x, after_desc.y + desc_to_buttons_gap));

    
    ImVec2 buttonsMin = ImGui::GetCursorScreenPos();
    ImGui::BeginGroup();

    
    const bool show_active_toggle = showActiveToggle;
    float availableButtons = std::max(0.0f, availableWidth);
    if (!show_active_toggle) {
        DrawResetButton(availableButtons, 1.28f, ImDrawFlags_RoundCornersAll);
    } else {
        DrawActiveInactiveButton(availableButtons, 1.22f, ImDrawFlags_RoundCornersTop);
        ImVec2 top_max = ImGui::GetItemRectMax();
        const float join_overlap = std::max(1.0f, style.FrameBorderSize);
        ImGui::SetCursorScreenPos(ImVec2(buttonsMin.x, top_max.y - join_overlap));
        DrawResetButton(availableButtons, 1.22f, ImDrawFlags_RoundCornersBottom);
    }

    ImGui::EndGroup(); 
    ImVec2 buttonsMax = ImGui::GetItemRectMax();
    ImGui::EndGroup(); 

    
    ImGui::Dummy(ImVec2(0.0f, module_to_module_gap));

    ImVec2 widgetEnd = ImGui::GetItemRectMax();
    widgetEnd.x = std::max(widgetEnd.x, widgetStart.x + availableWidth);
    const bool cardHovered = ImGui::IsMouseHoveringRect(widgetStart, widgetEnd);
    const bool buttonsHovered = ImGui::IsMouseHoveringRect(buttonsMin, buttonsMax);
    if (cardHovered && !buttonsHovered) {
        if (ImGui::IsMouseReleased(ImGuiMouseButton_Left) && !ImGui::IsMouseDragging(ImGuiMouseButton_Left, 6.0f)) {
            HandleSettingsButtonClick();
        }
    }

    
    Widgets<bool>::UpdateActivity(this, ImGui::IsItemActive());
    ImGui::PopID();
    ImGui::PopID();

    if (skipIntroAnimation) {
        skipIntroAnimation = false;
    }
}

static float GetGlyphOffsetY(ImFont* font, float targetSize) {
    if (!font) {
        return 0.0f;
    }
    float baseSize = ImGui::GetFontSize();
    float scale = (baseSize > 0.0f) ? (targetSize / baseSize) : 1.0f;
    if (font->Sources.Size > 0 && font->Sources[0]) {
        return font->Sources[0]->GlyphOffset.y * scale;
    }
    return 0.0f;
}

static float MeasureWrappedTextHeight(ImFont* font, float fontSize, float maxWidth, const char* text) {
    if (!text || !*text) {
        return fontSize * 1.1f;
    }
    if (!font) {
        font = ImGui::GetFont();
    }
    if (maxWidth <= 0.0f) {
        return fontSize * 1.1f;
    }

    const float line_height = fontSize * 1.1f;
    const char* line_start = text;
    int line_count = 0;

    while (*line_start) {
        while (*line_start && (*line_start == ' ' || *line_start == '\t' || *line_start == '\n')) {
            if (*line_start == '\n') {
                line_count++;
            }
            line_start++;
        }

        if (!*line_start) {
            break;
        }

        const char* line_end = line_start;
        const char* potential_break = line_start;

        while (*line_end && *line_end != '\n') {
            if (*line_end == ' ') {
                ImVec2 test_size = font->CalcTextSizeA(fontSize, FLT_MAX, 0.0f, line_start, line_end);
                if (test_size.x <= maxWidth) {
                    potential_break = line_end;
                } else {
                    break;
                }
            }

            line_end++;

            ImVec2 test_size = font->CalcTextSizeA(fontSize, FLT_MAX, 0.0f, line_start, line_end);
            if (test_size.x > maxWidth) {
                if (potential_break > line_start) {
                    line_end = potential_break;
                } else {
                    line_end = line_start + 1;
                }
                break;
            }
        }

        if (line_end > line_start) {
            line_count++;
        }

        if (*line_end == '\n') {
            line_end++;
        }
        line_start = line_end;
    }

    if (line_count <= 0) {
        line_count = 1;
    }
    return line_height * line_count;
}

struct ModuleDescLines {
    std::string line1;
    std::string line2;
    bool has_line2 = false;
};

static std::string CollapseSpaces(const std::string& in) {
    std::string out;
    out.reserve(in.size());
    bool in_space = false;
    for (char ch : in) {
        const bool sp = (ch == ' ' || ch == '\t' || ch == '\n' || ch == '\r');
        if (sp) {
            if (!out.empty() && !in_space) {
                out.push_back(' ');
            }
            in_space = true;
        } else {
            out.push_back(ch);
            in_space = false;
        }
    }
    while (!out.empty() && out.back() == ' ') {
        out.pop_back();
    }
    return out;
}

static float MeasureTextLine(ImFont* font, float size, const std::string& s) {
    if (!font || s.empty()) {
        return 0.0f;
    }
    return font->CalcTextSizeA(size, FLT_MAX, 0.0f, s.c_str()).x;
}

static std::string JoinWords(const std::vector<std::string>& words, size_t begin, size_t end) {
    std::string out;
    for (size_t i = begin; i < end; ++i) {
        if (!out.empty()) {
            out.push_back(' ');
        }
        out += words[i];
    }
    return out;
}

static std::string TruncateToWidth(ImFont* font, float size, const std::string& src, float max_w) {
    if (!font || src.empty() || max_w <= 1.0f) {
        return src;
    }
    if (MeasureTextLine(font, size, src) <= max_w) {
        return src;
    }
    const std::string dots = "...";
    std::string out = src;
    while (!out.empty() && MeasureTextLine(font, size, out + dots) > max_w) {
        out.pop_back();
    }
    if (out.empty()) {
        return dots;
    }
    while (!out.empty() && out.back() == ' ') {
        out.pop_back();
    }
    return out + dots;
}

static ModuleDescLines SplitModuleDescriptionLines(const std::string& text, ImFont* font, float size, float max_w) {
    ModuleDescLines lines;
    const std::string normalized = CollapseSpaces(text);
    if (normalized.empty()) {
        lines.line1.clear();
        return lines;
    }
    if (!font || max_w <= 1.0f) {
        lines.line1 = normalized;
        return lines;
    }
    if (MeasureTextLine(font, size, normalized) <= max_w) {
        lines.line1 = normalized;
        return lines;
    }

    std::vector<std::string> words;
    {
        std::string cur;
        for (char ch : normalized) {
            if (ch == ' ') {
                if (!cur.empty()) {
                    words.push_back(cur);
                    cur.clear();
                }
            } else {
                cur.push_back(ch);
            }
        }
        if (!cur.empty()) {
            words.push_back(cur);
        }
    }
    if (words.empty()) {
        lines.line1 = normalized;
        return lines;
    }
    if (words.size() == 1) {
        lines.line1 = TruncateToWidth(font, size, words[0], max_w);
        return lines;
    }

    float best_score = std::numeric_limits<float>::max();
    size_t best_split = 1;
    bool found = false;
    for (size_t i = 1; i < words.size(); ++i) {
        const std::string l1 = JoinWords(words, 0, i);
        const std::string l2 = JoinWords(words, i, words.size());
        const float w1 = MeasureTextLine(font, size, l1);
        const float w2 = MeasureTextLine(font, size, l2);
        if (w1 > max_w || w2 > max_w) {
            continue;
        }
        const float c1 = static_cast<float>(i);
        const float c2 = static_cast<float>(words.size() - i);
        float score = std::fabs(w1 - w2) + std::fabs(c1 - c2) * 8.0f;
        if (c2 <= 1.0f) {
            score += 12000.0f; // avoid lonely last word line
        }
        if (c1 <= 1.0f) {
            score += 3000.0f;
        }
        if (score < best_score) {
            best_score = score;
            best_split = i;
            found = true;
        }
    }

    if (!found) {
        size_t i = 1;
        for (; i < words.size(); ++i) {
            const std::string probe = JoinWords(words, 0, i + 1);
            if (MeasureTextLine(font, size, probe) > max_w) {
                break;
            }
        }
        best_split = std::max<size_t>(1, std::min(i, words.size() - 1));
    }

    lines.line1 = JoinWords(words, 0, best_split);
    lines.line2 = JoinWords(words, best_split, words.size());
    lines.line1 = TruncateToWidth(font, size, lines.line1, max_w);
    lines.line2 = TruncateToWidth(font, size, lines.line2, max_w);
    lines.has_line2 = !lines.line2.empty();
    return lines;
}

static float TailGlyphHeight(const std::string& text, ImFont* font, float fontSize) {
    if (text.empty()) {
        return std::max(1.0f, fontSize);
    }
    const unsigned char c = static_cast<unsigned char>(text.back());
    float ratio = 0.78f;
    if (c >= 'a' && c <= 'z') {
        ratio = 0.72f;
    } else if (c >= 'A' && c <= 'Z') {
        ratio = 0.86f;
    } else if (c >= '0' && c <= '9') {
        ratio = 0.80f;
    }
    (void)font;
    return std::max(1.0f, fontSize * ratio);
}

void Module::DrawTitle(float availableWidth) {
    ImFont* titleFont = ImGui::GetFont();
    float titleFontSize = ImGui::GetFontSize() * 1.04f;

    ImVec2 titlePos = ImGui::GetCursorScreenPos();
    ImU32 titleColor = ImGui::GetColorU32(ImGui::GetStyle().Colors[ImGuiCol_Text]);
    ImDrawList* titleDrawList = ImGui::GetWindowDrawList();
    const float ui_scale = WidgetActivity::WidgetUiScale();
    const bool has_indicator = !indicatorLabel.empty();
    float indicator_width = 0.0f;
    float indicator_gap = 0.0f;
    float indicator_height = 0.0f;
    float indicator_pad_x = 0.0f;
    float indicator_pad_y = 0.0f;
    float indicator_font_size = titleFontSize;

    if (has_indicator) {
        indicator_font_size = std::max(1.0f, titleFontSize * 0.76f);
        const ImVec2 ind_text = titleFont
            ? titleFont->CalcTextSizeA(indicator_font_size, FLT_MAX, 0.0f, indicatorLabel.c_str())
            : ImGui::CalcTextSize(indicatorLabel.c_str());
        indicator_pad_x = 16.0f * std::max(0.85f, ui_scale);
        indicator_pad_y = std::max(ImGui::GetStyle().FramePadding.y, 2.0f * std::max(0.85f, ui_scale));
        indicator_width = ind_text.x + indicator_pad_x * 2.0f;
        indicator_height = std::max(ImGui::GetFrameHeight() * 1.20f, ind_text.y + indicator_pad_y * 2.0f);
        // Keep an explicit visual gap between indicator and title.
        indicator_gap = 6.0f * ui_scale;
    }
    const ImVec2 title_text_size = titleFont
        ? titleFont->CalcTextSizeA(titleFontSize, FLT_MAX, 0.0f, functionName.c_str())
        : ImGui::CalcTextSize(functionName.c_str());
    const float title_area_left = titlePos.x;
    const float title_area_right = titlePos.x + std::max(1.0f, availableWidth);
    const float title_glyph_off_y = GetGlyphOffsetY(titleFont, titleFontSize);

    ImVec2 title_draw_pos = titlePos;
    float badge_x = title_area_left;
    title_draw_pos.x = title_area_left;
    title_draw_pos.y = titlePos.y - title_glyph_off_y;
    const float title_center_y = title_draw_pos.y + title_text_size.y * 0.5f + title_glyph_off_y;
    float content_bottom = title_draw_pos.y + title_text_size.y;
    if (has_indicator && availableWidth > 0.0f) {
        badge_x = title_draw_pos.x + title_text_size.x + indicator_gap;
    }

    if (availableWidth > 0.0f) {
        ImVec2 clipMax = ImVec2(title_area_right, titlePos.y + std::max(title_text_size.y, indicator_height));
        titleDrawList->PushClipRect(title_draw_pos, clipMax, true);
        titleDrawList->AddText(titleFont, titleFontSize, title_draw_pos, titleColor, functionName.c_str());
        titleDrawList->PopClipRect();
    } else {
        titleDrawList->AddText(titleFont, titleFontSize, title_draw_pos, titleColor, functionName.c_str());
    }

    
    if (has_indicator && availableWidth > 0.0f) {
        ImVec4 badge_col = theme ? WidgetBase::PrimaryMidColor(theme) : ImVec4(0.294f, 0.412f, 0.996f, 0.6f);
        const float badge_lum = badge_col.x * 0.299f + badge_col.y * 0.587f + badge_col.z * 0.114f;
        ImVec4 badge_text_col = ImGui::GetStyle().Colors[ImGuiCol_Text];
        if ((theme && theme->IsLightMode()) || badge_lum > 0.58f) {
            badge_text_col = ImVec4(0.08f, 0.08f, 0.08f, badge_text_col.w);
        }

        const float badge_y = title_center_y - indicator_height * 0.5f;
        const ImVec2 badge_min = ImVec2(badge_x, badge_y);
        const ImVec2 badge_max = ImVec2(badge_x + indicator_width, badge_y + indicator_height);
        titleDrawList->AddRectFilled(badge_min, badge_max, ImGui::GetColorU32(badge_col), ImGui::GetStyle().FrameRounding);
        content_bottom = std::max(content_bottom, badge_max.y);

        const ImVec2 badge_text_size = titleFont
            ? titleFont->CalcTextSizeA(indicator_font_size, FLT_MAX, 0.0f, indicatorLabel.c_str())
            : ImGui::CalcTextSize(indicatorLabel.c_str());
        const float text_size = indicator_font_size;
        const float text_off_y = GetGlyphOffsetY(titleFont, text_size);
        const ImVec2 badge_text_pos = ImVec2(
            badge_min.x + (indicator_width - badge_text_size.x) * 0.5f,
            title_center_y - badge_text_size.y * 0.5f - text_off_y
        );
        titleDrawList->AddText(titleFont, text_size, badge_text_pos, ImGui::GetColorU32(badge_text_col), indicatorLabel.c_str());
    }

    const float consumed_h = std::max(1.0f, content_bottom - titlePos.y);
    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + consumed_h);
}

void Module::DrawDescription(float availableWidth) {
    ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(0, 0));
    const ImVec4 descColor = WidgetBase::DescriptionColor(theme);
    const ImGuiStyle& style = ImGui::GetStyle();
    const float desc_font_base = style.FontSizeBase * 0.85f;
    const float max_w = std::max(20.0f, availableWidth);
    const ImVec2 start = ImGui::GetCursorScreenPos();
    ImDrawList* dl = ImGui::GetWindowDrawList();

    ImGui::PushFont(nullptr, desc_font_base);
    ImFont* font = ImGui::GetFont();
    const float font_size = ImGui::GetFontSize();
    const ModuleDescLines lines = SplitModuleDescriptionLines(functionDescription, font, font_size, max_w);
    const float line_step = std::max(font_size * 1.08f, font_size + 1.0f);
    float y = start.y;
    if (!lines.line1.empty()) {
        dl->AddText(font, font_size, ImVec2(start.x, y), ImGui::GetColorU32(descColor), lines.line1.c_str());
        y += line_step;
    }
    if (lines.has_line2 && !lines.line2.empty()) {
        dl->AddText(font, font_size, ImVec2(start.x, y), ImGui::GetColorU32(descColor), lines.line2.c_str());
        y += line_step;
    }
    const float h = std::max(line_step, y - start.y);
    ImGui::Dummy(ImVec2(max_w, h));
    ImGui::PopFont();
    ImGui::PopStyleVar();
}

float Module::CalculateWrappedTextHeight(float fontSize, float availableWidth) {
    const char* text = functionDescription.c_str();
    if (!text || text[0] == '\0') {
        return fontSize * 1.1f;
    }
    if (availableWidth <= 0.0f) {
        return fontSize * 1.1f;
    }
    ImFont* font = ImGui::GetFont();
    return MeasureWrappedTextHeight(font, fontSize, availableWidth, text);
}

ImFont* Module::GetAwesomeFont(float& iconFontSizeValue) {
    ImFont* cogAwesomeFont = nullptr;
    if (theme) {
        cogAwesomeFont = theme->Get(ClickGUI::Theme::FontId::Awesome);
    }

    if (cogAwesomeFont) {
        ImGui::PushFont(cogAwesomeFont);
        float iconScale = 0.9f;
        float currentFontSize = ImGui::GetFontSize();
        iconFontSizeValue = currentFontSize * iconScale;
        ImGui::PopFont();
        return cogAwesomeFont;
    }

    float iconScale = 0.9f;
    iconFontSizeValue = ImGui::GetFontSize() * iconScale;
    return nullptr;
}

float Module::GetButtonHeight() {
    
    ImVec2 activeTextSize = ImGui::CalcTextSize("ACTIVE");
    ImVec2 inactiveTextSize = ImGui::CalcTextSize("INACTIVE");

    
    float maxTextWidth = std::max(activeTextSize.x, inactiveTextSize.x);
    float maxTextHeight = std::max(activeTextSize.y, inactiveTextSize.y);

    
    ImGuiStyle& btnStyle = ImGui::GetStyle();
    float basePaddingX = btnStyle.FramePadding.x;
    float basePaddingY = btnStyle.FramePadding.y;
    float scaleFactor = 1.8f;
    float enhancedPaddingX = basePaddingX * scaleFactor;
    float enhancedPaddingY = basePaddingY * scaleFactor;
    
    float buttonHeight = maxTextHeight + enhancedPaddingY * 2.0f;
    return buttonHeight;
}

void Module::GetButtonColors(bool isActive, ImVec4& outColor, ImVec4& outHoveredColor, ImVec4& outActiveColor) {
    if (theme) {
        if (isActive) {
            outColor = WidgetBase::PrimaryMidColor(theme);
        } else {
            outColor = WidgetInactiveTrack(theme);
        }
        
        outHoveredColor = ImVec4(outColor.x + 0.1f, outColor.y + 0.1f, outColor.z + 0.1f, outColor.w);
        outActiveColor = ImVec4(outColor.x + 0.2f, outColor.y + 0.2f, outColor.z + 0.2f, outColor.w);
    } else {
        if (isActive) {
            outColor = ImVec4(0.294f, 0.412f, 0.996f, 0.6f); 
        } else {
            outColor = WidgetInactiveTrack(nullptr);
        }
        outHoveredColor = ImVec4(0.210f, 0.210f, 0.210f, 0.6f);
        outActiveColor = ImVec4(0.310f, 0.310f, 0.310f, 0.6f);
    }
}

void Module::HandleSettingsButtonClick() {
    if (activeCogWidget && activeCogWidget != this) {
        activeCogWidget = nullptr;
    }

    if (activeCogWidget == this) {
        
        activeCogWidget = nullptr;
    } else {
        
        activeCogWidget = this;
    }

    if (activeSettingsIndex && *activeSettingsIndex != settingsIndex) {
        *activeSettingsIndex = settingsIndex;
    }
}

void Module::DrawActiveInactiveButton(float width, float heightScale, ImDrawFlags cornerFlags) {
    if (width <= 0.0f) {
        return;
    }
    
    ImGui::PushID(isActive);
    ImGui::PushID("active_button"); 

    
    ImVec4 buttonColor;
    if (*isActive) {
        
        if (theme) {
            buttonColor = WidgetBase::PrimaryMidColor(theme);
        } else {
            buttonColor = ImVec4(0.294f, 0.412f, 0.996f, 0.6f); 
        }
    } else {
        
        buttonColor = WidgetInactiveTrack(theme);
    }

    
    ImVec4 newTargetColor;
    if (*isActive) {
        
        if (theme) {
            newTargetColor = WidgetBase::PrimaryMidColor(theme);
        } else {
            newTargetColor = ImVec4(0.294f, 0.412f, 0.996f, 0.6f); 
        }
    } else {
        
        newTargetColor = WidgetInactiveTrack(theme);
    }

    
    targetButtonColor = newTargetColor;

    
    float interpolationSpeed = 0.15f; 
    currentButtonColor.x += (targetButtonColor.x - currentButtonColor.x) * interpolationSpeed;
    currentButtonColor.y += (targetButtonColor.y - currentButtonColor.y) * interpolationSpeed;
    currentButtonColor.z += (targetButtonColor.z - currentButtonColor.z) * interpolationSpeed;
    currentButtonColor.w += (targetButtonColor.w - currentButtonColor.w) * interpolationSpeed;

    
    ImGui::PushStyleColor(ImGuiCol_Button, currentButtonColor);
    ImGui::PushStyleColor(ImGuiCol_ButtonHovered, currentButtonColor);
    ImGui::PushStyleColor(ImGuiCol_ButtonActive, currentButtonColor);

    
    const float buttonHeight = GetButtonHeight() * std::max(0.80f, heightScale);
    bool activeButtonClicked = ImGui::InvisibleButton("##active_btn", ImVec2(width, buttonHeight));

    
    ImDrawList* activeButtonDrawList = ImGui::GetWindowDrawList();
    ImVec2 activeBtnMin = ImGui::GetItemRectMin();
    ImVec2 activeBtnMax = ImGui::GetItemRectMax();

    
    activeButtonDrawList->AddRectFilled(activeBtnMin, activeBtnMax, ImGui::GetColorU32(currentButtonColor), ImGui::GetStyle().FrameRounding, cornerFlags);

    
    const char* activeLabel = *isActive ? "ACTIVE" : "INACTIVE";
    ImVec2 currentTextSize = ImGui::CalcTextSize(activeLabel);

    
    ImVec2 textCenterPos;
    float btnW = width;
    float btnH = buttonHeight;
    ImGuiID textId = ImGui::GetID("active_text");
    float targetAlpha = *isActive ? 1.0f : 0.7f;
    float targetScale = *isActive ? 1.0f : 0.95f;
    float textAlpha = targetAlpha;
    float textScale = targetScale;
    if (!skipIntroAnimation) {
        textAlpha = iam_tween_float(textId, ImGui::GetID("active_text_alpha"),
            targetAlpha, 0.25f, iam_ease_preset(iam_ease_out_cubic), iam_policy_crossfade, ImGui::GetIO().DeltaTime);
        textScale = iam_tween_float(textId, ImGui::GetID("active_text_scale"),
            targetScale, 0.25f, iam_ease_preset(iam_ease_out_cubic), iam_policy_crossfade, ImGui::GetIO().DeltaTime);
    }
    ImVec2 scaledTextSize = ImVec2(currentTextSize.x * textScale, currentTextSize.y * textScale);
    const ImVec2 activeGlyphOff = WidgetBase::ScaledGlyphOffset(ImGui::GetFont(), ImGui::GetFontSize() * textScale);
    textCenterPos.x = activeBtnMin.x + (btnW - scaledTextSize.x) * 0.5f;
    textCenterPos.y = activeBtnMin.y + (btnH - scaledTextSize.y) * 0.5f - activeGlyphOff.y;

    
    ImVec4 activeTextColorVec4 = ImGui::GetStyle().Colors[ImGuiCol_Text];
    if (*isActive) {
        activeTextColorVec4 = ResolveButtonTextColor(theme, currentButtonColor, activeTextColorVec4);
    }
    activeTextColorVec4.w *= textAlpha;
    activeButtonDrawList->PushClipRect(activeBtnMin, activeBtnMax, true);
    activeButtonDrawList->AddText(ImGui::GetFont(), ImGui::GetFontSize() * textScale, textCenterPos,
                                  ImGui::GetColorU32(activeTextColorVec4), activeLabel);
    activeButtonDrawList->PopClipRect();

    
    if (activeButtonClicked) {
        *isActive = !(*isActive);
        if (functionName == "Color Grading") {
            post_processing.color_grading.enabled = *isActive;
        }
    }

    ImGui::PopStyleColor(3);
    ImGui::PopID();
    ImGui::PopID();
}

void Module::DrawResetButton(float width, float heightScale, ImDrawFlags cornerFlags) {
    if (width <= 0.0f) {
        return;
    }
    ImGui::PushID(isActive);
    ImGui::PushID("bind_button");

    ImVec4 buttonColor = WidgetInactiveTrack(theme);
    targetBindColor = buttonColor;
    const float interpolationSpeed = 0.15f;
    currentBindColor.x += (targetBindColor.x - currentBindColor.x) * interpolationSpeed;
    currentBindColor.y += (targetBindColor.y - currentBindColor.y) * interpolationSpeed;
    currentBindColor.z += (targetBindColor.z - currentBindColor.z) * interpolationSpeed;
    currentBindColor.w += (targetBindColor.w - currentBindColor.w) * interpolationSpeed;

    ImGui::PushStyleColor(ImGuiCol_Button, currentBindColor);
    ImGui::PushStyleColor(ImGuiCol_ButtonHovered, currentBindColor);
    ImGui::PushStyleColor(ImGuiCol_ButtonActive, currentBindColor);

    const float buttonHeight = GetButtonHeight() * std::max(0.80f, heightScale);
    bool bindButtonClicked = ImGui::InvisibleButton("##bind_btn", ImVec2(width, buttonHeight));
    const bool bindButtonActive = ImGui::IsItemActive();
    const bool bindButtonHovered = ImGui::IsItemHovered();
    const ImGuiID bindBtnId = ImGui::GetItemID();
    const double now = ImGui::GetTime();
    const float dt = std::max(1e-4f, ImGui::GetIO().DeltaTime);

    static std::unordered_map<ImGuiID, ResetButtonAnimState> anim;
    ResetButtonAnimState& st = anim[bindBtnId];
    if (bindButtonClicked) {
        st.playing = true;
        st.started = now;
        st.t = 0.0f;
    }
    const float hover_k = 1.0f - std::exp(-8.0f * dt);
    const float press_k = 1.0f - std::exp(-12.0f * dt);
    st.hover += ((bindButtonHovered ? 1.0f : 0.0f) - st.hover) * hover_k;
    st.press += ((bindButtonActive ? 1.0f : 0.0f) - st.press) * press_k;
    if (st.playing) {
        const float elapsed = static_cast<float>(now - st.started);
        const float u = std::clamp(elapsed / 0.48f, 0.0f, 1.0f);
        st.t = u * u * (3.0f - 2.0f * u);
        if (st.t >= 1.0f) {
            st.t = 0.0f;
            st.playing = false;
        }
    }

    ImDrawList* bindButtonDrawList = ImGui::GetWindowDrawList();
    ImVec2 bindBtnMin = ImGui::GetItemRectMin();
    ImVec2 bindBtnMax = ImGui::GetItemRectMax();
    const float btnW = width;
    const float btnH = buttonHeight;
    const float ui_scale = WidgetActivity::WidgetUiScale();
    const float button_rounding = std::max(0.0f, ImGui::GetStyle().FrameRounding);

    ImVec4 track_col = currentBindColor;
    track_col.w = std::clamp(track_col.w * (1.0f + st.hover * 0.16f + st.press * 0.08f), 0.0f, 1.0f);
    bindButtonDrawList->AddRectFilled(bindBtnMin, bindBtnMax, ImGui::GetColorU32(track_col), button_rounding, cornerFlags);

    const ImVec4 reset_fill_base = ImVec4(0.92f, 0.28f, 0.31f, 0.72f);
    ImVec4 reset_fill = reset_fill_base;
    reset_fill.w = std::clamp(reset_fill.w * (1.0f + st.hover * 0.10f), 0.0f, 1.0f);
    float fill_w = 0.0f;
    if (st.playing) {
        fill_w = btnW * SweepNorm(st.t);
        if (fill_w > 1.0f) {
            const bool fill_is_full = fill_w >= (btnW - 1.0f);
            const float rr_fill = std::min(button_rounding, std::min(fill_w, btnH) * 0.5f);
            const ImDrawFlags left_mask = ImDrawFlags_RoundCornersTopLeft | ImDrawFlags_RoundCornersBottomLeft;
            const ImDrawFlags fill_flags = fill_is_full ? cornerFlags : (cornerFlags & left_mask);
            bindButtonDrawList->AddRectFilled(
                bindBtnMin,
                ImVec2(bindBtnMin.x + fill_w, bindBtnMax.y),
                ImGui::GetColorU32(reset_fill),
                rr_fill,
                fill_flags
            );
        }
    }

    const char* bindLabel = "RESET";
    ImFont* font = ImGui::GetFont();
    const float textSizePx = ImGui::GetFontSize();
    const ImVec2 bindTextSize = font
        ? font->CalcTextSizeA(textSizePx, FLT_MAX, 0.0f, bindLabel)
        : ImGui::CalcTextSize(bindLabel);

    ImVec2 textCenterPos;
    ImGuiID textId = ImGui::GetID("bind_text");
    float targetAlpha = 0.92f;
    float targetScale = 1.0f;
    float textAlpha = targetAlpha;
    float textScale = targetScale;
    if (!skipIntroAnimation) {
        textAlpha = iam_tween_float(textId, ImGui::GetID("bind_text_alpha"),
            targetAlpha, 0.25f, iam_ease_preset(iam_ease_out_cubic), iam_policy_crossfade, ImGui::GetIO().DeltaTime);
        textScale = iam_tween_float(textId, ImGui::GetID("bind_text_scale"),
            targetScale, 0.25f, iam_ease_preset(iam_ease_out_cubic), iam_policy_crossfade, ImGui::GetIO().DeltaTime);
    }
    ImVec2 scaledTextSize = ImVec2(bindTextSize.x * textScale, bindTextSize.y * textScale);
    const ImVec2 resetGlyphOff = WidgetBase::ScaledGlyphOffset(font, textSizePx * textScale);
    textCenterPos.x = bindBtnMin.x + (btnW - scaledTextSize.x) * 0.5f;
    textCenterPos.y = bindBtnMin.y + (btnH - scaledTextSize.y) * 0.5f - resetGlyphOff.y;

    const ImVec4 baseTextColor = ImGui::GetStyle().Colors[ImGuiCol_Text];
    const ImVec4 darkTextColor = ImVec4(0.08f, 0.08f, 0.08f, baseTextColor.w * textAlpha);
    const float fillEdge = bindBtnMin.x + fill_w;
    const bool hasFill = fill_w > 0.5f;
    bindButtonDrawList->PushClipRect(bindBtnMin, bindBtnMax, true);
    const char* p = bindLabel;
    float pen_x = textCenterPos.x;
    while (*p) {
        unsigned int cp = 0;
        const int adv = ImTextCharFromUtf8(&cp, p, nullptr);
        if (adv <= 0) {
            break;
        }
        const char* next = p + adv;
        const ImVec2 gsz = font
            ? font->CalcTextSizeA(textSizePx * textScale, FLT_MAX, 0.0f, p, next, nullptr)
            : ImGui::CalcTextSize(p, next);
        const float char_center_x = pen_x + gsz.x * 0.5f;

        ImVec4 draw_col = baseTextColor;
        draw_col.w *= textAlpha;
        if (!post_processing.flags.blur && hasFill && char_center_x <= fillEdge && LumaLocal(reset_fill) > 0.60f) {
            draw_col = darkTextColor;
        } else if (!post_processing.flags.blur && !hasFill) {
            draw_col = ResolveButtonTextColor(theme, track_col, draw_col);
        }
        draw_col = LerpVec4Local(draw_col, ImVec4(1.0f, 1.0f, 1.0f, draw_col.w), st.hover * 0.04f);
        bindButtonDrawList->AddText(font, textSizePx * textScale, ImVec2(pen_x, textCenterPos.y),
                                    ImGui::GetColorU32(draw_col), p, next);
        pen_x += gsz.x;
        p = next;
    }
    bindButtonDrawList->PopClipRect();

    if (bindButtonClicked) {
        HandleResetButtonClick();
    }

    ImGui::PopStyleColor(3);
    ImGui::PopID();
    ImGui::PopID();
}

void Module::HandleResetButtonClick() {
    WidgetManager::ResetScopeValuesGlobal(functionName);
    ResetModuleDefaultsByName(functionName);
}

float Module::GetButtonWidthForLabel(const char* label) {
    ImVec2 textSize = ImGui::CalcTextSize(label ? label : "");
    ImGuiStyle& btnStyle = ImGui::GetStyle();
    const float ui_scale = WidgetActivity::WidgetUiScale();
    float pad_x = std::max(12.0f * ui_scale, btnStyle.FramePadding.x * 2.0f);
    return textSize.x + pad_x * 2.0f;
}

Module::Module(const char* name, const char* description, const char* indicator, bool* active, bool* bound, bool showActiveToggleValue, int* activeSettingsIndexPtr, int settingsIndexValue, ModuleCallback* settingsSlotPtr, ModuleCallback settings, Theme* themePtr)
    : functionName(name), functionDescription(description), indicatorLabel(indicator ? indicator : ""), isActive(active), isBound(bound), showActiveToggle(showActiveToggleValue), activeSettingsIndex(activeSettingsIndexPtr), settingsIndex(settingsIndexValue), settingsSlot(settingsSlotPtr), theme(themePtr), lastActiveState(*active) {
        
        if (*active) {
            
            if (theme) {
                currentButtonColor = WidgetBase::PrimaryMidColor(theme);
            } else {
                currentButtonColor = ImVec4(0.294f, 0.412f, 0.996f, 0.6f); 
            }
        } else {
            
            currentButtonColor = WidgetInactiveTrack(theme);
        }
        targetButtonColor = currentButtonColor;
        if (isBound && *isBound) {
            currentBindColor = theme ? WidgetBase::PrimaryMidColor(theme)
                                     : ImVec4(0.294f, 0.412f, 0.996f, 0.6f);
        } else {
            currentBindColor = WidgetInactiveTrack(theme);
        }
        targetBindColor = currentBindColor;

        if (settingsSlot && settings) {
            *settingsSlot = settings;
        }
    }
