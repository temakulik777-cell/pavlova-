#include "../wigdets.h"
#include "../../imgui/box_shadow.h"
#include <algorithm>
#include <cfloat>
#include <cstdio>
#include <cmath>
#include <cstdint>
#include <string>
#include <vector>
#include <unordered_map>

static ImVec4 WidgetAlpha(ImVec4 c) {
    return WidgetBase::AlphaAware(c);
}

static ImVec4 ResolveDescriptionColor(Theme* theme) {
    return WidgetBase::DescriptionColor(theme);
}

static ImVec4 ResolveTrackColor(Theme* theme) {
    return WidgetBase::TrackColor(theme);
}

static ImVec4 ResolvePrimaryColor(Theme* theme) {
    return WidgetBase::PrimaryColor(theme);
}

static ImVec4 ColorPopupBgColor(Theme* theme) {
    if (theme) {
        return theme->HexToImVec4(theme->material.surfaceVariant);
    }
    return ImVec4(0.11f, 0.11f, 0.11f, 1.0f);
}

static ImVec4 ColorPopupItemColor(Theme* theme) {
    if (theme) {
        return theme->HexToImVec4(theme->material.surfaceContainer);
    }
    return ImVec4(0.08f, 0.08f, 0.08f, 1.0f);
}

static ImVec4 ColorPopupSelectedColor(Theme* theme) {
    return WidgetBase::PrimaryMidColor(theme);
}

static void DrawPopupShadowBox(const ImVec2& min, const ImVec2& max, float rounding, float alpha_mul, Theme* theme, bool blur_mode) {
    if (!post_processing.flags.shadow || alpha_mul <= 0.0001f) {
        return;
    }
    const ClickGUI& gui = ClickGUI::Get();
    const int shadow_rings = std::clamp(gui.appearance.shadowRings, 6, 32);
    const float shadow_smooth = std::clamp(gui.appearance.shadowSmoothness, 0.35f, 1.60f);
    const float tuned_alpha = std::clamp(alpha_mul * 0.72f, 0.0f, 1.0f);
    if (blur_mode) {
        ImVec4 glow = ImVec4(1.0f, 1.0f, 1.0f, 0.22f);
        if (theme && theme->IsLightMode()) {
            glow = ImVec4(0.0f, 0.0f, 0.0f, 0.16f);
        } else if (theme) {
            glow = theme->HexToImVec4(theme->material.surfaceVariant);
            glow.w = 0.22f;
        }
        drawRoundedRectShadow(min, max, rounding, ImColor(glow.x, glow.y, glow.z, glow.w), tuned_alpha, shadow_rings, shadow_smooth, true);
    } else {
        drawRoundedRectShadow(min, max, rounding, ImColor(0.0f, 0.0f, 0.0f, 0.20f), tuned_alpha, shadow_rings, shadow_smooth, true);
    }
}

static Blur s_color_popup_blur(Hardware::GPU);

static void DrawColorPopupBlur(ImDrawList* draw_list,
                               const ImVec2& window_pos,
                               const ImVec2& window_size,
                               float alpha,
                               float corner_radius,
                               int downscale_factor,
                               float blur_radius,
                               Blur::Type blur_type) {
    if (!draw_list || alpha <= 0.001f || window_size.x <= 1.0f || window_size.y <= 1.0f) {
        return;
    }
    if (glWidth <= 0 || glHeight <= 0) {
        return;
    }
    const float x0 = window_pos.x;
    const float y0 = window_pos.y;
    const float x1 = window_pos.x + window_size.x;
    const float y1 = window_pos.y + window_size.y;
    const float ds_scale = (float)std::max(1, downscale_factor);
    const float pad_f = std::max(8.0f, ((blur_radius * 2.0f) + 6.0f) * ds_scale + 12.0f);
    const int pad = std::max(1, (int)std::ceil(pad_f));
    const int cap_x0 = std::max(0, (int)std::floor(x0) - pad);
    const int cap_y0 = std::max(0, (int)std::floor(y0) - pad);
    const int cap_x1 = std::min(glWidth, (int)std::ceil(x1) + pad);
    const int cap_y1 = std::min(glHeight, (int)std::ceil(y1) + pad);
    const int cap_w = std::max(0, cap_x1 - cap_x0);
    const int cap_h = std::max(0, cap_y1 - cap_y0);
    if (cap_w <= 0 || cap_h <= 0) {
        return;
    }
    const int read_x = cap_x0;
    const int read_y = glHeight - cap_y1;

    s_color_popup_blur.backend = Hardware::GPU;
    s_color_popup_blur.type = blur_type;
    struct ColorBlurJob { int x, y, w, h; float r; int ds; Blur::Type t; };
    auto* job = new ColorBlurJob{read_x, read_y, cap_w, cap_h, blur_radius, std::max(1, downscale_factor), blur_type};
    draw_list->AddCallback([](const ImDrawList*, const ImDrawCmd* cmd) {
        auto* j = static_cast<ColorBlurJob*>(cmd->UserCallbackData);
        s_color_popup_blur.backend = Hardware::GPU;
        s_color_popup_blur.type = j->t;
        s_color_popup_blur.process(j->x, j->y, j->w, j->h, j->r, j->ds);
        delete j;
    }, job);

    const float u0 = std::clamp((x0 - (float)cap_x0) / (float)cap_w, 0.0f, 1.0f);
    const float u1 = std::clamp((x1 - (float)cap_x0) / (float)cap_w, 0.0f, 1.0f);
    const float v_top = std::clamp(1.0f - ((y0 - (float)cap_y0) / (float)cap_h), 0.0f, 1.0f);
    const float v_bottom = std::clamp(1.0f - ((y1 - (float)cap_y0) / (float)cap_h), 0.0f, 1.0f);
    const ImU32 tint = ImGui::GetColorU32(ImVec4(1.0f, 1.0f, 1.0f, std::clamp(alpha, 0.0f, 1.0f)));
    draw_list->AddImageRounded(
        (void*)(intptr_t)s_color_popup_blur.tex,
        window_pos,
        ImVec2(window_pos.x + window_size.x, window_pos.y + window_size.y),
        ImVec2(u0, v_top), ImVec2(u1, v_bottom),
        tint, corner_radius, ImDrawFlags_RoundCornersAll
    );
}

static GLuint s_color_palette_tex = 0;
static int s_color_palette_size = 0;

static ImVec4 LerpColor(const ImVec4& a, const ImVec4& b, float t) {
    return ImVec4(
        a.x + (b.x - a.x) * t,
        a.y + (b.y - a.y) * t,
        a.z + (b.z - a.z) * t,
        a.w + (b.w - a.w) * t
    );
}

static ImVec4 EvalPaletteColor(float nx, float ny) {
    nx = std::clamp(nx, 0.0f, 1.0f);
    ny = std::clamp(ny, 0.0f, 1.0f);

    static const ImVec4 kStops[] = {
        ImVec4(1.00f, 0.05f, 0.05f, 1.0f), // red
        ImVec4(1.00f, 0.45f, 0.00f, 1.0f), // orange
        ImVec4(1.00f, 0.90f, 0.00f, 1.0f), // yellow
        ImVec4(0.15f, 0.85f, 0.18f, 1.0f), // green
        ImVec4(0.00f, 0.84f, 0.88f, 1.0f), // cyan
        ImVec4(0.10f, 0.35f, 1.00f, 1.0f), // blue
        ImVec4(0.44f, 0.18f, 1.00f, 1.0f), // violet
        ImVec4(0.95f, 0.20f, 0.78f, 1.0f), // magenta
        ImVec4(1.00f, 0.05f, 0.05f, 1.0f)  // wrap to red
    };
    constexpr int kStopCount = (int)(sizeof(kStops) / sizeof(kStops[0]));
    const float scaled = nx * (float)(kStopCount - 1);
    const int idx = std::clamp((int)std::floor(scaled), 0, kStopCount - 2);
    const float t = std::clamp(scaled - (float)idx, 0.0f, 1.0f);
    ImVec4 base = LerpColor(kStops[idx], kStops[idx + 1], t);
    float r = base.x, g = base.y, b = base.z;

    const float white_mix = std::pow(1.0f - nx, 1.30f) * (0.46f - ny * 0.26f);
    r = r * (1.0f - white_mix) + white_mix;
    g = g * (1.0f - white_mix) + white_mix;
    b = b * (1.0f - white_mix) + white_mix;

    const float dark_mix = std::pow(ny, 1.08f) * 0.88f;
    r *= (1.0f - dark_mix);
    g *= (1.0f - dark_mix);
    b *= (1.0f - dark_mix);
    return ImVec4(std::clamp(r, 0.0f, 1.0f), std::clamp(g, 0.0f, 1.0f), std::clamp(b, 0.0f, 1.0f), 1.0f);
}

static ImVec2 ApproxPaletteCoordFromColor(float r, float g, float b) {
    const int samples = 56;
    float best_d2 = FLT_MAX;
    ImVec2 best_uv(0.5f, 0.5f);
    for (int y = 0; y <= samples; ++y) {
        const float ny = (float)y / (float)samples;
        for (int x = 0; x <= samples; ++x) {
            const float nx = (float)x / (float)samples;
            const ImVec4 c = EvalPaletteColor(nx, ny);
            const float dr = c.x - r;
            const float dg = c.y - g;
            const float db = c.z - b;
            const float d2 = dr * dr + dg * dg + db * db;
            if (d2 < best_d2) {
                best_d2 = d2;
                best_uv = ImVec2(nx, ny);
            }
        }
    }
    return best_uv;
}

static void EnsurePaletteTexture(int tex_size = 1024) {
    tex_size = std::max(128, tex_size);
    if (s_color_palette_tex != 0 && s_color_palette_size == tex_size) {
        return;
    }
    if (s_color_palette_tex == 0) {
        glGenTextures(1, &s_color_palette_tex);
    }
    if (s_color_palette_tex == 0) {
        return;
    }

    std::vector<uint8_t> rgba(tex_size * tex_size * 4);
    for (int y = 0; y < tex_size; ++y) {
        const float ny = (float)y / (float)std::max(1, tex_size - 1);
        for (int x = 0; x < tex_size; ++x) {
            const float nx = (float)x / (float)std::max(1, tex_size - 1);
            const ImVec4 c = EvalPaletteColor(nx, ny);
            const int idx = (y * tex_size + x) * 4;
            rgba[idx + 0] = (uint8_t)std::clamp((int)std::lround(c.x * 255.0f), 0, 255);
            rgba[idx + 1] = (uint8_t)std::clamp((int)std::lround(c.y * 255.0f), 0, 255);
            rgba[idx + 2] = (uint8_t)std::clamp((int)std::lround(c.z * 255.0f), 0, 255);
            rgba[idx + 3] = 255;
        }
    }

    GLint prev_tex = 0;
    glGetIntegerv(GL_TEXTURE_BINDING_2D, &prev_tex);
    glBindTexture(GL_TEXTURE_2D, s_color_palette_tex);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, tex_size, tex_size, 0, GL_RGBA, GL_UNSIGNED_BYTE, rgba.data());
    glBindTexture(GL_TEXTURE_2D, (GLuint)prev_tex);
    s_color_palette_size = tex_size;
}

static ImVec2 GetScaledGlyphOffset(const ImFont* font, float size) {
    return WidgetBase::ScaledGlyphOffset(font, size);
}

static float ClampNorm(float v, float min_v, float max_v) {
    return WidgetBase::ClampNorm(v, min_v, max_v);
}

static float Unnorm(float t, float min_v, float max_v) {
    return WidgetBase::Unnorm(t, min_v, max_v);
}

static float CalcWrappedTextHeight(const char* text, float font_size, float wrap_width) {
    return WidgetBase::CalcWrappedTextHeight(text, font_size, wrap_width);
}

struct ColorPopupState {
    ImGuiID owner = 0;
    bool open = false;
    int opened_frame = -1;
};
static ColorPopupState s_color_popup;

struct ColorOverlayState {
    bool request_capture = false;
    bool has_capture = false;
    int capture_w = 0;
    int capture_h = 0;
};
static ColorOverlayState s_color_overlay;

struct ColorOverlayFrameData {
    bool valid = false;
    ImGuiID owner = 0;
    std::string label;
    float* r = nullptr;
    float* g = nullptr;
    float* b = nullptr;
    float* r2 = nullptr;
    float* g2 = nullptr;
    float* b2 = nullptr;
    int active_slot = 0;
    float min = 0.0f;
    float max = 1.0f;
    Theme* theme = nullptr;
    float sel_nx = 0.5f;
    float sel_ny = 0.5f;
    bool selection_valid = false;
};
static ColorOverlayFrameData s_color_frame;
static bool s_color_popup_blocks_input = false;
static int s_color_popup_blocks_frame = -1;
static bool s_color_popup_visual_valid = false;
static ImVec2 s_color_popup_visual_min = ImVec2(0.0f, 0.0f);
static ImVec2 s_color_popup_visual_max = ImVec2(0.0f, 0.0f);

bool ColorPickerPopupNeedsPostRenderCapture() {
    return post_processing.flags.blur && s_color_overlay.request_capture;
}

void ColorPickerPopupPostRenderCapture(int display_w, int display_h) {
    (void)display_w;
    (void)display_h;
    if (!post_processing.flags.blur || !s_color_overlay.request_capture) {
        s_color_overlay.has_capture = false;
        return;
    }
    s_color_overlay.has_capture = false;
}

void ColorPickerPopupRenderPostPass() {
    if (!s_color_frame.valid || !s_color_frame.r || !s_color_frame.g || !s_color_frame.b) {
        s_color_popup_visual_valid = false;
        return;
    }

    const ImGuiID popup_id = s_color_frame.owner;
    const float target_open = (s_color_popup.owner == popup_id && s_color_popup.open) ? 1.0f : 0.0f;
    const float dt = ImGui::GetIO().DeltaTime;
    const float popup_speed = std::clamp(ClickGUI::Get().animationTuning.popupSpeed, 0.2f, 4.0f);
    const float popup_anim_duration = 0.38f / popup_speed;
    const float popup_progress = iam_tween_float(
        popup_id, ImHashStr("color_popup_progress"), target_open, popup_anim_duration,
        iam_ease_preset(iam_ease_out_cubic),
        iam_policy_crossfade, dt
    );
    const float popup_alpha = (popup_progress > 0.001f) ? 1.0f : 0.0f;

    if (target_open <= 0.0f && popup_alpha <= 0.001f && s_color_popup.owner == popup_id) {
        s_color_popup.owner = 0;
        s_color_overlay.has_capture = false;
        s_color_overlay.request_capture = false;
        s_color_frame.valid = false;
        s_color_frame.selection_valid = false;
        s_color_popup_visual_valid = false;
        return;
    }
    if (popup_alpha <= 0.001f) {
        s_color_popup_visual_valid = false;
        return;
    }

    ImGuiViewport* vp = ImGui::GetMainViewport();
    const float scale = 1.0f;
    const float palette_side = std::clamp(
        std::min(vp->Size.x * 0.52f, vp->Size.y * 0.52f),
        280.0f,
        620.0f
    );
    const float chrome = 44.0f;
    const float base_w = palette_side + chrome;
    const float base_h = palette_side + chrome;
    const ImVec2 wnd_size(base_w, base_h);
    const ImVec2 center(vp->GetCenter().x - wnd_size.x * 0.5f, vp->GetCenter().y - wnd_size.y * 0.5f);
    const ImVec2 start_pos(center.x, vp->Pos.y + vp->Size.y + 32.0f);
    const ImVec2 wnd_pos = ImLerp(start_pos, center, popup_progress);
    const ImVec2 wnd_max(wnd_pos.x + wnd_size.x, wnd_pos.y + wnd_size.y);
    s_color_popup_visual_valid = true;
    s_color_popup_visual_min = wnd_pos;
    s_color_popup_visual_max = wnd_max;
    const float popup_rounding = 16.0f;
    const bool use_blur = post_processing.flags.blur;
    const float overlay_alpha = use_blur ? 0.40f : 0.22f;
    ImDrawList* bg = ImGui::GetForegroundDrawList();
    DrawPopupShadowBox(wnd_pos, wnd_max, popup_rounding, popup_alpha, s_color_frame.theme, use_blur);

    if (use_blur) {
        ClickGUI& gui = ClickGUI::Get();
        const int popup_downscale = 15;
        DrawColorPopupBlur(
            bg,
            wnd_pos,
            wnd_size,
            popup_alpha,
            popup_rounding,
            popup_downscale,
            std::max(0.1f, gui.sidebar.BlurRadius),
            gui.sidebar.BlurType
        );
    }

    if (use_blur) {
        const Theme* popup_theme = s_color_frame.theme;
        const bool light_mode = popup_theme && popup_theme->IsLightMode();
        const ImVec4 overlay_col = light_mode
            ? ImVec4(1.0f, 1.0f, 1.0f, overlay_alpha * 0.68f)
            : ImVec4(0.0f, 0.0f, 0.0f, overlay_alpha);
        bg->AddRectFilled(
            wnd_pos,
            wnd_max,
            ImGui::GetColorU32(overlay_col),
            popup_rounding,
            ImDrawFlags_RoundCornersAll
        );

        ImVec4 popup_tint = ColorPopupBgColor(s_color_frame.theme);
        popup_tint.w = std::clamp((0.08f + 0.06f), 0.0f, 1.0f);
        bg->AddRectFilled(wnd_pos, wnd_max, ImGui::GetColorU32(popup_tint), popup_rounding, ImDrawFlags_RoundCornersAll);
    }

    if (s_color_popup.owner == popup_id && s_color_popup.open && ImGui::IsMouseClicked(0) &&
        ImGui::GetFrameCount() > s_color_popup.opened_frame) {
        ImVec2 mp = ImGui::GetMousePos();
        bool inside = (mp.x >= wnd_pos.x && mp.x <= wnd_max.x && mp.y >= wnd_pos.y && mp.y <= wnd_max.y);
        if (!inside) {
            s_color_popup.open = false;
        }
    }
    if (s_color_popup.owner == popup_id && s_color_popup.open && ImGui::IsKeyPressed(ImGuiKey_Escape)) {
        s_color_popup.open = false;
    }

    char wnd_name[64];
    std::snprintf(wnd_name, sizeof(wnd_name), "##color_picker_popup_%08X", popup_id);

    ImVec4 wnd_bg = use_blur
        ? ColorPopupBgColor(s_color_frame.theme)
        : ColorPopupItemColor(s_color_frame.theme);
    if (use_blur) {
        wnd_bg.w = 0.0f;
    } else {
        // Keep popup content visually above menu/child shadows in non-blur mode.
        bg->AddRectFilled(wnd_pos, wnd_max, ImGui::GetColorU32(wnd_bg), popup_rounding, ImDrawFlags_RoundCornersAll);
    }
    ImVec4 text_col = ImGui::GetStyle().Colors[ImGuiCol_Text];

    ImGui::SetNextWindowPos(wnd_pos, ImGuiCond_Always);
    ImGui::SetNextWindowSize(wnd_size, ImGuiCond_Always);
    ImGui::SetNextWindowBgAlpha(wnd_bg.w);
    if (s_color_popup.owner == popup_id && s_color_popup.open) {
        ImGui::SetNextWindowFocus();
    }
    ImGui::PushStyleVar(ImGuiStyleVar_Alpha, 1.0f);

    ImGui::PushStyleColor(ImGuiCol_WindowBg, wnd_bg);
    ImGui::PushStyleColor(ImGuiCol_Text, text_col);
    ImGui::PushStyleColor(ImGuiCol_Border, ImVec4(0, 0, 0, 0));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, popup_rounding);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0.0f);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(18.0f * scale, 18.0f * scale));

    if (ImGui::Begin(wnd_name, nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoMove)) {
        ImGui::BringWindowToDisplayFront(ImGui::GetCurrentWindow());
        ImDrawList* dl = ImGui::GetForegroundDrawList();
        const ImVec2 content_min = ImGui::GetCursorScreenPos();
        const ImVec2 content_avail = ImGui::GetContentRegionAvail();
        const float outer_pad = std::clamp(18.0f * scale, 14.0f, 24.0f);
        const float rr = std::clamp(10.0f * scale, 8.0f, 14.0f);
        const float panel_pad = std::clamp(12.0f * scale, 10.0f, 16.0f);
        const float palette_size = std::max(120.0f, std::min(content_avail.x - outer_pad * 2.0f, content_avail.y - outer_pad * 2.0f));
        const ImVec2 pal_min(
            content_min.x + std::max(0.0f, (content_avail.x - palette_size) * 0.5f),
            content_min.y + std::max(0.0f, (content_avail.y - palette_size) * 0.5f)
        );
        const ImVec2 pal_max(pal_min.x + palette_size, pal_min.y + palette_size);
        const float block_x = pal_min.x;
        const float block_y = pal_min.y;
        const float block_w = palette_size;
        const float block_h = palette_size;

        float* active_r = (s_color_frame.active_slot == 1 && s_color_frame.r2) ? s_color_frame.r2 : s_color_frame.r;
        float* active_g = (s_color_frame.active_slot == 1 && s_color_frame.g2) ? s_color_frame.g2 : s_color_frame.g;
        float* active_b = (s_color_frame.active_slot == 1 && s_color_frame.b2) ? s_color_frame.b2 : s_color_frame.b;
        float rn = ClampNorm(*active_r, s_color_frame.min, s_color_frame.max);
        float gn = ClampNorm(*active_g, s_color_frame.min, s_color_frame.max);
        float bn = ClampNorm(*active_b, s_color_frame.min, s_color_frame.max);
        if (!s_color_frame.selection_valid) {
            const ImVec2 uv = ApproxPaletteCoordFromColor(rn, gn, bn);
            s_color_frame.sel_nx = uv.x;
            s_color_frame.sel_ny = uv.y;
            s_color_frame.selection_valid = true;
        }

        (void)block_x;
        (void)block_y;
        (void)block_w;
        (void)block_h;
        (void)panel_pad;
        EnsurePaletteTexture(1024);
        if (s_color_palette_tex != 0) {
            dl->AddImageRounded(
                (ImTextureID)(intptr_t)s_color_palette_tex,
                pal_min,
                pal_max,
                ImVec2(0.0f, 0.0f),
                ImVec2(1.0f, 1.0f),
                ImGui::GetColorU32(ImVec4(1, 1, 1, 1.0f)),
                rr,
                ImDrawFlags_RoundCornersAll
            );
        }

        ImGui::SetCursorScreenPos(pal_min);
        ImGui::InvisibleButton("##color_palette_square", ImVec2(palette_size, palette_size));
        if (ImGui::IsItemActive() && ImGui::GetIO().MouseDown[0]) {
            ImVec2 mp = ImGui::GetIO().MousePos;
            const float nx = std::clamp((mp.x - pal_min.x) / std::max(1.0f, palette_size), 0.0f, 1.0f);
            const float ny = std::clamp((mp.y - pal_min.y) / std::max(1.0f, palette_size), 0.0f, 1.0f);
            s_color_frame.sel_nx = nx;
            s_color_frame.sel_ny = ny;
            const ImVec4 c = EvalPaletteColor(nx, ny);
            rn = c.x;
            gn = c.y;
            bn = c.z;
            *active_r = Unnorm(rn, s_color_frame.min, s_color_frame.max);
            *active_g = Unnorm(gn, s_color_frame.min, s_color_frame.max);
            *active_b = Unnorm(bn, s_color_frame.min, s_color_frame.max);
        }

        const float cx = pal_min.x + std::clamp(s_color_frame.sel_nx, 0.0f, 1.0f) * palette_size;
        const float cy = pal_min.y + std::clamp(s_color_frame.sel_ny, 0.0f, 1.0f) * palette_size;
        const ImVec4 knob_col = EvalPaletteColor(std::clamp(s_color_frame.sel_nx, 0.0f, 1.0f),
                                                 std::clamp(s_color_frame.sel_ny, 0.0f, 1.0f));
        const float sv_knob_r = std::clamp(8.0f * scale, 7.0f, 12.0f);
        if (post_processing.flags.glow) {
            const ImVec2 cpos(cx, cy);
            const int glow_layers = 14;
        const float glow_spread = 5.0f * scale;
            const float glow_alpha_scale = post_processing.flags.glow_alpha_scale;
            for (int i = 0; i < glow_layers; ++i) {
                const float u = ((float)i + 1.0f) / (float)glow_layers;
                const float edge = 1.0f - u;
                const float r = sv_knob_r + 1.2f + u * glow_spread;
                const float a = (0.020f + 0.070f * edge * edge) * glow_alpha_scale;
                dl->AddCircleFilled(cpos, r, ImGui::GetColorU32(ImVec4(0.95f, 0.97f, 1.00f, a)), 40);
            }
            dl->AddCircleFilled(cpos, sv_knob_r + 2.0f * scale, ImGui::GetColorU32(ImVec4(knob_col.x, knob_col.y, knob_col.z, 0.08f * glow_alpha_scale)), 40);
        }
        dl->AddCircleFilled(ImVec2(cx, cy), sv_knob_r + std::max(1.0f, 1.8f * scale), IM_COL32(0, 0, 0, post_processing.flags.blur ? 80 : 60), 24);
        dl->AddCircleFilled(ImVec2(cx, cy), sv_knob_r, ImGui::GetColorU32(knob_col), 24);
        dl->AddCircle(ImVec2(cx, cy), sv_knob_r, IM_COL32(255, 255, 255, 240), 24, std::max(1.2f, 1.8f * scale));
        ImGui::SetCursorScreenPos(content_min);
        ImGui::Dummy(content_avail);
    }
    ImGui::End();
    ImGui::PopStyleVar();
    ImGui::PopStyleVar(3);
    ImGui::PopStyleColor(3);

}

bool ColorPickerPopupBlocksInput() {
    return s_color_popup_blocks_input || (s_color_popup.owner != 0 && s_color_popup.open) ||
           s_color_overlay.request_capture || s_color_frame.valid;
}

bool ColorPickerPopupGetVisualRect(ImVec2* out_min, ImVec2* out_max) {
    if (!s_color_popup_visual_valid) {
        return false;
    }
    if (out_min) {
        *out_min = s_color_popup_visual_min;
    }
    if (out_max) {
        *out_max = s_color_popup_visual_max;
    }
    return true;
}

bool ColorPicker3(const char* label, const char* description, float* r, float* g, float* b,
                  float min, float max, Theme* theme) {
    return ColorPicker3(label, description, r, g, b, nullptr, nullptr, nullptr, min, max, theme, nullptr);
}

bool ColorPicker3(const char* label, const char* description, float* r, float* g, float* b,
                  float min, float max, Theme* theme, bool* out_active) {
    return ColorPicker3(label, description, r, g, b, nullptr, nullptr, nullptr, min, max, theme, out_active);
}

bool ColorPicker3(const char* label, const char* description,
                  float* r1, float* g1, float* b1,
                  float* r2, float* g2, float* b2,
                  float min, float max, Theme* theme) {
    return ColorPicker3(label, description, r1, g1, b1, r2, g2, b2, min, max, theme, nullptr);
}

bool ColorPicker3(const char* label, const char* description,
                  float* r1, float* g1, float* b1,
                  float* r2, float* g2, float* b2,
                  float min, float max, Theme* theme, bool* out_active) {
    if (!label || !r1 || !g1 || !b1) {
        if (out_active) *out_active = false;
        return false;
    }

    ImDrawList* dl = ImGui::GetForegroundDrawList();
    ImGuiStyle& style = ImGui::GetStyle();
    ImVec2 start = ImGui::GetCursorScreenPos();
    float full_w = std::max(1.0f, ImGui::GetContentRegionAvail().x);
    float ui_scale = WidgetActivity::WidgetUiScale();
    const bool has_second_color = (r2 && g2 && b2);
    const float old_r = *r1;
    const float old_g = *g1;
    const float old_b = *b1;
    const float old_r2 = has_second_color ? *r2 : 0.0f;
    const float old_g2 = has_second_color ? *g2 : 0.0f;
    const float old_b2 = has_second_color ? *b2 : 0.0f;

    const float desc_font = style.FontSizeBase * 0.85f;
    ImVec2 label_size = ImGui::CalcTextSize(label);
    float desc_h = 0.0f;
    const float desc_wrap_w = std::max(20.0f, full_w);
    float desc_font_effective = desc_font;
    if (description && description[0] != '\0') {
        ImGui::PushFont(nullptr, desc_font);
        desc_font_effective = ImGui::GetFontSize();
        float measured_h = CalcWrappedTextHeight(description, desc_font_effective, desc_wrap_w);
        desc_h = std::max(measured_h, desc_font_effective);
        ImGui::PopFont();
    }

    const float label_desc_gap = std::max(1.0f, style.ItemInnerSpacing.y * 0.60f);
    const float top_h = label_size.y;
    const float title_desc_h = top_h + ((desc_h > 0.0f) ? (label_desc_gap + desc_h) : 0.0f);
    const float preview_size = ImGui::GetFrameHeight() * 1.20f * 1.22f;

    const float label_bottom = start.y + top_h;
    const float desc_y = label_bottom + (desc_h > 0.0f ? label_desc_gap : 0.0f);
    const float desc_draw_y = desc_y;
    const float total_h = title_desc_h;
    ImGui::Dummy(ImVec2(full_w, total_h));
    ImVec2 layout_end = ImGui::GetCursorScreenPos();

    float label_y = start.y + (top_h - label_size.y) * 0.5f;
    dl->AddText(ImVec2(start.x, label_y), ImGui::GetColorU32(style.Colors[ImGuiCol_Text]), label);
    if (description && description[0] != '\0') {
        ImGui::PushFont(nullptr, desc_font);
        dl->AddText(ImGui::GetFont(), ImGui::GetFontSize(), ImVec2(start.x, desc_draw_y),
                    ImGui::GetColorU32(ResolveDescriptionColor(theme)), description, nullptr, desc_wrap_w);
        ImGui::PopFont();
    }

    static std::unordered_map<ImGuiID, int> s_active_slot;
    ImGuiID base_id = ImHashStr(label);
    int& active_slot = s_active_slot[base_id];
    if (!has_second_color) {
        active_slot = 0;
    } else if (active_slot != 0 && active_slot != 1) {
        active_slot = 0;
    }

    float* active_r = (active_slot == 1 && has_second_color) ? r2 : r1;
    float* active_g = (active_slot == 1 && has_second_color) ? g2 : g1;
    float* active_b = (active_slot == 1 && has_second_color) ? b2 : b1;

    const float preview_gap = has_second_color ? ImGui::GetStyle().ItemSpacing.y : 0.0f;
    const float total_preview_w = has_second_color ? (preview_size * 2.0f + preview_gap) : preview_size;
    ImVec2 prev_min(start.x + full_w - total_preview_w, start.y + (title_desc_h - preview_size) * 0.5f);
    ImVec2 prev_max(prev_min.x + preview_size, prev_min.y + preview_size);
    ImVec2 prev2_min(0.0f, 0.0f);
    ImVec2 prev2_max(0.0f, 0.0f);
    if (has_second_color) {
        prev2_min = prev_min;
        prev2_max = ImVec2(prev2_min.x + preview_size, prev2_min.y + preview_size);
        prev_min.x += preview_size + preview_gap;
        prev_max.x += preview_size + preview_gap;
    }

    const float p1_r = ClampNorm(*r1, min, max);
    const float p1_g = ClampNorm(*g1, min, max);
    const float p1_b = ClampNorm(*b1, min, max);
    ImVec4 preview_col = ImVec4(p1_r, p1_g, p1_b, 1.0f);
    dl->AddRectFilled(prev_min, prev_max, ImGui::GetColorU32(preview_col), style.FrameRounding);
    if (has_second_color) {
        const float rn2 = ClampNorm(*r2, min, max);
        const float gn2 = ClampNorm(*g2, min, max);
        const float bn2 = ClampNorm(*b2, min, max);
        dl->AddRectFilled(prev2_min, prev2_max, ImGui::GetColorU32(ImVec4(rn2, gn2, bn2, 1.0f)), style.FrameRounding);
    }

    bool active_any = false;

    ImGui::PushID(label);
    const ImGuiID color_popup_id = ImGui::GetID("##color_popup_owner");
    ImGui::SetCursorScreenPos(prev_min);
    bool preview_clicked = ImGui::InvisibleButton("##color_preview_btn", ImVec2(preview_size, preview_size));
    if (preview_clicked) {
        active_slot = 0;
        s_color_frame.selection_valid = false;
    }
    bool preview_active = ImGui::IsItemActive();
    active_any = active_any || preview_active;

    bool preview2_clicked = false;
    bool preview2_active = false;
    if (has_second_color) {
        ImGui::SetCursorScreenPos(prev2_min);
        preview2_clicked = ImGui::InvisibleButton("##color_preview_btn2", ImVec2(preview_size, preview_size));
        preview2_active = ImGui::IsItemActive();
        active_any = active_any || preview2_active;
        if (preview2_clicked) {
            active_slot = 1;
            s_color_frame.selection_valid = false;
        }
    }

    if (preview_clicked || preview2_clicked) {
        s_color_popup.owner = color_popup_id;
        if (!s_color_popup.open) {
            s_color_popup.opened_frame = ImGui::GetFrameCount();
        }
        s_color_popup.open = true;
        s_color_frame.selection_valid = false;
    }

    const float popup_target_open = (s_color_popup.owner == color_popup_id && s_color_popup.open) ? 1.0f : 0.0f;
    const float popup_speed = std::clamp(ClickGUI::Get().animationTuning.popupSpeed, 0.2f, 4.0f);
    const float popup_anim_duration = 0.38f / popup_speed;
    const float popup_progress = iam_tween_float(
        color_popup_id, ImHashStr("color_popup_progress"), popup_target_open, popup_anim_duration,
        iam_ease_preset(iam_ease_out_cubic),
        iam_policy_crossfade, ImGui::GetIO().DeltaTime
    );
    const float popup_alpha = (popup_progress > 0.001f) ? 1.0f : 0.0f;
    const int frame_now = ImGui::GetFrameCount();
    if (s_color_popup_blocks_frame != frame_now) {
        s_color_popup_blocks_frame = frame_now;
        s_color_popup_blocks_input = false;
    }
    if ((s_color_popup.owner == color_popup_id) &&
        (popup_target_open > 0.001f || popup_alpha > 0.001f || s_color_popup.open)) {
        s_color_popup_blocks_input = true;
    }
    s_color_overlay.request_capture = (popup_target_open > 0.001f || popup_alpha > 0.001f);
    if (s_color_popup.owner == color_popup_id) {
        s_color_frame.valid = true;
        s_color_frame.owner = color_popup_id;
        s_color_frame.label = label;
        s_color_frame.r = r1;
        s_color_frame.g = g1;
        s_color_frame.b = b1;
        s_color_frame.r2 = r2;
        s_color_frame.g2 = g2;
        s_color_frame.b2 = b2;
        s_color_frame.active_slot = active_slot;
        s_color_frame.min = min;
        s_color_frame.max = max;
        s_color_frame.theme = theme;
        active_any = true;
    }
    if (popup_target_open <= 0.0f && popup_alpha <= 0.001f && s_color_popup.owner == color_popup_id) {
        s_color_popup.owner = 0;
        s_color_overlay.has_capture = false;
        s_color_overlay.request_capture = false;
        s_color_frame.valid = false;
        s_color_frame.selection_valid = false;
        s_color_popup_blocks_input = false;
        s_color_popup_visual_valid = false;
    }

    ImGui::PopID();

    if (out_active) {
        *out_active = active_any;
    }
    ImGui::SetCursorScreenPos(layout_end);
    const bool primary_changed =
        std::fabs(*r1 - old_r) > 0.0001f || std::fabs(*g1 - old_g) > 0.0001f || std::fabs(*b1 - old_b) > 0.0001f;
    const bool secondary_changed = has_second_color &&
        (std::fabs(*r2 - old_r2) > 0.0001f || std::fabs(*g2 - old_g2) > 0.0001f || std::fabs(*b2 - old_b2) > 0.0001f);
    return primary_changed || secondary_changed;
}
