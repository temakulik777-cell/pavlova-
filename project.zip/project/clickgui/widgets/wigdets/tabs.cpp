#include "../wigdets.h"
#include "../../layouts/layouts.h"
#include "../../imgui/imgui.h"
#include "../../imgui/imgui_internal.h"
#include "../../imgui/im_anim/im_anim.h"
#include "../../render/post_processing.h"
#include "../../clickgui.h"
#include "../../component/components.h"
#include "../../../unity_engine/Input/Touch.h"
#include "../../../assets/images.h"
#include <algorithm>
#include <array>
#include <cmath>

static bool isDragging = false;
static ImVec2 dragStartPos = ImVec2(0, 0);
static int initialTab = 0;
static bool wasDrag = false;
static ImGuiID tabAssignedTouchId = 0;

static inline bool IsValidRegion(const ImageRegion& r) {
    return r.width > 0 && r.height > 0 &&
           r.u_max > r.u_min && r.v_max > r.v_min;
}

struct TabAtlasCacheItem {
    ImageRegion uv{};
};

struct TabDef {
    const char* icon;
    const char* name;
    const char* glow_name;
    const char* button_id;
};

static constexpr int kTabCount = 6;
static const std::array<TabDef, kTabCount> kTabs = {{
    {"ghost", "Aimbot", "text_aimbot_glow", "tab_button_0"},
    {"movement", "Movement", "text_movement_glow", "tab_button_1"},
    {"render", "Render", "text_render_glow", "tab_button_2"},
    {"misc", "Misc", "text_misc_glow", "tab_button_3"},
    {"custom", "Config", "text_config_glow", "tab_button_4"},
    {"hud", "HUD", "text_hud_glow", "tab_button_5"},
}};

static TabAtlasCacheItem g_tab_atlas_cache[kTabCount];

struct TabsFrameState {
    int frame = -1;
    bool block_tab_input = false;
    float dt = 1.0f / 60.0f;
    float ui_scale = 1.0f;
    float left_inset = 3.0f;
    float tab_switch_distance = 50.0f;
    ImVec2 current_pos = ImVec2(0, 0);
    bool is_down = false;
    bool is_released = false;
    bool just_opened = false;
    int settle_frames = 0;
};

static TabsFrameState g_tabs_state;

struct TabLayoutMetrics {
    float row_height = 0.0f;
    float row_advance = 0.0f;
    float icon_size = 0.0f;
    float text_spacing = 0.0f;
    float inner_pad_y = 0.0f;
};

static TabLayoutMetrics GetTabLayoutMetrics(float ui_scale) {
    const ImGuiStyle& style = ImGui::GetStyle();
    const float text_line_height = ImGui::GetTextLineHeight();
    TabLayoutMetrics m;
    m.inner_pad_y = style.FramePadding.y * 1.8f;
    m.row_height = ImGui::GetFrameHeight() * 1.20f * 1.22f;
    m.row_advance = m.row_height;
    m.icon_size = std::max(text_line_height * 2.0f, m.row_height - m.inner_pad_y * 1.25f);
    m.text_spacing = std::max(style.ItemInnerSpacing.x, 8.0f * ui_scale);
    return m;
}

static ImDrawFlags GetTabCornerFlags(int tab_index) {
    if (kTabCount <= 1) {
        return ImDrawFlags_RoundCornersAll;
    }
    if (tab_index == 0) {
        return ImDrawFlags_RoundCornersTop;
    }
    if (tab_index == kTabCount - 1) {
        return ImDrawFlags_RoundCornersBottom;
    }
    return ImDrawFlags_RoundCornersNone;
}

static ImU32 g_tab_main_area_color = 0;

static ImVec4 GetTabInactiveTrackColor(Theme* theme, const ClickGUI::Settings* settings = nullptr) {
    (void)settings;
    if (post_processing.flags.blur) {
        if (theme && theme->IsLightMode()) {
            ImVec4 c = theme->HexToImVec4(theme->material.onSurfaceVariant);
            c.w = 0.12f;
            return c;
        }
        return ImVec4(1.0f, 1.0f, 1.0f, 0.050f);
    }
    if (g_tab_main_area_color != 0) {
        return ImGui::ColorConvertU32ToFloat4(g_tab_main_area_color);
    }
    if (theme) {
        return theme->HexToImVec4(theme->material.surfaceVariant);
    }
    return ImVec4(0.110f, 0.110f, 0.110f, 1.0f);
}

static ImVec4 ResolveTabForegroundColor(Theme* theme, const ImVec4& button_color, const ImVec4& fallback) {
    const float lum = button_color.x * 0.299f + button_color.y * 0.587f + button_color.z * 0.114f;
    const float effective_lum = lum * button_color.w + 0.09f * (1.0f - button_color.w);
    if ((theme && theme->IsLightMode()) || effective_lum > 0.58f) {
        return ImVec4(0.08f, 0.08f, 0.08f, fallback.w);
    }
    return fallback;
}

static void RefreshTabAtlasCache() {
    if (!images.Ready()) {
        return;
    }

    for (int i = 0; i < kTabCount; ++i) {
        g_tab_atlas_cache[i].uv = images.RegionForName(kTabs[i].icon);
        GLuint icon_tex = IsValidRegion(g_tab_atlas_cache[i].uv)
            ? images.TextureForRegion(g_tab_atlas_cache[i].uv)
            : 0;
        (void)icon_tex;
    }
}

static void PrepareTabsFrame(int& selectedTab, const ClickGUI::Settings* settings) {
    const int frame = ImGui::GetFrameCount();
    if (g_tabs_state.frame == frame) {
        return;
    }
    g_tabs_state.frame = frame;

    RefreshTabAtlasCache();

    g_tabs_state.dt = ImGui::GetIO().DeltaTime;
    if (g_tabs_state.dt <= 0.0f) g_tabs_state.dt = 1.0f / 60.0f;
    if (g_tabs_state.dt > 0.1f) g_tabs_state.dt = 0.1f;

    const float fallback_scale = (ImGui::GetIO().FontGlobalScale != 0.0f)
        ? (ImGui::GetIO().FontGlobalScale / 0.75f)
        : 1.0f;
    g_tabs_state.ui_scale = (settings && settings->gui) ? settings->gui->cache.uiScale : fallback_scale;
    g_tabs_state.left_inset = 22.0f * g_tabs_state.ui_scale;
    g_tabs_state.tab_switch_distance = 50.0f * g_tabs_state.ui_scale;
    static bool s_prev_menu_open = false;
    const bool menu_open = (settings && settings->gui) ? settings->gui->open : false;
    if (menu_open && !s_prev_menu_open) {
        g_tabs_state.settle_frames = 2;
    } else if (!menu_open) {
        g_tabs_state.settle_frames = 0;
    }
    g_tabs_state.just_opened = menu_open && (g_tabs_state.settle_frames > 0);
    if (menu_open && g_tabs_state.settle_frames > 0) {
        --g_tabs_state.settle_frames;
    }
    s_prev_menu_open = menu_open;

    g_tabs_state.block_tab_input = ComboPopupBlocksInput() || ColorPickerPopupBlocksInput() || IsLayoutInputCaptured();

    if (g_tabs_state.block_tab_input && tabAssignedTouchId != 0) {
        GetTouchSystem.MarkTouchUsed(tabAssignedTouchId, false);
        tabAssignedTouchId = 0;
        isDragging = false;
        wasDrag = false;
    }

    bool mouse_down = g_tabs_state.block_tab_input ? false : ImGui::IsMouseDown(ImGuiMouseButton_Left);
    bool mouse_released = g_tabs_state.block_tab_input ? false : ImGui::IsMouseReleased(ImGuiMouseButton_Left);
    ImVec2 mouse_pos = ImGui::GetMousePos();

    g_tabs_state.current_pos = mouse_pos;
    g_tabs_state.is_down = mouse_down;
    g_tabs_state.is_released = mouse_released;

    ImVector<ImGuiID> unused_touches;
    if (!g_tabs_state.block_tab_input) {
        GetTouchSystem.GetUnusedTouchIDs(unused_touches);
    }

    if (!g_tabs_state.block_tab_input && tabAssignedTouchId != 0 && GetTouchSystem.IsTouchActive(tabAssignedTouchId)) {
        g_tabs_state.current_pos = GetTouchSystem.GetTouchPosition(tabAssignedTouchId);
        TouchPhase touch_phase = GetTouchSystem.GetTouchPhase(tabAssignedTouchId);
        g_tabs_state.is_down = (touch_phase == TouchPhase_Began || touch_phase == TouchPhase_Moved || touch_phase == TouchPhase_Stationary);
        g_tabs_state.is_released = (touch_phase == TouchPhase_Ended || touch_phase == TouchPhase_Canceled);
    } else if (!g_tabs_state.block_tab_input && unused_touches.Size > 0) {
        ImGuiID new_touch_id = unused_touches[0];
        ImVec2 touch_pos = GetTouchSystem.GetTouchPosition(new_touch_id);
        TouchPhase touch_phase = GetTouchSystem.GetTouchPhase(new_touch_id);

        ImVec2 pos = ImGui::GetCursorScreenPos();
        const TabLayoutMetrics metrics = GetTabLayoutMetrics(g_tabs_state.ui_scale);
        const float tab_area_width = std::max(1.0f, ImGui::GetContentRegionAvail().x - g_tabs_state.left_inset);
        ImVec2 tab_area_min = pos;
        ImVec2 tab_area_max = ImVec2(
            pos.x + g_tabs_state.left_inset + tab_area_width,
            pos.y + metrics.row_advance * kTabCount
        );

        bool is_touch_in_tab_area = touch_pos.x >= tab_area_min.x && touch_pos.x <= tab_area_max.x &&
                                    touch_pos.y >= tab_area_min.y && touch_pos.y <= tab_area_max.y;

        bool touch_began = (touch_phase == TouchPhase_Began);
        bool touch_active = (touch_phase == TouchPhase_Began || touch_phase == TouchPhase_Moved || touch_phase == TouchPhase_Stationary);
        bool touch_ended = (touch_phase == TouchPhase_Ended || touch_phase == TouchPhase_Canceled);

        if (is_touch_in_tab_area && touch_began && !isDragging) {
            tabAssignedTouchId = new_touch_id;
            g_tabs_state.current_pos = touch_pos;
            GetTouchSystem.MarkTouchUsed(new_touch_id, true);
            g_tabs_state.is_down = touch_active;
            g_tabs_state.is_released = touch_ended;
        }
    }

    if (g_tabs_state.is_released) {
        wasDrag = false;
        isDragging = false;
        if (tabAssignedTouchId != 0) {
            GetTouchSystem.MarkTouchUsed(tabAssignedTouchId, false);
            tabAssignedTouchId = 0;
        }
    }

    if (isDragging && g_tabs_state.is_down) {
        float delta_y = g_tabs_state.current_pos.y - dragStartPos.y;
        if (fabsf(delta_y) > g_tabs_state.tab_switch_distance) {
            wasDrag = true;
            int target_tab = initialTab + (int)(delta_y / g_tabs_state.tab_switch_distance);
            target_tab = std::clamp(target_tab, 0, kTabCount - 1);
            if (target_tab != selectedTab) {
                selectedTab = target_tab;
                post_processing.glow_cache.needs_update = true;
            }
        }
    }
}

int TabsCount() {
    return kTabCount;
}

void SetTabMainAreaColor(ImU32 color) {
    g_tab_main_area_color = color;
}

ImU32 GetTabMainAreaColor() {
    return g_tab_main_area_color;
}

void Tabs(int& selectedTab, int tabIndex, const ClickGUI::Settings* settings)
{
    if (tabIndex < 0 || tabIndex >= kTabCount) {
        return;
    }

    PrepareTabsFrame(selectedTab, settings);

    const TabDef& tab = kTabs[tabIndex];
    const float dt = g_tabs_state.dt;
    const float ui_scale = g_tabs_state.ui_scale;
    const bool block_tab_input = g_tabs_state.block_tab_input;
    Theme* theme = (settings && settings->gui) ? settings->gui->theme.get() : nullptr;
    const float tabs_speed = (settings && settings->gui)
        ? std::clamp(settings->gui->animationTuning.tabsSpeed, 0.2f, 4.0f)
        : 1.0f;
    const float tabs_anim_duration = 0.9f / tabs_speed;

    ImVec2 base_cursor_pos = ImGui::GetCursorPos();
    ImVec2 base_cursor_screen = ImGui::GetCursorScreenPos();
    const float win_pad_x = ImGui::GetStyle().WindowPadding.x;
    // Ширина от края окна (как у таскбара: sidebar_content_left = cursor.x - WindowPadding.x)
    const float sidebar_content_left = base_cursor_screen.x - win_pad_x;
    const float sidebar_width = std::max(1.0f, ImGui::GetContentRegionAvail().x);
    const float pad_x = 22.0f * ui_scale;
    const float tab_x_screen = sidebar_content_left + pad_x;
    const float tabs_row_width = std::max(1.0f, sidebar_width - pad_x * 2.0f);
    const TabLayoutMetrics metrics = GetTabLayoutMetrics(ui_scale);

    ImVec2 label_size = ImGui::CalcTextSize(tab.name);

    // Позиционируем InvisibleButton через SetCursorScreenPos
    ImVec2 cursor_pos = base_cursor_pos;
    ImVec2 pos = ImVec2(tab_x_screen, base_cursor_screen.y);
    ImGui::SetCursorScreenPos(pos);
    ImVec2 tab_button_size = ImVec2(tabs_row_width, metrics.row_height);

    cursor_pos = ImGui::GetCursorPos();

    ImGui::SetCursorPos(cursor_pos);
    ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(0, 0));
    bool tab_pressed = (!block_tab_input) && ImGui::InvisibleButton(tab.button_id, tab_button_size);
    bool tab_hovered = (!block_tab_input) && ImGui::IsItemHovered();
    ImGui::PopStyleVar();
    const bool tab_active = (selectedTab == tabIndex);

    if (tab_pressed && !wasDrag) {
        selectedTab = tabIndex;
        post_processing.glow_cache.needs_update = true;
    }

    ImGui::SetCursorPos(cursor_pos);

    ImVec4 active_color = ImVec4(0.137f, 0.561f, 0.886f, 0.8f);
    ImVec4 inactive_color = ImGui::GetStyle().Colors[ImGuiCol_Text];
    inactive_color.w = 0.55f;

    if (settings && settings->gui && settings->gui->theme) {
        active_color = WidgetBase::PrimaryMidColor(settings->gui->theme.get());
        if (settings->gui->theme->IsLightMode()) {
            inactive_color = settings->gui->theme->HexToImVec4(settings->gui->theme->material.onSurfaceVariant);
            inactive_color.w = 0.88f;
        } else {
            inactive_color = ImGui::GetStyle().Colors[ImGuiCol_Text];
            inactive_color.w = 0.55f;
        }
    }

    ImVec4 tab_track_color_target = inactive_color;
    if (settings && settings->gui && settings->gui->theme) {
        if (tab_active) {
            tab_track_color_target = WidgetBase::PrimaryMidColor(settings->gui->theme.get());
        } else {
            tab_track_color_target = settings->gui->theme->IsLightMode()
                ? settings->gui->theme->HexToImVec4(settings->gui->theme->material.onSurfaceVariant)
                : GetTabInactiveTrackColor(settings->gui->theme.get(), settings);
            if (settings->gui->theme->IsLightMode()) {
                tab_track_color_target.w = 0.16f;
            }
        }
    } else {
        tab_track_color_target = tab_active ? ImVec4(0.294f, 0.412f, 0.996f, 0.6f) : ImVec4(1.0f, 1.0f, 1.0f, 0.050f);
    }
    if (tab_hovered && !tab_active) {
        tab_track_color_target.w = std::clamp(tab_track_color_target.w * 1.18f, 0.0f, 1.0f);
    }

    // Animate accent fill with smooth interpolation
    ImGuiID track_id = ImGui::GetID(tab.button_id);
    ImGuiID track_r_ch = ImGui::GetID("track_r");
    ImGuiID track_g_ch = ImGui::GetID("track_g");
    ImGuiID track_b_ch = ImGui::GetID("track_b");
    ImGuiID track_a_ch = ImGui::GetID("track_a");
    const iam_policy track_policy = g_tabs_state.just_opened ? iam_policy_cut : iam_policy_crossfade;
    ImVec4 tab_track_color;
    tab_track_color.x = iam_tween_float(track_id, track_r_ch, tab_track_color_target.x, tabs_anim_duration, iam_ease_preset(iam_ease_out_cubic), track_policy, dt);
    tab_track_color.y = iam_tween_float(track_id, track_g_ch, tab_track_color_target.y, tabs_anim_duration, iam_ease_preset(iam_ease_out_cubic), track_policy, dt);
    tab_track_color.z = iam_tween_float(track_id, track_b_ch, tab_track_color_target.z, tabs_anim_duration, iam_ease_preset(iam_ease_out_cubic), track_policy, dt);
    tab_track_color.w = iam_tween_float(track_id, track_a_ch, tab_track_color_target.w, tabs_anim_duration, iam_ease_preset(iam_ease_out_cubic), track_policy, dt);

    ImVec4 active_fg_color = ResolveTabForegroundColor(theme, tab_track_color, ImGui::GetStyle().Colors[ImGuiCol_Text]);

    ImDrawList* draw_list = ImGui::GetWindowDrawList();
    ImVec2 track_min = pos;
    ImVec2 track_max = ImVec2(pos.x + tab_button_size.x, pos.y + tab_button_size.y);
    const float track_rounding = std::max(0.0f, ImGui::GetStyle().FrameRounding);
    draw_list->AddRectFilled(
        track_min,
        track_max,
        ImGui::GetColorU32(tab_track_color),
        track_rounding,
        GetTabCornerFlags(tabIndex)
    );

    ImGuiID text_id = ImGui::GetID(tab.name);
    ImGuiID text_alpha_channel_id = ImGui::GetID("text_alpha");
    ImGuiID text_scale_channel_id = ImGui::GetID("text_scale");
    ImGuiID text_position_channel_id = ImGui::GetID("text_position");

    float target_text_alpha = (selectedTab == tabIndex) ? 0.8f : 0.75f;
    float current_text_alpha = iam_tween_float(text_id, text_alpha_channel_id, target_text_alpha, tabs_anim_duration,
        iam_ease_preset(iam_ease_out_cubic),
        g_tabs_state.just_opened ? iam_policy_cut : iam_policy_crossfade, dt);

    float target_text_scale = (selectedTab == tabIndex) ? 1.15f : 1.0f;
    float current_text_scale = iam_tween_float(text_id, text_scale_channel_id, target_text_scale, tabs_anim_duration,
        iam_ease_preset(iam_ease_out_cubic),
        g_tabs_state.just_opened ? iam_policy_cut : iam_policy_crossfade, dt);

    float target_text_position_offset = (selectedTab == tabIndex) ? (-1.0f * ui_scale) : 0.0f;
    float current_text_position_offset = iam_tween_float(text_id, text_position_channel_id, target_text_position_offset, tabs_anim_duration,
        iam_ease_preset(iam_ease_out_cubic),
        g_tabs_state.just_opened ? iam_policy_cut : iam_policy_crossfade, dt);

    float scaled_text_height = label_size.y * current_text_scale;
    float scaled_text_width = label_size.x * current_text_scale;
    const ImVec2 glyph_off = WidgetBase::ScaledGlyphOffset(ImGui::GetFont(), ImGui::GetFontSize() * current_text_scale);
    float text_x = pos.x + (tabs_row_width - scaled_text_width) * 0.5f;
    float text_y = pos.y + (metrics.row_height - scaled_text_height) * 0.5f - glyph_off.y + current_text_position_offset;

    ImGui::SetCursorScreenPos(ImVec2(text_x, text_y));

    ImVec4 inactive_text_color = inactive_color;
    ImVec4 active_text_color = active_fg_color;
    float inactive_late_blend = ImClamp((1.05f - current_text_scale) / 0.05f, 0.0f, 1.0f);
    ImVec4 final_text_color = (selectedTab == tabIndex)
        ? active_text_color
        : ImLerp(active_text_color, inactive_text_color, inactive_late_blend);
    final_text_color.w = (selectedTab == tabIndex) ? current_text_alpha : inactive_text_color.w;

    ImVec2 text_pos = ImGui::GetCursorScreenPos();
    ImFont* font = ImGui::GetFont();
    float font_size = ImGui::GetFontSize() * current_text_scale;

    if (post_processing.flags.glow) {
        const float glow_scale = 2.05f;
        const float glow_visible_h = std::max(1.0f, scaled_text_height * glow_scale);
        const float glow_h = glow_visible_h;
        float glow_w = std::max(1.0f, scaled_text_width + glow_visible_h * 1.0f);
        glow_w = std::max(glow_w, scaled_text_width * 0.99f);
        const float glow_y_shift = 3.25f * ui_scale;
        const ImVec2 glow_min(text_pos.x - (glow_w - scaled_text_width) * 0.5f,
                              text_pos.y - (glow_h - scaled_text_height) * 0.5f + glow_y_shift);
        const ImVec2 glow_max(glow_min.x + glow_w, glow_min.y + glow_h);
        const float inactive_alpha = 0.52f;
        const float active_alpha = 0.78f;
        const float glow_alpha = (selectedTab == tabIndex) ? active_alpha : inactive_alpha;
        ImVec4 glow_tint = (selectedTab == tabIndex)
            ? ImVec4(active_color.x, active_color.y, active_color.z, glow_alpha)
            : ImVec4(inactive_color.x, inactive_color.y, inactive_color.z, glow_alpha);
        draw_list->PushClipRectFullScreen();
        post_processing.DrawGlowTexture(draw_list, tab.glow_name, glow_min, glow_max, glow_tint, 1.0f);
        draw_list->PopClipRect();
    }

    const int text_vtx_start = draw_list->VtxBuffer.Size;
    draw_list->AddText(font, font_size, text_pos, ImGui::GetColorU32(final_text_color), tab.name);
    const int text_vtx_end = draw_list->VtxBuffer.Size;
    const bool use_active_accent_gradient = tab_active &&
        settings && settings->gui && settings->gui->theme &&
        active_text_color.x > 0.2f && active_text_color.y > 0.2f && active_text_color.z > 0.2f;
    if (use_active_accent_gradient && text_vtx_end > text_vtx_start) {
        WidgetBase::ShadeVertsAccent(
            draw_list, text_vtx_start, text_vtx_end,
            text_pos, ImVec2(text_pos.x + std::max(1.0f, scaled_text_width), text_pos.y),
            settings->gui->theme.get(),
            final_text_color.w
        );
    }

    if (!isDragging && tab_hovered && g_tabs_state.is_down && !g_tabs_state.is_released) {
        dragStartPos = g_tabs_state.current_pos;
        isDragging = true;
        initialTab = selectedTab;
        wasDrag = false;
    }

    ImGui::SetCursorScreenPos(ImVec2(base_cursor_screen.x, pos.y + metrics.row_advance));
    ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(0, 0));
    ImGui::Dummy(ImVec2(0, 0));
    ImGui::PopStyleVar();

    // Сепаратор между табами (как граница между кнопками модуля)
    if (tabIndex < kTabCount - 1) {
        const float join_overlap = std::max(1.0f, ImGui::GetStyle().FrameBorderSize);
        ImVec4 sep_col = GetTabInactiveTrackColor(theme, settings);
        sep_col.w = std::clamp(sep_col.w * 0.6f, 0.04f, 0.18f);
        draw_list->AddLine(
            ImVec2(track_min.x, track_max.y - join_overlap),
            ImVec2(track_max.x, track_max.y - join_overlap),
            ImGui::GetColorU32(sep_col), join_overlap
        );
    }
}

void Tabs(int& selectedTab, const ClickGUI::Settings* settings)
{
    for (int i = 0; i < kTabCount; ++i) {
        Tabs(selectedTab, i, settings);
    }
}
