#include "../wigdets.h"
#include "imgui/im_anim/im_anim.h"
#include <algorithm>

static ImVec4 ResolveDescriptionColor(Theme* theme) {
    return WidgetBase::DescriptionColor(theme);
}

static ImVec4 ResolveFillColor(Theme* theme) {
    return WidgetBase::PrimaryMidColor(theme);
}

static ImVec4 ResolveTrackColor(Theme* theme) {
    return WidgetBase::TrackColor(theme);
}

bool Checkbox(const char* label, const char* description, bool* value, Theme* theme) {
    return Checkbox(label, description, value, theme, nullptr);
}

bool Checkbox(const char* label, const char* description, bool* value, Theme* theme, bool* out_active) {
    if (!label || !value) {
        if (out_active) {
            *out_active = false;
        }
        return false;
    }

    ImDrawList* dl = ImGui::GetWindowDrawList();
    ImGuiStyle& style = ImGui::GetStyle();
    ImVec2 start = ImGui::GetCursorScreenPos();
    float full_w = ImGui::GetContentRegionAvail().x;
    if (full_w < 1.0f) {
        full_w = 1.0f;
    }

    float base = style.FontSizeBase;
    const float desc_offset = std::max(1.0f, style.ItemInnerSpacing.y * 0.55f);
    ImVec2 label_size = ImGui::CalcTextSize(label);
    float desc_height = 0.0f;
    float desc_width = 0.0f;
    if (description && description[0] != '\0') {
        ImGui::PushFont(nullptr, base * 0.85f);
        ImVec2 desc_size = ImGui::CalcTextSize(description);
        ImGui::PopFont();
        desc_height = desc_size.y + desc_offset;
        desc_width = desc_size.x;
    }

    float row_h = label_size.y + desc_height;
    float check_size = ImGui::GetFrameHeight() * 1.20f * 1.22f;
    if (row_h < check_size) {
        row_h = check_size;
    }

    ImGui::PushID(label);
    ImGui::Dummy(ImVec2(full_w, row_h));

    dl->AddText(start, ImGui::GetColorU32(style.Colors[ImGuiCol_Text]), label);

    if (description && description[0] != '\0') {
        ImVec4 descColor = ResolveDescriptionColor(theme);
        ImGui::PushFont(nullptr, base * 0.85f);
        dl->AddText(ImVec2(start.x, start.y + label_size.y + desc_offset),
                    ImGui::GetColorU32(descColor), description);
        ImGui::PopFont();
    }

    float checkbox_x = start.x + full_w - check_size;
    float checkbox_y = start.y + (row_h - check_size) * 0.5f;
    ImVec2 box_min = ImVec2(checkbox_x, checkbox_y);
    ImVec2 box_max = ImVec2(checkbox_x + check_size, checkbox_y + check_size);

    float text_w = std::max(label_size.x, desc_width);
    float text_h = label_size.y + desc_height;
    if (text_w < 1.0f) {
        text_w = 1.0f;
    }
    if (text_h < 1.0f) {
        text_h = 1.0f;
    }

    ImGui::SetCursorScreenPos(start);
    bool text_clicked = ImGui::InvisibleButton("##checkbox_text_btn", ImVec2(text_w, text_h));
    bool text_active = ImGui::IsItemActive();

    ImGui::SetCursorScreenPos(box_min);
    bool box_clicked = ImGui::InvisibleButton("##checkbox_btn", ImVec2(check_size, check_size));
    bool box_active = ImGui::IsItemActive();

    bool changed = (text_clicked || box_clicked);
    if (changed) {
        *value = !*value;
    }
    ImGuiID id = ImGui::GetItemID();

    ImVec4 track = ResolveTrackColor(theme);
    ImVec4 fill = ResolveFillColor(theme);
    float on_t = iam_tween_float(id, ImHashStr("check_on"), *value ? 1.0f : 0.0f,
                                 0.22f, iam_ease_preset(iam_ease_out_cubic),
                                 iam_policy_crossfade, ImGui::GetIO().DeltaTime);
    ImVec4 mixed = ImVec4(
        track.x + (fill.x - track.x) * on_t,
        track.y + (fill.y - track.y) * on_t,
        track.z + (fill.z - track.z) * on_t,
        track.w + (fill.w - track.w) * on_t
    );
    const float box_w = std::max(1.0f, box_max.x - box_min.x);
    const float box_h = std::max(1.0f, box_max.y - box_min.y);
    const float rr = std::min(style.FrameRounding, std::min(box_w, box_h) * 0.5f);
    dl->AddRectFilled(box_min, box_max, ImGui::GetColorU32(mixed), rr);

    if (out_active) {
        *out_active = (text_active || box_active);
    }
    ImGui::PopID();

    return changed;
}
