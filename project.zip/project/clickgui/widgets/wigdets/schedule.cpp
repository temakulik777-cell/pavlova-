#include "../wigdets.h"
#include <algorithm>
#include <cmath>
#include <unordered_map>
#include <vector>

bool CurveGraph(const char* label, const char* description, float* values, int count,
                const char* const names[], const float* mins, const float* maxs, Theme* theme) {
    return CurveGraph(label, description, values, count, names, mins, maxs, theme, nullptr);
}

bool CurveGraph(const char* label, const char* description, float* values, int count,
                const char* const names[], const float* mins, const float* maxs, Theme* theme,
                bool* out_active) {
    if (!label || !values || count < 2) {
        if (out_active) *out_active = false;
        return false;
    }

    ImDrawList* dl = ImGui::GetWindowDrawList();
    ImGuiStyle& style = ImGui::GetStyle();
    ImVec2 start = ImGui::GetCursorScreenPos();
    float full_w = std::max(1.0f, ImGui::GetContentRegionAvail().x);
    float ui_scale = WidgetActivity::WidgetUiScale();

    const float desc_font = style.FontSizeBase * 0.85f;
    ImVec2 label_size = ImGui::CalcTextSize(label);
    float desc_h = 0.0f;
    const float desc_wrap_w = std::max(20.0f, full_w);
    float desc_font_effective = desc_font;
    if (description && description[0] != '\0') {
        ImGui::PushFont(nullptr, desc_font);
        desc_font_effective = ImGui::GetFontSize();
        float measured_h = WidgetBase::CalcWrappedTextHeight(description, desc_font_effective, desc_wrap_w);
        desc_h = std::max(measured_h, desc_font_effective);
        ImGui::PopFont();
    }
    desc_h = std::max(desc_h, desc_font);
    const float graph_h = 110.0f * ui_scale;
    const float label_desc_gap = std::max(8.0f, style.ItemSpacing.y) * 0.55f;
    const float desc_widget_gap = label_desc_gap + ImGui::GetStyle().FontSizeBase * 0.25f;
    const float label_bottom = start.y + label_size.y;
    const float desc_y = label_bottom + (desc_h > 0.0f ? label_desc_gap : 0.0f);
    const float desc_draw_y = desc_y;
    const float desc_bottom = desc_y + desc_h;
    const float graph_top = (desc_h > 0.0f)
        ? (desc_bottom + desc_widget_gap)
        : (label_bottom + desc_widget_gap);
    const ImVec2 gmin(start.x, graph_top);
    const ImVec2 gmax(start.x + full_w, graph_top + graph_h);
    const float pad = 14.0f * ui_scale;
    const float xlabels_h = ImGui::GetFontSize() + 2.0f * ui_scale;
    const ImVec2 pmin(gmin.x + pad, gmin.y + pad);
    const ImVec2 pmax(gmax.x - pad, gmax.y - pad);

    float total_h = (gmax.y - start.y) + xlabels_h;
    ImGui::Dummy(ImVec2(full_w, total_h));
    ImVec2 layout_end = ImGui::GetCursorScreenPos();
    dl->AddText(start, ImGui::GetColorU32(style.Colors[ImGuiCol_Text]), label);
    if (description && description[0] != '\0') {
        ImGui::PushFont(nullptr, desc_font);
        dl->AddText(ImGui::GetFont(), ImGui::GetFontSize(), ImVec2(start.x, desc_draw_y),
                    ImGui::GetColorU32(WidgetBase::DescriptionColor(theme)), description, nullptr, desc_wrap_w);
        ImGui::PopFont();
    }

    ImVec4 track = WidgetBase::TrackColor(theme);
    ImVec4 primary = WidgetBase::PrimaryColor(theme);
    WidgetBase::AccentGradient primary_grad = WidgetBase::PrimaryGradient(theme);
    primary.w = post_processing.flags.blur ? 0.70f : 0.82f;
    dl->AddRectFilled(gmin, gmax, ImGui::GetColorU32(track), style.FrameRounding);
    {
        ImU32 grid_col = ImGui::GetColorU32(ImVec4(1.0f, 1.0f, 1.0f, post_processing.flags.blur ? 0.04f : 0.06f));
        float gh = std::max(1.0f, gmax.y - gmin.y);
        float gw = std::max(1.0f, gmax.x - gmin.x);
        float cell = gh / 4.0f;
        if (cell < 6.0f) {
            cell = 6.0f;
        }

        for (float y = gmin.y + cell; y < gmax.y - 0.5f; y += cell) {
            dl->AddLine(ImVec2(gmin.x, y), ImVec2(gmax.x, y), grid_col, 1.0f);
        }
        for (float x = gmin.x + cell; x < gmax.x - 0.5f; x += cell) {
            dl->AddLine(ImVec2(x, gmin.y), ImVec2(x, gmax.y), grid_col, 1.0f);
        }
    }

    bool changed = false;
    bool active_any = false;
    std::vector<ImVec2> points;
    points.reserve((size_t)count);

    static std::unordered_map<ImGuiID, int> s_active_point;
    static std::unordered_map<ImGuiID, std::vector<float>> s_display_t;
    ImGuiID graph_id = ImGui::GetID(label);
    int& active_point = s_active_point[graph_id];
    if (!ImGui::GetIO().MouseDown[0]) {
        active_point = -1;
    }
    std::vector<float>& display_t = s_display_t[graph_id];
    if ((int)display_t.size() != count) {
        display_t.assign((size_t)count, 0.0f);
    }
    float dt = ImGui::GetIO().DeltaTime;
    if (dt <= 0.0f) dt = 1.0f / 60.0f;
    if (dt > 0.1f) dt = 0.1f;

    ImGui::PushID(label);
    for (int i = 0; i < count; ++i) {
        float min_v = mins ? mins[i] : 0.0f;
        float max_v = maxs ? maxs[i] : 1.0f;
        float target_t = WidgetBase::ClampNorm(values[i], min_v, max_v);
        float x = pmin.x + ((float)i / (float)(count - 1)) * (pmax.x - pmin.x);
        float y_for_hit = pmax.y - display_t[(size_t)i] * (pmax.y - pmin.y);

        ImVec2 hit_min(x - 22.0f * ui_scale, y_for_hit - 22.0f * ui_scale);
        ImVec2 hit_max(x + 22.0f * ui_scale, y_for_hit + 22.0f * ui_scale);
        ImGui::SetCursorScreenPos(hit_min);
        ImGui::InvisibleButton(("##curve_pt_" + std::to_string(i)).c_str(), ImVec2(hit_max.x - hit_min.x, hit_max.y - hit_min.y));
        bool pt_active = ImGui::IsItemActive();
        if (pt_active) {
            active_point = i;
        }
        if (active_point == i && ImGui::GetIO().MouseDown[0]) {
            pt_active = true;
        }
        active_any = active_any || pt_active || (active_point >= 0 && ImGui::GetIO().MouseDown[0]);
        if (pt_active && ImGui::GetIO().MouseDown[0]) {
            float tt = (pmax.y - ImGui::GetIO().MousePos.y) / std::max(1.0f, (pmax.y - pmin.y));
            float nv = WidgetBase::Unnorm(tt, min_v, max_v);
            if (std::fabs(values[i] - nv) > 0.0001f) {
                values[i] = nv;
                changed = true;
            }
            target_t = WidgetBase::ClampNorm(values[i], min_v, max_v);
        }

        if (active_point == i && ImGui::GetIO().MouseDown[0]) {
            display_t[(size_t)i] = target_t;
        } else {
            const float smooth_k = 1.0f - std::exp(-12.0f * dt);
            display_t[(size_t)i] = display_t[(size_t)i] + (target_t - display_t[(size_t)i]) * smooth_k;
        }

        float y = pmax.y - display_t[(size_t)i] * (pmax.y - pmin.y);
        points.emplace_back(x, y);
    }
    ImGui::PopID();

    if (points.size() >= 2) {
        std::vector<ImVec2> smooth;
        smooth.reserve(points.size() * 10);
        for (int i = 0; i < (int)points.size() - 1; ++i) {
            const ImVec2 p0 = points[i];
            const ImVec2 p1 = points[i + 1];
            const float dx = p1.x - p0.x;
            const ImVec2 c0(p0.x + dx * 0.35f, p0.y);
            const ImVec2 c1(p1.x - dx * 0.35f, p1.y);
            const int seg = 18;
            for (int s = 0; s <= seg; ++s) {
                float t = (float)s / (float)seg;
                float u = 1.0f - t;
                ImVec2 q(
                    u * u * u * p0.x + 3.0f * u * u * t * c0.x + 3.0f * u * t * t * c1.x + t * t * t * p1.x,
                    u * u * u * p0.y + 3.0f * u * u * t * c0.y + 3.0f * u * t * t * c1.y + t * t * t * p1.y
                );
                smooth.push_back(q);
            }
        }
        if (post_processing.flags.glow) {
            const float glow_base_alpha = post_processing.flags.blur ? 0.070f : 0.085f;
            for (int layer = 0; layer < 3; ++layer) {
                const float t = (float)layer / 2.0f;
                const float a = glow_base_alpha * (1.0f - t * t);
                const float w = (6.0f - layer * 1.6f) * ui_scale;
                ImVec4 gc(primary.x, primary.y, primary.z, a);
                dl->AddPolyline(smooth.data(), (int)smooth.size(), ImGui::GetColorU32(gc), 0, w);
            }
        }
        if (primary_grad.gradient) {
            for (int i = 0; i < (int)smooth.size() - 1; ++i) {
                const float t0 = (smooth[i].x - pmin.x) / std::max(1.0f, pmax.x - pmin.x);
                const float t1 = (smooth[i + 1].x - pmin.x) / std::max(1.0f, pmax.x - pmin.x);
                const float tm = std::clamp((t0 + t1) * 0.5f, 0.0f, 1.0f);
                ImVec4 cm = ImLerp(primary_grad.start, primary_grad.end, tm);
                cm.w = primary.w;
                dl->AddLine(smooth[i], smooth[i + 1], ImGui::GetColorU32(cm), 2.0f * ui_scale);
            }
        } else {
            dl->AddPolyline(smooth.data(), (int)smooth.size(), ImGui::GetColorU32(primary), 0, 2.0f * ui_scale);
        }
    }

    for (int i = 0; i < (int)points.size(); ++i) {
        if (post_processing.flags.glow) {
            const ImVec4 glow_col(primary.x, primary.y, primary.z, post_processing.flags.blur ? 0.07f : 0.10f);
            dl->AddCircleFilled(points[i], 10.0f * ui_scale, ImGui::GetColorU32(glow_col));
            dl->AddCircleFilled(points[i], 8.0f * ui_scale, ImGui::GetColorU32(ImVec4(glow_col.x, glow_col.y, glow_col.z, glow_col.w * 0.75f)));
        }
        if (primary_grad.gradient) {
            const float t = (points[i].x - pmin.x) / std::max(1.0f, pmax.x - pmin.x);
            ImVec4 pc = ImLerp(primary_grad.start, primary_grad.end, std::clamp(t, 0.0f, 1.0f));
            pc.w = 0.95f;
            dl->AddCircleFilled(points[i], 5.0f * ui_scale, ImGui::GetColorU32(pc));
        } else {
            dl->AddCircleFilled(points[i], 5.0f * ui_scale, ImGui::GetColorU32(ImVec4(primary.x, primary.y, primary.z, 0.95f)));
        }
        if (names && names[i] && names[i][0] != '\0') {
            ImVec2 ts = ImGui::CalcTextSize(names[i]);
            float tx = points[i].x - ts.x * 0.5f;
            tx = std::clamp(tx, gmin.x + 2.0f * ui_scale, gmax.x - ts.x - 2.0f * ui_scale);
            float ty = gmax.y + (xlabels_h - ts.y) * 0.5f;
            dl->AddText(ImVec2(tx, ty), ImGui::GetColorU32(WidgetBase::DescriptionColor(theme)), names[i]);
        }
    }

    if (out_active) {
        *out_active = active_any;
    }
    ImGui::SetCursorScreenPos(layout_end);
    return changed;
}
