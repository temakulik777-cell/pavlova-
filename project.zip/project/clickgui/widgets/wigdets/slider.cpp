#include "../wigdets.h"
#include <algorithm>
#include <cfloat>
#include <cmath>

static ImVec4 ResolveFillColor(Theme* theme) {
    return WidgetBase::PrimaryMidColor(theme);
}

static ImVec4 ResolveTrackColor(Theme* theme) {
    return WidgetBase::TrackColor(theme);
}

static ImVec4 LerpVec4(const ImVec4& a, const ImVec4& b, float t) {
    return ImVec4(
        a.x + (b.x - a.x) * t,
        a.y + (b.y - a.y) * t,
        a.z + (b.z - a.z) * t,
        a.w + (b.w - a.w) * t
    );
}

static float Luma(const ImVec4& c) {
    return c.x * 0.299f + c.y * 0.587f + c.z * 0.114f;
}

static bool SliderCore(const char* label, const char* description,
                                 float* value, float min, float max, Theme* theme,
                                 const char* value_format, bool* out_active) {
    if (!label || !value) {
        if (out_active) {
            *out_active = false;
        }
        return false;
    }

    ImDrawList* dl = ImGui::GetWindowDrawList();
    ImVec2 start = ImGui::GetCursorScreenPos();
    float full_w = ImGui::GetContentRegionAvail().x;
    const ImGuiStyle& style = ImGui::GetStyle();
    if (full_w <= 0.0f) {
        full_w = 1.0f;
    }

    const float label_desc_gap = std::max(8.0f, style.ItemSpacing.y) * 0.55f;
    const float desc_widget_gap = label_desc_gap + ImGui::GetStyle().FontSizeBase * 0.25f;
    const float label_widget_gap = std::max(1.0f, style.ItemInnerSpacing.y * 0.60f);
    ImVec2 label_size = ImGui::CalcTextSize(label);
    float desc_h = 0.0f;
    float desc_w = 0.0f;
    float desc_font = ImGui::GetStyle().FontSizeBase * 0.85f;
    const float desc_wrap_w = std::max(20.0f, full_w);
    float desc_font_effective = desc_font;

    if (description && description[0] != '\0') {
        ImGui::PushFont(nullptr, desc_font);
        desc_font_effective = ImGui::GetFontSize();
        ImFont* font = ImGui::GetFont();
        if (font) {
            ImVec2 dsz_unwrapped = font->CalcTextSizeA(desc_font_effective, FLT_MAX, 0.0f, description, nullptr, nullptr);
            desc_w = dsz_unwrapped.x;
        }
        float measured_h = WidgetBase::CalcWrappedTextHeight(description, desc_font_effective, desc_wrap_w);
        desc_h = std::max(measured_h, desc_font_effective);
        ImGui::PopFont();
    }
    desc_h = std::max(desc_h, desc_font); // always reserve desc height like module

    float slider_height = ImGui::GetFrameHeight() * 1.20f * 1.22f;
    float label_bottom = start.y + label_size.y;
    float desc_y = label_bottom + (desc_h > 0.0f ? label_desc_gap : 0.0f);
    float desc_draw_y = desc_y;
    float desc_bottom = desc_y + desc_h;
    float slider_y = (desc_h > 0.0f)
        ? (desc_bottom + desc_widget_gap)
        : (label_bottom + desc_widget_gap);

    float total_h = (slider_y - start.y) + slider_height;
    if (total_h < slider_height) {
        total_h = slider_height;
    }
    // Inter-widget spacing is handled by WidgetManager::AddItemSpacing().
    // Keep slider block height tight to avoid larger gaps than checkbox widgets.
    total_h += 0.0f;

    ImGui::Dummy(ImVec2(full_w, total_h));
    ImVec2 layout_end = ImGui::GetCursorScreenPos();
    dl->AddText(start, ImGui::GetColorU32(ImGui::GetStyle().Colors[ImGuiCol_Text]), label);
    if (description && description[0] != '\0') {
        ImVec4 descColor = WidgetBase::DescriptionColor(theme);
        ImGui::PushFont(nullptr, desc_font);
        dl->AddText(ImGui::GetFont(), ImGui::GetFontSize(), ImVec2(start.x, desc_draw_y),
                    ImGui::GetColorU32(descColor), description, nullptr, desc_wrap_w);
        ImGui::PopFont();
    }

    ImVec2 slider_pos(start.x, slider_y);
    float slider_width = full_w;

    ImGui::PushID(label);
    float text_w = std::max(label_size.x, desc_w);
    float text_h = std::max(slider_y - start.y, 1.0f);
    bool text_clicked = false;
    bool text_active = false;
    if (text_w > 0.0f) {
        ImGui::SetCursorScreenPos(start);
        text_clicked = ImGui::InvisibleButton("##slider_text_btn", ImVec2(text_w, text_h));
        text_active = ImGui::IsItemActive();
    }

    ImGui::SetCursorScreenPos(slider_pos);
    ImGui::InvisibleButton("##slider", ImVec2(slider_width, slider_height));
    bool changed = false;
    bool slider_active = ImGui::IsItemActive();
    if (out_active) {
        *out_active = (text_active || slider_active);
    }

    if (text_clicked || (slider_active && ImGui::GetIO().MouseDown[0])) {
        float t = (ImGui::GetIO().MousePos.x - slider_pos.x) / slider_width;
        t = std::clamp(t, 0.0f, 1.0f);
        float new_value = min + (max - min) * t;
        if (new_value != *value) {
            *value = new_value;
            changed = true;
        }
    }

    float t = (*value - min) / (max - min);
    t = std::clamp(t, 0.0f, 1.0f);

    ImVec2 slider_min = slider_pos;
    ImVec2 slider_max = ImVec2(slider_pos.x + slider_width, slider_pos.y + slider_height);

    ImVec4 track = ResolveTrackColor(theme);
    ImVec4 fill = ResolveFillColor(theme);
    const float rr_full = std::min(std::max(0.0f, style.FrameRounding), slider_height * 0.5f);

    dl->AddRectFilled(slider_min, slider_max, ImGui::GetColorU32(track), rr_full);

    ImVec2 fill_max = ImVec2(slider_min.x + slider_width * t, slider_max.y);
    const float fill_w_px = std::max(0.0f, fill_max.x - slider_min.x);
    if (fill_w_px > 1.0f) {
        const float fill_rounding = std::min(rr_full, fill_w_px * 0.5f);
        dl->AddRectFilled(slider_min, fill_max, ImGui::GetColorU32(fill), fill_rounding, ImDrawFlags_RoundCornersAll);
    }

    char value_buf[64];
    if (!value_format) {
        value_format = "%.2f";
    }
    snprintf(value_buf, sizeof(value_buf), value_format, *value);

    ImVec2 text_size = ImGui::GetFont()->CalcTextSizeA(ImGui::GetFontSize(), FLT_MAX, 0.0f, value_buf, nullptr, nullptr);
    ImVec2 glyph_off = WidgetBase::ScaledGlyphOffset(ImGui::GetFont(), ImGui::GetFontSize());
    float padding_x = (slider_height - text_size.y) * 0.5f;
    padding_x = std::max(6.0f, padding_x);
    float text_x = slider_max.x - padding_x - text_size.x;
    float text_y = slider_min.y + (slider_height - text_size.y) * 0.5f - glyph_off.y;
    const ImVec4 base_text_col = ImGui::GetStyle().Colors[ImGuiCol_Text];
    const ImVec4 dark_text_col = ImVec4(0.08f, 0.08f, 0.08f, base_text_col.w);
    const float slider_mid_y = (slider_min.y + slider_max.y) * 0.5f;
    const float fill_w = std::max(1.0f, fill_max.x - slider_min.x);
    const bool has_active_fill = fill_max.x > slider_min.x + 0.5f;

    const char* p = value_buf;
    float pen_x = text_x;
    while (*p) {
        unsigned int cp = 0;
        const int adv = ImTextCharFromUtf8(&cp, p, nullptr);
        if (adv <= 0) {
            break;
        }
        const char* next = p + adv;
        ImVec2 gsz = ImGui::GetFont()->CalcTextSizeA(ImGui::GetFontSize(), FLT_MAX, 0.0f, p, next, nullptr);
        const float char_center_x = pen_x + gsz.x * 0.5f;

        ImVec4 draw_col = base_text_col;
        if (has_active_fill && char_center_x <= fill_max.x) {
            ImVec4 bg_col = fill;
            if (Luma(bg_col) > 0.60f) {
                draw_col = dark_text_col;
            }
        }

        dl->AddText(ImVec2(pen_x, text_y), ImGui::GetColorU32(draw_col), p, next);
        pen_x += gsz.x;
        p = next;
    }

    ImGui::SetCursorScreenPos(layout_end);
    ImGui::PopID();
    return changed;
}

bool SliderFloat(const char* label, const char* description, float* value, float min, float max, Theme* theme) {
    return SliderCore(label, description, value, min, max, theme, "%.2f", nullptr);
}

bool SliderFloat(const char* label, const char* description, float* value, float min, float max, Theme* theme, bool* out_active) {
    return SliderCore(label, description, value, min, max, theme, "%.2f", out_active);
}

bool SliderInt(const char* label, const char* description, int* value, int min, int max, Theme* theme) {
    return SliderInt(label, description, value, min, max, theme, nullptr);
}

bool SliderInt(const char* label, const char* description, int* value, int min, int max, Theme* theme, bool* out_active) {
    if (!value) {
        if (out_active) {
            *out_active = false;
        }
        return false;
    }
    float tmp = static_cast<float>(*value);
    bool changed = SliderCore(label, description, &tmp,
                                        static_cast<float>(min), static_cast<float>(max),
                                        theme, "%.0f", out_active);
    if (changed) {
        *value = static_cast<int>(std::round(tmp));
    }
    return changed;
}
