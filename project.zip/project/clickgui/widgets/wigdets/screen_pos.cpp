#include "../wigdets.h"
#include <algorithm>
#include <cmath>
#include <cfloat>
#include <cstring>
#include <unordered_map>
#include <vector>

namespace {
enum class PreviewWidgetKind {
    Unknown,
    Watermark,
    SpeedGraph,
    MovementRecorder
};

struct PreviewSlot {
    const float* norm_x = nullptr;
    const float* norm_y = nullptr;
    float visible_width_norm = 0.0f;
    float visible_height_norm = 0.0f;
    float expanded_width_norm = 0.0f;
    PreviewWidgetKind kind = PreviewWidgetKind::Unknown;
};

struct PreviewRect {
    ImVec2 visible_min = ImVec2(0.0f, 0.0f);
    ImVec2 visible_max = ImVec2(0.0f, 0.0f);
    ImVec2 expanded_min = ImVec2(0.0f, 0.0f);
    ImVec2 expanded_max = ImVec2(0.0f, 0.0f);
};

struct AxisCandidate {
    float value = 0.0f;
    float cost = 0.0f;
    bool snapped = false;
};

struct LayoutGapMemory {
    float horizontal_gap_norm = 0.0f;
    float vertical_gap_norm = 0.0f;
    bool has_horizontal_gap = false;
    bool has_vertical_gap = false;
};

struct AnimatedPreviewRect {
    PreviewRect rect;
    bool initialized = false;
};

static PreviewRect BuildPreviewRect(const ImVec2& pmin, const ImVec2& pmax,
                                    float norm_x, float norm_y,
                                    float object_width_norm, float object_height_norm,
                                    float expanded_width_norm) {
    PreviewRect out;
    const float preview_w = std::max(1.0f, pmax.x - pmin.x);
    const float preview_h = std::max(1.0f, pmax.y - pmin.y);
    const float visible_w = preview_w * std::clamp(object_width_norm, 0.05f, 0.95f);
    const float visible_h = preview_h * std::clamp(object_height_norm, 0.03f, 0.60f);
    const bool has_distinct_expanded = (expanded_width_norm - object_width_norm) > 0.0025f;
    const float ext_w = has_distinct_expanded
        ? std::min(preview_w, preview_w * std::clamp(expanded_width_norm, object_width_norm, 0.98f))
        : visible_w;
    const float ext_h = has_distinct_expanded
        ? std::min(preview_h, visible_h * 1.08f)
        : visible_h;
    const float max_vis_y = std::max(0.0f, preview_h - visible_h);
    const float vis_y = pmin.y + std::clamp(std::clamp(norm_y, 0.0f, 1.0f) * max_vis_y, 0.0f, max_vis_y);

    const float max_ext_x = std::max(0.0f, preview_w - ext_w);
    const float ext_x = pmin.x + std::clamp(std::clamp(norm_x, 0.0f, 1.0f) * max_ext_x, 0.0f, max_ext_x);
    const float vis_x = ext_x;

    const float ext_y = has_distinct_expanded ? (vis_y - (ext_h - visible_h) * 0.5f) : vis_y;
    out.visible_min = ImVec2(vis_x, vis_y);
    out.visible_max = ImVec2(vis_x + visible_w, vis_y + visible_h);
    out.expanded_min = ImVec2(ext_x, ext_y);
    out.expanded_max = ImVec2(ext_x + ext_w, ext_y + ext_h);
    return out;
}

static bool RectsOverlap(const ImVec2& a_min, const ImVec2& a_max, const ImVec2& b_min, const ImVec2& b_max) {
    return a_min.x < b_max.x && a_max.x > b_min.x && a_min.y < b_max.y && a_max.y > b_min.y;
}

static bool RangesOverlap(float a0, float a1, float b0, float b1, float pad = 0.0f) {
    return (a0 < b1 - pad) && (a1 > b0 + pad);
}

static float RectWidth(const PreviewRect& rect) {
    return rect.visible_max.x - rect.visible_min.x;
}

static float RectHeight(const PreviewRect& rect) {
    return rect.visible_max.y - rect.visible_min.y;
}

static bool HasCloseValue(const std::vector<AxisCandidate>& values, float v, float eps) {
    for (const AxisCandidate& c : values) {
        if (std::fabs(c.value - v) <= eps) {
            return true;
        }
    }
    return false;
}

static ImVec2 LerpVec2(const ImVec2& a, const ImVec2& b, float t) {
    return ImVec2(ImLerp(a.x, b.x, t), ImLerp(a.y, b.y, t));
}

static PreviewRect LerpPreviewRect(const PreviewRect& a, const PreviewRect& b, float t) {
    PreviewRect out;
    out.visible_min = LerpVec2(a.visible_min, b.visible_min, t);
    out.visible_max = LerpVec2(a.visible_max, b.visible_max, t);
    out.expanded_min = LerpVec2(a.expanded_min, b.expanded_min, t);
    out.expanded_max = LerpVec2(a.expanded_max, b.expanded_max, t);
    return out;
}

static PreviewWidgetKind DetectPreviewWidgetKind(const char* label,
                                                 const char* description,
                                                 const float* norm_x,
                                                 const ClickGUI& gui) {
    if (norm_x == &gui.watermarkNormX) {
        return PreviewWidgetKind::Watermark;
    }
    if (norm_x == &gui.speedGraphNormX) {
        return PreviewWidgetKind::SpeedGraph;
    }
    if (norm_x == &gui.movementRecorderNormX) {
        return PreviewWidgetKind::MovementRecorder;
    }
    if (label) {
        if (std::strcmp(label, "Overlay Position") == 0) {
            return PreviewWidgetKind::MovementRecorder;
        }
        if (std::strcmp(label, "Position") == 0 && description) {
            if (std::strstr(description, "graph") != nullptr) {
                return PreviewWidgetKind::SpeedGraph;
            }
            if (std::strstr(description, "screen grid") != nullptr) {
                return PreviewWidgetKind::Watermark;
            }
        }
    }
    if (description) {
        if (std::strcmp(description, "Move recorder overlay by screen grid") == 0) {
            return PreviewWidgetKind::MovementRecorder;
        }
        if (std::strcmp(description, "Move graph by screen grid") == 0) {
            return PreviewWidgetKind::SpeedGraph;
        }
        if (std::strcmp(description, "Move by screen grid") == 0) {
            return PreviewWidgetKind::Watermark;
        }
    }
    return PreviewWidgetKind::Unknown;
}

static std::vector<PreviewSlot> CollectOtherPreviewSlots(PreviewWidgetKind current_kind) {
    const ClickGUI& gui = ClickGUI::Get();
    std::vector<PreviewSlot> slots;
    auto add_slot = [&](PreviewWidgetKind kind, const float* nx, const float* ny, float vw, float vh, float ew) {
        if (!nx || !ny || kind == current_kind) {
            return;
        }
        slots.push_back(PreviewSlot{nx, ny, vw, vh, ew, kind});
    };
    add_slot(PreviewWidgetKind::Watermark, &gui.watermarkNormX, &gui.watermarkNormY,
             gui.watermarkVisibleWidthNorm, gui.watermarkVisibleHeightNorm, gui.watermarkExpandedWidthNorm);
    add_slot(PreviewWidgetKind::SpeedGraph, &gui.speedGraphNormX, &gui.speedGraphNormY,
             gui.speedGraphVisibleWidthNorm, gui.speedGraphVisibleHeightNorm, gui.speedGraphExpandedWidthNorm);
    add_slot(PreviewWidgetKind::MovementRecorder, &gui.movementRecorderNormX, &gui.movementRecorderNormY,
             gui.movementRecorderVisibleWidthNorm, gui.movementRecorderVisibleHeightNorm, gui.movementRecorderExpandedWidthNorm);
    return slots;
}
}

bool ScreenPositionGrid(const char* label, const char* description,
                        float* norm_x, float* norm_y,
                        float screen_aspect, float object_width_norm, float object_height_norm, float expanded_width_norm,
                        Theme* theme) {
    return ScreenPositionGrid(
        label, description, norm_x, norm_y,
        screen_aspect, object_width_norm, object_height_norm, expanded_width_norm, theme, nullptr
    );
}

bool ScreenPositionGrid(const char* label, const char* description,
                        float* norm_x, float* norm_y,
                        float screen_aspect, float object_width_norm, float object_height_norm, float expanded_width_norm,
                        Theme* theme, bool* out_active) {
    if (!label || !norm_x || !norm_y) {
        if (out_active) *out_active = false;
        return false;
    }

    ImDrawList* dl = ImGui::GetWindowDrawList();
    ImGuiStyle& style = ImGui::GetStyle();
    const ImVec2 start = ImGui::GetCursorScreenPos();
    const float full_w = std::max(1.0f, ImGui::GetContentRegionAvail().x);
    const float ui_scale = WidgetActivity::WidgetUiScale();

    const float desc_font = style.FontSizeBase * 0.85f;
    const ImVec2 label_size = ImGui::CalcTextSize(label);
    const float desc_wrap_w = std::max(20.0f, full_w);
    float desc_h = 0.0f;
    float desc_font_effective = desc_font;
    if (description && description[0] != '\0') {
        ImGui::PushFont(nullptr, desc_font);
        desc_font_effective = ImGui::GetFontSize();
        const float measured_h = WidgetBase::CalcWrappedTextHeight(description, desc_font_effective, desc_wrap_w);
        desc_h = std::max(measured_h, desc_font_effective);
        ImGui::PopFont();
    }
    desc_h = std::max(desc_h, desc_font); // always reserve desc height like module

    const float target_aspect = std::clamp(screen_aspect, 0.5f, 3.0f);
    const float desired_inner_h = std::max(1.0f, full_w / target_aspect);
    const float graph_h = std::max(110.0f * ui_scale, desired_inner_h);
    const float label_desc_gap = std::max(8.0f, style.ItemSpacing.y) * 0.55f;
    const float desc_widget_gap = label_desc_gap + ImGui::GetStyle().FontSizeBase * 0.25f;
    const float label_bottom = start.y + label_size.y;
    const float desc_y = label_bottom + (desc_h > 0.0f ? label_desc_gap : 0.0f);
    const float desc_bottom = desc_y + desc_h;
    const float graph_top = (desc_h > 0.0f) ? (desc_bottom + desc_widget_gap) : (label_bottom + desc_widget_gap);

    const ImVec2 gmin(start.x, graph_top);
    const ImVec2 gmax(start.x + full_w, graph_top + graph_h);
    const float total_h = gmax.y - start.y;
    ImGui::Dummy(ImVec2(full_w, total_h));
    const ImVec2 layout_end = ImGui::GetCursorScreenPos();

    dl->AddText(start, ImGui::GetColorU32(style.Colors[ImGuiCol_Text]), label);
    if (description && description[0] != '\0') {
        ImGui::PushFont(nullptr, desc_font);
        dl->AddText(ImGui::GetFont(), ImGui::GetFontSize(), ImVec2(start.x, desc_y),
                    ImGui::GetColorU32(WidgetBase::DescriptionColor(theme)), description, nullptr, desc_wrap_w);
        ImGui::PopFont();
    }

    const ImVec4 track = WidgetBase::TrackColor(theme);
    const ImVec4 primary = WidgetBase::PrimaryColor(theme);
    WidgetBase::AccentGradient primary_grad = WidgetBase::PrimaryGradient(theme);
    dl->AddRectFilled(gmin, gmax, ImGui::GetColorU32(track), style.FrameRounding);

    const float preview_w = std::max(1.0f, (gmax.x - gmin.x));
    const float preview_h = std::max(1.0f, (gmax.y - gmin.y));
    const ImVec2 pmin(gmin.x, gmin.y);
    const ImVec2 pmax(gmax.x, gmax.y);

    ClickGUI& gui = ClickGUI::Get();
    const PreviewWidgetKind current_kind = DetectPreviewWidgetKind(label, description, norm_x, gui);
    float* effective_norm_x = norm_x;
    float* effective_norm_y = norm_y;
    if (current_kind == PreviewWidgetKind::Watermark) {
        effective_norm_x = &gui.watermarkNormX;
        effective_norm_y = &gui.watermarkNormY;
        object_width_norm = gui.watermarkVisibleWidthNorm;
        object_height_norm = gui.watermarkVisibleHeightNorm;
        expanded_width_norm = gui.watermarkExpandedWidthNorm;
    } else if (current_kind == PreviewWidgetKind::SpeedGraph) {
        effective_norm_x = &gui.speedGraphNormX;
        effective_norm_y = &gui.speedGraphNormY;
        object_width_norm = gui.speedGraphVisibleWidthNorm;
        object_height_norm = gui.speedGraphVisibleHeightNorm;
        expanded_width_norm = gui.speedGraphExpandedWidthNorm;
    } else if (current_kind == PreviewWidgetKind::MovementRecorder) {
        effective_norm_x = &gui.movementRecorderNormX;
        effective_norm_y = &gui.movementRecorderNormY;
        object_width_norm = gui.movementRecorderVisibleWidthNorm;
        object_height_norm = gui.movementRecorderVisibleHeightNorm;
        expanded_width_norm = gui.movementRecorderExpandedWidthNorm;
    }

    object_width_norm = std::clamp(object_width_norm, 0.05f, 0.95f);
    object_height_norm = std::clamp(object_height_norm, 0.03f, 0.60f);
    expanded_width_norm = std::clamp(expanded_width_norm, object_width_norm, 0.98f);
    const std::vector<PreviewSlot> other_slots = CollectOtherPreviewSlots(current_kind);

    struct DragState {
        bool armed = false;
        bool dragging = false;
        ImVec2 mouse_start = ImVec2(0.0f, 0.0f);
        float norm_start_x = 0.0f;
        float norm_start_y = 0.0f;
    };
    static std::unordered_map<ImGuiID, DragState> s_drag;
    static std::unordered_map<ImGuiID, AnimatedPreviewRect> s_animated_preview;
    static LayoutGapMemory s_gap_memory;

    bool changed = false;
    bool active = false;
    ImGui::PushID(label);
    ImGui::SetCursorScreenPos(pmin);
    ImGui::InvisibleButton("##screen_pos_drag", ImVec2(preview_w, preview_h));
    const ImGuiID drag_id = ImGui::GetItemID();
    DragState& drag = s_drag[drag_id];
    active = ImGui::IsItemActive();
    if (ImGui::IsItemActivated()) {
        drag.armed = true;
        drag.dragging = false;
        drag.mouse_start = ImGui::GetIO().MousePos;
        drag.norm_start_x = *effective_norm_x;
        drag.norm_start_y = *effective_norm_y;
    }
    if (active && ImGui::GetIO().MouseDown[0]) {
        if (drag.armed && !drag.dragging) {
            const ImVec2 delta = ImVec2(
                ImGui::GetIO().MousePos.x - drag.mouse_start.x,
                ImGui::GetIO().MousePos.y - drag.mouse_start.y
            );
            const float threshold = std::max(6.0f, 8.0f * ui_scale);
            if ((delta.x * delta.x + delta.y * delta.y) >= threshold * threshold) {
                drag.dragging = true;
            }
        }
        if (drag.dragging) {
            const ImVec2 mp = ImGui::GetIO().MousePos;
            const float dx_px = mp.x - drag.mouse_start.x;
            const float dy_px = mp.y - drag.mouse_start.y;
            const float wm_w = preview_w * object_width_norm;
            const float wm_h = preview_h * object_height_norm;
            const float max_vis_x = std::max(0.0f, preview_w - wm_w);
            const float max_vis_y = std::max(0.0f, preview_h - wm_h);
            const float base_vis_x = std::clamp(drag.norm_start_x, 0.0f, 1.0f) * max_vis_x;
            const float base_vis_y = std::clamp(drag.norm_start_y, 0.0f, 1.0f) * max_vis_y;
            const float raw_vis_x = std::clamp(base_vis_x + dx_px, 0.0f, max_vis_x);
            const float raw_vis_y = std::clamp(base_vis_y + dy_px, 0.0f, max_vis_y);
            const float snap_threshold_x = std::max(11.0f * ui_scale, std::round(preview_w / 18.0f));
            const float snap_threshold_y = std::max(8.0f * ui_scale, std::round(preview_h / 24.0f));
            const float default_gap_x = std::max(6.0f * ui_scale, preview_w * 0.012f);
            const float default_gap_y = std::max(6.0f * ui_scale, preview_h * 0.012f);
            const float gap_x = s_gap_memory.has_horizontal_gap ? (s_gap_memory.horizontal_gap_norm * preview_w) : default_gap_x;
            const float gap_y = s_gap_memory.has_vertical_gap ? (s_gap_memory.vertical_gap_norm * preview_h) : default_gap_y;
            const float max_mem_gap_x = std::max(26.0f * ui_scale, preview_w * 0.08f);
            const float max_mem_gap_y = std::max(26.0f * ui_scale, preview_h * 0.08f);

            std::vector<AxisCandidate> x_candidates;
            std::vector<AxisCandidate> y_candidates;
            auto add_axis_candidate = [&](std::vector<AxisCandidate>& out, float value, float raw_value, float min_v, float max_v, bool snapped, float threshold) {
                value = std::clamp(value, min_v, max_v);
                if (HasCloseValue(out, value, 0.75f)) {
                    return;
                }
                const float delta = std::fabs(raw_value - value);
                if (!snapped || delta <= threshold) {
                    out.push_back(AxisCandidate{value, delta, snapped});
                }
            };

            add_axis_candidate(x_candidates, raw_vis_x, raw_vis_x, 0.0f, max_vis_x, false, snap_threshold_x);
            add_axis_candidate(y_candidates, raw_vis_y, raw_vis_y, 0.0f, max_vis_y, false, snap_threshold_y);
            add_axis_candidate(x_candidates, 0.0f, raw_vis_x, 0.0f, max_vis_x, true, snap_threshold_x);
            add_axis_candidate(x_candidates, max_vis_x, raw_vis_x, 0.0f, max_vis_x, true, snap_threshold_x);
            add_axis_candidate(y_candidates, 0.0f, raw_vis_y, 0.0f, max_vis_y, true, snap_threshold_y);
            add_axis_candidate(y_candidates, max_vis_y, raw_vis_y, 0.0f, max_vis_y, true, snap_threshold_y);

            const float center_x = std::max(0.0f, (preview_w - wm_w) * 0.5f);
            const float center_y = std::max(0.0f, (preview_h - wm_h) * 0.5f);
            add_axis_candidate(x_candidates, center_x, raw_vis_x, 0.0f, max_vis_x, true, snap_threshold_x);
            add_axis_candidate(y_candidates, center_y, raw_vis_y, 0.0f, max_vis_y, true, snap_threshold_y);

            for (const PreviewSlot& slot : other_slots) {
                const PreviewRect other = BuildPreviewRect(
                    pmin, pmax, *slot.norm_x, *slot.norm_y,
                    slot.visible_width_norm, slot.visible_height_norm, slot.expanded_width_norm
                );
                const float other_w = RectWidth(other);
                const float other_h = RectHeight(other);
                (void)other_w;
                (void)other_h;
                add_axis_candidate(x_candidates, other.visible_min.x - pmin.x, raw_vis_x, 0.0f, max_vis_x, true, snap_threshold_x);
                add_axis_candidate(x_candidates, other.visible_max.x - pmin.x - wm_w, raw_vis_x, 0.0f, max_vis_x, true, snap_threshold_x);
                add_axis_candidate(x_candidates, (other.visible_min.x + other.visible_max.x) * 0.5f - pmin.x - wm_w * 0.5f, raw_vis_x, 0.0f, max_vis_x, true, snap_threshold_x);
                add_axis_candidate(x_candidates, other.visible_min.x - pmin.x - wm_w - gap_x, raw_vis_x, 0.0f, max_vis_x, true, snap_threshold_x);
                add_axis_candidate(x_candidates, other.visible_max.x - pmin.x + gap_x, raw_vis_x, 0.0f, max_vis_x, true, snap_threshold_x);

                add_axis_candidate(y_candidates, other.visible_min.y - pmin.y, raw_vis_y, 0.0f, max_vis_y, true, snap_threshold_y);
                add_axis_candidate(y_candidates, other.visible_max.y - pmin.y - wm_h, raw_vis_y, 0.0f, max_vis_y, true, snap_threshold_y);
                add_axis_candidate(y_candidates, (other.visible_min.y + other.visible_max.y) * 0.5f - pmin.y - wm_h * 0.5f, raw_vis_y, 0.0f, max_vis_y, true, snap_threshold_y);
                add_axis_candidate(y_candidates, other.visible_min.y - pmin.y - wm_h - gap_y, raw_vis_y, 0.0f, max_vis_y, true, snap_threshold_y);
                add_axis_candidate(y_candidates, other.visible_max.y - pmin.y + gap_y, raw_vis_y, 0.0f, max_vis_y, true, snap_threshold_y);
            }

            float best_vis_x = raw_vis_x;
            float best_vis_y = raw_vis_y;
            float best_score = FLT_MAX;
            bool found = false;
            for (const AxisCandidate& xc : x_candidates) {
                const float nx = (max_vis_x > 0.0f) ? (xc.value / max_vis_x) : 0.0f;
                for (const AxisCandidate& yc : y_candidates) {
                    const float ny = (max_vis_y > 0.0f) ? (yc.value / max_vis_y) : 0.0f;
                    const PreviewRect candidate = BuildPreviewRect(
                        pmin, pmax, nx, ny, object_width_norm, object_height_norm, expanded_width_norm
                    );
                    bool blocked = false;
                    for (const PreviewSlot& slot : other_slots) {
                        const PreviewRect other = BuildPreviewRect(
                            pmin, pmax, *slot.norm_x, *slot.norm_y,
                            slot.visible_width_norm, slot.visible_height_norm, slot.expanded_width_norm
                        );
                        if (RectsOverlap(candidate.visible_min, candidate.visible_max, other.visible_min, other.visible_max)) {
                            blocked = true;
                            break;
                        }
                    }
                    if (blocked) {
                        continue;
                    }
                    float score = xc.cost + yc.cost;
                    if (xc.snapped) score -= snap_threshold_x * 0.28f;
                    if (yc.snapped) score -= snap_threshold_y * 0.18f;
                    if (xc.snapped && yc.snapped) score -= (snap_threshold_x + snap_threshold_y) * 0.08f;
                    if (score < best_score) {
                        best_score = score;
                        best_vis_x = xc.value;
                        best_vis_y = yc.value;
                        found = true;
                    }
                }
            }

            if (found) {
                const float nx = (max_vis_x > 0.0f) ? (best_vis_x / max_vis_x) : 0.0f;
                const float ny = (max_vis_y > 0.0f) ? (best_vis_y / max_vis_y) : 0.0f;
                if (std::fabs(*effective_norm_x - nx) > 0.0001f || std::fabs(*effective_norm_y - ny) > 0.0001f) {
                    *effective_norm_x = nx;
                    *effective_norm_y = ny;
                    changed = true;
                }
            }
        }
    }
    if (ImGui::IsItemDeactivated() || !ImGui::GetIO().MouseDown[0]) {
        if (drag.dragging) {
            const PreviewRect settled = BuildPreviewRect(
                pmin, pmax, *effective_norm_x, *effective_norm_y, object_width_norm, object_height_norm, expanded_width_norm
            );
            const float align_eps_x = std::max(5.0f * ui_scale, preview_w * 0.008f);
            const float align_eps_y = std::max(5.0f * ui_scale, preview_h * 0.008f);
            const float snap_threshold_x = std::max(11.0f * ui_scale, std::round(preview_w / 18.0f));
            const float snap_threshold_y = std::max(8.0f * ui_scale, std::round(preview_h / 24.0f));
            const float max_mem_gap_x = std::max(26.0f * ui_scale, preview_w * 0.08f);
            const float max_mem_gap_y = std::max(26.0f * ui_scale, preview_h * 0.08f);
            const float gap_store_eps_x = std::max(18.0f * ui_scale, snap_threshold_x * 1.8f);
            const float gap_store_eps_y = std::max(18.0f * ui_scale, snap_threshold_y * 1.8f);
            for (const PreviewSlot& slot : other_slots) {
                const PreviewRect other = BuildPreviewRect(
                    pmin, pmax, *slot.norm_x, *slot.norm_y,
                    slot.visible_width_norm, slot.visible_height_norm, slot.expanded_width_norm
                );
                const float gap_right = settled.visible_min.x - other.visible_max.x;
                const float gap_left = other.visible_min.x - settled.visible_max.x;
                if ((gap_right >= 0.0f || gap_left >= 0.0f) &&
                    RangesOverlap(settled.visible_min.y, settled.visible_max.y, other.visible_min.y, other.visible_max.y, 1.0f)) {
                    const float gap = (gap_right >= 0.0f) ? gap_right : gap_left;
                    const bool aligned_y = std::fabs(settled.visible_min.y - other.visible_min.y) <= align_eps_y ||
                                           std::fabs(settled.visible_max.y - other.visible_max.y) <= align_eps_y ||
                                           std::fabs(((settled.visible_min.y + settled.visible_max.y) * 0.5f) - ((other.visible_min.y + other.visible_max.y) * 0.5f)) <= align_eps_y;
                    if (aligned_y && gap <= std::min(gap_store_eps_x, max_mem_gap_x)) {
                        s_gap_memory.horizontal_gap_norm = std::clamp(gap / std::max(1.0f, preview_w), 0.0f, 0.25f);
                        s_gap_memory.has_horizontal_gap = true;
                    }
                }
                const float gap_bottom = settled.visible_min.y - other.visible_max.y;
                const float gap_top = other.visible_min.y - settled.visible_max.y;
                if ((gap_bottom >= 0.0f || gap_top >= 0.0f) &&
                    RangesOverlap(settled.visible_min.x, settled.visible_max.x, other.visible_min.x, other.visible_max.x, 1.0f)) {
                    const float gap = (gap_bottom >= 0.0f) ? gap_bottom : gap_top;
                    const bool aligned_x = std::fabs(settled.visible_min.x - other.visible_min.x) <= align_eps_x ||
                                           std::fabs(settled.visible_max.x - other.visible_max.x) <= align_eps_x ||
                                           std::fabs(((settled.visible_min.x + settled.visible_max.x) * 0.5f) - ((other.visible_min.x + other.visible_max.x) * 0.5f)) <= align_eps_x;
                    if (aligned_x && gap <= std::min(gap_store_eps_y, max_mem_gap_y)) {
                        s_gap_memory.vertical_gap_norm = std::clamp(gap / std::max(1.0f, preview_h), 0.0f, 0.25f);
                        s_gap_memory.has_vertical_gap = true;
                    }
                }
            }
        }
        drag.armed = false;
        drag.dragging = false;
    }
    ImGui::PopID();

    const PreviewRect current = BuildPreviewRect(
        pmin, pmax, *effective_norm_x, *effective_norm_y, object_width_norm, object_height_norm, expanded_width_norm
    );
    AnimatedPreviewRect& animated = s_animated_preview[drag_id];
    if (!animated.initialized) {
        animated.rect = current;
        animated.initialized = true;
    } else {
        const float dt = std::clamp(ImGui::GetIO().DeltaTime, 1.0f / 240.0f, 0.05f);
        const float lerp_t = drag.dragging ? (1.0f - std::exp(-dt * 18.0f)) : (1.0f - std::exp(-dt * 12.0f));
        animated.rect = LerpPreviewRect(animated.rect, current, lerp_t);
    }
    const PreviewRect& display = animated.rect;

    {
        const ImU32 grid_col = ImGui::GetColorU32(ImVec4(1.0f, 1.0f, 1.0f, post_processing.flags.blur ? 0.05f : 0.07f));
        const float cell = std::max(14.0f * ui_scale, std::round(preview_h / 10.0f));
        for (float x = pmin.x + cell; x < pmax.x - 0.5f; x += cell) {
            dl->AddLine(ImVec2(x, pmin.y), ImVec2(x, pmax.y), grid_col, 1.0f);
        }
        for (float y = pmin.y + cell; y < pmax.y - 0.5f; y += cell) {
            dl->AddLine(ImVec2(pmin.x, y), ImVec2(pmax.x, y), grid_col, 1.0f);
        }
    }

    const float marker_round = std::max(4.0f, 6.0f * ui_scale);
    const ImVec4 ghost_base = post_processing.flags.blur
        ? ImVec4(1.0f, 1.0f, 1.0f, 0.0f)
        : ImVec4(0.92f, 0.92f, 0.92f, 0.0f);
    ImVec4 ghost_expanded = ghost_base;
    ghost_expanded.w = post_processing.flags.blur ? 0.022f : 0.015f;
    ImVec4 ghost_visible = ghost_base;
    ghost_visible.w = post_processing.flags.blur ? 0.055f : 0.040f;
    for (const PreviewSlot& slot : other_slots) {
        const PreviewRect other = BuildPreviewRect(
            pmin, pmax, *slot.norm_x, *slot.norm_y,
            slot.visible_width_norm, slot.visible_height_norm, slot.expanded_width_norm
        );
        dl->AddRectFilled(other.expanded_min, other.expanded_max, ImGui::GetColorU32(ghost_expanded), marker_round);
        dl->AddRectFilled(other.visible_min, other.visible_max, ImGui::GetColorU32(ghost_visible), marker_round);
    }

    ImVec4 expanded_fill = post_processing.flags.blur
        ? ImVec4(primary.x, primary.y, primary.z, 0.038f)
        : ImVec4(primary.x, primary.y, primary.z, 0.028f);
    ImVec4 visible_fill = post_processing.flags.blur
        ? ImVec4(primary.x, primary.y, primary.z, 0.095f)
        : ImVec4(primary.x, primary.y, primary.z, 0.075f);
    const ImVec2& ext_min = display.expanded_min;
    const ImVec2& ext_max = display.expanded_max;
    const ImVec2& vis_min = display.visible_min;
    const ImVec2& vis_max = display.visible_max;
    dl->AddRectFilled(ext_min, ext_max, ImGui::GetColorU32(expanded_fill), marker_round);
    dl->AddRectFilled(vis_min, vis_max, ImGui::GetColorU32(visible_fill), marker_round);

    const ImVec2 anchor((pmin.x + pmax.x) * 0.5f, (pmin.y + pmax.y) * 0.5f);
    const float axis_alpha = post_processing.flags.blur ? 0.70f : 0.82f;
    ImVec4 axis_start = primary_grad.start;
    ImVec4 axis_end = primary_grad.end;
    axis_start.w = axis_alpha;
    axis_end.w = axis_alpha;
    const ImU32 axis_col = ImGui::GetColorU32(ImVec4(primary.x, primary.y, primary.z, axis_alpha));
    const float axis_thickness = 2.0f * ui_scale;
    if (post_processing.flags.glow) {
        const float glow_base_alpha = post_processing.flags.blur ? 0.070f : 0.085f;
        for (int layer = 0; layer < 3; ++layer) {
            const float t = (float)layer / 2.0f;
            const float a = glow_base_alpha * (1.0f - t * t);
            const float w = (6.0f - layer * 1.6f) * ui_scale;
            const ImU32 gcol = ImGui::GetColorU32(ImVec4(primary.x, primary.y, primary.z, a));
            dl->AddLine(ImVec2(pmin.x, anchor.y), ImVec2(pmax.x, anchor.y), gcol, w);
            dl->AddLine(ImVec2(anchor.x, pmin.y), ImVec2(anchor.x, pmax.y), gcol, w);
        }
    }
    if (primary_grad.gradient) {
        dl->AddRectFilledMultiColor(
            ImVec2(pmin.x, anchor.y - axis_thickness * 0.5f),
            ImVec2(pmax.x, anchor.y + axis_thickness * 0.5f),
            ImGui::GetColorU32(axis_start), ImGui::GetColorU32(axis_end),
            ImGui::GetColorU32(axis_end), ImGui::GetColorU32(axis_start)
        );
        dl->AddRectFilledMultiColor(
            ImVec2(anchor.x - axis_thickness * 0.5f, pmin.y),
            ImVec2(anchor.x + axis_thickness * 0.5f, pmax.y),
            ImGui::GetColorU32(axis_start), ImGui::GetColorU32(axis_start),
            ImGui::GetColorU32(axis_end), ImGui::GetColorU32(axis_end)
        );
    } else {
        dl->AddLine(ImVec2(pmin.x, anchor.y), ImVec2(pmax.x, anchor.y), axis_col, axis_thickness);
        dl->AddLine(ImVec2(anchor.x, pmin.y), ImVec2(anchor.x, pmax.y), axis_col, axis_thickness);
    }

    const ImU32 current_outline = ImGui::GetColorU32(ImVec4(primary.x, primary.y, primary.z, post_processing.flags.blur ? 0.82f : 0.92f));
    dl->AddRect(vis_min, vis_max, current_outline, marker_round, ImDrawFlags_RoundCornersAll, std::max(1.0f, 1.4f * ui_scale));

    if (out_active) {
        *out_active = active;
    }
    ImGui::SetCursorScreenPos(layout_end);
    return changed;
}
