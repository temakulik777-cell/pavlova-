#include "wigdets.h"
#include <unordered_map>
#include <algorithm>
#include <cmath>
#include <vector>

namespace WidgetActivity {
bool g_active = false;
bool g_has_value = false;

void BeginCapture() {
    g_active = false;
    g_has_value = false;
}

float WidgetUiScale() {
    const float font_scale = ImGui::GetIO().FontGlobalScale;
    return (font_scale != 0.0f) ? (font_scale / 0.75f) : 1.0f;
}

void SetActive(bool active) {
    g_active = active;
    g_has_value = true;
}

bool ConsumeOrFallback(bool fallback) {
    bool value = g_has_value ? g_active : fallback;
    g_active = false;
    g_has_value = false;
    return value;
}
}

namespace WidgetBase {
ImVec4 AlphaAware(ImVec4 c) {
    if (post_processing.flags.blur) {
        c.w = 0.6f;
    }
    return c;
}

ImVec2 ScaledGlyphOffset(const ImFont* font, float size) {
    if (!font || font->Sources.empty() || font->Sources[0] == nullptr) {
        return ImVec2(0.0f, 0.0f);
    }
    const ImFontConfig* cfg = font->Sources[0];
    float base_size = cfg->SizePixels > 0.0f ? cfg->SizePixels : 1.0f;
    float k = size / base_size;
    return ImVec2(cfg->GlyphOffset.x * k, cfg->GlyphOffset.y * k);
}

float CalcWrappedTextHeight(const char* text, float font_size, float wrap_width) {
    if (!text || text[0] == '\0') {
        return 0.0f;
    }
    ImFont* font = ImGui::GetFont();
    if (!font) {
        return 0.0f;
    }
    float w = (wrap_width > 0.0f) ? wrap_width : FLT_MAX;
    ImVec2 sz = font->CalcTextSizeA(font_size, FLT_MAX, w, text, nullptr, nullptr);
    return sz.y;
}

ImVec4 DescriptionColor(Theme* theme) {
    if (post_processing.flags.blur) {
        if (theme && theme->IsLightMode()) {
            ImVec4 c = theme->HexToImVec4(theme->material.onSurfaceVariant);
            c.w = 0.90f;
            return c;
        }
        return ImVec4(1.0f, 1.0f, 1.0f, 0.3f);
    }
    if (theme) {
        return theme->HexToImVec4(theme->material.onSurfaceVariant);
    }
    return ImVec4(0.4f, 0.4f, 0.4f, 1.0f);
}

ImVec4 TrackColor(Theme* theme) {
    if (post_processing.flags.blur) {
        if (theme && theme->IsLightMode()) {
            ImVec4 c = theme->HexToImVec4(theme->material.onSurfaceVariant);
            c.w = 0.12f;
            return c;
        }
        return ImVec4(1.0f, 1.0f, 1.0f, 0.050f);
    }
    if (theme) {
        return AlphaAware(theme->HexToImVec4(theme->material.surfaceVariant));
    }
    return ImVec4(0.11f, 0.11f, 0.11f, 0.6f);
}

ImVec4 PrimaryColor(Theme* theme) {
    if (theme) {
        ImVec4 c = theme->GetResolvedAccentColor();
        c.w = 1.0f;
        return c;
    }
    return ImVec4(0.294f, 0.412f, 0.996f, 1.0f);
}

AccentGradient PrimaryGradient(Theme* theme) {
    AccentGradient out{};
    if (theme) {
        ImVec4 start, end;
        theme->GetResolvedAccentGradient(start, end);
        out.start = start;
        out.end = end;
        out.start.w = 1.0f;
        out.end.w = 1.0f;
        out.gradient = (theme->GetAccentMode() != Theme::AccentMode::Accent);
        return out;
    }
    out.start = ImVec4(0.294f, 0.412f, 0.996f, 1.0f);
    out.end = out.start;
    out.gradient = false;
    return out;
}

ImVec4 PrimaryMidColor(Theme* theme) {
    AccentGradient g = PrimaryGradient(theme);
    if (theme && g.gradient && theme->GetAccentGradientDirection() == Theme::AccentGradientDirection::Vertical) {
        const float h = std::max(1.0f, (float)((glHeight > 0) ? glHeight : 1080));
        const float y = ImGui::GetCursorScreenPos().y;
        const float t = std::clamp(y / h, 0.0f, 1.0f);
        return ImVec4(
            g.start.x + (g.end.x - g.start.x) * t,
            g.start.y + (g.end.y - g.start.y) * t,
            g.start.z + (g.end.z - g.start.z) * t,
            g.start.w + (g.end.w - g.start.w) * t
        );
    }
    return ImVec4(
        g.start.x + (g.end.x - g.start.x) * 0.5f,
        g.start.y + (g.end.y - g.start.y) * 0.5f,
        g.start.z + (g.end.z - g.start.z) * 0.5f,
        g.start.w + (g.end.w - g.start.w) * 0.5f
    );
}

ImVec4 AccentColorAtY(Theme* theme, float y_screen) {
    AccentGradient g = PrimaryGradient(theme);
    if (!theme || !g.gradient || theme->GetAccentGradientDirection() == Theme::AccentGradientDirection::Horizontal) {
        return ImVec4(
            g.start.x + (g.end.x - g.start.x) * 0.5f,
            g.start.y + (g.end.y - g.start.y) * 0.5f,
            g.start.z + (g.end.z - g.start.z) * 0.5f,
            g.start.w + (g.end.w - g.start.w) * 0.5f
        );
    }
    const float h = std::max(1.0f, (float)((glHeight > 0) ? glHeight : 1080));
    const float t = std::clamp(y_screen / h, 0.0f, 1.0f);
    return ImVec4(
        g.start.x + (g.end.x - g.start.x) * t,
        g.start.y + (g.end.y - g.start.y) * t,
        g.start.z + (g.end.z - g.start.z) * t,
        g.start.w + (g.end.w - g.start.w) * t
    );
}

void AddAccentRect(ImDrawList* dl, const ImVec2& min, const ImVec2& max,
                   const AccentGradient& grad, Theme* theme, float rounding, ImDrawFlags flags) {
    if (!dl) {
        return;
    }
    if (grad.gradient) {
        if (theme && theme->GetAccentGradientDirection() == Theme::AccentGradientDirection::Vertical) {
            ImVec4 c = AccentColorAtY(theme, (min.y + max.y) * 0.5f);
            dl->AddRectFilled(min, max, ImGui::GetColorU32(c), rounding, flags);
            return;
        }
        const float w = std::max(0.0f, max.x - min.x);
        const float h = std::max(0.0f, max.y - min.y);
        const float r = std::min(rounding, std::min(w, h) * 0.5f);
        if (r <= 0.5f) {
            dl->AddRectFilledMultiColor(
                min, max,
                ImGui::GetColorU32(grad.start), ImGui::GetColorU32(grad.end),
                ImGui::GetColorU32(grad.end), ImGui::GetColorU32(grad.start)
            );
            return;
        }
        if (w <= r * 2.0f + 0.5f) {
            const ImVec4 mid = ImVec4(
                (grad.start.x + grad.end.x) * 0.5f,
                (grad.start.y + grad.end.y) * 0.5f,
                (grad.start.z + grad.end.z) * 0.5f,
                (grad.start.w + grad.end.w) * 0.5f
            );
            dl->AddRectFilled(min, max, ImGui::GetColorU32(mid), r, flags);
            return;
        }
        const bool round_left = (flags & ImDrawFlags_RoundCornersLeft) != 0 ||
                                (flags & ImDrawFlags_RoundCornersTopLeft) != 0 ||
                                (flags & ImDrawFlags_RoundCornersBottomLeft) != 0 ||
                                flags == ImDrawFlags_RoundCornersAll;
        const bool round_right = (flags & ImDrawFlags_RoundCornersRight) != 0 ||
                                 (flags & ImDrawFlags_RoundCornersTopRight) != 0 ||
                                 (flags & ImDrawFlags_RoundCornersBottomRight) != 0 ||
                                 flags == ImDrawFlags_RoundCornersAll;
        const float seam_overlap = 1.0f;
        const float left_split = round_left ? (min.x + r + seam_overlap) : min.x;
        const float right_split = round_right ? (max.x - r - seam_overlap) : max.x;
        if (left_split > min.x) {
            dl->AddRectFilled(min, ImVec2(left_split, max.y), ImGui::GetColorU32(grad.start), r, ImDrawFlags_RoundCornersLeft);
        }
        if (right_split < max.x) {
            dl->AddRectFilled(ImVec2(right_split, min.y), max, ImGui::GetColorU32(grad.end), r, ImDrawFlags_RoundCornersRight);
        }
        if (right_split > left_split) {
            dl->AddRectFilledMultiColor(
                ImVec2(left_split, min.y), ImVec2(right_split, max.y),
                ImGui::GetColorU32(grad.start), ImGui::GetColorU32(grad.end),
                ImGui::GetColorU32(grad.end), ImGui::GetColorU32(grad.start)
            );
        }
        return;
    }
    dl->AddRectFilled(min, max, ImGui::GetColorU32(grad.start), rounding, flags);
}

void ShadeVertsAccent(ImDrawList* dl, int vtx_start, int vtx_end,
                      const ImVec2& p0, const ImVec2& p1,
                      Theme* theme, float alpha) {
    if (!dl || vtx_end <= vtx_start) {
        return;
    }
    AccentGradient grad = PrimaryGradient(theme);
    grad.start.w = std::clamp(grad.start.w * alpha, 0.0f, 1.0f);
    grad.end.w = std::clamp(grad.end.w * alpha, 0.0f, 1.0f);
    if (theme && grad.gradient && theme->GetAccentGradientDirection() == Theme::AccentGradientDirection::Vertical) {
        ImVec4 c = AccentColorAtY(theme, p0.y);
        const ImU32 col = ImGui::GetColorU32(ImVec4(c.x, c.y, c.z, std::clamp(c.w * alpha, 0.0f, 1.0f)));
        for (int i = vtx_start; i < vtx_end; ++i) {
            const ImU32 prev = dl->VtxBuffer[i].col;
            const unsigned int a = (unsigned int)(prev >> IM_COL32_A_SHIFT) & 0xFFu;
            dl->VtxBuffer[i].col = (col & ~IM_COL32_A_MASK) | ((a & 0xFFu) << IM_COL32_A_SHIFT);
        }
        return;
    }
    ImGui::ShadeVertsLinearColorGradientKeepAlpha(
        dl, vtx_start, vtx_end, p0, p1,
        ImGui::GetColorU32(grad.start), ImGui::GetColorU32(grad.end)
    );
}

ImVec4 OutlineColor(Theme* theme) {
    if (post_processing.flags.blur) {
        if (theme && theme->IsLightMode()) {
            ImVec4 c = theme->HexToImVec4(theme->material.onSurfaceVariant);
            c.w = 0.24f;
            return c;
        }
        return ImVec4(1.0f, 1.0f, 1.0f, 0.12f);
    }
    if (theme) {
        ImVec4 c = theme->HexToImVec4(theme->material.onSurfaceVariant);
        c.w = 0.22f;
        return c;
    }
    return ImVec4(1.0f, 1.0f, 1.0f, 0.12f);
}

float ClampNorm(float v, float min_v, float max_v) {
    float den = std::max(0.0001f, max_v - min_v);
    return std::clamp((v - min_v) / den, 0.0f, 1.0f);
}

float Unnorm(float t, float min_v, float max_v) {
    return min_v + std::clamp(t, 0.0f, 1.0f) * (max_v - min_v);
}
}

static ImVec4 WidgetAlpha(ImVec4 c) {
    if (post_processing.flags.blur) {
        c.w = 0.6f;
    }
    return c;
}

static ImVec4 ButtonTrackColor(Theme* theme) {
    if (post_processing.flags.blur) {
        if (theme && theme->IsLightMode()) {
            ImVec4 c = theme->HexToImVec4(theme->material.onSurfaceVariant);
            c.w = 0.12f;
            return c;
        }
        return ImVec4(1.0f, 1.0f, 1.0f, 0.050f);
    }
    if (theme) {
        return WidgetAlpha(theme->HexToImVec4(theme->material.surfaceVariant));
    }
    return ImVec4(0.11f, 0.11f, 0.11f, 0.6f);
}

static ImVec4 ButtonFillColor(Theme* theme) {
    return WidgetBase::PrimaryMidColor(theme);
}

static ImVec4 ResolveButtonTextColor(Theme* theme, const ImVec4& button_color, const ImVec4& fallback) {
    const float lum = button_color.x * 0.299f + button_color.y * 0.587f + button_color.z * 0.114f;
    const float effective_lum = lum * button_color.w + 0.09f * (1.0f - button_color.w);
    if ((theme && theme->IsLightMode()) || effective_lum > 0.58f) {
        return ImVec4(0.08f, 0.08f, 0.08f, fallback.w);
    }
    return fallback;
}

static ImVec4 LerpVec4Local(const ImVec4& a, const ImVec4& b, float t) {
    return ImVec4(
        a.x + (b.x - a.x) * t,
        a.y + (b.y - a.y) * t,
        a.z + (b.z - a.z) * t,
        a.w + (b.w - a.w) * t
    );
}

static float LumaLocal(const ImVec4& c) {
    return c.x * 0.299f + c.y * 0.587f + c.z * 0.114f;
}

static float SweepNorm(float phase) {
    const float p = std::clamp(phase, 0.0f, 1.0f);
    if (p < 0.5f) {
        const float u = p * 2.0f;
        return u * u * (3.0f - 2.0f * u);
    }
    const float u = (p - 0.5f) * 2.0f;
    return 1.0f - (u * u * (3.0f - 2.0f * u));
}

struct ButtonAnimState {
    float t = 0.0f;
    bool playing = false;
    double started = 0.0;
    float hover = 0.0f;
    float press = 0.0f;
};

struct ActionButtonLabelParts {
    std::string left;
    std::string right;
    bool split = false;
};

struct ActionButtonRenderResult {
    bool clicked = false;
    bool active = false;
};

static ActionButtonLabelParts BuildActionButtonLabelParts(const char* label) {
    ActionButtonLabelParts out;
    if (!label || !*label) {
        return out;
    }
    std::vector<std::string> words;
    {
        std::string cur;
        for (const char* p = label; *p; ++p) {
            if (*p == ' ' || *p == '\t' || *p == '\n' || *p == '\r') {
                if (!cur.empty()) {
                    words.push_back(cur);
                    cur.clear();
                }
            } else {
                cur.push_back(*p);
            }
        }
        if (!cur.empty()) {
            words.push_back(cur);
        }
    }
    if (words.empty()) {
        out.left = label;
        return out;
    }
    if (words.size() == 1) {
        out.left = label;
        return out;
    }
    if (words.size() == 2) {
        out.left = words[0];
        out.right = words[1];
        out.split = true;
        return out;
    }
    size_t best_split = 1;
    int best_diff = INT_MAX;
    for (size_t i = 1; i < words.size(); ++i) {
        int l = 0;
        int r = 0;
        for (size_t j = 0; j < i; ++j) l += (int)words[j].size();
        for (size_t j = i; j < words.size(); ++j) r += (int)words[j].size();
        const int diff = std::abs(l - r);
        if (diff < best_diff) {
            best_diff = diff;
            best_split = i;
        }
    }
    for (size_t i = 0; i < best_split; ++i) {
        if (!out.left.empty()) out.left.push_back(' ');
        out.left += words[i];
    }
    for (size_t i = best_split; i < words.size(); ++i) {
        if (!out.right.empty()) out.right.push_back(' ');
        out.right += words[i];
    }
    out.split = !out.left.empty() && !out.right.empty();
    return out;
}

static ActionButtonRenderResult RenderActionButtonCell(const char* label, Theme* theme, const ImVec2& size, ImDrawFlags corner_flags) {
    ActionButtonRenderResult out;
    if (!label) {
        return out;
    }

    ImVec2 pos = ImGui::GetCursorScreenPos();
    const float w = std::max(1.0f, size.x);
    const float h = std::max(1.0f, size.y);
    const float ui_scale = WidgetActivity::WidgetUiScale();

    out.clicked = ImGui::InvisibleButton("##action_btn", ImVec2(w, h));
    out.active = ImGui::IsItemActive();
    const bool hovered = ImGui::IsItemHovered();
    ImGuiID id = ImGui::GetItemID();

    static std::unordered_map<ImGuiID, ButtonAnimState> anim;
    const double now = ImGui::GetTime();
    const float dt = std::max(1e-4f, ImGui::GetIO().DeltaTime);
    ButtonAnimState& st = anim[id];
    if (out.clicked) {
        st.playing = true;
        st.started = now;
        st.t = 0.0f;
    }
    const float hover_k = 1.0f - std::exp(-8.0f * dt);
    const float press_k = 1.0f - std::exp(-12.0f * dt);
    st.hover += ((hovered ? 1.0f : 0.0f) - st.hover) * hover_k;
    st.press += ((out.active ? 1.0f : 0.0f) - st.press) * press_k;
    if (st.playing) {
        float elapsed = static_cast<float>(now - st.started);
        const float u = std::clamp(elapsed / 0.48f, 0.0f, 1.0f);
        st.t = u * u * (3.0f - 2.0f * u);
        if (st.t >= 1.0f) {
            st.t = 0.0f;
            st.playing = false;
        }
    }

    ImDrawList* dl = ImGui::GetWindowDrawList();
    ImGuiStyle& style = ImGui::GetStyle();
    ImVec2 minp = pos;
    ImVec2 maxp = ImVec2(pos.x + w, pos.y + h);

    ImVec4 track = ButtonTrackColor(theme);
    ImVec4 fill = ButtonFillColor(theme);
    track.w = std::clamp(track.w * (1.0f + st.hover * 0.16f + st.press * 0.08f), 0.0f, 1.0f);
    fill.w = std::clamp(fill.w * (1.0f + st.hover * 0.10f), 0.0f, 1.0f);
    const ImU32 track_u32 = ImGui::GetColorU32(track);
    const ImU32 fill_u32 = ImGui::GetColorU32(fill);
    const float button_rounding = std::max(0.0f, style.FrameRounding);
    dl->AddRectFilled(minp, maxp, track_u32, button_rounding, corner_flags);

    float fill_w = 0.0f;
    if (st.playing) {
        fill_w = w * SweepNorm(st.t);
        if (fill_w > 1.0f) {
            const bool fill_is_full = fill_w >= (w - 1.0f);
            const float rr_fill = std::min(button_rounding, std::min(fill_w, h) * 0.5f);
            const ImDrawFlags left_mask = ImDrawFlags_RoundCornersTopLeft | ImDrawFlags_RoundCornersBottomLeft;
            const ImDrawFlags fill_flags = fill_is_full ? corner_flags : (corner_flags & left_mask);
            dl->AddRectFilled(minp, ImVec2(minp.x + fill_w, maxp.y), fill_u32, rr_fill, fill_flags);
        }
    }

    ImFont* font = ImGui::GetFont();
    const float text_size_px = ImGui::GetFontSize() * 0.96f;
    const ActionButtonLabelParts parts = BuildActionButtonLabelParts(label);
    const ImVec2 text_size = font
        ? font->CalcTextSizeA(text_size_px, FLT_MAX, 0.0f, label)
        : ImGui::CalcTextSize(label);
    const ImVec2 glyph_off = WidgetBase::ScaledGlyphOffset(font, text_size_px);
    const float ty = minp.y + (h - text_size.y) * 0.5f - glyph_off.y;

    const ImVec4 base_text_col = style.Colors[ImGuiCol_Text];
    const ImVec4 dark_text_col = ImVec4(0.08f, 0.08f, 0.08f, base_text_col.w);
    const float fill_edge = minp.x + fill_w;
    const bool has_fill = fill_w > 0.5f;
    auto draw_text_run = [&](const char* run_text, float x, float y) {
        if (!run_text || !*run_text) {
            return;
        }
        const char* p = run_text;
        float pen_x = x;
        while (*p) {
            unsigned int cp = 0;
            const int adv = ImTextCharFromUtf8(&cp, p, nullptr);
            if (adv <= 0) {
                break;
            }
            const char* next = p + adv;
            ImVec2 gsz = font
                ? font->CalcTextSizeA(text_size_px, FLT_MAX, 0.0f, p, next, nullptr)
                : ImGui::CalcTextSize(p, next);
            const float char_center_x = pen_x + gsz.x * 0.5f;
            ImVec4 draw_col = base_text_col;
            if (has_fill && char_center_x <= fill_edge && LumaLocal(fill) > 0.78f) {
                draw_col = dark_text_col;
            } else if (!has_fill) {
                draw_col = ResolveButtonTextColor(theme, track, draw_col);
            }
            draw_col = LerpVec4Local(draw_col, ImVec4(1.0f, 1.0f, 1.0f, draw_col.w), st.hover * 0.04f);
            dl->AddText(font, text_size_px, ImVec2(pen_x, y), ImGui::GetColorU32(draw_col), p, next);
            pen_x += gsz.x;
            p = next;
        }
    };

    if (parts.split) {
        const ImVec2 left_size = font
            ? font->CalcTextSizeA(text_size_px, FLT_MAX, 0.0f, parts.left.c_str())
            : ImGui::CalcTextSize(parts.left.c_str());
        const ImVec2 right_size = font
            ? font->CalcTextSizeA(text_size_px, FLT_MAX, 0.0f, parts.right.c_str())
            : ImGui::CalcTextSize(parts.right.c_str());
        const float pad_x = std::max(style.FramePadding.x, 10.0f * ui_scale);
        const float left_x = minp.x + pad_x - glyph_off.x;
        const float right_x = maxp.x - pad_x - right_size.x - glyph_off.x;
        if (left_x + left_size.x + pad_x <= right_x) {
            draw_text_run(parts.left.c_str(), left_x, ty);
            draw_text_run(parts.right.c_str(), right_x, ty);
        } else {
            const float tx = minp.x + (w - text_size.x) * 0.5f - glyph_off.x;
            draw_text_run(label, tx, ty);
        }
    } else {
        const float tx = minp.x + (w - text_size.x) * 0.5f - glyph_off.x;
        draw_text_run(label, tx, ty);
    }

    return out;
}

bool ActionButton(const char* label, Theme* theme, bool* out_active) {
    if (!label) {
        if (out_active) {
            *out_active = false;
        }
        return false;
    }

    float w = ImGui::GetContentRegionAvail().x;
    if (w < 1.0f) {
        w = 1.0f;
    }
    float h = ImGui::GetFrameHeight();

    ImGui::PushID(label);
    const ActionButtonRenderResult result = RenderActionButtonCell(label, theme, ImVec2(w, h), ImDrawFlags_RoundCornersAll);

    if (out_active) {
        *out_active = result.active;
    }
    ImGui::PopID();
    return result.clicked;
}

bool ActionButtonQuad(const std::array<const char*, 4>& labels, Theme* theme, std::array<bool, 4>* out_active) {
    const float full_w = std::max(1.0f, ImGui::GetContentRegionAvail().x);
    const float col_gap = 0.0f;
    const float row_gap = 0.0f;
    const float cell_w = std::max(1.0f, (full_w - col_gap) * 0.5f);
    const float cell_h = ImGui::GetFrameHeight() * 1.04f;
    std::array<bool, 4> clicked = {false, false, false, false};

    for (int row = 0; row < 2; ++row) {
        for (int col = 0; col < 2; ++col) {
            const int idx = row * 2 + col;
            const ImDrawFlags corners =
                (idx == 0) ? ImDrawFlags_RoundCornersTopLeft :
                (idx == 1) ? ImDrawFlags_RoundCornersTopRight :
                (idx == 2) ? ImDrawFlags_RoundCornersBottomLeft :
                             ImDrawFlags_RoundCornersBottomRight;
            ImGui::PushID(idx);
            const ActionButtonRenderResult result = RenderActionButtonCell(labels[idx], theme, ImVec2(cell_w, cell_h), corners);
            clicked[idx] = result.clicked;
            ImGui::PopID();
            if (col == 0) {
                ImGui::SameLine(0.0f, col_gap);
            }
        }
        if (row == 0) {
            ImGui::Dummy(ImVec2(0.0f, row_gap));
        }
    }

    if (out_active) {
        *out_active = clicked;
    }
    return clicked[0] || clicked[1] || clicked[2] || clicked[3];
}

void SectionSeparator(const char* text) {
    const char* section_text = (text && text[0] != '\0') ? text : "Settings";
    const float ui_scale = WidgetActivity::WidgetUiScale();
    const float section_gap = 8.0f * ui_scale;
    const float section_top_gap = 4.0f * ui_scale;
    const float section_bottom_gap = 0.0f * ui_scale;
    const float left_line_w = 20.0f * ui_scale;
    const float section_text_shift = left_line_w + section_gap + (6.75f * ui_scale);
    const float section_y_pad = 0.0f * ui_scale;
    ImFont* section_font = ImGui::GetFont();
    const float section_font_size = ImGui::GetFontSize();

    ImVec2 section_pos = ImGui::GetCursorScreenPos();
    section_pos.y += section_top_gap;
    const float section_width = ImGui::GetContentRegionAvail().x;
    const ImVec2 section_text_size = section_font
        ? section_font->CalcTextSizeA(section_font_size, FLT_MAX, 0.0f, section_text)
        : ImGui::CalcTextSize(section_text);
    const ImVec2 section_text_pos(section_pos.x + section_text_shift, section_pos.y);

    ImGui::GetWindowDrawList()->AddText(
        section_font,
        section_font_size,
        section_text_pos,
        ImGui::GetColorU32(ImGui::GetStyle().Colors[ImGuiCol_Text]),
        section_text
    );

    const float line_y = section_text_pos.y + section_text_size.y * 0.5f + section_y_pad;
    const float line_left_end_x = section_text_pos.x - section_gap;
    const float line_right_start_x = section_text_pos.x + section_text_size.x + section_gap;
    const float line_end_x = section_pos.x + std::max(0.0f, section_width);
    const ImU32 sep_col = ImGui::GetColorU32(ImVec4(1.0f, 1.0f, 1.0f, 0.42f));
    const float sep_thickness = std::max(1.0f, ImGui::GetStyle().SeparatorTextBorderSize);
    ImDrawList* dl = ImGui::GetWindowDrawList();
    if (line_left_end_x > section_pos.x + 1.0f) {
        dl->AddLine(ImVec2(section_pos.x, line_y), ImVec2(line_left_end_x, line_y), sep_col, sep_thickness);
    }
    if (line_end_x > line_right_start_x + 1.0f) {
        dl->AddLine(ImVec2(line_right_start_x, line_y), ImVec2(line_end_x, line_y), sep_col, sep_thickness);
    }

    // Dummy adds default ItemSpacing.y below itself; subtract it so top/bottom visual gap stays balanced.
    const float auto_spacing = ImGui::GetStyle().ItemSpacing.y;
    const float bottom_trim = 2.0f * ui_scale;
    const float occupy_h = std::max(1.0f, section_top_gap + section_text_size.y + section_bottom_gap - auto_spacing - bottom_trim);
    ImGui::Dummy(ImVec2(0.0f, occupy_h));
}

CheckboxRenderer::CheckboxRenderer(const char* label, const char* description, bool* value, Theme* theme)
    : label_(label), description_(description), value_(value), theme_(theme) {}

bool CheckboxRenderer::Render(bool* out_active) {
    return Checkbox(label_, description_, value_, theme_, out_active);
}

SliderFloatRenderer::SliderFloatRenderer(const char* label, const char* description, float* value, float min, float max, Theme* theme)
    : label_(label), description_(description), value_(value), min_(min), max_(max), theme_(theme) {}

bool SliderFloatRenderer::Render(bool* out_active) {
    return SliderFloat(label_, description_, value_, min_, max_, theme_, out_active);
}

SliderIntRenderer::SliderIntRenderer(const char* label, const char* description, int* value, int min, int max, Theme* theme)
    : label_(label), description_(description), value_(value), min_(min), max_(max), theme_(theme) {}

bool SliderIntRenderer::Render(bool* out_active) {
    return SliderInt(label_, description_, value_, min_, max_, theme_, out_active);
}

ComboRenderer::ComboRenderer(const char* label, const char* description, int* value, const char* const items[], int items_count, Theme* theme)
    : label_(label), description_(description), value_(value), items_(items), items_count_(items_count), theme_(theme) {}

bool ComboRenderer::Render(bool* out_active) {
    return Combo(label_, description_, value_, items_, items_count_, theme_, out_active);
}

ColorPicker3Renderer::ColorPicker3Renderer(const char* label, const char* description,
                                           float* r, float* g, float* b,
                                           float min, float max, Theme* theme)
    : label_(label), description_(description), r_(r), g_(g), b_(b), min_(min), max_(max), theme_(theme) {}

bool ColorPicker3Renderer::Render(bool* out_active) {
    return ColorPicker3(label_, description_, r_, g_, b_, min_, max_, theme_, out_active);
}

CurveGraphRenderer::CurveGraphRenderer(const char* label, const char* description,
                                       float* values, int count, const char* const names[],
                                       const float* mins, const float* maxs, Theme* theme)
    : label_(label), description_(description), values_(values), count_(count), names_(names),
      mins_(mins), maxs_(maxs), theme_(theme) {}

bool CurveGraphRenderer::Render(bool* out_active) {
    return CurveGraph(label_, description_, values_, count_, names_, mins_, maxs_, theme_, out_active);
}


WidgetManager::WidgetManager() {
    s_active_instance = this;
}

void WidgetManager::Init() {
}


template<typename T>
WidgetReference<T>::WidgetReference(T* ptr) : value_ptr(ptr) {}

template<typename T>
WidgetReference<T>::operator T&() { return *value_ptr; }

template<typename T>
WidgetReference<T>::operator const T&() const { return *value_ptr; }

template<typename T>
T& WidgetReference<T>::operator*() { return *value_ptr; }

template<typename T>
const T& WidgetReference<T>::operator*() const { return *value_ptr; }

template<typename T>
T* WidgetReference<T>::operator->() { return value_ptr; }

template<typename T>
const T* WidgetReference<T>::operator->() const { return value_ptr; }

template<typename T>
WidgetReference<T>& WidgetReference<T>::operator=(const T& value) {
    *value_ptr = value;
    return *this;
}

template<typename T>
WidgetReference<T>& WidgetReference<T>::operator=(T&& value) {
    *value_ptr = std::move(value);
    return *this;
}


template class WidgetReference<bool>;
template class WidgetReference<int>;
template class WidgetReference<float>;
template class WidgetReference<double>;


template class Widgets<bool>;
template class Widgets<int>;
template class Widgets<float>;
template class Widgets<double>;
