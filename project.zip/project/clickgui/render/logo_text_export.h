#pragma once

#include <cstddef>

namespace LogoTextExport {

bool ExportMontserratLogoPng(
    float font_size_px,
    const char* line_top,
    const char* line_bottom,
    const char* out_path,
    int& out_w,
    int& out_h,
    size_t& out_written_alpha_px,
    int& out_errno);

bool ExportSingleTextPng(
    float font_size_px,
    const char* text,
    const char* out_path,
    int& out_w,
    int& out_h,
    size_t& out_written_alpha_px,
    int& out_errno);

bool ExportUiTextSetPngs(
    float font_size_px,
    const char* out_dir,
    int& out_ok_count,
    int& out_fail_count,
    int& out_errno);

} // namespace LogoTextExport
