#include "logo_text_export.h"

#include <algorithm>
#include <cmath>
#include <vector>
#include <string>
#include <sys/stat.h>
#include <sys/types.h>
#include <cerrno>
#include <cstdio>

#include "../imgui/imgui.h"
#include "../imgui/imgui_internal.h"
#include "../../assets/fonts/montserrat.h"
#include "../../assets/fonts/montserrat_regular.h"
#include "../../assets/fonts/wigrum_regular.h"
#include "../../good_luck/stb/stb_image_write.h"

namespace LogoTextExport {

struct FontCandidate {
    const unsigned char* data;
    int size;
};

struct LineBounds {
    float min_x = 0.0f;
    float max_x = 0.0f;
    float min_y = 0.0f;
    float max_y = 0.0f;
    float width = 0.0f;
};

static bool NextUtf8(const char*& p, unsigned int& out_cp) {
    out_cp = 0;
    if (!p || !*p) return false;
    unsigned int cp = 0;
    int consumed = ImTextCharFromUtf8(&cp, p, nullptr);
    if (consumed <= 0 || cp == 0) return false;
    p += consumed;
    out_cp = cp;
    return true;
}

static bool HasAllGlyphs(ImFontBaked* baked, const char* text) {
    if (!baked || !text) return false;
    const char* p = text;
    while (*p) {
        unsigned int cp = 0;
        if (!NextUtf8(p, cp)) break;
        if (!baked->FindGlyphNoFallback(static_cast<ImWchar>(cp))) {
            return false;
        }
    }
    return true;
}

static bool BuildFontAtlasForTexts(float px, const char* const* texts, int text_count, ImFontAtlas& atlas, ImFont*& font, ImFontBaked*& baked) {
    static const ImWchar ranges[] = {0x0020, 0x00FF, 0x0400, 0x052F, 0};
    const FontCandidate candidates[] = {
        {montserrat_data, static_cast<int>(montserrat_size)},
        {montserrat_regular_data, static_cast<int>(montserrat_regular_size)},
        {wigrum_regular_data, static_cast<int>(wigrum_regular_size)},
    };

    ImFontConfig cfg{};
    cfg.FontDataOwnedByAtlas = false;
    cfg.OversampleH = 1;
    cfg.OversampleV = 1;
    cfg.RasterizerMultiply = 1.0f;

    font = nullptr;
    baked = nullptr;
    for (const auto& c : candidates) {
        atlas.Clear();
        font = atlas.AddFontFromMemoryCompressedTTF(
            const_cast<unsigned char*>(c.data), c.size, px, &cfg, ranges);
        if (!font) {
            continue;
        }
        atlas.Build();
        baked = font->GetFontBaked(px);
        if (!baked) {
            continue;
        }

        bool all_ok = true;
        for (int i = 0; i < text_count; ++i) {
            if (!HasAllGlyphs(baked, texts[i])) {
                all_ok = false;
                break;
            }
        }
        if (all_ok) {
            return true;
        }
        font = nullptr;
        baked = nullptr;
    }
    return false;
}

static bool EnsureDirRecursive(const char* dir_path) {
    if (!dir_path || !*dir_path) {
        return false;
    }
    std::string path(dir_path);
    size_t pos = 0;
    if (!path.empty() && path[0] == '/') {
        pos = 1;
    }
    while (pos <= path.size()) {
        size_t slash = path.find('/', pos);
        std::string sub = (slash == std::string::npos) ? path : path.substr(0, slash);
        if (!sub.empty()) {
            if (::mkdir(sub.c_str(), 0777) != 0 && errno != EEXIST) {
                return false;
            }
        }
        if (slash == std::string::npos) {
            break;
        }
        pos = slash + 1;
    }
    return true;
}

bool ExportMontserratLogoPng(
    float font_size_px,
    const char* line_top,
    const char* line_bottom,
    const char* out_path,
    int& out_w,
    int& out_h,
    size_t& out_written_alpha_px,
    int& out_errno) {
    out_w = 0;
    out_h = 0;
    out_written_alpha_px = 0;
    out_errno = 0;
    if (!line_top || !line_bottom || !out_path || !*out_path) return false;

    const float px = std::max(8.0f, font_size_px);

    ImFontAtlas atlas;
    ImFont* font = nullptr;
    ImFontBaked* baked = nullptr;
    const char* texts[] = {line_top, line_bottom};
    if (!BuildFontAtlasForTexts(px, texts, 2, atlas, font, baked)) return false;

    unsigned char* atlas_a8 = nullptr;
    int atlas_w = 0, atlas_h = 0;
    atlas.GetTexDataAsAlpha8(&atlas_a8, &atlas_w, &atlas_h);
    if (!atlas_a8 || atlas_w <= 0 || atlas_h <= 0) return false;

    auto measure_line = [&](const char* text) {
        LineBounds b{};
        bool has = false;
        float pen_x = 0.0f;
        const char* p = text;
        while (*p) {
            unsigned int cp = 0;
            if (!NextUtf8(p, cp)) break;
            const ImFontGlyph* g = baked->FindGlyphNoFallback(static_cast<ImWchar>(cp));
            if (!g) continue;
            const float gx0 = pen_x + g->X0;
            const float gx1 = pen_x + g->X1;
            if (!has) {
                b.min_x = gx0; b.max_x = gx1;
                b.min_y = g->Y0; b.max_y = g->Y1;
                has = true;
            } else {
                b.min_x = std::min(b.min_x, gx0);
                b.max_x = std::max(b.max_x, gx1);
                b.min_y = std::min(b.min_y, g->Y0);
                b.max_y = std::max(b.max_y, g->Y1);
            }
            pen_x += g->AdvanceX;
        }
        b.width = has ? std::max(0.0f, b.max_x - b.min_x) : 0.0f;
        return b;
    };

    const LineBounds top = measure_line(line_top);
    const LineBounds bottom = measure_line(line_bottom);
    const float text_w = std::max(top.width, bottom.width);
    const float line_gap = std::max(4.0f, std::round(px * 0.12f));
    const int pad = std::max(8, static_cast<int>(std::round(px * 0.16f)));
    const int glow_pad = std::max(16, static_cast<int>(std::round(px * 0.85f)));
    const int outer_pad = pad + glow_pad;
    const float top_baseline = static_cast<float>(outer_pad) - top.min_y;
    const float top_bottom_y = top_baseline + top.max_y;
    const float bottom_baseline = top_bottom_y + line_gap - bottom.min_y + std::round(px * 0.17f);
    const float bottom_bottom_y = bottom_baseline + bottom.max_y;

    out_w = std::max(1, static_cast<int>(std::ceil(text_w)) + outer_pad * 2);
    out_h = std::max(1, static_cast<int>(std::ceil(bottom_bottom_y + outer_pad)));
    std::vector<unsigned char> rgba(static_cast<size_t>(out_w) * static_cast<size_t>(out_h) * 4u, 0u);

    const float top_x = static_cast<float>(outer_pad) + (text_w - top.width) * 0.5f - top.min_x;
    const float bottom_x = static_cast<float>(outer_pad) + (text_w - bottom.width) * 0.5f - bottom.min_x + std::round(px * 0.09f);

    auto blit_line = [&](const char* text, float x_start, float baseline_y) {
        float pen_x = x_start;
        const char* p = text;
        while (*p) {
            unsigned int cp = 0;
            if (!NextUtf8(p, cp)) break;
            const ImFontGlyph* g = baked->FindGlyphNoFallback(static_cast<ImWchar>(cp));
            if (!g) continue;

            const int dst_x0 = static_cast<int>(std::floor(pen_x + g->X0));
            const int dst_y0 = static_cast<int>(std::floor(baseline_y + g->Y0));
            const int dst_x1 = static_cast<int>(std::ceil (pen_x + g->X1));
            const int dst_y1 = static_cast<int>(std::ceil (baseline_y + g->Y1));
            const int gw = std::max(1, dst_x1 - dst_x0);
            const int gh = std::max(1, dst_y1 - dst_y0);

            const int src_x0 = std::clamp(static_cast<int>(std::floor(g->U0 * atlas_w)), 0, atlas_w - 1);
            const int src_y0 = std::clamp(static_cast<int>(std::floor(g->V0 * atlas_h)), 0, atlas_h - 1);
            const int src_x1 = std::clamp(static_cast<int>(std::ceil (g->U1 * atlas_w)), 0, atlas_w);
            const int src_y1 = std::clamp(static_cast<int>(std::ceil (g->V1 * atlas_h)), 0, atlas_h);
            const int sw = std::max(1, src_x1 - src_x0);
            const int sh = std::max(1, src_y1 - src_y0);

            for (int y = 0; y < gh; ++y) {
                const int dy = dst_y0 + y;
                if (dy < 0 || dy >= out_h) continue;
                const float ty = (gh > 1) ? (static_cast<float>(y) / static_cast<float>(gh - 1)) : 0.0f;
                const int sy = src_y0 + std::clamp(static_cast<int>(std::round(ty * (sh - 1))), 0, sh - 1);
                for (int x = 0; x < gw; ++x) {
                    const int dx = dst_x0 + x;
                    if (dx < 0 || dx >= out_w) continue;
                    const float tx = (gw > 1) ? (static_cast<float>(x) / static_cast<float>(gw - 1)) : 0.0f;
                    const int sx = src_x0 + std::clamp(static_cast<int>(std::round(tx * (sw - 1))), 0, sw - 1);
                    const unsigned char a = atlas_a8[sy * atlas_w + sx];
                    if (!a) continue;
                    const size_t di = (static_cast<size_t>(dy) * static_cast<size_t>(out_w) + static_cast<size_t>(dx)) * 4u;
                    rgba[di + 0] = 255;
                    rgba[di + 1] = 255;
                    rgba[di + 2] = 255;
                    if (a > rgba[di + 3]) rgba[di + 3] = a;
                }
            }

            pen_x += g->AdvanceX;
        }
    };

    blit_line(line_top, top_x, top_baseline);
    blit_line(line_bottom, bottom_x, bottom_baseline);

    for (size_t i = 3; i < rgba.size(); i += 4) {
        if (rgba[i] != 0) ++out_written_alpha_px;
    }

    std::remove(out_path);
    errno = 0;
    const int ok = stbi_write_png(out_path, out_w, out_h, 4, rgba.data(), out_w * 4);
    out_errno = errno;
    return ok != 0;
}

bool ExportSingleTextPng(
    float font_size_px,
    const char* text,
    const char* out_path,
    int& out_w,
    int& out_h,
    size_t& out_written_alpha_px,
    int& out_errno) {
    out_w = 0;
    out_h = 0;
    out_written_alpha_px = 0;
    out_errno = 0;
    if (!text || !*text || !out_path || !*out_path) {
        return false;
    }

    const float px = std::max(8.0f, font_size_px);
    ImFontAtlas atlas;
    ImFont* font = nullptr;
    ImFontBaked* baked = nullptr;
    const char* texts[] = {text};
    if (!BuildFontAtlasForTexts(px, texts, 1, atlas, font, baked)) {
        return false;
    }

    unsigned char* atlas_a8 = nullptr;
    int atlas_w = 0, atlas_h = 0;
    atlas.GetTexDataAsAlpha8(&atlas_a8, &atlas_w, &atlas_h);
    if (!atlas_a8 || atlas_w <= 0 || atlas_h <= 0) {
        return false;
    }

    LineBounds line{};
    bool has = false;
    float pen_x = 0.0f;
    const char* p = text;
    while (*p) {
        unsigned int cp = 0;
        if (!NextUtf8(p, cp)) break;
        const ImFontGlyph* g = baked->FindGlyphNoFallback(static_cast<ImWchar>(cp));
        if (!g) continue;
        const float gx0 = pen_x + g->X0;
        const float gx1 = pen_x + g->X1;
        if (!has) {
            line.min_x = gx0; line.max_x = gx1;
            line.min_y = g->Y0; line.max_y = g->Y1;
            has = true;
        } else {
            line.min_x = std::min(line.min_x, gx0);
            line.max_x = std::max(line.max_x, gx1);
            line.min_y = std::min(line.min_y, g->Y0);
            line.max_y = std::max(line.max_y, g->Y1);
        }
        pen_x += g->AdvanceX;
    }
    line.width = has ? std::max(0.0f, line.max_x - line.min_x) : 0.0f;
    if (!has) {
        return false;
    }

    const int pad = std::max(8, static_cast<int>(std::round(px * 0.16f)));
    const int glow_pad = std::max(16, static_cast<int>(std::round(px * 0.85f)));
    const int outer_pad = pad + glow_pad;
    const float baseline = static_cast<float>(outer_pad) - line.min_y;
    const float text_bottom = baseline + line.max_y;

    out_w = std::max(1, static_cast<int>(std::ceil(line.width)) + outer_pad * 2);
    out_h = std::max(1, static_cast<int>(std::ceil(text_bottom + outer_pad)));
    std::vector<unsigned char> rgba(static_cast<size_t>(out_w) * static_cast<size_t>(out_h) * 4u, 0u);

    float pen = static_cast<float>(outer_pad) - line.min_x;
    p = text;
    while (*p) {
        unsigned int cp = 0;
        if (!NextUtf8(p, cp)) break;
        const ImFontGlyph* g = baked->FindGlyphNoFallback(static_cast<ImWchar>(cp));
        if (!g) continue;

        const int dst_x0 = static_cast<int>(std::floor(pen + g->X0));
        const int dst_y0 = static_cast<int>(std::floor(baseline + g->Y0));
        const int dst_x1 = static_cast<int>(std::ceil (pen + g->X1));
        const int dst_y1 = static_cast<int>(std::ceil (baseline + g->Y1));
        const int gw = std::max(1, dst_x1 - dst_x0);
        const int gh = std::max(1, dst_y1 - dst_y0);

        const int src_x0 = std::clamp(static_cast<int>(std::floor(g->U0 * atlas_w)), 0, atlas_w - 1);
        const int src_y0 = std::clamp(static_cast<int>(std::floor(g->V0 * atlas_h)), 0, atlas_h - 1);
        const int src_x1 = std::clamp(static_cast<int>(std::ceil (g->U1 * atlas_w)), 0, atlas_w);
        const int src_y1 = std::clamp(static_cast<int>(std::ceil (g->V1 * atlas_h)), 0, atlas_h);
        const int sw = std::max(1, src_x1 - src_x0);
        const int sh = std::max(1, src_y1 - src_y0);

        for (int y = 0; y < gh; ++y) {
            const int dy = dst_y0 + y;
            if (dy < 0 || dy >= out_h) continue;
            const float ty = (gh > 1) ? (static_cast<float>(y) / static_cast<float>(gh - 1)) : 0.0f;
            const int sy = src_y0 + std::clamp(static_cast<int>(std::round(ty * (sh - 1))), 0, sh - 1);
            for (int x = 0; x < gw; ++x) {
                const int dx = dst_x0 + x;
                if (dx < 0 || dx >= out_w) continue;
                const float tx = (gw > 1) ? (static_cast<float>(x) / static_cast<float>(gw - 1)) : 0.0f;
                const int sx = src_x0 + std::clamp(static_cast<int>(std::round(tx * (sw - 1))), 0, sw - 1);
                const unsigned char a = atlas_a8[sy * atlas_w + sx];
                if (!a) continue;
                const size_t di = (static_cast<size_t>(dy) * static_cast<size_t>(out_w) + static_cast<size_t>(dx)) * 4u;
                rgba[di + 0] = 255;
                rgba[di + 1] = 255;
                rgba[di + 2] = 255;
                if (a > rgba[di + 3]) rgba[di + 3] = a;
            }
        }

        pen += g->AdvanceX;
    }

    for (size_t i = 3; i < rgba.size(); i += 4) {
        if (rgba[i] != 0) ++out_written_alpha_px;
    }

    std::remove(out_path);
    errno = 0;
    const int ok = stbi_write_png(out_path, out_w, out_h, 4, rgba.data(), out_w * 4);
    out_errno = errno;
    return ok != 0;
}

bool ExportUiTextSetPngs(
    float font_size_px,
    const char* out_dir,
    int& out_ok_count,
    int& out_fail_count,
    int& out_errno) {
    out_ok_count = 0;
    out_fail_count = 0;
    out_errno = 0;
    if (!out_dir || !*out_dir) {
        return false;
    }
    if (!EnsureDirRecursive(out_dir)) {
        out_errno = errno;
        return false;
    }

    struct TextFileEntry {
        const char* file_name;
        const char* text;
    };
    const TextFileEntry entries[] = {
        {"logo_project.png", "Проект"},
        {"logo_yor.png", "«Йор»"},
        {"tab_aimbot.png", "Aimbot"},
        {"tab_movement.png", "Movement"},
        {"tab_render.png", "Render"},
        {"tab_misc.png", "Misc"},
        {"tab_config.png", "Config"},
        {"tab_hud.png", "HUD"},
    };

    std::string base(out_dir);
    if (!base.empty() && base.back() != '/') {
        base.push_back('/');
    }

    for (const auto& e : entries) {
        std::string path = base + e.file_name;
        int w = 0, h = 0, err = 0;
        size_t alpha_px = 0;
        const bool ok = ExportSingleTextPng(font_size_px, e.text, path.c_str(), w, h, alpha_px, err);
        if (ok) {
            ++out_ok_count;
        } else {
            ++out_fail_count;
            out_errno = err;
        }
    }
    return out_fail_count == 0;
}

} // namespace LogoTextExport
