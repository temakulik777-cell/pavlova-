#pragma once

#include <functional>
#include <vector>

struct RenderContext;

struct RenderPass {
    const char* name = nullptr;
    std::function<void(RenderContext&)> fn;
};

class Pipeline {
public:
    void Clear();
    void AddPass(std::function<void(RenderContext&)> fn, const char* name = nullptr);
    void Execute(RenderContext& context);

private:
    std::vector<RenderPass> passes_;
};
