#include "pipeline.h"
#include "render_context.h"

void Pipeline::Clear() {
    passes_.clear();
}

void Pipeline::AddPass(std::function<void(RenderContext&)> fn, const char* name) {
    if (!fn) {
        return;
    }
    RenderPass pass;
    pass.name = name;
    pass.fn = std::move(fn);
    passes_.push_back(std::move(pass));
}

void Pipeline::Execute(RenderContext& context) {
    for (auto& pass : passes_) {
        if (pass.fn) {
            pass.fn(context);
        }
    }
}
