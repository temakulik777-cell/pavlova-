#pragma once

#include "../../imgui/imgui.h"

struct ClickGUI;

struct RenderContext {
    ClickGUI* gui = nullptr;
    ImGuiIO* io = nullptr;

    ImDrawList* bg_draw_list = nullptr;
    ImDrawList* fg_draw_list = nullptr;
    ImDrawList* win_draw_list = nullptr;

    ImVec2 clamped_window_pos = ImVec2(0, 0);
    ImVec2 window_pos = ImVec2(0, 0);
    ImVec2 window_size = ImVec2(0, 0);

    int gl_width = 0;
    int gl_height = 0;
    int clamped_window_width = 0;
    int clamped_window_height = 0;
    int final_clamped_window_width = 0;
    int final_clamped_window_height = 0;

    float sidebar_width = 0.0f;
    float scale_effect = 1.0f;
    float window_padding_x = 0.0f;

    ImU32 sidebar_color = 0;
    ImU32 main_area_color = 0;
    ImU32 bg_color = 0;

    bool should_render_transparent = false;
    bool blur_enabled = false;
    float blur_alpha = 0.0f;
    float ui_scale = 1.0f;
    float anim_raw = 0.0f;
    float anim_t = 0.0f;
    float alpha_t = 0.0f;
    float visual_t = 0.0f;
    bool menu_visible = false;
};
