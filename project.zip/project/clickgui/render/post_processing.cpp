#include "post_processing.h"
#include <algorithm>
#include <cmath>
#include <map>
#include <mutex>
#include <vector>
#include <chrono>
#include <string>
#include <unordered_map>
#include <memory>
#include <cstdio>
#include <cstdarg>
#include <cerrno>
#include <cstring>
#include <cstddef>
#include "../imgui/imgui.h"
#include "../imgui/imgui_internal.h"
#include "../imgui/backends/imgui_impl_opengl3.h"
#include "../imgui/im_anim/im_anim.h"
#include "logo_text_export.h"
#include "../../assets/images.h"
#include "../../assets/fonts/montserrat.h"
#include "../../axlebolt/player_controller.h"
#include "../../good_luck/stb/stb_image.h"
#define STB_IMAGE_WRITE_IMPLEMENTATION
#include "../../good_luck/stb/stb_image_write.h"
#include "../clickgui.h"
#include "../widgets/wigdets.h"
#include "../../unity_engine/Input/Touch.h"
extern int glHeight;
extern int glWidth;

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif
#ifndef GL_DEPTH_WRITEMASK
#define GL_DEPTH_WRITEMASK 0x0B72
#endif

PostProcessing post_processing;
TabMorphFxState tabMorphFx;

static GLuint CreateProgram(const char* vs_src, const char* fs_src);

namespace {
static inline float GetUiScaleForFx() {
    const float font_scale = ImGui::GetIO().FontGlobalScale;
    return (font_scale != 0.0f) ? (font_scale / 0.75f) : 1.0f;
}

static inline float GetEffectiveCornerRadius(const ClickGUI* gui) {
    if (!gui || !gui->theme) {
        return 19.5f;
    }
    const float raw = std::max(0.0f, gui->theme->style.CornerRadius);
    const float ui_scale = (gui->cache.uiScale > 0.0f) ? gui->cache.uiScale : GetUiScaleForFx();
    const float k = std::clamp(ui_scale / 1.30f, 0.45f, 2.25f);
    return raw * k;
}

inline bool IsValidRegionForDraw(const ImageRegion& uv) {
    const bool finite =
        std::isfinite(uv.u_min) && std::isfinite(uv.v_min) &&
        std::isfinite(uv.u_max) && std::isfinite(uv.v_max);
    if (!finite) {
        return false;
    }
    if (!(uv.u_max > uv.u_min) || !(uv.v_max > uv.v_min)) {
        return false;
    }
    if (uv.u_min < 0.0f || uv.v_min < 0.0f || uv.u_max > 1.0f || uv.v_max > 1.0f) {
        return false;
    }
    return true;
}

static float MeasureTextWidth(ImFontBaked* baked, const char* text, float scale_mul) {
    if (!baked || !text || !*text) {
        return 0.0f;
    }
    const ImFontGlyph* fallback_glyph = nullptr;
    if (baked->FallbackGlyphIndex >= 0 && baked->FallbackGlyphIndex < baked->Glyphs.Size) {
        fallback_glyph = &baked->Glyphs[baked->FallbackGlyphIndex];
    }
    if (!fallback_glyph && '?' >= 0 && '?' < baked->IndexLookup.Size) {
        const int gi = baked->IndexLookup['?'];
        if (gi >= 0 && gi < baked->Glyphs.Size) {
            fallback_glyph = &baked->Glyphs[gi];
        }
    }
    auto get_glyph_no_load = [&](ImWchar c) -> const ImFontGlyph* {
        if (c >= 0 && c < baked->IndexLookup.Size) {
            const int gi = baked->IndexLookup[c];
            if (gi >= 0 && gi < baked->Glyphs.Size) {
                return &baked->Glyphs[gi];
            }
        }
        return fallback_glyph;
    };
    float x = 0.0f;
    const char* p = text;
    while (*p) {
        unsigned int c = 0;
        int consumed = ImTextCharFromUtf8(&c, p, nullptr);
        if (consumed <= 0 || c == 0) {
            break;
        }
        p += consumed;
        const ImFontGlyph* g = get_glyph_no_load(static_cast<ImWchar>(c));
        if (g) {
            x += g->AdvanceX * scale_mul;
        } else {
            x += baked->FallbackAdvanceX * scale_mul;
        }
    }
    return x;
}

struct ExportTextVertex {
    float x;
    float y;
    float u;
    float v;
};

static GLuint g_export_text_prog = 0;
static GLint g_export_text_u_size = -1;
static GLint g_export_text_u_tex = -1;

static bool EnsureExportTextProgram() {
    if (g_export_text_prog != 0) {
        return true;
    }
    static const char* kVs = R"(#version 300 es
layout(location=0) in vec2 aPos;
layout(location=1) in vec2 aUV;
uniform vec2 uSize;
out vec2 vUV;
void main() {
    vec2 ndc = vec2((aPos.x / uSize.x) * 2.0 - 1.0, 1.0 - (aPos.y / uSize.y) * 2.0);
    gl_Position = vec4(ndc, 0.0, 1.0);
    vUV = aUV;
}
)";
static const char* kFs = R"(#version 300 es
precision mediump float;
in vec2 vUV;
uniform sampler2D uTex;
out vec4 FragColor;
void main() {
    vec4 t = texture(uTex, vUV);
    float a = max(t.r, t.a);
    FragColor = vec4(1.0, 1.0, 1.0, a);
}
)";
    g_export_text_prog = ::CreateProgram(kVs, kFs);
    if (g_export_text_prog == 0) {
        return false;
    }
    g_export_text_u_size = glGetUniformLocation(g_export_text_prog, "uSize");
    g_export_text_u_tex = glGetUniformLocation(g_export_text_prog, "uTex");
    return true;
}

static void AppendTextVertices(
    ImFontBaked* baked,
    const char* text,
    float x_start,
    float baseline_y,
    float scale_mul,
    std::vector<ExportTextVertex>& out) {
    if (!baked || !text || !*text) {
        return;
    }
    const ImFontGlyph* fallback_glyph = nullptr;
    if (baked->FallbackGlyphIndex >= 0 && baked->FallbackGlyphIndex < baked->Glyphs.Size) {
        fallback_glyph = &baked->Glyphs[baked->FallbackGlyphIndex];
    }
    auto get_glyph_no_load = [&](ImWchar c) -> const ImFontGlyph* {
        if (c >= 0 && c < baked->IndexLookup.Size) {
            const int gi = baked->IndexLookup[c];
            if (gi >= 0 && gi < baked->Glyphs.Size) {
                return &baked->Glyphs[gi];
            }
        }
        return fallback_glyph;
    };

    float pen_x = x_start;
    const char* p = text;
    while (*p) {
        unsigned int c = 0;
        int consumed = ImTextCharFromUtf8(&c, p, nullptr);
        if (consumed <= 0 || c == 0) {
            break;
        }
        p += consumed;
        const ImFontGlyph* g = get_glyph_no_load(static_cast<ImWchar>(c));
        if (!g) {
            pen_x += baked->FallbackAdvanceX * scale_mul;
            continue;
        }
        const float x0 = pen_x + g->X0 * scale_mul;
        const float y0 = baseline_y + g->Y0 * scale_mul;
        const float x1 = pen_x + g->X1 * scale_mul;
        const float y1 = baseline_y + g->Y1 * scale_mul;
        const float u0 = g->U0;
        const float v0 = g->V0;
        const float u1 = g->U1;
        const float v1 = g->V1;

        out.push_back({x0, y0, u0, v0});
        out.push_back({x1, y0, u1, v0});
        out.push_back({x1, y1, u1, v1});
        out.push_back({x0, y0, u0, v0});
        out.push_back({x1, y1, u1, v1});
        out.push_back({x0, y1, u0, v1});

        pen_x += g->AdvanceX * scale_mul;
    }
}
} 

PostProcessing::PostProcessing()
    : blur(std::make_unique<Blur>(Hardware::GPU)) {
    
    color_grading.presets[0] = ColorGradingPreset{1.00f, 1.00f, 0.000f, 0.00f, 1.00f, 1.00f, 1.00f, 1.00f};
    
    color_grading.presets[1] = ColorGradingPreset{0.88f, 1.10f, -0.015f, 0.08f, 1.03f, 1.00f, 0.97f, 0.92f};
    
    color_grading.presets[2] = ColorGradingPreset{1.25f, 1.06f, 0.008f, 0.20f, 0.98f, 1.00f, 1.00f, 1.00f};
    
    color_grading.presets[3] = ColorGradingPreset{1.08f, 1.04f, 0.005f, 0.10f, 0.99f, 1.06f, 1.00f, 0.93f};
    
    color_grading.presets[4] = ColorGradingPreset{1.03f, 1.05f, -0.004f, 0.08f, 1.00f, 0.92f, 0.98f, 1.08f};
    
    color_grading.presets[5] = ColorGradingPreset{0.00f, 1.20f, -0.010f, 0.00f, 1.05f, 1.00f, 1.00f, 1.00f};
    
    color_grading.presets[6] = ColorGradingPreset{0.92f, 0.96f, 0.020f, 0.06f, 0.95f, 1.02f, 0.98f, 1.06f};
    
    color_grading.presets[7] = ColorGradingPreset{1.18f, 1.12f, -0.006f, 0.28f, 1.02f, 0.92f, 1.07f, 0.90f};
    color_grading.current = color_grading.presets[0];
}

bool PostProcessing::ExportLogoTextPng(ImFont* font, float font_size, const char* out_path) const {
    if (!font || !font->OwnerAtlas || !out_path || !*out_path) {
        return false;
    }
    int out_w = 0;
    int out_h = 0;
    size_t written_px = 0;
    int write_errno = 0;
    const bool ok = LogoTextExport::ExportMontserratLogoPng(
        font_size * 3.0f,
        "«Йор»",
        "Проект",
        out_path,
        out_w,
        out_h,
        written_px,
        write_errno);
    return ok;
}

bool PostProcessing::ExportUiTextGlowPngs(ImFont* font, float font_size, const char* out_dir) const {
    if (!font || !font->OwnerAtlas || !out_dir || !*out_dir) {
        return false;
    }
    int ok_count = 0;
    int fail_count = 0;
    int write_errno = 0;
    const bool ok = LogoTextExport::ExportUiTextSetPngs(
        font_size * 3.0f,
        out_dir,
        ok_count,
        fail_count,
        write_errno);
    return ok;
}

void PostProcessing::BeginFadeMaskBlendCallback(const ImDrawList*, const ImDrawCmd*) {
    glEnable(GL_BLEND);
    glBlendEquation(GL_FUNC_ADD);
    glBlendFunc(GL_ZERO, GL_ONE_MINUS_SRC_ALPHA);
}

void PostProcessing::BeginFadeBackgroundAddCallback(const ImDrawList*, const ImDrawCmd*) {
    glEnable(GL_BLEND);
    glBlendEquation(GL_FUNC_ADD);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE);
}

static GLuint CreateShader(GLenum type, const char* src) {
    if (!glCreateShader || !glShaderSource || !glCompileShader || !glGetShaderiv) {
        return 0;
    }
    GLuint shader = glCreateShader(type);
    if (!shader) {
        return 0;
    }
    glShaderSource(shader, 1, &src, nullptr);
    glCompileShader(shader);
    GLint status = GL_FALSE;
    glGetShaderiv(shader, GL_COMPILE_STATUS, &status);
    if (status != GL_TRUE) {
        if (glDeleteShader) {
            glDeleteShader(shader);
        }
        return 0;
    }
    return shader;
}

static GLuint CreateProgram(const char* vs_src, const char* fs_src) {
    if (!glCreateProgram || !glAttachShader || !glLinkProgram || !glGetProgramiv) {
        return 0;
    }
    GLuint vs = CreateShader(GL_VERTEX_SHADER, vs_src);
    GLuint fs = CreateShader(GL_FRAGMENT_SHADER, fs_src);
    if (!vs || !fs) {
        if (vs && glDeleteShader) glDeleteShader(vs);
        if (fs && glDeleteShader) glDeleteShader(fs);
        return 0;
    }
    GLuint prog = glCreateProgram();
    if (!prog) {
        if (glDeleteShader) { glDeleteShader(vs); glDeleteShader(fs); }
        return 0;
    }
    glAttachShader(prog, vs);
    glAttachShader(prog, fs);
    glLinkProgram(prog);
    GLint status = GL_FALSE;
    glGetProgramiv(prog, GL_LINK_STATUS, &status);
    if (glDeleteShader) { glDeleteShader(vs); glDeleteShader(fs); }
    if (status != GL_TRUE) {
        if (glDeleteProgram) glDeleteProgram(prog);
        return 0;
    }
    return prog;
}

static void SetupTexture(GLuint tex, int w, int h) {
    glBindTexture(GL_TEXTURE_2D, tex);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, nullptr);
}

static const char* kBlurVS = R"(#version 300 es
layout(location=0) in vec2 aPos;
layout(location=1) in vec2 aUV;
out vec2 vUV;
void main() {
    vUV = aUV;
    gl_Position = vec4(aPos, 0.0, 1.0);
}
)";

static const char* kBlurFS = R"(#version 300 es
precision highp float;
in vec2 vUV;
uniform sampler2D uTex;
uniform vec2 uDirection;
uniform vec2 uTexel;
out vec4 FragColor;
void main() {
    vec2 off = uDirection * uTexel;
    vec4 c = texture(uTex, vUV) * 0.227027;
    c += texture(uTex, vUV + off * 1.384615) * 0.316216;
    c += texture(uTex, vUV - off * 1.384615) * 0.316216;
    c += texture(uTex, vUV + off * 3.230769) * 0.070270;
    c += texture(uTex, vUV - off * 3.230769) * 0.070270;
    FragColor = c;
}
)";

namespace {
static GLuint g_fade_mix_prog = 0;
static GLuint g_fade_mix_tex = 0;
static GLuint g_fade_mix_fbo = 0;
static Blur g_fade_inner_blur(Hardware::GPU);
static int g_fade_mix_w = 0;
static int g_fade_mix_h = 0;
static GLint g_fade_mix_u_tex_edge = -1;
static GLint g_fade_mix_u_tex_inner = -1;
static GLint g_fade_mix_u_rect_uv_min = -1;
static GLint g_fade_mix_u_rect_uv_max = -1;
static GLint g_fade_mix_u_band = -1;
static GLint g_fade_mix_u_top_alpha = -1;
static GLint g_fade_mix_u_bottom_alpha = -1;
static bool EnsureFadeMixResources(int width, int height);
}

void PostProcessing::RenderBlur(ImDrawList* draw_list, const ImVec2& window_pos, int sidebar_width,
                                int sidebar_height, float alpha, bool scalled, float corner_radius,
                                int downscale_factor, float blur_radius, Blur::Type blur_type, const ImVec4& tint_color,
                                ImDrawFlags corner_flags) {
    if (!flags.blur || !draw_list || !blur) {
        return;
    }
    if (alpha <= 0.001f) {
        return;
    }

    if (sidebar_width <= 0 || sidebar_height <= 0) {
        return;
    }
    if (glWidth <= 0 || glHeight <= 0) {
        return;
    }

    const float x0 = window_pos.x;
    const float y0 = window_pos.y;
    const float x1 = window_pos.x + (float)sidebar_width;
    const float y1 = window_pos.y + (float)sidebar_height;
    const float ds_scale = (float)std::max(1, downscale_factor);
    const float pad_f = std::max(8.0f, ((blur_radius * 2.0f) + 6.0f) * ds_scale + 12.0f);
    const int pad = std::max(1, (int)std::ceil(pad_f));
    const int cap_x0 = std::max(0, (int)std::floor(x0) - pad);
    const int cap_y0 = std::max(0, (int)std::floor(y0) - pad);
    const int cap_x1 = std::min(glWidth, (int)std::ceil(x1) + pad);
    const int cap_y1 = std::min(glHeight, (int)std::ceil(y1) + pad);
    const int cap_w = std::max(0, cap_x1 - cap_x0);
    const int cap_h = std::max(0, cap_y1 - cap_y0);
    if (cap_w <= 0 || cap_h <= 0) {
        return;
    }
    const int read_x = cap_x0;
    const int read_y = glHeight - cap_y1;

    blur->backend = Hardware::GPU;
    blur->type = blur_type;

    const int frame = ImGui::GetFrameCount();
    const int screen_area = std::max(1, glWidth * glHeight);
    const int capture_area = std::max(1, cap_w * cap_h);
    const bool large_region = capture_area >= (screen_area / 6);
    static int s_last_large_blur_capture_frame = -10000;
    bool refresh_capture = true;
    if (!scalled && large_region && blur->tex != 0) {
        if (frame - s_last_large_blur_capture_frame < 2) {
            refresh_capture = false;
        } else {
            s_last_large_blur_capture_frame = frame;
        }
    }
    if (refresh_capture) {
        int effective_downscale = std::max(1, downscale_factor);
        if (!scalled && large_region) {
            effective_downscale = std::max(effective_downscale, downscale_factor + 1);
        }
        blur->process(read_x, read_y, cap_w, cap_h, blur_radius, effective_downscale);
    }
    if (blur->tex == 0) {
        return;
    }

    const float u0 = std::clamp((x0 - (float)cap_x0) / (float)cap_w, 0.0f, 1.0f);
    const float u1 = std::clamp((x1 - (float)cap_x0) / (float)cap_w, 0.0f, 1.0f);
    const float v_top = std::clamp(1.0f - ((y0 - (float)cap_y0) / (float)cap_h), 0.0f, 1.0f);
    const float v_bottom = std::clamp(1.0f - ((y1 - (float)cap_y0) / (float)cap_h), 0.0f, 1.0f);

    ImVec4 final_tint = tint_color;
    final_tint.w *= alpha;
    draw_list->AddImageRounded(
        (void*)(intptr_t)blur->tex,
        ImVec2(window_pos.x, window_pos.y),
        ImVec2(window_pos.x + sidebar_width, window_pos.y + sidebar_height),
        ImVec2(u0, v_top),
        ImVec2(u1, v_bottom),
        ImGui::GetColorU32(final_tint),
        corner_radius,
        corner_flags
    );
}

void PostProcessing::RenderBlurGradientFade(ImDrawList* draw_list, const ImVec2& rect_min, const ImVec2& rect_size,
                                            float gradient_h, float top_alpha, float bottom_alpha,
                                            int downscale_factor, float blur_radius, Blur::Type blur_type,
                                            float corner_radius) {
    if (!draw_list || !flags.blur || !blur) {
        return;
    }
    if (gradient_h <= 0.0f || rect_size.x <= 1.0f || rect_size.y <= 1.0f) {
        return;
    }
    if (top_alpha <= 0.001f && bottom_alpha <= 0.001f) {
        return;
    }
    if (glWidth <= 0 || glHeight <= 0) {
        return;
    }

    const float x0 = rect_min.x;
    const float y0 = rect_min.y;
    const float x1 = rect_min.x + rect_size.x;
    const float y1 = rect_min.y + rect_size.y;
    const int ds_fixed = std::max(1, downscale_factor);
    const float max_radius = std::max(0.9f, blur_radius * 0.82f);
    const float min_radius = std::max(0.55f, blur_radius * 0.10f);
    const float ds_scale = (float)ds_fixed;
    const float pad_f = std::max(8.0f, ((blur_radius * 2.0f) + 6.0f) * ds_scale + 12.0f);
    const int pad = std::max(1, (int)std::ceil(pad_f));
    const int cap_x0 = std::max(0, (int)std::floor(x0) - pad);
    const int cap_y0 = std::max(0, (int)std::floor(y0) - pad);
    const int cap_x1 = std::min(glWidth, (int)std::ceil(x1) + pad);
    const int cap_y1 = std::min(glHeight, (int)std::ceil(y1) + pad);
    const int cap_w = std::max(0, cap_x1 - cap_x0);
    const int cap_h = std::max(0, cap_y1 - cap_y0);
    if (cap_w <= 0 || cap_h <= 0) {
        return;
    }
    const int read_x = cap_x0;
    const int read_y = glHeight - cap_y1;
    const float u0 = std::clamp((x0 - (float)cap_x0) / (float)cap_w, 0.0f, 1.0f);
    const float u1 = std::clamp((x1 - (float)cap_x0) / (float)cap_w, 0.0f, 1.0f);
    const float v_top = std::clamp(1.0f - ((y0 - (float)cap_y0) / (float)cap_h), 0.0f, 1.0f);
    const float v_bottom = std::clamp(1.0f - ((y1 - (float)cap_y0) / (float)cap_h), 0.0f, 1.0f);
    const float inv_h = 1.0f / std::max(1.0f, rect_size.y);
    const float strip_h = std::min(gradient_h, rect_size.y * 0.5f);
    const int steps = 22;

    auto map_v = [&](float y) {
        const float t = std::clamp((y - y0) * inv_h, 0.0f, 1.0f);
        return v_top + (v_bottom - v_top) * t;
    };
    auto smooth = [](float t) {
        t = std::clamp(t, 0.0f, 1.0f);
        return t * t * (3.0f - 2.0f * t);
    };

    blur->backend = Hardware::GPU;
    blur->type = blur_type;
    draw_list->PushClipRect(ImVec2(x0, y0), ImVec2(x1, y1), true);

    for (int i = 0; i < steps; ++i) {
        const float t0 = (float)i / (float)steps;
        const float t1 = (float)(i + 1) / (float)steps;
        const float tm = (t0 + t1) * 0.5f;
        const float edge_strength = std::pow(smooth(1.0f - tm), 0.92f);
        const float radius = min_radius + (max_radius - min_radius) * edge_strength;
        blur->process(read_x, read_y, cap_w, cap_h, radius, ds_fixed);
        const GLuint tex = blur->tex;
        if (!tex) {
            continue;
        }

        const float top_a = std::pow(edge_strength, 1.35f) * std::clamp(top_alpha, 0.0f, 1.0f);
        if (top_a > 0.001f) {
            const float ya = y0 + strip_h * t0 - 0.3f;
            const float yb = y0 + strip_h * t1 + 0.3f;
            ImU32 col = ImGui::GetColorU32(ImVec4(1.0f, 1.0f, 1.0f, top_a));
            if (i == 0 && corner_radius > 0.0f) {
                draw_list->AddImageRounded((void*)(intptr_t)tex, ImVec2(x0, ya), ImVec2(x1, yb),
                                           ImVec2(u0, map_v(ya)), ImVec2(u1, map_v(yb)), col,
                                           corner_radius, ImDrawFlags_RoundCornersTop);
            } else {
                draw_list->AddImage((void*)(intptr_t)tex, ImVec2(x0, ya), ImVec2(x1, yb),
                                    ImVec2(u0, map_v(ya)), ImVec2(u1, map_v(yb)), col);
            }
        }

        const float bottom_a = std::pow(edge_strength, 1.35f) * std::clamp(bottom_alpha, 0.0f, 1.0f);
        if (bottom_a > 0.001f) {
            const float ya = y1 - strip_h * t1 - 0.3f;
            const float yb = y1 - strip_h * t0 + 0.3f;
            ImU32 col = ImGui::GetColorU32(ImVec4(1.0f, 1.0f, 1.0f, bottom_a));
            if (i == 0 && corner_radius > 0.0f) {
                draw_list->AddImageRounded((void*)(intptr_t)tex, ImVec2(x0, ya), ImVec2(x1, yb),
                                           ImVec2(u0, map_v(ya)), ImVec2(u1, map_v(yb)), col,
                                           corner_radius, ImDrawFlags_RoundCornersBottom);
            } else {
                draw_list->AddImage((void*)(intptr_t)tex, ImVec2(x0, ya), ImVec2(x1, yb),
                                    ImVec2(u0, map_v(ya)), ImVec2(u1, map_v(yb)), col);
            }
        }
    }

    draw_list->PopClipRect();
}

namespace {
static GLuint g_cg_prog = 0;
static GLuint g_cg_src_tex = 0;
static int g_cg_w = 0;
static int g_cg_h = 0;
static GLint g_cg_u_tex = -1;
static GLint g_cg_u_saturation = -1;
static GLint g_cg_u_contrast = -1;
static GLint g_cg_u_brightness = -1;
static GLint g_cg_u_vibrance = -1;
static GLint g_cg_u_gamma = -1;
static GLint g_cg_u_tint = -1;

static const char* kColorGradingVS = R"(#version 300 es
out vec2 vUV;
void main() {
    vec2 pos[4] = vec2[](
        vec2(-1.0, -1.0),
        vec2( 1.0, -1.0),
        vec2(-1.0,  1.0),
        vec2( 1.0,  1.0)
    );
    vec2 uv[4] = vec2[](
        vec2(0.0, 0.0),
        vec2(1.0, 0.0),
        vec2(0.0, 1.0),
        vec2(1.0, 1.0)
    );
    int idx = gl_VertexID & 3;
    vUV = uv[idx];
    gl_Position = vec4(pos[idx], 0.0, 1.0);
}
)";

static const char* kColorGradingFS = R"(#version 300 es
precision mediump float;
in vec2 vUV;
uniform sampler2D uTex;
uniform float uSaturation;
uniform float uContrast;
uniform float uBrightness;
uniform float uVibrance;
uniform float uGamma;
uniform vec3 uTint;
out vec4 FragColor;
void main() {
    vec4 src = texture(uTex, vUV);
    vec3 c = src.rgb;
    float lum = dot(c, vec3(0.2126, 0.7152, 0.0722));
    c = mix(vec3(lum), c, max(0.0, uSaturation));
    c = (c - 0.5) * uContrast + 0.5;
    float mx = max(c.r, max(c.g, c.b));
    c = mix(c, vec3(mx), uVibrance);
    c += vec3(uBrightness);
    c *= uTint;
    float invGamma = 1.0 / max(0.001, uGamma);
    c = pow(max(c, 0.0), vec3(invGamma));
    FragColor = vec4(clamp(c, 0.0, 1.0), src.a);
}
)";

static const char* kFadeMixVS = R"(#version 300 es
out vec2 vUV;
void main() {
    vec2 pos[4] = vec2[](
        vec2(-1.0, -1.0),
        vec2( 1.0, -1.0),
        vec2(-1.0,  1.0),
        vec2( 1.0,  1.0)
    );
    vec2 uv[4] = vec2[](
        vec2(0.0, 0.0),
        vec2(1.0, 0.0),
        vec2(0.0, 1.0),
        vec2(1.0, 1.0)
    );
    int idx = gl_VertexID & 3;
    vUV = uv[idx];
    gl_Position = vec4(pos[idx], 0.0, 1.0);
}
)";

static const char* kFadeMixFS = R"(#version 300 es
precision mediump float;
in vec2 vUV;
uniform sampler2D uTexEdge;
uniform sampler2D uTexInner;
uniform vec2 uRectUVMin;
uniform vec2 uRectUVMax;
uniform float uBand;
uniform float uTopAlpha;
uniform float uBottomAlpha;
out vec4 FragColor;
void main() {
    vec2 srcUV = mix(uRectUVMin, uRectUVMax, vUV);
    vec3 edgeRGB = texture(uTexEdge, srcUV).rgb;
    vec3 innerRGB = texture(uTexInner, srcUV).rgb;
    float band = max(0.0001, uBand);
    float topT = clamp(1.0 - (vUV.y / band), 0.0, 1.0);
    float bottomT = clamp(1.0 - ((1.0 - vUV.y) / band), 0.0, 1.0);
    float topW = topT * topT * (3.0 - 2.0 * topT);
    float bottomW = bottomT * bottomT * (3.0 - 2.0 * bottomT);
    float edgeW = max(topW * uTopAlpha, bottomW * uBottomAlpha);
    edgeW = pow(edgeW, 0.75);
    edgeW = smoothstep(0.08, 1.0, edgeW);
    vec3 rgb = mix(innerRGB, edgeRGB, edgeW);
    float a = edgeW * edgeW * edgeW;
    if (a < 0.003) a = 0.0;
    FragColor = vec4(rgb, clamp(a, 0.0, 1.0));
}
)";

static bool EnsureFadeMixResources(int width, int height) {
    if (width <= 0 || height <= 0) {
        return false;
    }
    if (!glDrawArrays || !glUseProgram || !glBindTexture || !glActiveTexture ||
        !glGenTextures || !glTexImage2D || !glTexParameteri ||
        !glGenFramebuffers || !glBindFramebuffer || !glFramebufferTexture2D) {
        return false;
    }

    if (g_fade_mix_prog == 0) {
        g_fade_mix_prog = CreateProgram(kFadeMixVS, kFadeMixFS);
        if (g_fade_mix_prog == 0) {
            return false;
        }
        g_fade_mix_u_tex_edge = glGetUniformLocation(g_fade_mix_prog, "uTexEdge");
        g_fade_mix_u_tex_inner = glGetUniformLocation(g_fade_mix_prog, "uTexInner");
        g_fade_mix_u_rect_uv_min = glGetUniformLocation(g_fade_mix_prog, "uRectUVMin");
        g_fade_mix_u_rect_uv_max = glGetUniformLocation(g_fade_mix_prog, "uRectUVMax");
        g_fade_mix_u_band = glGetUniformLocation(g_fade_mix_prog, "uBand");
        g_fade_mix_u_top_alpha = glGetUniformLocation(g_fade_mix_prog, "uTopAlpha");
        g_fade_mix_u_bottom_alpha = glGetUniformLocation(g_fade_mix_prog, "uBottomAlpha");
    }

    if (g_fade_mix_tex == 0) {
        glGenTextures(1, &g_fade_mix_tex);
    }
    glBindTexture(GL_TEXTURE_2D, g_fade_mix_tex);
    if (g_fade_mix_w != width || g_fade_mix_h != height) {
        g_fade_mix_w = width;
        g_fade_mix_h = height;
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, g_fade_mix_w, g_fade_mix_h, 0, GL_RGBA, GL_UNSIGNED_BYTE, nullptr);
    }
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

    if (g_fade_mix_fbo == 0) {
        glGenFramebuffers(1, &g_fade_mix_fbo);
    }
    glBindFramebuffer(GL_FRAMEBUFFER, g_fade_mix_fbo);
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, g_fade_mix_tex, 0);

    return true;
}

static bool EnsureColorGradingResources(int width, int height) {
    if (width <= 0 || height <= 0) {
        return false;
    }
    if (!glDrawArrays || !glCopyTexSubImage2D || !glGetIntegerv || !glUseProgram || !glBindTexture) {
        return false;
    }

    if (g_cg_prog == 0) {
        g_cg_prog = CreateProgram(kColorGradingVS, kColorGradingFS);
        if (g_cg_prog == 0) {
            return false;
        }
        g_cg_u_tex = glGetUniformLocation(g_cg_prog, "uTex");
        g_cg_u_saturation = glGetUniformLocation(g_cg_prog, "uSaturation");
        g_cg_u_contrast = glGetUniformLocation(g_cg_prog, "uContrast");
        g_cg_u_brightness = glGetUniformLocation(g_cg_prog, "uBrightness");
        g_cg_u_vibrance = glGetUniformLocation(g_cg_prog, "uVibrance");
        g_cg_u_gamma = glGetUniformLocation(g_cg_prog, "uGamma");
        g_cg_u_tint = glGetUniformLocation(g_cg_prog, "uTint");
    }

    if (g_cg_src_tex == 0) {
        glGenTextures(1, &g_cg_src_tex);
    }
    glBindTexture(GL_TEXTURE_2D, g_cg_src_tex);
    if (g_cg_w != width || g_cg_h != height) {
        g_cg_w = width;
        g_cg_h = height;
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, g_cg_w, g_cg_h, 0, GL_RGBA, GL_UNSIGNED_BYTE, nullptr);
    }
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    return true;
}
} 

void PostProcessing::ApplyColorGrading(int width, int height) {
    if (!color_grading.enabled) {
        return;
    }
    if (!EnsureColorGradingResources(std::max(1, width), std::max(1, height))) {
        color_grading.enabled = false;
        return;
    }

    if (glGetError) {
        while (glGetError() != 0) {}
    }
    GLint live_viewport[4] = {0, 0, std::max(1, width), std::max(1, height)};
    if (glGetIntegerv) {
        glGetIntegerv(GL_VIEWPORT, live_viewport);
    }
    const int vp_x = live_viewport[0];
    const int vp_y = live_viewport[1];
    const int vp_w = std::max(1, live_viewport[2]);
    const int vp_h = std::max(1, live_viewport[3]);
    if (!EnsureColorGradingResources(vp_w, vp_h)) {
        color_grading.enabled = false;
        return;
    }

    const ColorGradingPreset& p = color_grading.current;

    GLint prev_program = 0;
    GLint prev_tex = 0;
    GLint prev_active_tex = 0;
    GLint prev_fbo = 0;
    GLint prev_scissor_box[4] = {0, 0, 0, 0};
    GLint prev_blend_src_rgb = GL_ONE;
    GLint prev_blend_dst_rgb = GL_ZERO;
    GLint prev_blend_src_alpha = GL_ONE;
    GLint prev_blend_dst_alpha = GL_ZERO;
    GLint prev_blend_eq_rgb = GL_FUNC_ADD;
    GLint prev_blend_eq_alpha = GL_FUNC_ADD;
    GLint prev_viewport[4] = {0, 0, width, height};
    GLboolean prev_scissor = GL_FALSE;
    GLboolean prev_blend = GL_FALSE;
    GLboolean prev_depth = GL_FALSE;
    GLboolean prev_cull = GL_FALSE;
    GLboolean prev_stencil = GL_FALSE;
    GLboolean prev_depth_mask = GL_TRUE;
    GLboolean prev_color_mask[4] = {1, 1, 1, 1};
    if (glGetIntegerv) {
        glGetIntegerv(GL_CURRENT_PROGRAM, &prev_program);
        glGetIntegerv(GL_TEXTURE_BINDING_2D, &prev_tex);
        glGetIntegerv(GL_ACTIVE_TEXTURE, &prev_active_tex);
        glGetIntegerv(GL_FRAMEBUFFER_BINDING, &prev_fbo);
        glGetIntegerv(GL_VIEWPORT, prev_viewport);
        glGetIntegerv(GL_SCISSOR_BOX, prev_scissor_box);
        glGetIntegerv(GL_BLEND_SRC_RGB, &prev_blend_src_rgb);
        glGetIntegerv(GL_BLEND_DST_RGB, &prev_blend_dst_rgb);
        glGetIntegerv(GL_BLEND_SRC_ALPHA, &prev_blend_src_alpha);
        glGetIntegerv(GL_BLEND_DST_ALPHA, &prev_blend_dst_alpha);
        glGetIntegerv(GL_BLEND_EQUATION_RGB, &prev_blend_eq_rgb);
        glGetIntegerv(GL_BLEND_EQUATION_ALPHA, &prev_blend_eq_alpha);
    }
    if (glIsEnabled) {
        prev_scissor = glIsEnabled(GL_SCISSOR_TEST);
        prev_blend = glIsEnabled(GL_BLEND);
        prev_depth = glIsEnabled(GL_DEPTH_TEST);
        prev_cull = glIsEnabled(GL_CULL_FACE);
        prev_stencil = glIsEnabled(GL_STENCIL_TEST);
    }
    if (glGetBooleanv) {
        glGetBooleanv(GL_COLOR_WRITEMASK, prev_color_mask);
        glGetBooleanv(GL_DEPTH_WRITEMASK, &prev_depth_mask);
    }

    
    glBindFramebuffer(GL_FRAMEBUFFER, prev_fbo);
    glBindTexture(GL_TEXTURE_2D, g_cg_src_tex);
    glCopyTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, vp_x, vp_y, vp_w, vp_h);

    glBindFramebuffer(GL_FRAMEBUFFER, prev_fbo);
    glViewport(vp_x, vp_y, vp_w, vp_h);
    glDisable(GL_SCISSOR_TEST);
    glDisable(GL_DEPTH_TEST);
    glDisable(GL_STENCIL_TEST);
    glDisable(GL_CULL_FACE);
    glDisable(GL_BLEND);
    glDepthMask(1);
    glColorMask(GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE);
    glUseProgram(g_cg_prog);
    glUniform1i(g_cg_u_tex, 0);
    glUniform1f(g_cg_u_saturation, std::clamp(p.saturation, 0.0f, 2.5f));
    glUniform1f(g_cg_u_contrast, std::clamp(p.contrast, 0.5f, 2.0f));
    glUniform1f(g_cg_u_brightness, std::clamp(p.brightness, -0.25f, 0.25f));
    glUniform1f(g_cg_u_vibrance, std::clamp(p.vibrance, 0.0f, 1.0f));
    glUniform1f(g_cg_u_gamma, std::clamp(p.gamma, 0.6f, 1.8f));
    glUniform3f(g_cg_u_tint,
                std::clamp(p.tint_r, 0.7f, 1.3f),
                std::clamp(p.tint_g, 0.7f, 1.3f),
                std::clamp(p.tint_b, 0.7f, 1.3f));

    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, g_cg_src_tex);
    glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);

    glUseProgram(prev_program);
    glActiveTexture(prev_active_tex);
    glBindTexture(GL_TEXTURE_2D, prev_tex);
    glBindFramebuffer(GL_FRAMEBUFFER, prev_fbo);
    glViewport(prev_viewport[0], prev_viewport[1], prev_viewport[2], prev_viewport[3]);
    glScissor(prev_scissor_box[0], prev_scissor_box[1], prev_scissor_box[2], prev_scissor_box[3]);
    glBlendFuncSeparate(prev_blend_src_rgb, prev_blend_dst_rgb, prev_blend_src_alpha, prev_blend_dst_alpha);
    glBlendEquationSeparate(prev_blend_eq_rgb, prev_blend_eq_alpha);
    glDepthMask(prev_depth_mask);
    glColorMask(prev_color_mask[0], prev_color_mask[1], prev_color_mask[2], prev_color_mask[3]);
    if (prev_scissor) glEnable(GL_SCISSOR_TEST); else glDisable(GL_SCISSOR_TEST);
    if (prev_blend) glEnable(GL_BLEND); else glDisable(GL_BLEND);
    if (prev_depth) glEnable(GL_DEPTH_TEST); else glDisable(GL_DEPTH_TEST);
    if (prev_cull) glEnable(GL_CULL_FACE); else glDisable(GL_CULL_FACE);
    if (prev_stencil) glEnable(GL_STENCIL_TEST); else glDisable(GL_STENCIL_TEST);

    if (glGetError) {
        GLenum err = glGetError();
        if (err != 0) {
            color_grading.enabled = false;
        }
    }
}

static int DefaultBlurSteps(PostProcessing::RectGlow::Style style) {
    switch (style) {
        case PostProcessing::RectGlow::Style::Slider:
            return 8;
        case PostProcessing::RectGlow::Style::Scrollbar:
            return 6;
        case PostProcessing::RectGlow::Style::Combo:
            return 6;
    }
    return 8;
}

static float StyleIntensityScale(PostProcessing::RectGlow::Style style) {
    if (style == PostProcessing::RectGlow::Style::Combo) {
        return 1.2f;
    }
    return 1.0f;
}

static void RectGlowParams(PostProcessing::RectGlow::Style style, float& expand_x, float& expand_y, float& rounding_base) {
    switch (style) {
        case PostProcessing::RectGlow::Style::Slider:
            expand_x = 20.0f;
            expand_y = 20.0f;
            rounding_base = 7.0f;
            break;
        case PostProcessing::RectGlow::Style::Scrollbar:
            expand_x = 15.0f;
            expand_y = 15.0f;
            rounding_base = 4.0f;
            break;
        case PostProcessing::RectGlow::Style::Combo:
            expand_x = 15.0f;
            expand_y = 15.0f;
            rounding_base = 20.0f;
            break;
    }
}

static void DrawGlowStrip(ImDrawList* draw_list, ImVec2 center, float layer_radius, int glow_strips,
                          const float bright_colors1[3], const float bright_colors2[3], float alpha_factor) {
    for (int strip = 0; strip < glow_strips; strip++) {
        float x_normalized = (float)strip / (glow_strips - 1);
        float t_gradient = x_normalized;

        float r = bright_colors1[0] * (1.0f - t_gradient) + bright_colors2[0] * t_gradient;
        float g = bright_colors1[1] * (1.0f - t_gradient) + bright_colors2[1] * t_gradient;
        float b = bright_colors1[2] * (1.0f - t_gradient) + bright_colors2[2] * t_gradient;

        ImVec4 glow_color = ImVec4(r, g, b, alpha_factor);
        ImU32 glow_col = ImGui::GetColorU32(glow_color);

        float strip_width = 2.0f * layer_radius / glow_strips;
        float strip_x_center_for_drawing = center.x - layer_radius + (strip + 0.5f) * strip_width;

        float dx = (strip_x_center_for_drawing - center.x) / layer_radius;
        if (dx >= -1.0f && dx <= 1.0f) {
            float dy = sqrtf(1.0f - dx * dx);
            float strip_height = dy * layer_radius * 2.0f;

            ImVec2 strip_top = ImVec2(strip_x_center_for_drawing - strip_width * 0.5f, center.y - (strip_height * 0.5f));
            ImVec2 strip_bottom = ImVec2(strip_x_center_for_drawing + strip_width * 0.5f, center.y + (strip_height * 0.5f));

            draw_list->AddRectFilled(strip_top, strip_bottom, glow_col);
        }
    }
}

static void DrawGlowEffect(ImDrawList* draw_list, ImVec2 center, float radius, float outline_padding,
                           float outline_thickness, float glow_blur_steps, const float bright_colors1[3],
                           const float bright_colors2[3], bool glow_enabled) {
    if (!glow_enabled) {
        return;
    }

    const int glow_blur_steps_int = (int)glow_blur_steps;
    for (int i = 1; i <= glow_blur_steps_int; i++) {
        float progress = (float)i / glow_blur_steps;
        float layer_radius = radius + outline_padding + outline_thickness + (progress * 10.0f);
        float alpha_factor = (1.0f - progress) * (1.0f - progress) * 0.12f * 0.25f;

        DrawGlowStrip(draw_list, center, layer_radius, 64, bright_colors1, bright_colors2, alpha_factor);
    }
}

static void DrawCircularOutline(ImDrawList* draw_list, ImVec2 center, float outline_radius,
                                float outline_thickness, const float bright_colors1[3],
                                const float bright_colors2[3], bool glow_enabled) {
    const int segments = 64;
    for (int i = 0; i < segments; i++) {
        float t1 = (float)i / segments;
        float t2 = (float)(i + 1) / segments;

        ImVec2 p1 = ImVec2(
            center.x + cosf(t1 * 2 * M_PI) * outline_radius,
            center.y + sinf(t1 * 2 * M_PI) * outline_radius
        );
        ImVec2 p2 = ImVec2(
            center.x + cosf(t2 * 2 * M_PI) * outline_radius,
            center.y + sinf(t2 * 2 * M_PI) * outline_radius
        );

        float x1_normalized = (p1.x - (center.x - outline_radius)) / (2.0f * outline_radius) * 2.0f - 1.0f;
        float x2_normalized = (p2.x - (center.x - outline_radius)) / (2.0f * outline_radius) * 2.0f - 1.0f;

        float t_gradient1 = (x1_normalized + 1.0f) * 0.5f;
        float t_gradient2 = (x2_normalized + 1.0f) * 0.5f;

        float r1 = bright_colors1[0] * (1.0f - t_gradient1) + bright_colors2[0] * t_gradient1;
        float g1 = bright_colors1[1] * (1.0f - t_gradient1) + bright_colors2[1] * t_gradient1;
        float b1 = bright_colors1[2] * (1.0f - t_gradient1) + bright_colors2[2] * t_gradient1;

        float r2 = bright_colors1[0] * (1.0f - t_gradient2) + bright_colors2[0] * t_gradient2;
        float g2 = bright_colors1[1] * (1.0f - t_gradient2) + bright_colors2[1] * t_gradient2;
        float b2 = bright_colors1[2] * (1.0f - t_gradient2) + bright_colors2[2] * t_gradient2;

        ImVec4 color1 = ImVec4(r1, g1, b1, 0.8f);
        ImVec4 color2 = ImVec4(r2, g2, b2, 0.8f);

        if (glow_enabled) {
            color1.w = 0.9f;
            color2.w = 0.9f;
        }

        draw_list->AddLine(p1, p2, ImGui::GetColorU32(color1), outline_thickness);
    }
}

namespace {
struct DecodedAtlasPixels {
    int width = 0;
    int height = 0;
    std::vector<unsigned char> rgba;
    bool valid = false;
};

static std::unordered_map<int, DecodedAtlasPixels> g_decoded_atlas_cache;

static float ColorLuma(float r, float g, float b) {
    return 0.2126f * r + 0.7152f * g + 0.0722f * b;
}

static float ColorDistanceSq(float r1, float g1, float b1, float r2, float g2, float b2) {
    const float dr = r1 - r2;
    const float dg = g1 - g2;
    const float db = b1 - b2;
    return dr * dr + dg * dg + db * db;
}

static const DecodedAtlasPixels* GetDecodedAtlasPixels(AtlasKind atlas_kind) {
    const int key = static_cast<int>(atlas_kind);
    auto found = g_decoded_atlas_cache.find(key);
    if (found != g_decoded_atlas_cache.end()) {
        return found->second.valid ? &found->second : nullptr;
    }

    DecodedAtlasPixels decoded{};
    const unsigned char* compressed_data = atlas::AtlasData(atlas_kind);
    const int compressed_size = atlas::AtlasDataSize(atlas_kind);
    const int original_size = atlas::AtlasOriginalSize(atlas_kind);
    if (compressed_data && compressed_size > 0) {
        std::vector<unsigned char> png_data = Images::DecompressZlib(
            compressed_data, compressed_size, static_cast<unsigned long>(original_size));
        if (png_data.empty()) {
            png_data.assign(compressed_data, compressed_data + compressed_size);
        }

        int w = 0;
        int h = 0;
        int ch = 0;
        unsigned char* pixels = stbi_load_from_memory(
            png_data.data(),
            static_cast<int>(png_data.size()),
            &w, &h, &ch, STBI_rgb_alpha);
        if (pixels && w > 0 && h > 0) {
            decoded.width = w;
            decoded.height = h;
            decoded.rgba.assign(pixels, pixels + static_cast<size_t>(w * h * 4));
            decoded.valid = true;
        }
        if (pixels) {
            stbi_image_free(pixels);
        }
    }

    auto [it, _] = g_decoded_atlas_cache.emplace(key, std::move(decoded));
    return it->second.valid ? &it->second : nullptr;
}

static void ExtractTwoBrightestColorsFromRegion(
    AtlasKind atlas_kind, const ImVec2& uv_min, const ImVec2& uv_max, float color1[3], float color2[3]) {
    color1[0] = 1.0f; color1[1] = 1.0f; color1[2] = 1.0f;
    color2[0] = 0.80f; color2[1] = 0.80f; color2[2] = 0.80f;

    const DecodedAtlasPixels* atlas_pixels = GetDecodedAtlasPixels(atlas_kind);
    if (!atlas_pixels || atlas_pixels->width <= 0 || atlas_pixels->height <= 0) {
        return;
    }

    const int x0 = std::clamp(static_cast<int>(std::floor(uv_min.x * atlas_pixels->width)), 0, atlas_pixels->width - 1);
    const int y0 = std::clamp(static_cast<int>(std::floor(uv_min.y * atlas_pixels->height)), 0, atlas_pixels->height - 1);
    const int x1 = std::clamp(static_cast<int>(std::ceil(uv_max.x * atlas_pixels->width)) - 1, 0, atlas_pixels->width - 1);
    const int y1 = std::clamp(static_cast<int>(std::ceil(uv_max.y * atlas_pixels->height)) - 1, 0, atlas_pixels->height - 1);
    if (x1 < x0 || y1 < y0) {
        return;
    }

    const int span_x = x1 - x0 + 1;
    const int span_y = y1 - y0 + 1;
    const int step = std::max(1, std::min(span_x, span_y) / 96);

    float best1_r = 1.0f, best1_g = 1.0f, best1_b = 1.0f, best1_score = -1.0f;

    for (int y = y0; y <= y1; y += step) {
        for (int x = x0; x <= x1; x += step) {
            const int idx = (y * atlas_pixels->width + x) * 4;
            const float a = atlas_pixels->rgba[idx + 3] / 255.0f;
            if (a <= 0.03f) {
                continue;
            }
            const float r = atlas_pixels->rgba[idx + 0] / 255.0f;
            const float g = atlas_pixels->rgba[idx + 1] / 255.0f;
            const float b = atlas_pixels->rgba[idx + 2] / 255.0f;
            const float max_c = std::max(r, std::max(g, b));
            const float min_c = std::min(r, std::min(g, b));
            const float sat = (max_c > 0.0001f) ? ((max_c - min_c) / max_c) : 0.0f;
            const float luma = ColorLuma(r, g, b);

            
            if (luma > 0.96f || sat < 0.08f) {
                continue;
            }

            const float score = luma * (0.35f + 0.65f * a);

            if (score > best1_score) {
                best1_r = r; best1_g = g; best1_b = b; best1_score = score;
            }
        }
    }

    if (best1_score > 0.0f) {
        color1[0] = best1_r; color1[1] = best1_g; color1[2] = best1_b;
    }

    
    float cluster_sum_r = 0.0f, cluster_sum_g = 0.0f, cluster_sum_b = 0.0f;
    int cluster_count = 0;
    const float cluster_max_dist_sq = 0.050f; 
    const float cluster_min_luma = best1_score * 0.45f;

    for (int y = y0; y <= y1; y += step) {
        for (int x = x0; x <= x1; x += step) {
            const int idx = (y * atlas_pixels->width + x) * 4;
            const float a = atlas_pixels->rgba[idx + 3] / 255.0f;
            if (a <= 0.03f) {
                continue;
            }
            const float r = atlas_pixels->rgba[idx + 0] / 255.0f;
            const float g = atlas_pixels->rgba[idx + 1] / 255.0f;
            const float b = atlas_pixels->rgba[idx + 2] / 255.0f;
            const float max_c = std::max(r, std::max(g, b));
            const float min_c = std::min(r, std::min(g, b));
            const float sat = (max_c > 0.0001f) ? ((max_c - min_c) / max_c) : 0.0f;
            const float luma = ColorLuma(r, g, b);
            if (luma > 0.96f || sat < 0.08f) {
                continue;
            }
            if (luma < cluster_min_luma) {
                continue;
            }
            const float dist_sq = ColorDistanceSq(r, g, b, best1_r, best1_g, best1_b);
            if (dist_sq > cluster_max_dist_sq || dist_sq < 0.00015f) {
                continue;
            }

            cluster_sum_r += r;
            cluster_sum_g += g;
            cluster_sum_b += b;
            cluster_count++;
        }
    }

    if (cluster_count > 0) {
        color2[0] = cluster_sum_r / static_cast<float>(cluster_count);
        color2[1] = cluster_sum_g / static_cast<float>(cluster_count);
        color2[2] = cluster_sum_b / static_cast<float>(cluster_count);
    } else {
        color2[0] = std::clamp(color1[0] * 0.84f, 0.0f, 1.0f);
        color2[1] = std::clamp(color1[1] * 0.84f, 0.0f, 1.0f);
        color2[2] = std::clamp(color1[2] * 0.84f, 0.0f, 1.0f);
    }
}
} 

static void DrawGlowCircle(ImDrawList* draw_list, ImVec2 center, float radius, float outline_padding,
                           float outline_thickness, float glow_blur_steps,
                           const float bright_colors1[3], const float bright_colors2[3], bool glow_enabled) {

    DrawGlowEffect(draw_list, center, radius, outline_padding, outline_thickness, glow_blur_steps,
                   bright_colors1, bright_colors2, glow_enabled);

    float outline_radius = radius + outline_padding;
    DrawCircularOutline(draw_list, center, outline_radius, outline_thickness, bright_colors1, bright_colors2, glow_enabled);
}

void PostProcessing::Apply(const Effect& effect, ImDrawList* draw_list) {
    if (!draw_list) {
        return;
    }
    effect.Apply(draw_list, *this);
}

void PostProcessing::CleanupGlowCache() {
    if (glow_cache.glow_texture != 0) {
        glDeleteTextures(1, &glow_cache.glow_texture);
        glow_cache.glow_texture = 0;
    }
    glow_cache.glow_data.clear();
    glow_cache.needs_update = true;
}

namespace {
struct TextGlowJob {
    ImFont* font = nullptr;
    float font_size = 0.0f;
    std::string text;
    int width = 0;
    int height = 0;
    float pad = 0.0f;
    float blur_radius = 0.0f;
    int downscale = 2;
    ImTextureID tex_id = 0;
    std::vector<ImDrawVert> vtx;
    std::vector<ImDrawIdx> idx;
};

static Blur g_text_glow_blur(Hardware::GPU);
static GLuint g_text_glow_fbo = 0;
static GLuint g_text_glow_tex = 0;
static int g_text_glow_w = 0;
static int g_text_glow_h = 0;
static GLuint g_text_prog = 0;
static GLuint g_text_vao = 0;
static GLuint g_text_vbo = 0;
static GLuint g_text_ebo = 0;
static GLint g_text_loc_tex = -1;
static GLint g_text_loc_proj = -1;
static int g_text_glow_last_log_frame = -1;
static int g_text_glow_draw_frame = -1;
static int g_text_glow_draw_count = 0;
static bool g_text_glow_render_active = false;
static float g_text_glow_intensity = 1.0f;
static float g_text_glow_radius_scale = 1.0f;
static float g_text_glow_alpha_scale = 1.0f;
static int g_text_glow_steps = 0;
static int g_text_glow_downscale = 0;
static bool g_text_glow_debug_skip = false;

static void GlowLog(const char* fmt, ...) {
    (void)fmt;
}

static const char* kTextVS = R"(#version 300 es
layout (location = 0) in vec2 aPos;
layout (location = 1) in vec2 aUV;
layout (location = 2) in vec4 aColor;
uniform mat4 uProj;
out vec2 vUV;
out vec4 vColor;
void main() {
    vUV = aUV;
    vColor = aColor;
    gl_Position = uProj * vec4(aPos, 0.0, 1.0);
}
)";

static const char* kTextFS = R"(#version 300 es
precision highp float;
in vec2 vUV;
in vec4 vColor;
uniform sampler2D uTex;
out vec4 FragColor;
void main() {
    vec4 tex = texture(uTex, vUV);
    FragColor = vColor * tex;
}
)";

GLuint CreateTextProgram() {
    GLuint vs = CreateShader(GL_VERTEX_SHADER, kTextVS);
    GLuint fs = CreateShader(GL_FRAGMENT_SHADER, kTextFS);
    if (!vs || !fs) {
        return 0;
    }
    GLuint prog = glCreateProgram();
    if (!prog) {
        glDeleteShader(vs);
        glDeleteShader(fs);
        return 0;
    }
    glAttachShader(prog, vs);
    glAttachShader(prog, fs);
    glLinkProgram(prog);
    GLint status = GL_FALSE;
    glGetProgramiv(prog, GL_LINK_STATUS, &status);
    glDeleteShader(vs);
    glDeleteShader(fs);
    if (status != GL_TRUE) {
        glDeleteProgram(prog);
        return 0;
    }
    return prog;
}

bool HasTextGlowGL() {
    return glCreateShader && glShaderSource && glCompileShader && glGetShaderiv &&
        glCreateProgram && glAttachShader && glLinkProgram && glGetProgramiv &&
        glGetUniformLocation && glUseProgram && glUniform1i && glUniformMatrix4fv &&
        glGenVertexArrays && glGenBuffers && glBindVertexArray && glBindBuffer &&
        glBufferData && glEnableVertexAttribArray && glVertexAttribPointer &&
        glGenTextures && glBindTexture && glTexParameteri && glTexImage2D &&
        glGenFramebuffers && glBindFramebuffer && glFramebufferTexture2D &&
        glViewport && glDrawElements &&
        glActiveTexture && glGetIntegerv &&
        glBlendEquation && glBlendFuncSeparate &&
        glClearColor && glClear;
}

void EnsureTextGlowRenderer() {
    if (g_text_prog == 0) {
        g_text_prog = CreateTextProgram();
        if (g_text_prog == 0) {
            return;
        }
        g_text_loc_tex = glGetUniformLocation(g_text_prog, "uTex");
        g_text_loc_proj = glGetUniformLocation(g_text_prog, "uProj");
    }
    if (g_text_vao == 0) {
        glGenVertexArrays(1, &g_text_vao);
        glGenBuffers(1, &g_text_vbo);
        glGenBuffers(1, &g_text_ebo);
        glBindVertexArray(g_text_vao);
        glBindBuffer(GL_ARRAY_BUFFER, g_text_vbo);
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, g_text_ebo);
        glEnableVertexAttribArray(0);
        glEnableVertexAttribArray(1);
        glEnableVertexAttribArray(2);
        glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, sizeof(ImDrawVert), (void*)offsetof(ImDrawVert, pos));
        glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, sizeof(ImDrawVert), (void*)offsetof(ImDrawVert, uv));
        glVertexAttribPointer(2, 4, GL_UNSIGNED_BYTE, GL_TRUE, sizeof(ImDrawVert), (void*)offsetof(ImDrawVert, col));
        glBindVertexArray(0);
        glBindBuffer(GL_ARRAY_BUFFER, 0);
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
    }
}

void EnsureTextGlowTarget(int width, int height) {
    if (width <= 0 || height <= 0) {
        return;
    }
    if (g_text_glow_w == width && g_text_glow_h == height && g_text_glow_fbo != 0 && g_text_glow_tex != 0) {
        return;
    }
    g_text_glow_w = width;
    g_text_glow_h = height;
    if (g_text_glow_tex == 0) {
        glGenTextures(1, &g_text_glow_tex);
    }
    glBindTexture(GL_TEXTURE_2D, g_text_glow_tex);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, g_text_glow_w, g_text_glow_h, 0, GL_RGBA, GL_UNSIGNED_BYTE, nullptr);
    if (g_text_glow_fbo == 0) {
        glGenFramebuffers(1, &g_text_glow_fbo);
    }
    glBindFramebuffer(GL_FRAMEBUFFER, g_text_glow_fbo);
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, g_text_glow_tex, 0);
}

void RenderTextToFbo(const TextGlowJob& job) {
    if (!job.font || job.text.empty() || g_text_glow_fbo == 0 || g_text_prog == 0) {
        return;
    }
    if (job.vtx.empty() || job.idx.empty()) {
        return;
    }

    GLint prev_fbo = 0;
    GLint prev_viewport[4] = {0, 0, 0, 0};
    GLint prev_program = 0;
    GLint prev_vao = 0;
    GLint prev_vbo = 0;
    GLint prev_ebo = 0;
    GLint prev_active = 0;
    GLint prev_tex0 = 0;
    GLint prev_tex_active = 0;
    GLboolean prev_blend = GL_FALSE;
    GLboolean prev_scissor = GL_FALSE;
    GLboolean prev_depth = GL_FALSE;
    GLboolean prev_cull = GL_FALSE;
    GLboolean prev_stencil = GL_FALSE;

    glGetIntegerv(GL_FRAMEBUFFER_BINDING, &prev_fbo);
    glGetIntegerv(GL_VIEWPORT, prev_viewport);
    glGetIntegerv(GL_CURRENT_PROGRAM, &prev_program);
    glGetIntegerv(GL_VERTEX_ARRAY_BINDING, &prev_vao);
    glGetIntegerv(GL_ARRAY_BUFFER_BINDING, &prev_vbo);
    glGetIntegerv(GL_ELEMENT_ARRAY_BUFFER_BINDING, &prev_ebo);
    glGetIntegerv(GL_ACTIVE_TEXTURE, &prev_active);
    glGetIntegerv(GL_TEXTURE_BINDING_2D, &prev_tex_active);
    glActiveTexture(GL_TEXTURE0);
    glGetIntegerv(GL_TEXTURE_BINDING_2D, &prev_tex0);
    glActiveTexture(prev_active);
    prev_blend = glIsEnabled(GL_BLEND);
    prev_scissor = glIsEnabled(GL_SCISSOR_TEST);
    prev_depth = glIsEnabled(GL_DEPTH_TEST);
    prev_cull = glIsEnabled(GL_CULL_FACE);
    prev_stencil = glIsEnabled(GL_STENCIL_TEST);

    glBindFramebuffer(GL_FRAMEBUFFER, g_text_glow_fbo);
    glViewport(0, 0, g_text_glow_w, g_text_glow_h);
    glEnable(GL_BLEND);
    glBlendEquation(GL_FUNC_ADD);
    glBlendFuncSeparate(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA, GL_ONE, GL_ONE_MINUS_SRC_ALPHA);
    glDisable(GL_DEPTH_TEST);
    glDisable(GL_CULL_FACE);
    glDisable(GL_STENCIL_TEST);
    glDisable(GL_SCISSOR_TEST);
    glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
    glClear(GL_COLOR_BUFFER_BIT);
    glUseProgram(g_text_prog);
    glUniform1i(g_text_loc_tex, 0);
    float L = 0.0f;
    float R = static_cast<float>(g_text_glow_w);
    float T = 0.0f;
    float B = static_cast<float>(g_text_glow_h);
    const float ortho[4][4] = {
        { 2.0f/(R-L),   0.0f,         0.0f,   0.0f },
        { 0.0f,         2.0f/(T-B),   0.0f,   0.0f },
        { 0.0f,         0.0f,        -1.0f,   0.0f },
        { (R+L)/(L-R),  (T+B)/(B-T),  0.0f,   1.0f },
    };
    glUniformMatrix4fv(g_text_loc_proj, 1, GL_FALSE, &ortho[0][0]);

    glBindVertexArray(g_text_vao);
    glBindBuffer(GL_ARRAY_BUFFER, g_text_vbo);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, g_text_ebo);
    glBufferData(GL_ARRAY_BUFFER, (int)job.vtx.size() * (int)sizeof(ImDrawVert), job.vtx.data(), GL_STREAM_DRAW);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, (int)job.idx.size() * (int)sizeof(ImDrawIdx), job.idx.data(), GL_STREAM_DRAW);

    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, (GLuint)(intptr_t)job.tex_id);
    GLenum idx_type = (sizeof(ImDrawIdx) == 2) ? GL_UNSIGNED_SHORT : GL_UNSIGNED_INT;
    glDrawElements(GL_TRIANGLES, (GLsizei)job.idx.size(), idx_type, (void*)(intptr_t)0);

    glBindFramebuffer(GL_FRAMEBUFFER, prev_fbo);
    glViewport(prev_viewport[0], prev_viewport[1], prev_viewport[2], prev_viewport[3]);
    glUseProgram(prev_program);
    glBindVertexArray(prev_vao);
    glBindBuffer(GL_ARRAY_BUFFER, prev_vbo);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, prev_ebo);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, prev_tex0);
    glActiveTexture(prev_active);
    glBindTexture(GL_TEXTURE_2D, prev_tex_active);
    if (prev_blend) glEnable(GL_BLEND); else glDisable(GL_BLEND);
    if (prev_scissor) glEnable(GL_SCISSOR_TEST); else glDisable(GL_SCISSOR_TEST);
    if (prev_depth) glEnable(GL_DEPTH_TEST); else glDisable(GL_DEPTH_TEST);
    if (prev_cull) glEnable(GL_CULL_FACE); else glDisable(GL_CULL_FACE);
    if (prev_stencil) glEnable(GL_STENCIL_TEST); else glDisable(GL_STENCIL_TEST);
}

void TextGlowRenderCallback(const ImDrawList* parent_list, const ImDrawCmd* cmd) {
    (void)parent_list;
    if (!cmd || !cmd->UserCallbackData) {
        return;
    }
    std::unique_ptr<TextGlowJob> job(static_cast<TextGlowJob*>(cmd->UserCallbackData));
    int frame = ImGui::GetFrameCount();
    if (g_text_glow_debug_skip) {
        return;
    }
    if (!g_text_glow_render_active) {
        return;
    }
    if (!HasTextGlowGL()) {
        return;
    }
    if (!ImGui::GetCurrentContext()) {
        return;
    }
    EnsureTextGlowRenderer();
    EnsureTextGlowTarget(job->width, job->height);
    if (g_text_prog == 0 || g_text_glow_fbo == 0) {
        return;
    }
    RenderTextToFbo(*job);

    GLint prev_fbo = 0;
    glGetIntegerv(GL_FRAMEBUFFER_BINDING, &prev_fbo);
    glBindFramebuffer(GL_FRAMEBUFFER, g_text_glow_fbo);
    g_text_glow_blur.backend = Hardware::GPU;
    g_text_glow_blur.type = Blur::Type::Gaussian;
    g_text_glow_blur.process(0, 0, job->width, job->height, job->blur_radius, std::max(1, job->downscale));
    glBindFramebuffer(GL_FRAMEBUFFER, prev_fbo);
}
} 

void PostProcessing::SetTextGlowRenderActive(bool active) {
    g_text_glow_render_active = active;
}

void PostProcessing::SetTextGlowIntensity(float value) {
    g_text_glow_intensity = std::max(0.0f, value);
}

float PostProcessing::GetTextGlowIntensity() const {
    return g_text_glow_intensity;
}

void PostProcessing::SetTextGlowRadiusScale(float value) {
    g_text_glow_radius_scale = std::max(0.0f, value);
}

float PostProcessing::GetTextGlowRadiusScale() const {
    return g_text_glow_radius_scale;
}

void PostProcessing::SetTextGlowAlphaScale(float value) {
    g_text_glow_alpha_scale = std::max(0.0f, value);
}

float PostProcessing::GetTextGlowAlphaScale() const {
    return g_text_glow_alpha_scale;
}

void PostProcessing::SetTextGlowSteps(int steps) {
    g_text_glow_steps = (steps < 0) ? 0 : steps;
}

int PostProcessing::GetTextGlowSteps() const {
    return g_text_glow_steps;
}

void PostProcessing::SetTextGlowDownscale(int value) {
    g_text_glow_downscale = (value < 0) ? 0 : value;
}

int PostProcessing::GetTextGlowDownscale() const {
    return g_text_glow_downscale;
}

void PostProcessing::RadialGradient::Apply(ImDrawList* draw_list, PostProcessing& post) const {
    (void)post;
    if (((color_in | color_out) & IM_COL32_A_MASK) == 0 || radius < 0.5f) {
        return;
    }
    draw_list->AddCircleFilled(center, radius, color_in);
}

void PostProcessing::SmoothSquareShadow::Apply(ImDrawList* draw_list, PostProcessing& post) const {
    (void)post;
    ImVec4 center_color = ImGui::ColorConvertU32ToFloat4(color_center);

    for (int i = 0; i < blur_steps; i++) {
        float scale = 1.05f + (i * 0.07f);
        float alpha_factor = 0.07f * (1.0f - (float)i / (float)blur_steps);

        ImVec4 temp_color = center_color;
        temp_color.w = alpha_factor;
        ImU32 temp_col = ImGui::ColorConvertFloat4ToU32(temp_color);

        ImVec2 temp_glow_size = ImVec2(size.x * scale, size.y * scale);
        ImVec2 temp_rect_min = ImVec2(center.x - temp_glow_size.x / 2, center.y - temp_glow_size.y / 2);
        ImVec2 temp_rect_max = ImVec2(center.x + temp_glow_size.x / 2, center.y + temp_glow_size.y / 2);

        draw_list->AddRectFilled(temp_rect_min, temp_rect_max, temp_col, 4.0f);
    }
}

void PostProcessing::GaussianShadow::Apply(ImDrawList* draw_list, PostProcessing& post) const {
    (void)post;
    if (((color_center | color_edge) & IM_COL32_A_MASK) == 0) {
        return;
    }

    ImVec4 col_center_f = ImGui::ColorConvertU32ToFloat4(color_center);
    ImVec4 col_edge_f = ImGui::ColorConvertU32ToFloat4(color_edge);

    for (int i = 0; i < blur_steps; i++) {
        float t = (float)i / (float)(blur_steps - 1);

        float x = t * 3.0f;
        float gaussian = exp(-(x * x) / (2.0f * sigma * sigma));

        ImVec4 current_color;
        float color_t = sqrtf(t);
        current_color.x = col_center_f.x * (1.0f - color_t) + col_edge_f.x * color_t;
        current_color.y = col_center_f.y * (1.0f - color_t) + col_edge_f.y * color_t;
        current_color.z = col_center_f.z * (1.0f - color_t) + col_edge_f.z * color_t;
        current_color.w = col_center_f.w * (1.0f - t) + 0.0f * t * gaussian;

        float scale = 1.0f + t * 0.9f;

        ImVec2 current_size = ImVec2(size.x * scale, size.y * scale);
        ImVec2 rect_min = ImVec2(center.x - current_size.x / 2, center.y - current_size.y / 2);
        ImVec2 rect_max = ImVec2(center.x + current_size.x / 2, center.y + current_size.y / 2);

        float rounding = 5.0f * scale;

        draw_list->AddRectFilled(rect_min, rect_max,
            ImGui::ColorConvertFloat4ToU32(current_color), rounding);
    }
}

void PostProcessing::ArrowGlow::Apply(ImDrawList* draw_list, PostProcessing& post) const {
    (void)post;
    if (((inner_color) & IM_COL32_A_MASK) == 0 || radius < 0.5f) {
        return;
    }

    ImVec4 inner_color_vec4 = ImGui::ColorConvertU32ToFloat4(inner_color);

    for (int i = 0; i < steps; i++) {
        float step_radius = radius + (i * 0.8f);
        float alpha_factor = 1.0f - ((float)i / (float)steps) * ((float)i / (float)steps);

        ImU32 current_color = IM_COL32(
            (int)(inner_color_vec4.x * 255),
            (int)(inner_color_vec4.y * 255),
            (int)(inner_color_vec4.z * 255),
            (int)(inner_color_vec4.w * 15.0f * alpha_factor)
        );

        draw_list->AddCircleFilled(center, step_radius, current_color, 16);
    }
}

void PostProcessing::RectGlow::Apply(ImDrawList* draw_list, PostProcessing& post) const {
    (void)post;
    if (rect.Max.x <= rect.Min.x || rect.Max.y <= rect.Min.y) {
        return;
    }

    int steps = blur_steps <= 0 ? DefaultBlurSteps(style) : blur_steps;
    if (steps <= 0) {
        return;
    }

    float expand_x = 15.0f;
    float expand_y = 15.0f;
    float rounding_base = 4.0f;
    RectGlowParams(style, expand_x, expand_y, rounding_base);

    float intensity_scale = StyleIntensityScale(style);

    ImVec4 color_f = ImGui::ColorConvertU32ToFloat4(color);
    int denom = (steps > 1) ? (steps - 1) : 1;

    for (int i = 0; i < steps; i++) {
        float t = (float)i / (float)denom;
        float alpha = color_f.w * 0.25f * (1.0f - t * t) * intensity * intensity_scale;

        if (alpha <= 0.001f) {
            continue;
        }

        ImVec4 current_color = color_f;
        current_color.w = alpha;

        float expansion_x = t * expand_x;
        float expansion_y = t * expand_y;

        ImVec2 min = ImVec2(rect.Min.x - expansion_x, rect.Min.y - expansion_y);
        ImVec2 max = ImVec2(rect.Max.x + expansion_x, rect.Max.y + expansion_y);

        float rounding = rounding_base + (expansion_x + expansion_y) * 0.5f;

        draw_list->AddRectFilled(min, max, ImGui::ColorConvertFloat4ToU32(current_color), rounding);
    }
}

void PostProcessing::GradientGlow::Apply(ImDrawList* draw_list, PostProcessing& post) const {
    (void)post;
    if (rect.Max.x <= rect.Min.x || rect.Max.y <= rect.Min.y) {
        return;
    }

    float width = rect.Max.x - rect.Min.x;

    for (int j = 1; j <= blur_steps; j++) {
        float t = (float)j / (float)blur_steps;
        float expansion_x = t * 15.0f;
        float expansion_y = t * 15.0f;
        float alpha_factor = (blur_steps - j) / (float)blur_steps * 0.3f * intensity;

        ImRect expanded_rect = ImRect(
            rect.Min.x - expansion_x,
            rect.Min.y - expansion_y,
            rect.Max.x + expansion_x,
            rect.Max.y + expansion_y
        );

        float rounding = 4.0f + (expansion_x + expansion_y) * 0.1f;

        int segment_count = (int)fmaxf(20.0f, fminf(width, 50.0f));

        for (int i = 0; i < segment_count; i++) {
            float segment_t = i == segment_count - 1 ? 1.0f : (float)i / (segment_count - 1);

            ImU32 segment_color;
            if (rainbow_mode) {
                float hue = fmodf(ImGui::GetTime() * 0.5f + segment_t, 1.0f);
                segment_color = ImGui::GetColorU32(ImVec4(ImColor::HSV(hue, 0.8f, 1.0f)));
            } else {
                ImVec4 interpolated_color;
                interpolated_color.x = color1.x * (1.0f - segment_t) + color2.x * segment_t;
                interpolated_color.y = color1.y * (1.0f - segment_t) + color2.y * segment_t;
                interpolated_color.z = color1.z * (1.0f - segment_t) + color2.z * segment_t;
                interpolated_color.w = alpha_factor;
                segment_color = ImGui::ColorConvertFloat4ToU32(interpolated_color);
            }

            ImVec4 color_rgba = ImGui::ColorConvertU32ToFloat4(segment_color);
            color_rgba.w *= alpha_factor;
            segment_color = ImGui::ColorConvertFloat4ToU32(color_rgba);

            float x_start = expanded_rect.Min.x + (expanded_rect.Max.x - expanded_rect.Min.x) * (float)i / segment_count;
            float x_end = expanded_rect.Min.x + (expanded_rect.Max.x - expanded_rect.Min.x) * (float)(i + 1) / segment_count;

            if (i == 0) {
                draw_list->AddRectFilled(
                    ImVec2(x_start, expanded_rect.Min.y),
                    ImVec2(x_end, expanded_rect.Max.y),
                    segment_color,
                    rounding, ImDrawFlags_RoundCornersLeft
                );
            } else if (i == segment_count - 1) {
                draw_list->AddRectFilled(
                    ImVec2(x_start, expanded_rect.Min.y),
                    ImVec2(x_end, expanded_rect.Max.y),
                    segment_color,
                    rounding, ImDrawFlags_RoundCornersRight
                );
            } else {
                draw_list->AddRectFilled(
                    ImVec2(x_start, expanded_rect.Min.y),
                    ImVec2(x_end, expanded_rect.Max.y),
                    segment_color,
                    0.0f
                );
            }
        }
    }
}

void PostProcessing::DrawGlowTexture(ImDrawList* draw_list, const char* icon_name,
                                     const ImVec2& min, const ImVec2& max,
                                     const ImVec4& color, float alpha,
                                     const ImVec2* uv_min_override,
                                     const ImVec2* uv_max_override) const {
    if (!draw_list || !flags.glow || !icon_name || !*icon_name) {
        return;
    }

    if (!images.Ready()) return;

    const ImageRegion glow_uv = images.RegionForName(icon_name, AtlasKind::Glow);
    if (!IsValidRegionForDraw(glow_uv)) {
        return;
    }
    GLuint glow_tex = images.TextureForRegion(glow_uv);
    if (glow_tex == 0) {
        return;
    }

    ImVec4 out = color;
    const float glow_alpha = ImClamp(alpha, 0.0f, 1.0f);
    out.w = ImClamp(0.35f * color.w * glow_alpha * flags.glow_alpha_scale, 0.0f, 1.0f);
    const ImVec2 uv0 = uv_min_override ? *uv_min_override : ImVec2(glow_uv.u_min, glow_uv.v_min);
    const ImVec2 uv1 = uv_max_override ? *uv_max_override : ImVec2(glow_uv.u_max, glow_uv.v_max);
    
    draw_list->AddCallback(PostProcessing::BeginFadeBackgroundAddCallback, nullptr);
    draw_list->AddImage((void*)(intptr_t)glow_tex, min, max, uv0, uv1, ImGui::GetColorU32(out));
    draw_list->AddCallback(ImDrawCallback_ResetRenderState, nullptr);
}

void PostProcessing::DrawTextGlow(ImDrawList* draw_list, ImFont* font, float font_size, const char* text,
                                  const ImVec2& pos, const ImVec4& color, float blur_radius,
                                  float alpha, int downscale) {
    int frame = ImGui::GetFrameCount();
    if (frame != g_text_glow_draw_frame) {
        g_text_glow_draw_frame = frame;
        g_text_glow_draw_count = 0;
    }
    if (g_text_glow_draw_count < 3) {
        GlowLog("DrawTextGlow call: text='%s' size=%.2f blur=%.2f alpha=%.4f ds=%d pos=(%.1f,%.1f)",
                text ? text : "<null>", font_size, blur_radius, alpha, downscale, pos.x, pos.y);
        g_text_glow_draw_count++;
    }
    if (!draw_list || !font || !text || !*text || !flags.glow) {
        if (g_text_glow_draw_count < 6) {
            GlowLog("DrawTextGlow skip: draw_list=%p font=%p text=%p glow=%d",
                    draw_list, (void*)font, (void*)text, flags.glow ? 1 : 0);
            g_text_glow_draw_count++;
        }
        return;
    }
    if (blur_radius <= 0.0f || alpha <= 0.00001f) {
        if (g_text_glow_draw_count < 6) {
            GlowLog("DrawTextGlow skip: blur/alpha blur=%.3f alpha=%.6f", blur_radius, alpha);
            g_text_glow_draw_count++;
        }
        return;
    }
    float scaled_alpha = alpha * g_text_glow_intensity * g_text_glow_alpha_scale * 0.90f;
    float scaled_radius = blur_radius * g_text_glow_radius_scale;
    if (scaled_alpha <= 0.00001f || scaled_radius <= 0.0f) {
        return;
    }
    if (!g_text_glow_render_active || !HasTextGlowGL()) {
        if (font_size <= 0.0f) {
            return;
        }
        float blur_intensity = scaled_radius / std::max(1.0f, font_size);
        int steps = g_text_glow_steps > 0 ? g_text_glow_steps
            : std::max(6, std::min(64, (int)ceilf(scaled_radius * 1.25f)));
        steps = std::max(1, std::min(128, steps));
        TextGlow fallback(pos, font, font_size, text, color, blur_intensity, steps, scaled_alpha);
        fallback.Apply(draw_list, *this);
        return;
    }
    int effective_downscale = (g_text_glow_downscale > 0) ? g_text_glow_downscale : downscale;
    if (effective_downscale < 1) {
        effective_downscale = 1;
    }

    ImVec2 text_size = font->CalcTextSizeA(font_size, FLT_MAX, 0.0f, text);
    if (g_text_glow_draw_count < 6) {
        GlowLog("DrawTextGlow size: text_w=%.2f text_h=%.2f", text_size.x, text_size.y);
        g_text_glow_draw_count++;
    }
    if (!ImGui::GetCurrentContext()) {
        GlowLog("DrawTextGlow skip: no ImGui context");
        return;
    }
    ImDrawListSharedData* shared = ImGui::GetDrawListSharedData();
    if (!shared) {
        GlowLog("DrawTextGlow skip: no shared draw data");
        return;
    }
    if (!font->OwnerAtlas) {
        GlowLog("DrawTextGlow skip: font has no atlas");
        return;
    }
    float pad = std::max(2.0f, blur_radius * 1.5f);
    int width = static_cast<int>(ceilf(text_size.x + pad * 2.0f));
    int height = static_cast<int>(ceilf(text_size.y + pad * 2.0f));
    if (width <= 0 || height <= 0) {
        if (g_text_glow_draw_count < 6) {
            GlowLog("DrawTextGlow skip: bad size w=%d h=%d", width, height);
            g_text_glow_draw_count++;
        }
        return;
    }

    auto* job = new TextGlowJob();
    job->font = font;
    job->font_size = font_size;
    job->text = text;
    job->width = width;
    job->height = height;
    job->pad = pad;
    job->blur_radius = scaled_radius;
    job->downscale = effective_downscale;
    job->tex_id = font->OwnerAtlas->TexID.GetTexID();
    GlowLog("DrawTextGlow: tex_id=%p", (void*)(intptr_t)job->tex_id);
    {
        GlowLog("DrawTextGlow: capture from window draw list");
        ImDrawList* dl = draw_list;
        int vtx0 = dl->VtxBuffer.Size;
        int idx0 = dl->IdxBuffer.Size;
        int cmd0 = dl->CmdBuffer.Size;
        unsigned int vtx_current0 = dl->_VtxCurrentIdx;
        ImDrawCmdHeader cmd_header0 = dl->_CmdHeader;
        int clip0 = dl->_ClipRectStack.Size;
        int tex0 = dl->_TextureStack.Size;

        dl->PushTexture(font->OwnerAtlas->TexID);
        dl->PushClipRectFullScreen();
        dl->AddText(font, font_size, ImVec2(pad, pad), IM_COL32(255, 255, 255, 255), text);
        dl->PopClipRect();
        dl->PopTexture();
        if (dl->CmdBuffer.Size > 0) {
            ImTextureRef tex_ref = dl->CmdBuffer.back().GetTexID();
            job->tex_id = tex_ref.GetTexID();
        }

        int vtx1 = dl->VtxBuffer.Size;
        int idx1 = dl->IdxBuffer.Size;
        GlowLog("DrawTextGlow: dl vtx=%d idx=%d", vtx1 - vtx0, idx1 - idx0);

        if (vtx1 > vtx0 && idx1 > idx0) {
            job->vtx.assign(dl->VtxBuffer.begin() + vtx0, dl->VtxBuffer.end());
            job->idx.assign(dl->IdxBuffer.begin() + idx0, dl->IdxBuffer.end());
            for (auto& i : job->idx) {
                i = (ImDrawIdx)(i - vtx0);
            }
        }

        dl->VtxBuffer.resize(vtx0);
        dl->IdxBuffer.resize(idx0);
        dl->CmdBuffer.resize(cmd0);
        dl->_VtxCurrentIdx = vtx_current0;
        dl->_CmdHeader = cmd_header0;
        dl->_ClipRectStack.resize(clip0);
        dl->_TextureStack.resize(tex0);
        dl->_VtxWritePtr = dl->VtxBuffer.Data + vtx0;
        dl->_IdxWritePtr = dl->IdxBuffer.Data + idx0;
    }
    if (g_text_glow_draw_count < 6) {
        GlowLog("DrawTextGlow job: w=%d h=%d pad=%.2f", width, height, pad);
        g_text_glow_draw_count++;
    }

    draw_list->AddCallback(TextGlowRenderCallback, job);
    draw_list->AddCallback(ImDrawCallback_ResetRenderState, nullptr);
    if (g_text_glow_draw_count < 6) {
        GlowLog("DrawTextGlow callback queued");
        g_text_glow_draw_count++;
    }

    ImVec4 tint = color;
    tint.w = scaled_alpha;
    ImVec2 min = ImVec2(pos.x - pad, pos.y - pad);
    ImVec2 max = ImVec2(min.x + static_cast<float>(width), min.y + static_cast<float>(height));
    draw_list->AddImage(
        (void*)(intptr_t)g_text_glow_blur.tex,
        min,
        max,
        ImVec2(0.0f, 1.0f),
        ImVec2(1.0f, 0.0f),
        ImGui::GetColorU32(tint)
    );
}

void PostProcessing::UserIcon::Apply(ImDrawList* draw_list, PostProcessing& post) const {
    if (!draw_list || texture_id == 0) {
        return;
    }

    ImVec2 center = ImVec2(
        icon_pos.x + icon_size.x * 0.5f,
        icon_pos.y + icon_size.y * 0.5f
    );

    float radius = icon_size.x * 0.5f;

    float outline_thickness = 2.5f;
    float outline_padding = 1.0f;
    float glow_blur_steps = 20.0f;

    float bright_colors1[3];
    float bright_colors2[3];
    ExtractTwoBrightestColorsFromRegion(atlas_kind, uv_min, uv_max, bright_colors1, bright_colors2);

    DrawGlowCircle(draw_list, center, radius, outline_padding, outline_thickness, glow_blur_steps,
                   bright_colors1, bright_colors2, post.flags.glow);

    float new_icon_radius = radius - outline_padding - outline_thickness - 1.0f;
    ImVec2 new_icon_size = ImVec2(new_icon_radius * 2.0f, new_icon_radius * 2.0f);

    ImVec2 new_icon_pos = ImVec2(
        center.x - new_icon_radius,
        center.y - new_icon_radius
    );

    draw_list->AddImageRounded(
        (void*)(intptr_t)texture_id,
        new_icon_pos,
        ImVec2(new_icon_pos.x + new_icon_size.x, new_icon_pos.y + new_icon_size.y),
        uv_min,
        uv_max,
        IM_COL32_WHITE,
        new_icon_size.x * 0.5f
    );

}

void PostProcessing::TextGlow::Apply(ImDrawList* draw_list, PostProcessing& post) const {
    (void)post;
    if (!draw_list || !font || !text || !*text || blur_steps <= 0 || font_size <= 0.0f) {
        return;
    }

    float glow_alpha = alpha_intensity;
    if (glow_alpha <= 0.00001f) {
        return;
    }

    const float maxRadius = font_size * blur_intensity;
    if (maxRadius <= 0.0f) {
        return;
    }

    ImVec4 glowColor = color;
    glowColor.w = glow_alpha;

    static const int directions = 24;
    static float angles[24];
    static bool angles_init = false;
    if (!angles_init) {
        for (int a = 0; a < directions; ++a) {
            angles[a] = (360.0f / (float)directions) * (float)a;
        }
        angles_init = true;
    }

    for (int step = 1; step <= blur_steps; step++) {
        float radius = maxRadius * powf((float)step / (float)blur_steps, 1.233f);
        float alphaFactor = powf(1.0f - (float)step / (float)blur_steps, 2.0f - 1.233f);
        float currentAlpha = glowColor.w * alphaFactor;

        if (currentAlpha < 0.001f) {
            continue;
        }

        ImVec4 currentColor = glowColor;
        currentColor.w = currentAlpha;

        for (int d = 0; d < directions; d++) {
            float angleRad = angles[d] * 3.14159f / 180.0f;
            float offsetX = cosf(angleRad) * radius;
            float offsetY = sinf(angleRad) * radius;

            draw_list->AddText(
                font,
                font_size,
                ImVec2(pos.x + offsetX, pos.y + offsetY),
                ImColor(currentColor),
                text
            );
        }

    }
}

float calculateBrightnessFloat(float r, float g, float b) {
    return 0.2126f * r + 0.7152f * g + 0.0722f * b;
}

void getTwoBrightestColorsFromTexture(GLuint textureId, int width, int height, float color1[3], float color2[3]) {
    std::vector<unsigned char> pixels(width * height * 4);

    glBindTexture(GL_TEXTURE_2D, textureId);
    glGetTexImage(GL_TEXTURE_2D, 0, GL_RGBA, GL_UNSIGNED_BYTE, pixels.data());

    std::vector<ColorWithBrightness> colors;
    colors.reserve((width * height) / 4);

    for (int y = 0; y < height; y += 2) {
        for (int x = 0; x < width; x += 2) {
            int idx = (y * width + x) * 4;

            float r = pixels[idx] / 255.0f;
            float g = pixels[idx + 1] / 255.0f;
            float b = pixels[idx + 2] / 255.0f;

            float brightness = calculateBrightnessFloat(r, g, b);

            if (brightness > 0.1f) {
                colors.push_back({r, g, b, brightness});
            }
        }
    }

    std::sort(colors.begin(), colors.end(),
        [](const ColorWithBrightness& a, const ColorWithBrightness& b) {
            return a.brightness > b.brightness;
        });

    int topCount = colors.size() / 10;
    if (topCount < 1) {
        topCount = 1;
    }

    float sumR1 = 0;
    float sumG1 = 0;
    float sumB1 = 0;
    for (int i = 0; i < topCount && i < (int)colors.size(); i++) {
        sumR1 += colors[i].r;
        sumG1 += colors[i].g;
        sumB1 += colors[i].b;
    }

    color1[0] = sumR1 / topCount;
    color1[1] = sumG1 / topCount;
    color1[2] = sumB1 / topCount;

    int secondStart = topCount;
    int secondEnd = topCount * 2;
    int secondCount = secondEnd - secondStart;

    if (secondCount > 0 && secondStart < (int)colors.size()) {
        float sumR2 = 0;
        float sumG2 = 0;
        float sumB2 = 0;
        int actualCount = 0;

        for (int i = secondStart; i < secondEnd && i < (int)colors.size(); i++) {
            sumR2 += colors[i].r;
            sumG2 += colors[i].g;
            sumB2 += colors[i].b;
            actualCount++;
        }

        if (actualCount > 0) {
            color2[0] = sumR2 / actualCount;
            color2[1] = sumG2 / actualCount;
            color2[2] = sumB2 / actualCount;
        } else {
            color2[0] = color1[0] * 0.7f;
            color2[1] = color1[1] * 0.7f;
            color2[2] = color1[2] * 0.7f;
        }
    } else {
        color2[0] = color1[0] * 0.7f;
        color2[1] = color1[1] * 0.7f;
        color2[2] = color1[2] * 0.7f;
    }
}

void getTwoBrightestColorsFromRegion(AtlasKind atlas_kind, const ImVec2& uv_min, const ImVec2& uv_max, float color1[3], float color2[3]) {
    ExtractTwoBrightestColorsFromRegion(atlas_kind, uv_min, uv_max, color1, color2);
}

ImU32 ImLerpColor(ImU32 col_a, ImU32 col_b, float t) {
    ImVec4 col_a_f = ImGui::ColorConvertU32ToFloat4(col_a);
    ImVec4 col_b_f = ImGui::ColorConvertU32ToFloat4(col_b);

    ImVec4 result;
    result.x = col_a_f.x * (1.0f - t) + col_b_f.x * t;
    result.y = col_a_f.y * (1.0f - t) + col_b_f.y * t;
    result.z = col_a_f.z * (1.0f - t) + col_b_f.z * t;
    result.w = col_a_f.w * (1.0f - t) + col_b_f.w * t;

    return ImGui::ColorConvertFloat4ToU32(result);
}

void DrawTextWithEllipsis(ImDrawList* draw_list, ImVec2 pos, ImFont* font, float font_size,
                         const char* text, float max_width, ImU32 color) {
    ImVec2 text_size = ImGui::CalcTextSize(text);

    if (text_size.x <= max_width) {
        draw_list->AddText(font, font_size, pos, color, text);
        return;
    }

    const char* ellipsis = "...";
    float ellipsis_width = ImGui::CalcTextSize(ellipsis).x;

    int text_len = (int)strlen(text);
    int low = 0, high = text_len;
    int best_fit = 0;

    while (low <= high) {
        int mid = (low + high) / 2;
        ImVec2 partial_size = ImGui::CalcTextSize(text, text + mid);

        if (partial_size.x + ellipsis_width <= max_width) {
            best_fit = mid;
            low = mid + 1;
        } else {
            high = mid - 1;
        }
    }

    if (best_fit > 0) {
        char buffer[256];
        int copy_len = ImMin(best_fit, 255 - 3);
        strncpy(buffer, text, copy_len);
        buffer[copy_len] = '\0';
        strcat(buffer, ellipsis);

        draw_list->AddText(font, font_size, pos, color, buffer);
    } else {
        draw_list->AddText(font, font_size, pos, color, ellipsis);
    }
}

void DrawTextWithCustomSizeAndWrapping(ImDrawList* draw_list, ImVec2 pos, ImFont* font, float font_size, const char* text, float max_width, ImU32 color) {
    if (!text || !*text) {
        return;
    }
    if (!font) {
        font = ImGui::GetFont();
    }
    if (max_width <= 0.0f) {
        draw_list->AddText(font, font_size, pos, color, text);
        return;
    }

    const char* line_start = text;
    ImVec2 cursor_pos = pos;
    const float line_height = font_size * 1.1f;

    while (*line_start) {
        while (*line_start && (*line_start == ' ' || *line_start == '\t' || *line_start == '\n')) {
            if (*line_start == '\n') {
                line_start++;
                cursor_pos.y += line_height;
                cursor_pos.x = pos.x;
                continue;
            }
            line_start++;
        }

        if (!*line_start) {
            break;
        }

        const char* line_end = line_start;
        const char* potential_break = line_start;

        while (*line_end && *line_end != '\n') {
            if (*line_end == ' ') {
                ImVec2 test_size = font->CalcTextSizeA(font_size, FLT_MAX, 0.0f, line_start, line_end);
                if (test_size.x <= max_width) {
                    potential_break = line_end;
                } else {
                    break;
                }
            }

            line_end++;

            ImVec2 test_size = font->CalcTextSizeA(font_size, FLT_MAX, 0.0f, line_start, line_end);
            if (test_size.x > max_width) {
                if (potential_break > line_start) {
                    line_end = potential_break;
                } else {
                    line_end = line_start + 1;
                }
                break;
            }
        }

        if (line_end > line_start) {
            draw_list->AddText(font, font_size, cursor_pos, color, line_start, line_end);

            cursor_pos.y += line_height;
            cursor_pos.x = pos.x;
        }

        if (*line_end == '\n') {
            line_end++;
        }
        line_start = line_end;
    }
}

void DrawTextWithSmallerSeparators(ImDrawList* draw_list, ImFont* font, float font_size, ImVec2 pos, ImU32 color, const char* text) {
    const char* separator = strstr(text, " | ");
    if (separator) {
        size_t prefix_len = separator - text;
        char prefix[256];
        strncpy(prefix, text, prefix_len);
        prefix[prefix_len] = '\0';

        const char* suffix = separator + 3;

        draw_list->AddText(font, font_size, pos, color, prefix);

        ImVec2 prefixSize = font->CalcTextSizeA(font_size, FLT_MAX, 0.0f, prefix);
        ImVec2 separatorPos = ImVec2(pos.x + prefixSize.x, pos.y + (font_size - font_size * 0.75f) / 2);

        draw_list->AddText(font, font_size * 0.75f, separatorPos, color, " | ");

        ImVec2 separatorSize = font->CalcTextSizeA(font_size * 0.75f, FLT_MAX, 0.0f, " | ");
        ImVec2 suffixPos = ImVec2(pos.x + prefixSize.x + separatorSize.x, pos.y);

        draw_list->AddText(font, font_size, suffixPos, color, suffix);
    } else {
        draw_list->AddText(font, font_size, pos, color, text);
    }
}

ImVec2 ImCubicBezier(const ImVec2& p0, const ImVec2& p1, const ImVec2& p2, const ImVec2& p3, float t) {
    float u = 1.0f - t;
    float tt = t * t;
    float uu = u * u;
    float uuu = uu * u;
    float ttt = tt * t;

    return ImVec2(
        uuu * p0.x + 3.0f * uu * t * p1.x + 3.0f * u * tt * p2.x + ttt * p3.x,
        uuu * p0.y + 3.0f * uu * t * p1.y + 3.0f * u * tt * p2.y + ttt * p3.y
    );
}
namespace {
struct MenuRippleInstance {
    ImVec2 center = ImVec2(0.0f, 0.0f); 
    float start_time = 0.0f;
    float strength = 1.0f;
    bool active = false;
};

struct MenuRippleFxState {
    static constexpr int MaxRipples = 8;
    MenuRippleInstance ripples[MaxRipples];
    bool tap_tracking = false;
    bool tap_moved = false;
    ImVec2 tap_start = ImVec2(0.0f, 0.0f);
    float tap_time = 0.0f;
    bool drag_tracking = false;
    ImVec2 drag_last_pos = ImVec2(0.0f, 0.0f);
    ImVec2 drag_velocity = ImVec2(0.0f, 0.0f);
    float drag_emit_accum = 0.0f;
    bool inertia_active = false;
    ImVec2 inertia_pos = ImVec2(0.0f, 0.0f);
    ImVec2 inertia_vel = ImVec2(0.0f, 0.0f);
    float inertia_emit_accum = 0.0f;
    float inertia_time = 0.0f;
    float time = 0.0f;
    bool motion_has_prev = false;
    int motion_target_kind = 0; 
    ImVec2 motion_prev_center = ImVec2(0.0f, 0.0f);
    float motion_emit_accum = 0.0f;
    bool motion_tail_active = false;
    ImVec2 motion_tail_pos = ImVec2(0.0f, 0.0f);
    ImVec2 motion_tail_vel = ImVec2(0.0f, 0.0f);
    float motion_tail_emit_accum = 0.0f;
    float motion_tail_time = 0.0f;
    ImVec2 motion_prev_vel = ImVec2(0.0f, 0.0f);
    bool motion_counter_active = false;
    ImVec2 motion_counter_vel = ImVec2(0.0f, 0.0f);
    float motion_counter_time = 0.0f;
    bool touch_follow_active = false;
    ImVec2 touch_follow_pos = ImVec2(0.0f, 0.0f);
    ImVec2 touch_follow_vel = ImVec2(0.0f, 0.0f);
    float touch_follow_amp = 0.0f;

    GLuint program = 0;
    GLuint tex = 0;
    GLint u_tex = -1;
    GLint u_res = -1;
    GLint u_time = -1;
    GLint u_count = -1;
    GLint u_ripples = -1;
    GLint u_shape_center = -1;
    GLint u_shape_half = -1;
    GLint u_shape_vel = -1;
    GLint u_shape_phase = -1;
    GLint u_shape_amp = -1;
    GLint u_shape_round = -1;
    GLint u_shape_clip = -1;
    GLint u_touch_pos = -1;
    GLint u_touch_vel = -1;
    GLint u_touch_amp = -1;
    GLint u_touch_active = -1;
    GLint u_press_duration = -1;
    GLint u_press_radius_scale = -1;
    GLint u_press_speed_scale = -1;
    GLint u_touch_radius_scale = -1;
    GLint u_touch_force_scale = -1;
    GLint u_shape_force_scale = -1;
    int tex_w = 0;
    int tex_h = 0;
    ImVec2 flow_vel = ImVec2(0.0f, 0.0f);
    float flow_phase = 0.0f;
    float flow_amp = 0.0f;
    float flow_round = 12.0f;
    float flow_clip = 1.0f;
};

static MenuRippleFxState menuRippleFx;

static void ResetMenuRippleState() {
    for (int i = 0; i < MenuRippleFxState::MaxRipples; ++i) {
        menuRippleFx.ripples[i].active = false;
    }
    menuRippleFx.tap_tracking = false;
    menuRippleFx.tap_moved = false;
    menuRippleFx.drag_tracking = false;
    menuRippleFx.drag_emit_accum = 0.0f;
    menuRippleFx.inertia_active = false;
    menuRippleFx.inertia_emit_accum = 0.0f;
    menuRippleFx.inertia_time = 0.0f;
    menuRippleFx.motion_has_prev = false;
    menuRippleFx.motion_target_kind = 0;
    menuRippleFx.motion_emit_accum = 0.0f;
    menuRippleFx.motion_tail_active = false;
    menuRippleFx.motion_tail_emit_accum = 0.0f;
    menuRippleFx.motion_tail_time = 0.0f;
    menuRippleFx.motion_prev_vel = ImVec2(0.0f, 0.0f);
    menuRippleFx.motion_counter_active = false;
    menuRippleFx.motion_counter_vel = ImVec2(0.0f, 0.0f);
    menuRippleFx.motion_counter_time = 0.0f;
    menuRippleFx.touch_follow_active = false;
    menuRippleFx.touch_follow_pos = ImVec2(0.0f, 0.0f);
    menuRippleFx.touch_follow_vel = ImVec2(0.0f, 0.0f);
    menuRippleFx.touch_follow_amp = 0.0f;
    menuRippleFx.flow_vel = ImVec2(0.0f, 0.0f);
    menuRippleFx.flow_phase = 0.0f;
    menuRippleFx.flow_amp = 0.0f;
    menuRippleFx.flow_round = 12.0f;
    menuRippleFx.flow_clip = 1.0f;
}

static void SuppressMenuMotionFlow(float dt) {
    menuRippleFx.motion_has_prev = false;
    menuRippleFx.motion_target_kind = 0;
    menuRippleFx.motion_emit_accum = 0.0f;
    menuRippleFx.motion_tail_active = false;
    menuRippleFx.motion_tail_emit_accum = 0.0f;
    menuRippleFx.motion_tail_time = 0.0f;
    menuRippleFx.motion_prev_vel = ImVec2(0.0f, 0.0f);
    menuRippleFx.motion_counter_active = false;
    menuRippleFx.motion_counter_vel = ImVec2(0.0f, 0.0f);
    menuRippleFx.motion_counter_time = 0.0f;
    const float damp = std::exp(-18.0f * std::max(0.0f, dt));
    menuRippleFx.flow_vel = ImVec2(menuRippleFx.flow_vel.x * damp, menuRippleFx.flow_vel.y * damp);
    menuRippleFx.flow_amp *= damp;
    menuRippleFx.flow_clip = 0.0f;
}

static GLuint CompileShaderLocal(GLenum type, const char* src) {
    GLuint shader = glCreateShader(type);
    if (!shader) return 0;
    glShaderSource(shader, 1, &src, nullptr);
    glCompileShader(shader);
    GLint ok = 0;
    glGetShaderiv(shader, GL_COMPILE_STATUS, &ok);
    if (!ok) {
        glDeleteShader(shader);
        return 0;
    }
    return shader;
}

static void EnsureMenuRippleProgram() {
    if (menuRippleFx.program != 0) {
        return;
    }
    static const char* kVs = R"(#version 300 es
precision mediump float;
const vec2 kVerts[3] = vec2[](
    vec2(-1.0, -1.0),
    vec2( 3.0, -1.0),
    vec2(-1.0,  3.0)
);
void main() {
    gl_Position = vec4(kVerts[gl_VertexID], 0.0, 1.0);
}
)";
    static const char* kFs = R"(#version 300 es
precision highp float;
uniform sampler2D u_tex;
uniform vec2 u_res;
uniform float u_time;
uniform int u_count;
uniform vec4 u_ripples[8]; 
uniform vec2 u_shape_center;
uniform vec2 u_shape_half;
uniform vec2 u_shape_vel;
uniform float u_shape_phase;
uniform float u_shape_amp;
uniform float u_shape_round;
uniform float u_shape_clip;
uniform vec2 u_touch_pos;
uniform vec2 u_touch_vel;
uniform float u_touch_amp;
uniform float u_touch_active;
uniform float u_press_duration;
uniform float u_press_radius_scale;
uniform float u_press_speed_scale;
uniform float u_touch_radius_scale;
uniform float u_touch_force_scale;
uniform float u_shape_force_scale;
out vec4 fragColor;

void main() {
    vec2 frag_top = vec2(gl_FragCoord.x, u_res.y - gl_FragCoord.y);
    vec2 obj_rel = frag_top - u_shape_center;
    vec2 obj_half = max(u_shape_half, vec2(1.0));
    float obj_rr = clamp(u_shape_round, 0.0, min(obj_half.x, obj_half.y) - 0.5);
    vec2 obj_d = abs(obj_rel) - (obj_half - vec2(obj_rr));
    float obj_outside = length(max(obj_d, vec2(0.0)));
    float obj_inside = min(max(obj_d.x, obj_d.y), 0.0);
    float obj_sd = obj_outside + obj_inside - obj_rr; 
    vec2 offset = vec2(0.0);
    float clip_t = clamp(u_shape_clip, 0.0, 1.0);
    float clip_on = step(0.001, clip_t);
    float outside_only_mask = smoothstep(0.6, 8.0, obj_sd);
    float duration = max(0.08, u_press_duration);
    for (int i = 0; i < 8; ++i) {
        if (i >= u_count) break;
        vec4 r = u_ripples[i];
        float t = u_time - r.z;
        if (t <= 0.0 || t >= duration) continue;
        vec2 delta = frag_top - r.xy;
        float dist = length(delta);
        float amp = max(0.10, r.w);
        float wave_front = t * (720.0 + 170.0 * amp) * max(0.20, u_press_speed_scale);
        float band = (24.0 + (20.0 + 10.0 * amp) * t) * max(0.20, u_press_radius_scale);
        float x = (dist - wave_front) / max(1.0, band);
        float envelope = exp(-x * x) * exp(-t * (1.45 + 0.55 * (1.0 - amp)));
        float wave = sin((dist - wave_front) * (0.10 + 0.04 * amp)) * envelope;
        vec2 dir = (dist > 0.001) ? (delta / dist) : vec2(0.0);
        float point_mask = mix(1.0, outside_only_mask, clip_on);
        offset += dir * (wave * ((3.2 + 3.6 * amp) * (1.0 - t / duration)) * point_mask);
    }

    
    if (u_shape_amp > 0.001) {
        vec2 rel = frag_top - u_shape_center;
        vec2 half_sz = max(u_shape_half, vec2(1.0));
        float rr = clamp(u_shape_round, 0.0, min(half_sz.x, half_sz.y) - 0.5);
        vec2 d = abs(rel) - (half_sz - vec2(rr));
        float outside = length(max(d, vec2(0.0)));
        float inside = min(max(d.x, d.y), 0.0);
        float sd = outside + inside - rr; 

        vec2 vel = u_shape_vel;
        float vlen = max(length(vel), 1.0);
        
        vec2 dir = vel / vlen;
        vec2 n = vec2(-dir.y, dir.x);
        float reach = max(1.0, abs(dir.x) * half_sz.x + abs(dir.y) * half_sz.y);
        float along = dot(rel, dir);
        float across = dot(rel, n);

        float clip_boost = mix(1.0, 1.65, clip_t);
        float trail = smoothstep(1.28, -0.34, along / reach);
        float half_perp = abs(n.x) * half_sz.x + abs(n.y) * half_sz.y;
        float sd_out = max(sd, 0.0);
        
        float edge_k = (24.0 + 18.0 * u_shape_amp) * clip_boost;
        float across_k = (half_perp + 74.0 + 82.0 * u_shape_amp) * clip_boost;
        float long_k = (58.0 + 94.0 * u_shape_amp) * (0.85 + 0.65 * clip_boost);
        float edge_band = exp(-((sd_out * sd_out) / max(1.0, edge_k * edge_k)));
        float sheet_across = exp(-((across * across) / max(1.0, across_k * across_k)));
        float sheet_long = exp(-((along * along) / max(1.0, long_k * long_k)));
        float wake_field = max(edge_band * 0.40, sheet_across * sheet_long);
        
        
        float clip_mask = smoothstep(0.6, 8.0, sd); 
        float outside_mask = mix(1.0, clip_mask, clip_on);
        float wake = sin(across * 0.070 - u_shape_phase * (6.8 + 2.2 * u_shape_amp));
        float flow = wake * wake_field * trail * outside_mask * u_shape_amp;
        float force_scale = mix(1.0, 1.14, clip_t);
        float shape_force = max(0.20, u_shape_force_scale);
        offset += n * (flow * 3.0 * force_scale * shape_force) + dir * (flow * 1.0 * force_scale * shape_force);
    }

    
    if (u_touch_active > 0.001 && u_touch_amp > 0.001) {
        vec2 tr = frag_top - u_touch_pos;
        vec2 tvel = u_touch_vel;
        float tv_raw = length(tvel);
        if (tv_raw > 12.0) { 
            vec2 tdir = tvel / tv_raw;
            vec2 tn = vec2(-tdir.y, tdir.x);
            float talong = dot(tr, tdir);
            float tacross = dot(tr, tn);
            float rad = length(tr);
            float touch_rad = max(0.20, u_touch_radius_scale);
            float head_k = (42.0 + 70.0 * u_touch_amp) * touch_rad;
            float tail_k = (86.0 + 150.0 * u_touch_amp) * touch_rad;
            float cross_k = (34.0 + 56.0 * u_touch_amp) * touch_rad;
            float ahead = smoothstep(head_k * 0.95, -head_k * 0.10, talong);
            float behind = smoothstep(-tail_k, tail_k * 0.18, talong);
            float along_mask = ahead * behind;
            float radial_mask = exp(-((rad * rad) / max(1.0, (head_k * 0.92) * (head_k * 0.92))));
            float cross_mask = exp(-((tacross * tacross) / max(1.0, cross_k * cross_k)));
            float tail_fade = exp(-max(0.0, -talong) / max(1.0, tail_k * 0.85));
            float core = along_mask * cross_mask * max(radial_mask, tail_fade * 0.96);
            float tw = sin(tacross * 0.22 - u_shape_phase * 8.8);

            float boat_clip_mask = smoothstep(0.6, 3.2, obj_sd);
            float boat_mask = mix(1.0, boat_clip_mask, clip_on);
            float tf = tw * core * boat_mask * u_touch_amp;
            float touch_force = max(0.20, u_touch_force_scale);
            offset += tn * (tf * 5.2 * touch_force) + tdir * (tf * 1.05 * touch_force);
        }
    }

    
    if (clip_on > 0.5 && obj_sd < 0.0) {
        offset = vec2(0.0);
    }

    vec2 uv = (gl_FragCoord.xy + vec2(offset.x, -offset.y)) / u_res;
    uv = clamp(uv, vec2(0.0), vec2(1.0));
    fragColor = texture(u_tex, uv);
}
)";

    GLuint vs = CompileShaderLocal(GL_VERTEX_SHADER, kVs);
    GLuint fs = CompileShaderLocal(GL_FRAGMENT_SHADER, kFs);
    if (!vs || !fs) {
        if (vs) glDeleteShader(vs);
        if (fs) glDeleteShader(fs);
        return;
    }
    GLuint prog = glCreateProgram();
    if (!prog) {
        glDeleteShader(vs);
        glDeleteShader(fs);
        return;
    }
    glAttachShader(prog, vs);
    glAttachShader(prog, fs);
    glLinkProgram(prog);
    glDeleteShader(vs);
    glDeleteShader(fs);
    GLint linked = 0;
    glGetProgramiv(prog, GL_LINK_STATUS, &linked);
    if (!linked) {
        glDeleteProgram(prog);
        return;
    }
    menuRippleFx.program = prog;
    menuRippleFx.u_tex = glGetUniformLocation(prog, "u_tex");
    menuRippleFx.u_res = glGetUniformLocation(prog, "u_res");
    menuRippleFx.u_time = glGetUniformLocation(prog, "u_time");
    menuRippleFx.u_count = glGetUniformLocation(prog, "u_count");
    menuRippleFx.u_ripples = glGetUniformLocation(prog, "u_ripples");
    menuRippleFx.u_shape_center = glGetUniformLocation(prog, "u_shape_center");
    menuRippleFx.u_shape_half = glGetUniformLocation(prog, "u_shape_half");
    menuRippleFx.u_shape_vel = glGetUniformLocation(prog, "u_shape_vel");
    menuRippleFx.u_shape_phase = glGetUniformLocation(prog, "u_shape_phase");
    menuRippleFx.u_shape_amp = glGetUniformLocation(prog, "u_shape_amp");
    menuRippleFx.u_shape_round = glGetUniformLocation(prog, "u_shape_round");
    menuRippleFx.u_shape_clip = glGetUniformLocation(prog, "u_shape_clip");
    menuRippleFx.u_touch_pos = glGetUniformLocation(prog, "u_touch_pos");
    menuRippleFx.u_touch_vel = glGetUniformLocation(prog, "u_touch_vel");
    menuRippleFx.u_touch_amp = glGetUniformLocation(prog, "u_touch_amp");
    menuRippleFx.u_touch_active = glGetUniformLocation(prog, "u_touch_active");
    menuRippleFx.u_press_duration = glGetUniformLocation(prog, "u_press_duration");
    menuRippleFx.u_press_radius_scale = glGetUniformLocation(prog, "u_press_radius_scale");
    menuRippleFx.u_press_speed_scale = glGetUniformLocation(prog, "u_press_speed_scale");
    menuRippleFx.u_touch_radius_scale = glGetUniformLocation(prog, "u_touch_radius_scale");
    menuRippleFx.u_touch_force_scale = glGetUniformLocation(prog, "u_touch_force_scale");
    menuRippleFx.u_shape_force_scale = glGetUniformLocation(prog, "u_shape_force_scale");
}

static void EnsureMenuRippleTexture(int w, int h) {
    if (w <= 0 || h <= 0) return;
    if (menuRippleFx.tex == 0) {
        glGenTextures(1, &menuRippleFx.tex);
    }
    if (menuRippleFx.tex == 0) {
        return;
    }
    if (menuRippleFx.tex_w == w && menuRippleFx.tex_h == h) {
        return;
    }
    GLint prev = 0;
    glGetIntegerv(GL_TEXTURE_BINDING_2D, &prev);
    glBindTexture(GL_TEXTURE_2D, menuRippleFx.tex);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, nullptr);
    glBindTexture(GL_TEXTURE_2D, (GLuint)prev);
    menuRippleFx.tex_w = w;
    menuRippleFx.tex_h = h;
}

static inline bool InsideRect(const ImVec2& p, const ImVec2& min, const ImVec2& max) {
    return p.x >= min.x && p.x <= max.x && p.y >= min.y && p.y <= max.y;
}

static void SpawnMenuRipple(const ImVec2& pos, float strength = 1.0f) {
    const float now = menuRippleFx.time;
    const float s = std::clamp(strength, 0.10f, 1.50f);
    for (int i = 0; i < MenuRippleFxState::MaxRipples; ++i) {
        MenuRippleInstance& r = menuRippleFx.ripples[i];
        if (!r.active) continue;
        const float age = now - r.start_time;
        if (age < 0.0f || age > 0.07f) continue;
        const ImVec2 d = ImVec2(pos.x - r.center.x, pos.y - r.center.y);
        if ((d.x * d.x + d.y * d.y) <= (24.0f * 24.0f)) {
            r.center = ImVec2((r.center.x + pos.x) * 0.5f, (r.center.y + pos.y) * 0.5f);
            r.strength = std::max(r.strength, s);
            return;
        }
    }

    int idx = -1;
    for (int i = 0; i < MenuRippleFxState::MaxRipples; ++i) {
        if (!menuRippleFx.ripples[i].active) {
            idx = i;
            break;
        }
    }
    if (idx < 0) {
        idx = 0;
        for (int i = 1; i < MenuRippleFxState::MaxRipples; ++i) {
            if (menuRippleFx.ripples[i].start_time < menuRippleFx.ripples[idx].start_time) {
                idx = i;
            }
        }
    }
    menuRippleFx.ripples[idx].active = true;
    menuRippleFx.ripples[idx].center = pos;
    menuRippleFx.ripples[idx].start_time = menuRippleFx.time;
    menuRippleFx.ripples[idx].strength = s;
}

static void EmitDragTrailRipple(ClickGUI* gui, const ImVec2& pos, float speed) {
    if (!gui) {
        return;
    }
    const float speed_norm = std::clamp(speed / 2100.0f, 0.18f, 1.0f);
    const float drag_strength = std::clamp(gui->rippleTuning.dragStrength, 0.20f, 4.0f);
    SpawnMenuRipple(pos, std::clamp(speed_norm * drag_strength * 0.72f, 0.10f, 1.35f));
}

static ImVec2 RectCenter(const ImVec2& min, const ImVec2& max) {
    return ImVec2((min.x + max.x) * 0.5f, (min.y + max.y) * 0.5f);
}

static bool GetRippleMotionTargetRect(ClickGUI* gui, ImVec2* out_min, ImVec2* out_max, int* out_kind) {
    if (!gui) {
        return false;
    }
    ImVec2 pmin(0.0f, 0.0f), pmax(0.0f, 0.0f);
    if (ColorPickerPopupGetVisualRect(&pmin, &pmax)) {
        if (out_min) *out_min = pmin;
        if (out_max) *out_max = pmax;
        if (out_kind) *out_kind = 3;
        return true;
    }
    if (ComboPopupGetVisualRect(&pmin, &pmax)) {
        if (out_min) *out_min = pmin;
        if (out_max) *out_max = pmax;
        if (out_kind) *out_kind = 2;
        return true;
    }
    if (gui->open && gui->overlayMenuValid) {
        if (out_min) *out_min = gui->overlayMenuMin;
        if (out_max) *out_max = gui->overlayMenuMax;
        if (out_kind) *out_kind = 1;
        return true;
    }
    return false;
}

static void UpdateMenuMotionFlowRipples(ClickGUI* gui, float dt) {
    if (!gui) {
        return;
    }
    ImVec2 target_min(0.0f, 0.0f), target_max(0.0f, 0.0f);
    int target_kind = 0;
    if (!GetRippleMotionTargetRect(gui, &target_min, &target_max, &target_kind)) {
        menuRippleFx.motion_has_prev = false;
        menuRippleFx.motion_tail_active = false;
        menuRippleFx.motion_counter_active = false;
        menuRippleFx.motion_target_kind = 0;
        menuRippleFx.motion_emit_accum = 0.0f;
        const float damp = std::exp(-4.0f * std::max(0.0f, dt));
        menuRippleFx.flow_vel = ImVec2(menuRippleFx.flow_vel.x * damp, menuRippleFx.flow_vel.y * damp);
        menuRippleFx.flow_amp *= damp;
        menuRippleFx.flow_clip = std::clamp(menuRippleFx.flow_clip + (1.0f - menuRippleFx.flow_clip) * (1.0f - damp), 0.0f, 1.0f);
        menuRippleFx.flow_phase += dt * (1.2f + 2.4f * menuRippleFx.flow_amp);
        return;
    }

    const ImVec2 center = RectCenter(target_min, target_max);
    if (menuRippleFx.motion_target_kind != target_kind) {
        menuRippleFx.motion_target_kind = target_kind;
        menuRippleFx.motion_has_prev = false;
        menuRippleFx.motion_tail_active = false;
        menuRippleFx.motion_counter_active = false;
        menuRippleFx.motion_emit_accum = 0.0f;
    }
    if (target_kind == 1 && gui->theme) {
        menuRippleFx.flow_round = std::max(0.0f, GetEffectiveCornerRadius(gui));
    } else {
        menuRippleFx.flow_round = 16.0f;
    }

    const float dt_safe = std::max(dt, 1e-4f);
    if (!menuRippleFx.motion_has_prev) {
        menuRippleFx.motion_prev_center = center;
        menuRippleFx.motion_prev_vel = ImVec2(0.0f, 0.0f);
        menuRippleFx.motion_has_prev = true;
        return;
    }

    const ImVec2 delta(center.x - menuRippleFx.motion_prev_center.x,
                       center.y - menuRippleFx.motion_prev_center.y);
    const float dist = std::sqrt(std::max(0.0f, delta.x * delta.x + delta.y * delta.y));
    const float speed = dist / dt_safe;
    const ImVec2 inst_vel(delta.x / dt_safe, delta.y / dt_safe);
    const float prev_speed = std::sqrt(
        menuRippleFx.motion_prev_vel.x * menuRippleFx.motion_prev_vel.x +
        menuRippleFx.motion_prev_vel.y * menuRippleFx.motion_prev_vel.y
    );
    const float decel = (prev_speed - speed) / dt_safe;
    if (prev_speed > 160.0f && decel > 1200.0f) {
        const float push = std::clamp((decel - 900.0f) / 2600.0f, 0.22f, 0.95f);
        menuRippleFx.motion_counter_active = true;
        menuRippleFx.motion_counter_time = 0.0f;
        menuRippleFx.motion_counter_vel = ImVec2(
            -menuRippleFx.motion_prev_vel.x * push,
            -menuRippleFx.motion_prev_vel.y * push
        );
    }
    menuRippleFx.motion_tail_vel = ImVec2(
        menuRippleFx.motion_tail_vel.x * 0.58f + inst_vel.x * 0.42f,
        menuRippleFx.motion_tail_vel.y * 0.58f + inst_vel.y * 0.42f
    );

    float tail_speed_now = std::sqrt(
        menuRippleFx.motion_tail_vel.x * menuRippleFx.motion_tail_vel.x +
        menuRippleFx.motion_tail_vel.y * menuRippleFx.motion_tail_vel.y
    );

    if (speed > 78.0f) {
        menuRippleFx.motion_tail_active = false;
    } else {
        if (!menuRippleFx.motion_tail_active && tail_speed_now > 120.0f) {
            menuRippleFx.motion_tail_active = true;
            menuRippleFx.motion_tail_pos = center;
            menuRippleFx.motion_tail_time = 0.0f;
            menuRippleFx.motion_tail_emit_accum = 0.0f;
        }
    }

    if (menuRippleFx.motion_tail_active) {
        menuRippleFx.motion_tail_time += dt;
        const float damp = std::exp(-6.2f * std::max(0.0f, dt));
        menuRippleFx.motion_tail_vel = ImVec2(menuRippleFx.motion_tail_vel.x * damp,
                                               menuRippleFx.motion_tail_vel.y * damp);
        menuRippleFx.motion_tail_pos = ImVec2(
            menuRippleFx.motion_tail_pos.x + menuRippleFx.motion_tail_vel.x * dt,
            menuRippleFx.motion_tail_pos.y + menuRippleFx.motion_tail_vel.y * dt
        );
        const float tail_speed = std::sqrt(
            menuRippleFx.motion_tail_vel.x * menuRippleFx.motion_tail_vel.x +
            menuRippleFx.motion_tail_vel.y * menuRippleFx.motion_tail_vel.y
        );
        tail_speed_now = tail_speed;
        menuRippleFx.motion_tail_emit_accum += dt;
        if (tail_speed < 24.0f || menuRippleFx.motion_tail_time > 0.78f ||
            !InsideRect(menuRippleFx.motion_tail_pos, target_min, target_max)) {
            menuRippleFx.motion_tail_active = false;
        }
    }

    if (menuRippleFx.motion_counter_active) {
        menuRippleFx.motion_counter_time += dt;
        const float damp = std::exp(-8.4f * std::max(0.0f, dt));
        menuRippleFx.motion_counter_vel = ImVec2(
            menuRippleFx.motion_counter_vel.x * damp,
            menuRippleFx.motion_counter_vel.y * damp
        );
        const float cv = std::sqrt(
            menuRippleFx.motion_counter_vel.x * menuRippleFx.motion_counter_vel.x +
            menuRippleFx.motion_counter_vel.y * menuRippleFx.motion_counter_vel.y
        );
        if (cv < 18.0f || menuRippleFx.motion_counter_time > 0.42f) {
            menuRippleFx.motion_counter_active = false;
        }
    }

    ImVec2 desired_vel = menuRippleFx.motion_tail_active ? menuRippleFx.motion_tail_vel : inst_vel;
    if (menuRippleFx.motion_counter_active) {
        desired_vel = ImVec2(
            desired_vel.x + menuRippleFx.motion_counter_vel.x,
            desired_vel.y + menuRippleFx.motion_counter_vel.y
        );
    }
    float desired_amp = std::clamp(speed / 3200.0f, 0.0f, 0.40f);
    if (dist > 0.35f) {
        desired_amp = std::max(desired_amp, 0.03f);
    }
    if (menuRippleFx.motion_tail_active) {
        desired_amp = std::max(desired_amp, std::clamp(tail_speed_now / 5200.0f, 0.0f, 0.26f));
    }
    if (menuRippleFx.motion_counter_active) {
        const float cv = std::sqrt(
            menuRippleFx.motion_counter_vel.x * menuRippleFx.motion_counter_vel.x +
            menuRippleFx.motion_counter_vel.y * menuRippleFx.motion_counter_vel.y
        );
        desired_amp = std::max(desired_amp, std::clamp(cv / 4200.0f, 0.05f, 0.28f));
    }
    const float blend = 1.0f - std::exp(-6.2f * std::max(0.0f, dt));
    menuRippleFx.flow_vel = ImVec2(
        menuRippleFx.flow_vel.x + (desired_vel.x - menuRippleFx.flow_vel.x) * blend,
        menuRippleFx.flow_vel.y + (desired_vel.y - menuRippleFx.flow_vel.y) * blend
    );
    menuRippleFx.flow_amp = std::clamp(
        menuRippleFx.flow_amp + (desired_amp - menuRippleFx.flow_amp) * blend,
        0.0f,
        1.0f
    );
    const bool menu_opening = (target_kind == 1 && gui->animation.animationProgress < 0.995f);
    const bool shape_in_motion = (dist > 0.20f) || menuRippleFx.motion_tail_active ||
                                 menuRippleFx.motion_counter_active || menu_opening;
    const float target_clip = shape_in_motion ? 1.0f : 0.0f;
    menuRippleFx.flow_clip = std::clamp(
        menuRippleFx.flow_clip + (target_clip - menuRippleFx.flow_clip) * blend,
        0.0f, 1.0f
    );
    menuRippleFx.flow_phase += dt * (2.0f + 6.4f * menuRippleFx.flow_amp);

    menuRippleFx.motion_prev_center = center;
    menuRippleFx.motion_prev_vel = inst_vel;
}

void UpdateMenuRippleInputImpl(ClickGUI* gui, float dt, const ImVec2& mouse_pos, bool mouse_down, bool mouse_clicked, bool mouse_released) {
    menuRippleFx.time += std::max(0.0f, dt);
    if (!gui) {
        return;
    }
    if (!gui->menuRippleEnabled) {
        ResetMenuRippleState();
        return;
    }
    const bool popup_open = ComboPopupBlocksInput() || ColorPickerPopupBlocksInput();
    const bool suppress_motion_flow =
        !popup_open &&
        ((menuRippleFx.drag_tracking && mouse_down) || menuRippleFx.inertia_active);
    if (suppress_motion_flow) {
        SuppressMenuMotionFlow(dt);
    } else {
        UpdateMenuMotionFlowRipples(gui, dt);
    }
    const bool single_touch = (GetTouchSystem.ActiveTouchIDs.Size <= 1);
    bool touch_follow_active = false;
    ImVec2 touch_follow_pos = mouse_pos;
    ImVec2 touch_follow_vel = ImVec2(0.0f, 0.0f);
    float touch_follow_amp = 0.0f;

    if (mouse_clicked) {
        menuRippleFx.tap_tracking = true;
        menuRippleFx.tap_moved = false;
        menuRippleFx.tap_start = mouse_pos;
        menuRippleFx.tap_time = 0.0f;
        menuRippleFx.drag_tracking = !popup_open && gui->open && gui->overlayMenuValid &&
            InsideRect(mouse_pos, gui->overlayMenuMin, gui->overlayMenuMax);
        menuRippleFx.drag_last_pos = mouse_pos;
        menuRippleFx.drag_velocity = ImVec2(0.0f, 0.0f);
        menuRippleFx.drag_emit_accum = 0.0f;
        menuRippleFx.inertia_active = false;
        SuppressMenuMotionFlow(dt);
        menuRippleFx.flow_clip = 0.0f; 
    }

    if (!menuRippleFx.tap_tracking) {
        if (!menuRippleFx.inertia_active) {
            menuRippleFx.touch_follow_active = false;
            menuRippleFx.touch_follow_pos = mouse_pos;
            menuRippleFx.touch_follow_vel = ImVec2(0.0f, 0.0f);
            menuRippleFx.touch_follow_amp = 0.0f;
            return;
        }
    }

    menuRippleFx.tap_time += std::max(0.0f, dt);
    const float move_thresh = std::max(6.0f, 14.0f * gui->cache.uiScale);
    const float move_thresh_sq = move_thresh * move_thresh;
    ImVec2 d = ImVec2(mouse_pos.x - menuRippleFx.tap_start.x, mouse_pos.y - menuRippleFx.tap_start.y);
    if ((d.x * d.x + d.y * d.y) > move_thresh_sq) {
        menuRippleFx.tap_moved = true;
    }
    if (mouse_down && menuRippleFx.tap_time > 0.30f) {
        menuRippleFx.tap_moved = true; 
    }

    if (menuRippleFx.drag_tracking && mouse_down && !popup_open && gui->open && gui->overlayMenuValid && single_touch) {
        ImVec2 delta = ImVec2(mouse_pos.x - menuRippleFx.drag_last_pos.x, mouse_pos.y - menuRippleFx.drag_last_pos.y);
        const float delta_len2 = delta.x * delta.x + delta.y * delta.y;
        const float dt_safe = std::max(dt, 1e-4f);
        if (delta_len2 > 0.0f) {
            const ImVec2 vel = ImVec2(delta.x / dt_safe, delta.y / dt_safe);
            menuRippleFx.drag_velocity = ImVec2(
                menuRippleFx.drag_velocity.x * 0.55f + vel.x * 0.45f,
                menuRippleFx.drag_velocity.y * 0.55f + vel.y * 0.45f
            );
        }
        const float dist = std::sqrt(std::max(0.0f, delta_len2));
        menuRippleFx.drag_emit_accum += dist;
        menuRippleFx.drag_last_pos = mouse_pos;
        const float drag_speed = std::sqrt(
            menuRippleFx.drag_velocity.x * menuRippleFx.drag_velocity.x +
            menuRippleFx.drag_velocity.y * menuRippleFx.drag_velocity.y
        );
        const float emit_step = std::max(8.0f, 18.0f * std::max(0.75f, gui->cache.uiScale));
        while (menuRippleFx.drag_emit_accum >= emit_step) {
            menuRippleFx.drag_emit_accum -= emit_step;
            EmitDragTrailRipple(gui, mouse_pos, drag_speed);
        }
        if (drag_speed > 12.0f) {
            touch_follow_active = true;
            touch_follow_pos = mouse_pos;
            touch_follow_vel = menuRippleFx.drag_velocity;
            touch_follow_amp = std::clamp(drag_speed / 2800.0f, 0.0f, 0.70f);
        }
    }

    if (mouse_released) {
        const bool is_tap = !menuRippleFx.tap_moved && menuRippleFx.tap_time <= 0.30f;
        if (is_tap && !popup_open && gui->open && gui->overlayMenuValid &&
            InsideRect(mouse_pos, gui->overlayMenuMin, gui->overlayMenuMax)) {
            const float click_boost = 1.45f;
            SpawnMenuRipple(mouse_pos, std::clamp(gui->rippleTuning.pressStrength * click_boost, 0.10f, 2.0f));
        }
        if (!is_tap && menuRippleFx.drag_tracking) {
            const float v = std::sqrt(
                menuRippleFx.drag_velocity.x * menuRippleFx.drag_velocity.x +
                menuRippleFx.drag_velocity.y * menuRippleFx.drag_velocity.y
            );
            if (v > 90.0f) {
                menuRippleFx.inertia_active = true;
                menuRippleFx.inertia_pos = mouse_pos;
                const float max_v = 2400.0f;
                const float scale = (v > max_v) ? (max_v / v) : 1.0f;
                menuRippleFx.inertia_vel = ImVec2(menuRippleFx.drag_velocity.x * scale, menuRippleFx.drag_velocity.y * scale);
                menuRippleFx.inertia_emit_accum = 0.0f;
                menuRippleFx.inertia_time = 0.0f;
            }
        }
        menuRippleFx.tap_tracking = false;
        menuRippleFx.drag_tracking = false;
        menuRippleFx.flow_clip = 0.0f; 
    }

    if (menuRippleFx.inertia_active && !popup_open && gui->open && gui->overlayMenuValid && single_touch) {
        menuRippleFx.inertia_time += dt;
        const float damp = std::exp(-5.8f * std::max(0.0f, dt));
        menuRippleFx.inertia_vel = ImVec2(menuRippleFx.inertia_vel.x * damp, menuRippleFx.inertia_vel.y * damp);
        menuRippleFx.inertia_pos = ImVec2(
            menuRippleFx.inertia_pos.x + menuRippleFx.inertia_vel.x * dt,
            menuRippleFx.inertia_pos.y + menuRippleFx.inertia_vel.y * dt
        );

        const float speed = std::sqrt(
            menuRippleFx.inertia_vel.x * menuRippleFx.inertia_vel.x +
            menuRippleFx.inertia_vel.y * menuRippleFx.inertia_vel.y
        );
        menuRippleFx.inertia_emit_accum += dt;
        if (menuRippleFx.inertia_emit_accum >= 0.045f &&
            InsideRect(menuRippleFx.inertia_pos, gui->overlayMenuMin, gui->overlayMenuMax)) {
            menuRippleFx.inertia_emit_accum = 0.0f;
            EmitDragTrailRipple(gui, menuRippleFx.inertia_pos, speed);
        }
        if (speed < 35.0f || menuRippleFx.inertia_time > 0.85f ||
            !InsideRect(menuRippleFx.inertia_pos, gui->overlayMenuMin, gui->overlayMenuMax)) {
            menuRippleFx.inertia_active = false;
        } else if (speed > 12.0f) {
            touch_follow_active = true;
            touch_follow_pos = menuRippleFx.inertia_pos;
            touch_follow_vel = menuRippleFx.inertia_vel;
            touch_follow_amp = std::clamp(speed / 1800.0f, 0.0f, 0.90f);
        }
    } else if (menuRippleFx.inertia_active) {
        menuRippleFx.inertia_active = false;
    }

    if (touch_follow_active) {
        SuppressMenuMotionFlow(dt);
        menuRippleFx.flow_clip = 0.0f;
    }

    menuRippleFx.touch_follow_active = touch_follow_active;
    menuRippleFx.touch_follow_pos = touch_follow_pos;
    menuRippleFx.touch_follow_vel = touch_follow_vel;
    menuRippleFx.touch_follow_amp = touch_follow_amp;
}

static int CollectActiveRipples(float packed[MenuRippleFxState::MaxRipples * 4]) {
    const float life = 0.85f;
    int active_count = 0;
    for (int i = 0; i < MenuRippleFxState::MaxRipples; ++i) {
        MenuRippleInstance& r = menuRippleFx.ripples[i];
        if (!r.active) continue;
        if ((menuRippleFx.time - r.start_time) > life) {
            r.active = false;
            continue;
        }
        const int k = active_count * 4;
        packed[k + 0] = r.center.x;
        packed[k + 1] = r.center.y;
        packed[k + 2] = r.start_time;
        packed[k + 3] = r.strength;
        ++active_count;
        if (active_count >= MenuRippleFxState::MaxRipples) {
            break;
        }
    }
    return active_count;
}

static void RenderRippleOverlayClipped(ClickGUI* gui,
                                       int display_w,
                                       int display_h,
                                       const ImVec2& clip_min,
                                       const ImVec2& clip_max,
                                       float shape_amp_scale = 1.0f,
                                       float clip_pad_scale = 1.0f) {
    if (!gui || !gui->menuRippleEnabled || display_w <= 0 || display_h <= 0) {
        return;
    }

    float packed[MenuRippleFxState::MaxRipples * 4] = {};
    const int active_count = CollectActiveRipples(packed);
    const bool touch_active = menuRippleFx.touch_follow_active && (menuRippleFx.touch_follow_amp > 0.001f);
    const bool shape_active = menuRippleFx.flow_amp > 0.001f;
    if (active_count <= 0 && !shape_active && !touch_active) {
        return;
    }
    if (active_count <= 0 && !touch_active && menuRippleFx.flow_amp < 0.045f) {
        return;
    }
    {
        const int frame = ImGui::GetFrameCount();
        const bool strong_activity = (active_count > 0) || touch_active || (menuRippleFx.flow_amp > 0.22f);
        const int interval = strong_activity ? 1 : 2;
        static int s_last_ripple_render_frame = -10000;
        if ((frame - s_last_ripple_render_frame) < interval) {
            return;
        }
        s_last_ripple_render_frame = frame;
    }

    EnsureMenuRippleProgram();
    EnsureMenuRippleTexture(display_w, display_h);
    if (!menuRippleFx.program || !menuRippleFx.tex) {
        return;
    }

    const float shape_min_x = std::clamp(clip_min.x, 0.0f, (float)display_w);
    const float shape_min_y = std::clamp(clip_min.y, 0.0f, (float)display_h);
    const float shape_max_x = std::clamp(clip_max.x, 0.0f, (float)display_w);
    const float shape_max_y = std::clamp(clip_max.y, 0.0f, (float)display_h);
    const float vel_len = std::sqrt(menuRippleFx.flow_vel.x * menuRippleFx.flow_vel.x +
                                    menuRippleFx.flow_vel.y * menuRippleFx.flow_vel.y);
    const float clip_pad = (10.0f + menuRippleFx.flow_round +
        menuRippleFx.flow_amp * 58.0f + std::clamp(vel_len * 0.014f, 0.0f, 44.0f) +
        ((active_count > 0) ? 26.0f : 0.0f)) * std::clamp(clip_pad_scale, 0.10f, 2.0f);
    const float min_xf = std::clamp(shape_min_x - clip_pad, 0.0f, (float)display_w);
    const float min_yf = std::clamp(shape_min_y - clip_pad, 0.0f, (float)display_h);
    const float max_xf = std::clamp(shape_max_x + clip_pad, 0.0f, (float)display_w);
    const float max_yf = std::clamp(shape_max_y + clip_pad, 0.0f, (float)display_h);
    const int sx = std::clamp((int)std::floor(min_xf), 0, display_w);
    const int ex = std::clamp((int)std::ceil(max_xf), 0, display_w);
    const int sy = std::clamp((int)std::floor((float)display_h - max_yf), 0, display_h);
    const int ey = std::clamp((int)std::ceil((float)display_h - min_yf), 0, display_h);
    const int sw = ex - sx;
    const int sh = ey - sy;
    if (sw <= 1 || sh <= 1) {
        return;
    }

    GLint prev_program = 0, prev_tex0 = 0, prev_active = 0, prev_vao = 0;
    GLint prev_viewport[4] = {0, 0, 0, 0};
    GLint prev_scissor_box[4] = {0, 0, 0, 0};
    GLint prev_blend_src_rgb = 0, prev_blend_dst_rgb = 0, prev_blend_src_alpha = 0, prev_blend_dst_alpha = 0;
    GLint prev_blend_eq_rgb = 0, prev_blend_eq_alpha = 0;
    GLenum prev_depth_func = glegl_get_depth_func();
    GLboolean prev_depth_mask = glegl_get_depth_writemask();
    GLboolean prev_blend = glIsEnabled(GL_BLEND);
    GLboolean prev_depth = glIsEnabled(GL_DEPTH_TEST);
    GLboolean prev_cull = glIsEnabled(GL_CULL_FACE);
    GLboolean prev_stencil = glIsEnabled(GL_STENCIL_TEST);
    GLboolean prev_scissor = glIsEnabled(GL_SCISSOR_TEST);
    glGetIntegerv(GL_CURRENT_PROGRAM, &prev_program);
    glGetIntegerv(GL_ACTIVE_TEXTURE, &prev_active);
    glActiveTexture(GL_TEXTURE0);
    glGetIntegerv(GL_TEXTURE_BINDING_2D, &prev_tex0);
    glActiveTexture((GLenum)prev_active);
    glGetIntegerv(GL_VERTEX_ARRAY_BINDING, &prev_vao);
    glGetIntegerv(GL_VIEWPORT, prev_viewport);
    glGetIntegerv(GL_SCISSOR_BOX, prev_scissor_box);
    glGetIntegerv(GL_BLEND_SRC_RGB, &prev_blend_src_rgb);
    glGetIntegerv(GL_BLEND_DST_RGB, &prev_blend_dst_rgb);
    glGetIntegerv(GL_BLEND_SRC_ALPHA, &prev_blend_src_alpha);
    glGetIntegerv(GL_BLEND_DST_ALPHA, &prev_blend_dst_alpha);
    glGetIntegerv(GL_BLEND_EQUATION_RGB, &prev_blend_eq_rgb);
    glGetIntegerv(GL_BLEND_EQUATION_ALPHA, &prev_blend_eq_alpha);

    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, menuRippleFx.tex);
    glCopyTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, 0, 0, display_w, display_h);

    glUseProgram(menuRippleFx.program);
    glUniform1i(menuRippleFx.u_tex, 0);
    glUniform2f(menuRippleFx.u_res, (float)display_w, (float)display_h);
    glUniform1f(menuRippleFx.u_time, menuRippleFx.time);
    glUniform1i(menuRippleFx.u_count, active_count);
    glUniform4fv(menuRippleFx.u_ripples, active_count, packed);
    const float shape_cx = (shape_min_x + shape_max_x) * 0.5f;
    const float shape_cy = (shape_min_y + shape_max_y) * 0.5f;
    const float shape_hx = std::max(1.0f, (shape_max_x - shape_min_x) * 0.5f);
    const float shape_hy = std::max(1.0f, (shape_max_y - shape_min_y) * 0.5f);
    glUniform2f(menuRippleFx.u_shape_center, shape_cx, shape_cy);
    glUniform2f(menuRippleFx.u_shape_half, shape_hx, shape_hy);
    const bool touch_mode = touch_active;
    const float shape_scale = std::clamp(shape_amp_scale, 0.10f, 2.0f);
    const float shape_amp = touch_mode ? 0.0f : (menuRippleFx.flow_amp * shape_scale);
    glUniform2f(menuRippleFx.u_shape_vel, menuRippleFx.flow_vel.x, menuRippleFx.flow_vel.y);
    glUniform1f(menuRippleFx.u_shape_phase, menuRippleFx.flow_phase);
    glUniform1f(menuRippleFx.u_shape_amp, shape_amp);
    glUniform1f(menuRippleFx.u_shape_round, menuRippleFx.flow_round);
    glUniform1f(menuRippleFx.u_shape_clip, touch_mode ? 0.0f : menuRippleFx.flow_clip);
    glUniform2f(menuRippleFx.u_touch_pos, menuRippleFx.touch_follow_pos.x, menuRippleFx.touch_follow_pos.y);
    glUniform2f(menuRippleFx.u_touch_vel, menuRippleFx.touch_follow_vel.x, menuRippleFx.touch_follow_vel.y);
    glUniform1f(menuRippleFx.u_touch_amp, std::clamp(menuRippleFx.touch_follow_amp, 0.0f, 1.0f) * 0.78f);
    glUniform1f(menuRippleFx.u_touch_active, touch_active ? 1.0f : 0.0f);
    const ClickGUI::RippleTuning& ripple_cfg = gui->rippleTuning;
    glUniform1f(menuRippleFx.u_press_duration, std::clamp(ripple_cfg.pressDuration, 0.08f, 1.20f));
    glUniform1f(menuRippleFx.u_press_radius_scale, std::clamp(ripple_cfg.pressRadius * 0.84f, 0.20f, 4.00f));
    glUniform1f(menuRippleFx.u_press_speed_scale, std::clamp(ripple_cfg.pressSpeed * 0.84f, 0.20f, 4.00f));
    glUniform1f(menuRippleFx.u_touch_radius_scale, std::clamp(ripple_cfg.dragRadius, 0.20f, 4.00f));
    glUniform1f(menuRippleFx.u_touch_force_scale, std::clamp(ripple_cfg.dragStrength, 0.20f, 4.00f));
    glUniform1f(menuRippleFx.u_shape_force_scale, std::clamp(ripple_cfg.motionStrength, 0.20f, 4.00f));

    glDisable(GL_DEPTH_TEST);
    glDepthMask(GL_FALSE);
    glDisable(GL_CULL_FACE);
    glDisable(GL_STENCIL_TEST);
    glDisable(GL_BLEND);
    glViewport(0, 0, display_w, display_h);
    glEnable(GL_SCISSOR_TEST);
    glScissor(sx, sy, sw, sh);
    glBindVertexArray(0);
    glDrawArrays(GL_TRIANGLES, 0, 3);

    glScissor(prev_scissor_box[0], prev_scissor_box[1], prev_scissor_box[2], prev_scissor_box[3]);
    if (prev_scissor) glEnable(GL_SCISSOR_TEST); else glDisable(GL_SCISSOR_TEST);
    if (prev_depth) glEnable(GL_DEPTH_TEST); else glDisable(GL_DEPTH_TEST);
    if (prev_cull) glEnable(GL_CULL_FACE); else glDisable(GL_CULL_FACE);
    if (prev_stencil) glEnable(GL_STENCIL_TEST); else glDisable(GL_STENCIL_TEST);
    glDepthMask(prev_depth_mask);
    glDepthFunc(prev_depth_func);
    glBlendFuncSeparate(prev_blend_src_rgb, prev_blend_dst_rgb, prev_blend_src_alpha, prev_blend_dst_alpha);
    glBlendEquationSeparate(prev_blend_eq_rgb, prev_blend_eq_alpha);
    if (prev_blend) glEnable(GL_BLEND); else glDisable(GL_BLEND);
    glUseProgram((GLuint)prev_program);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, (GLuint)prev_tex0);
    glActiveTexture((GLenum)prev_active);
    glBindVertexArray((GLuint)prev_vao);
    glViewport(prev_viewport[0], prev_viewport[1], prev_viewport[2], prev_viewport[3]);
}

void RenderMenuRippleOverlayImpl(ClickGUI* gui, int display_w, int display_h) {
    if (!gui || !gui->menuRippleEnabled || !gui->open || !gui->overlayMenuValid) {
        return;
    }
    if (ComboPopupBlocksInput() || ColorPickerPopupBlocksInput()) {
        return; 
    }
    RenderRippleOverlayClipped(gui, display_w, display_h, gui->overlayMenuMin, gui->overlayMenuMax, 0.32f, 0.38f);
}

void RenderPopupRippleOverlayImpl(ClickGUI* gui, int display_w, int display_h) {
    if (!gui || !gui->menuRippleEnabled) {
        return;
    }
    ImVec2 pmin(0.0f, 0.0f), pmax(0.0f, 0.0f);
    if (ColorPickerPopupGetVisualRect(&pmin, &pmax)) {
        RenderRippleOverlayClipped(gui, display_w, display_h, pmin, pmax, 0.26f, 0.28f);
        return;
    }
    if (ComboPopupGetVisualRect(&pmin, &pmax)) {
        RenderRippleOverlayClipped(gui, display_w, display_h, pmin, pmax, 0.26f, 0.28f);
    }
}

void RenderWatermarkRippleOverlayImpl(ClickGUI* gui, int display_w, int display_h) {
    if (!gui || !gui->menuRippleEnabled) {
        return;
    }
    if (!gui->watermarkCaptureValid) {
        return;
    }
    menuRippleFx.flow_round = gui->theme ? std::max(6.0f, GetEffectiveCornerRadius(gui)) : 12.0f;
    RenderRippleOverlayClipped(gui, display_w, display_h, gui->watermarkCaptureMin, gui->watermarkCaptureMax, 0.24f, 0.32f);
}
}

void DrawMenuShadowBox(const ImVec2& min, const ImVec2& max, float rounding, float alpha_mul, ClickGUI* gui, bool blur_mode) {
    if (!post_processing.flags.shadow || alpha_mul <= 0.0001f) {
        return;
    }
    ClickGUI* resolved_gui = gui ? gui : &ClickGUI::Get();
    Theme* theme = resolved_gui ? resolved_gui->theme.get() : nullptr;
    const int shadow_rings = std::clamp(resolved_gui->appearance.shadowRings, 6, 32);
    const float shadow_smooth = std::clamp(resolved_gui->appearance.shadowSmoothness, 0.35f, 1.60f);
    
    const float tuned_alpha = std::clamp(alpha_mul * 0.78f, 0.0f, 1.0f);
    if (blur_mode) {
        ImVec4 glow = ImVec4(1.0f, 1.0f, 1.0f, 0.24f);
        if (theme && theme->IsLightMode()) {
            glow = ImVec4(0.0f, 0.0f, 0.0f, 0.18f);
        } else if (theme) {
            glow = theme->HexToImVec4(theme->material.surfaceVariant);
            glow.w = 0.24f;
        }
        drawRoundedRectShadow(min, max, rounding, ImColor(glow.x, glow.y, glow.z, glow.w), tuned_alpha, shadow_rings, shadow_smooth, true);
    } else {
        drawRoundedRectShadow(min, max, rounding, ImColor(0.0f, 0.0f, 0.0f, 0.22f), tuned_alpha, shadow_rings, shadow_smooth, true);
    }
}

static inline float GetSeamNotchRadius(float corner_radius) {
    return std::max(1.0f, corner_radius);
}

static inline float GetInverseCornerBezierK() {
    
    return 0.68f;
}

static inline float SolveOverlayAlpha(float base_alpha, float target_alpha) {
    base_alpha = std::clamp(base_alpha, 0.0f, 0.999f);
    target_alpha = std::clamp(target_alpha, 0.0f, 1.0f);
    if (target_alpha <= base_alpha + 1e-4f) {
        return 0.0f;
    }
    return std::clamp((target_alpha - base_alpha) / (1.0f - base_alpha), 0.0f, 1.0f);
}

static void DrawSeamContour(ImDrawList* draw_list,
                            float seam_x,
                            float y0,
                            float y1,
                            float inverse_r,
                            ImU32 col,
                            float thickness) {
    if (!draw_list || thickness <= 0.0f || y1 <= y0) {
        return;
    }
    const float r = std::max(0.0f, inverse_r);
    const float k = GetInverseCornerBezierK();
    const ImVec4 base = ImGui::ColorConvertU32ToFloat4(col);
    ImVec4 mid = base;
    mid.w *= 0.55f;
    const ImU32 mid_col = ImGui::GetColorU32(mid);
    ImVec4 arc_soft = base;
    arc_soft.w *= 0.42f;
    const ImU32 arc_soft_col = ImGui::GetColorU32(arc_soft);
    ImVec4 arc_main = base;
    arc_main.w *= 0.90f;
    const ImU32 arc_main_col = ImGui::GetColorU32(arc_main);

    if (r > 0.5f) {
        draw_list->PathClear();
        draw_list->PathLineTo(ImVec2(seam_x + r, y0));
        draw_list->PathBezierCubicCurveTo(
            ImVec2(seam_x + r * k, y0),
            ImVec2(seam_x, y0 + r * k),
            ImVec2(seam_x, y0 + r),
            16
        );
        draw_list->PathStroke(arc_soft_col, false, std::max(thickness * 1.8f, thickness + 1.0f));
        draw_list->PathClear();
        draw_list->PathLineTo(ImVec2(seam_x + r, y0));
        draw_list->PathBezierCubicCurveTo(
            ImVec2(seam_x + r * k, y0),
            ImVec2(seam_x, y0 + r * k),
            ImVec2(seam_x, y0 + r),
            16
        );
        draw_list->PathStroke(arc_main_col, false, thickness);
    }
    const float top_line = y0 + r;
    const float bot_line = y1 - r;
    if (bot_line > top_line) {
        const float half_t = thickness * 0.5f;
        const float fade = std::max(1.0f, r * 0.65f);
        const float line_h = bot_line - top_line;
        const ImU32 transparent = ImGui::GetColorU32(ImVec4(base.x, base.y, base.z, 0.0f));
        if (line_h > fade * 2.0f + 0.5f) {
            draw_list->AddRectFilledMultiColor(
                ImVec2(seam_x - half_t, top_line),
                ImVec2(seam_x + half_t, top_line + fade),
                transparent, transparent, mid_col, mid_col
            );
            draw_list->AddRectFilled(
                ImVec2(seam_x - half_t, top_line + fade),
                ImVec2(seam_x + half_t, bot_line - fade),
                mid_col
            );
            draw_list->AddRectFilledMultiColor(
                ImVec2(seam_x - half_t, bot_line - fade),
                ImVec2(seam_x + half_t, bot_line),
                mid_col, mid_col, transparent, transparent
            );
        } else {
            draw_list->AddRectFilledMultiColor(
                ImVec2(seam_x - half_t, top_line),
                ImVec2(seam_x + half_t, bot_line),
                transparent, transparent, transparent, transparent
            );
            draw_list->AddLine(ImVec2(seam_x, top_line), ImVec2(seam_x, bot_line), col, thickness);
        }
    }
    if (r > 0.5f) {
        draw_list->PathClear();
        draw_list->PathLineTo(ImVec2(seam_x, y1 - r));
        draw_list->PathBezierCubicCurveTo(
            ImVec2(seam_x, y1 - r * k),
            ImVec2(seam_x + r * k, y1),
            ImVec2(seam_x + r, y1),
            16
        );
        draw_list->PathStroke(arc_soft_col, false, std::max(thickness * 1.8f, thickness + 1.0f));
        draw_list->PathClear();
        draw_list->PathLineTo(ImVec2(seam_x, y1 - r));
        draw_list->PathBezierCubicCurveTo(
            ImVec2(seam_x, y1 - r * k),
            ImVec2(seam_x + r * k, y1),
            ImVec2(seam_x + r, y1),
            16
        );
        draw_list->PathStroke(arc_main_col, false, thickness);
    }
}

static void DrawSeamShadowGlow(ImDrawList* draw_list,
                               float seam_x,
                               float y0,
                               float y1,
                               float inverse_r,
                               float alpha_mul,
                               Theme* theme,
                               bool blur_mode,
                               float base_line_w) {
    if (!draw_list || !post_processing.flags.shadow || alpha_mul <= 0.0001f || y1 <= y0) {
        return;
    }

    ImVec4 glow = ImVec4(0.0f, 0.0f, 0.0f, blur_mode ? 0.20f : 0.16f);
    if (blur_mode) {
        glow = ImVec4(1.0f, 1.0f, 1.0f, 0.24f);
        if (theme && theme->IsLightMode()) {
            glow = ImVec4(0.0f, 0.0f, 0.0f, 0.18f);
        } else if (theme) {
            glow = theme->HexToImVec4(theme->material.surfaceVariant);
            glow.w = 0.24f;
        }
    } else if (theme && theme->IsLightMode()) {
        glow = theme->HexToImVec4(theme->material.onSurfaceVariant);
        glow.w = 0.15f;
    }

    glow.w *= std::clamp(alpha_mul, 0.0f, 1.0f);
    
    const float seam_half_w = std::max(base_line_w * 4.5f, inverse_r * 0.55f);
    const ImVec2 seam_min(seam_x - seam_half_w, y0);
    const ImVec2 seam_max(seam_x + seam_half_w, y1);
    const float seam_rounding = std::max(2.0f, std::min(inverse_r, seam_half_w));
    const ClickGUI& gui = ClickGUI::Get();
    const int shadow_rings = std::clamp(gui.appearance.shadowRings, 6, 32);
    const float shadow_smooth = std::clamp(gui.appearance.shadowSmoothness, 0.35f, 1.60f);
    drawRoundedRectShadow(
        seam_min,
        seam_max,
        seam_rounding,
        ImColor(glow.x, glow.y, glow.z, glow.w),
        std::clamp(alpha_mul * 0.75f, 0.0f, 1.0f),
        shadow_rings,
        shadow_smooth,
        true
    );
    const float glow_w = std::max(2.0f, base_line_w * 2.9f);
    DrawSeamContour(draw_list, seam_x, y0, y1, inverse_r, ImGui::GetColorU32(glow), glow_w);
}

static void DrawMainAreaWithInverseLeftCorners(ImDrawList* draw_list,
                                               const ImVec2& panel_min,
                                               const ImVec2& panel_max,
                                               float right_rounding,
                                               float left_inverse_rounding,
                                               ImU32 fill_col,
                                               ImU32 cut_col) {
    if (!draw_list || panel_max.x <= panel_min.x || panel_max.y <= panel_min.y) {
        return;
    }

    const float h = panel_max.y - panel_min.y;
    const float w = panel_max.x - panel_min.x;
    float ir = std::clamp(left_inverse_rounding, 0.0f, std::min(w, h) * 0.5f);
    float rr = std::clamp(right_rounding, 0.0f, std::min(w, h) * 0.5f);

    const float x0 = panel_min.x;
    const float y0 = panel_min.y;
    const float x1 = panel_max.x;
    const float y1 = panel_max.y;

    
    draw_list->AddRectFilled(
        ImVec2(x0, y0),
        ImVec2(x1, y1),
        fill_col,
        rr,
        ImDrawFlags_RoundCornersRight
    );

    if (ir > 0.5f) {
        
        const float seam_cut_overlap = std::max(0.5f, draw_list ? draw_list->_FringeScale : 1.0f);
        const float cut_x = x0 - seam_cut_overlap;
        
        const float k = GetInverseCornerBezierK();
        const ImVec2 p0(x0 + ir, y0);
        const ImVec2 p3(cut_x, y0 + ir);
        const ImVec2 c1(x0 + ir * k, y0);
        const ImVec2 c2(cut_x, y0 + ir * k);
        draw_list->PathClear();
        draw_list->PathLineTo(ImVec2(cut_x, y0));
        draw_list->PathLineTo(p0);
        draw_list->PathBezierCubicCurveTo(c1, c2, p3, 18);
        draw_list->PathFillConvex(cut_col);

        
        const ImVec2 bp0(cut_x, y1 - ir);
        const ImVec2 bp3(x0 + ir, y1);
        const ImVec2 bc1(cut_x, y1 - ir * k);
        const ImVec2 bc2(x0 + ir * k, y1);
        draw_list->PathClear();
        draw_list->PathLineTo(ImVec2(cut_x, y1));
        draw_list->PathLineTo(bp0);
        draw_list->PathBezierCubicCurveTo(bc1, bc2, bp3, 18);
        draw_list->PathFillConvex(cut_col);
    }
}

static void EnsureTabMorphTexture(TabMorphRegion& region, int w, int h) {
    if (w <= 0 || h <= 0) {
        return;
    }
    if (region.prev_tex == 0) {
        glGenTextures(1, &region.prev_tex);
    }
    if (region.curr_tex == 0) {
        glGenTextures(1, &region.curr_tex);
    }
    const bool resize = (region.tex_w != w) || (region.tex_h != h);
    if (!resize) {
        return;
    }
    GLint prev_active_tex = GL_TEXTURE0;
    GLint prev_tex0 = 0;
    glGetIntegerv(GL_ACTIVE_TEXTURE, &prev_active_tex);
    glActiveTexture(GL_TEXTURE0);
    glGetIntegerv(GL_TEXTURE_BINDING_2D, &prev_tex0);
    region.tex_w = w;
    region.tex_h = h;
    GLuint texs[2] = {region.prev_tex, region.curr_tex};
    for (GLuint tex : texs) {
        glBindTexture(GL_TEXTURE_2D, tex);
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, region.tex_w, region.tex_h, 0, GL_RGBA, GL_UNSIGNED_BYTE, nullptr);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    }
    glBindTexture(GL_TEXTURE_2D, (GLuint)prev_tex0);
    glActiveTexture((GLenum)prev_active_tex);
}

static void EnsureTabMorphProgram() {
    if (tabMorphFx.program != 0) {
        return;
    }
    static const char* kVs = R"(#version 300 es
precision mediump float;
const vec2 kVerts[3] = vec2[](
    vec2(-1.0, -1.0),
    vec2( 3.0, -1.0),
    vec2(-1.0,  3.0)
);
void main() {
    gl_Position = vec4(kVerts[gl_VertexID], 0.0, 1.0);
}
)";
static const char* kFs = R"(#version 300 es
precision highp float;
uniform sampler2D uPrev;
uniform sampler2D uCurr;
uniform vec2 uRes;
uniform vec4 uRect; 
uniform float uT;
uniform float uForce;
uniform float uBlur;
uniform float uDir;
uniform vec2 uOrigin; 
out vec4 fragColor;

vec4 samplePrev(vec2 uv) { return texture(uPrev, vec2(uv.x, 1.0 - uv.y)); }
vec4 sampleCurr(vec2 uv) { return texture(uCurr, vec2(uv.x, 1.0 - uv.y)); }
float sat(float x) { return clamp(x, 0.0, 1.0); }
float ease(float x) { x = sat(x); return x * x * (3.0 - 2.0 * x); }
float hash12(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}
vec2 quantizeUV(vec2 uv, vec2 panel, float px) {
    vec2 cell = max(vec2(px) / max(panel, vec2(1.0)), vec2(1e-4));
    return (floor(uv / cell) + 0.5) * cell;
}

void main() {
    vec2 frag_top = vec2(gl_FragCoord.x, uRes.y - gl_FragCoord.y);
    vec2 uv = (frag_top - uRect.xy) / max(uRect.zw, vec2(1.0));
    if (uv.x < 0.0 || uv.x > 1.0 || uv.y < 0.0 || uv.y > 1.0) discard;

    float t = sat(uT);
    float phase = ease(t);
    float style = sat(uBlur + uForce * 0.70);
    vec2 panel = max(uRect.zw, vec2(1.0));
    vec4 prevBase = samplePrev(uv);
    vec4 currBase = sampleCurr(uv);
    float diff = length(currBase.rgb - prevBase.rgb) + abs(currBase.a - prevBase.a) * 0.60;
    if (diff <= 0.002 && style <= 0.001) {
        fragColor = currBase;
        return;
    }

    vec2 origin = clamp(uOrigin, vec2(0.0), vec2(1.0));
    vec2 d = uv - origin;
    float dist = length(d);
    vec2 dir = (dist > 1e-4) ? d / dist : vec2(1.0, 0.0);
    vec2 side_dir = vec2(-dir.y, dir.x) * (uDir >= 0.0 ? 1.0 : -1.0);

    float front = mix(-0.18, 1.38, phase);
    float band = 0.095 + 0.024 * (1.0 - phase);
    float x = (dist - front) / max(0.008, band);
    float envelope = exp(-x * x);
    float wave = sin((dist - front) * (44.0 + 12.0 * style) - phase * 6.2) * envelope;
    float edge = 0.046 + 0.014 * style;
    float reveal = smoothstep(-edge, edge, (front - dist) + wave * (0.040 + 0.018 * style));

    vec2 nid = floor((uv + vec2(phase * 0.17, -phase * 0.11)) * panel / 7.0);
    float rnd = hash12(nid);
    float swirl_amt = (rnd - 0.5) * (0.014 + 0.006 * style) * envelope;
    vec2 swirl = side_dir * swirl_amt;
    vec2 push = dir * ((0.026 + 0.010 * style) * envelope);

    vec2 uvPrev = clamp(uv + push * (1.0 - reveal) + swirl, vec2(0.0), vec2(1.0));
    vec2 uvCurr = clamp(uv - push * reveal - swirl * 0.6, vec2(0.0), vec2(1.0));

    float pix_front = sat(envelope * (0.42 + 0.20 * style));
    float px = mix(1.0, 2.4, pix_front);
    uvPrev = quantizeUV(uvPrev, panel, px);
    uvCurr = quantizeUV(uvCurr, panel, px);

    vec4 prevCol = samplePrev(clamp(uvPrev, vec2(0.0), vec2(1.0)));
    vec4 currCol = sampleCurr(clamp(uvCurr, vec2(0.0), vec2(1.0)));
    vec4 color = mix(prevCol, currCol, reveal);

    float frontGlow = exp(-abs(dist - front) * (56.0 + 16.0 * style));
    color.rgb += vec3(0.010, 0.024, 0.032) * frontGlow * (0.28 + 0.22 * style) * (1.0 - phase * 0.72);
    color.rgb = mix(color.rgb, currBase.rgb, smoothstep(0.965, 1.0, phase));
    color.a = 1.0;
    fragColor = color;
}
)";
    GLuint vs = CompileShaderLocal(GL_VERTEX_SHADER, kVs);
    GLuint fs = CompileShaderLocal(GL_FRAGMENT_SHADER, kFs);
    if (!vs || !fs) {
        if (vs) glDeleteShader(vs);
        if (fs) glDeleteShader(fs);
        return;
    }
    GLuint prog = glCreateProgram();
    if (!prog) {
        glDeleteShader(vs);
        glDeleteShader(fs);
        return;
    }
    glAttachShader(prog, vs);
    glAttachShader(prog, fs);
    glLinkProgram(prog);
    glDeleteShader(vs);
    glDeleteShader(fs);
    GLint linked = 0;
    glGetProgramiv(prog, GL_LINK_STATUS, &linked);
    if (!linked) {
        glDeleteProgram(prog);
        return;
    }
    tabMorphFx.program = prog;
    tabMorphFx.u_prev = glGetUniformLocation(prog, "uPrev");
    tabMorphFx.u_curr = glGetUniformLocation(prog, "uCurr");
    tabMorphFx.u_res = glGetUniformLocation(prog, "uRes");
    tabMorphFx.u_rect = glGetUniformLocation(prog, "uRect");
    tabMorphFx.u_t = glGetUniformLocation(prog, "uT");
    tabMorphFx.u_force = glGetUniformLocation(prog, "uForce");
    tabMorphFx.u_blur = glGetUniformLocation(prog, "uBlur");
    tabMorphFx.u_dir = glGetUniformLocation(prog, "uDir");
    tabMorphFx.u_origin = glGetUniformLocation(prog, "uOrigin");
}

static bool CaptureRegionToTexture(GLuint tex, int tex_w, int tex_h, const ImVec2& min, const ImVec2& max, int display_h) {
    const int x = std::max(0, (int)std::floor(min.x));
    const int y_top = std::max(0, (int)std::floor(min.y));
    const int w = std::max(1, std::min(tex_w, (int)std::ceil(max.x - min.x)));
    const int h = std::max(1, std::min(tex_h, (int)std::ceil(max.y - min.y)));
    const int y_gl = std::max(0, display_h - y_top - h);
    if (!tex || w <= 0 || h <= 0) {
        return false;
    }
    GLint prev_active_tex = GL_TEXTURE0;
    GLint prev_tex0 = 0;
    glGetIntegerv(GL_ACTIVE_TEXTURE, &prev_active_tex);
    glActiveTexture(GL_TEXTURE0);
    glGetIntegerv(GL_TEXTURE_BINDING_2D, &prev_tex0);
    glBindTexture(GL_TEXTURE_2D, tex);
    glCopyTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, x, y_gl, w, h);
    glBindTexture(GL_TEXTURE_2D, (GLuint)prev_tex0);
    glActiveTexture((GLenum)prev_active_tex);
    return true;
}

static void RenderTabMorphRegion(TabMorphRegion& region,
                                 const ImVec2& min,
                                 const ImVec2& max,
                                 int display_w,
                                 int display_h,
                                 float progress,
                                 bool freeze_prev = false,
                                 ImVec2 origin_uv = ImVec2(0.0f, 0.0f)) {
    EnsureTabMorphProgram();
    if (!tabMorphFx.program) {
        return;
    }
    const int w = std::max(1, (int)std::ceil(max.x - min.x));
    const int h = std::max(1, (int)std::ceil(max.y - min.y));
    EnsureTabMorphTexture(region, w, h);
    if (!region.has_prev || region.prev_tex == 0 || region.curr_tex == 0) {
        return;
    }

    GLint prev_prog = 0, prev_active_tex = 0, prev_tex0 = 0, prev_tex1 = 0, prev_vao = 0, prev_scissor[4] = {0, 0, 0, 0};
    GLint prev_viewport[4] = {0, 0, 0, 0};
    GLint prev_blend_src_rgb = 0, prev_blend_dst_rgb = 0, prev_blend_src_alpha = 0, prev_blend_dst_alpha = 0;
    GLint prev_blend_eq_rgb = 0, prev_blend_eq_alpha = 0;
    GLenum prev_depth_func = glegl_get_depth_func();
    GLboolean prev_depth_mask = glegl_get_depth_writemask();
    GLboolean prev_color_mask[4] = {static_cast<GLboolean>(1), static_cast<GLboolean>(1),
                                    static_cast<GLboolean>(1), static_cast<GLboolean>(1)};
    GLboolean prev_blend = glIsEnabled(GL_BLEND);
    GLboolean prev_depth = glIsEnabled(GL_DEPTH_TEST);
    GLboolean prev_cull = glIsEnabled(GL_CULL_FACE);
    GLboolean prev_stencil = glIsEnabled(GL_STENCIL_TEST);
    GLboolean prev_scissor_enabled = GL_FALSE;
    glGetIntegerv(GL_CURRENT_PROGRAM, &prev_prog);
    glGetIntegerv(GL_ACTIVE_TEXTURE, &prev_active_tex);
    glActiveTexture(GL_TEXTURE0);
    glGetIntegerv(GL_TEXTURE_BINDING_2D, &prev_tex0);
    glActiveTexture((GLenum)(GL_TEXTURE0 + 1));
    glGetIntegerv(GL_TEXTURE_BINDING_2D, &prev_tex1);
    glActiveTexture((GLenum)prev_active_tex);
    glGetIntegerv(GL_VERTEX_ARRAY_BINDING, &prev_vao);
    glGetIntegerv(GL_VIEWPORT, prev_viewport);
    prev_scissor_enabled = glIsEnabled(GL_SCISSOR_TEST);
    glGetIntegerv(GL_SCISSOR_BOX, prev_scissor);
    glGetIntegerv(GL_BLEND_SRC_RGB, &prev_blend_src_rgb);
    glGetIntegerv(GL_BLEND_DST_RGB, &prev_blend_dst_rgb);
    glGetIntegerv(GL_BLEND_SRC_ALPHA, &prev_blend_src_alpha);
    glGetIntegerv(GL_BLEND_DST_ALPHA, &prev_blend_dst_alpha);
    glGetIntegerv(GL_BLEND_EQUATION_RGB, &prev_blend_eq_rgb);
    glGetIntegerv(GL_BLEND_EQUATION_ALPHA, &prev_blend_eq_alpha);
    glGetBooleanv(GL_COLOR_WRITEMASK, prev_color_mask);

    const int sx = std::max(0, (int)std::floor(min.x));
    const int sy_top = std::max(0, (int)std::floor(min.y));
    const int sw = std::max(1, (int)std::ceil(max.x - min.x));
    const int sh = std::max(1, (int)std::ceil(max.y - min.y));
    const int sy_gl = std::max(0, display_h - sy_top - sh);
    glDisable(GL_DEPTH_TEST);
    glDepthMask(GL_FALSE);
    glDisable(GL_CULL_FACE);
    glDisable(GL_STENCIL_TEST);
    glDisable(GL_BLEND);
    glEnable(GL_SCISSOR_TEST);
    glScissor(sx, sy_gl, sw, sh);
    glColorMask(GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE);
    glBindVertexArray(0);

    glUseProgram(tabMorphFx.program);
    glUniform1i(tabMorphFx.u_prev, 0);
    glUniform1i(tabMorphFx.u_curr, 1);
    glUniform2f(tabMorphFx.u_res, (float)display_w, (float)display_h);
    glUniform4f(tabMorphFx.u_rect, min.x, min.y, (float)sw, (float)sh);
    glUniform1f(tabMorphFx.u_t, std::clamp(progress, 0.0f, 1.0f));
    glUniform1f(tabMorphFx.u_force, std::clamp(tabMorphFx.force_motion, 0.0f, 1.0f));
    const float style_boost = std::clamp((tabMorphFx.speed_boost - 1.0f) * 0.72f + tabMorphFx.force_motion * 0.42f, 0.0f, 0.72f);
    glUniform1f(tabMorphFx.u_blur, style_boost);
    glUniform1f(tabMorphFx.u_dir, tabMorphFx.switch_dir >= 0.0f ? 1.0f : -1.0f);
    glUniform2f(tabMorphFx.u_origin, std::clamp(origin_uv.x, 0.0f, 1.0f), std::clamp(origin_uv.y, 0.0f, 1.0f));

    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, region.prev_tex);
    glActiveTexture((GLenum)(GL_TEXTURE0 + 1));
    glBindTexture(GL_TEXTURE_2D, freeze_prev ? region.prev_tex : region.curr_tex);
    glDrawArrays(GL_TRIANGLES, 0, 3);

    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, (GLuint)prev_tex0);
    glActiveTexture((GLenum)(GL_TEXTURE0 + 1));
    glBindTexture(GL_TEXTURE_2D, (GLuint)prev_tex1);
    glViewport(prev_viewport[0], prev_viewport[1], prev_viewport[2], prev_viewport[3]);
    glDepthMask(prev_depth_mask);
    glDepthFunc(prev_depth_func);
    glBlendFuncSeparate(prev_blend_src_rgb, prev_blend_dst_rgb, prev_blend_src_alpha, prev_blend_dst_alpha);
    glBlendEquationSeparate(prev_blend_eq_rgb, prev_blend_eq_alpha);
    glColorMask(prev_color_mask[0], prev_color_mask[1], prev_color_mask[2], prev_color_mask[3]);
    if (prev_blend) glEnable(GL_BLEND); else glDisable(GL_BLEND);
    if (prev_depth) glEnable(GL_DEPTH_TEST); else glDisable(GL_DEPTH_TEST);
    if (prev_cull) glEnable(GL_CULL_FACE); else glDisable(GL_CULL_FACE);
    if (prev_stencil) glEnable(GL_STENCIL_TEST); else glDisable(GL_STENCIL_TEST);
    glBindVertexArray((GLuint)prev_vao);
    glUseProgram((GLuint)prev_prog);
    glActiveTexture((GLenum)prev_active_tex);
    if (prev_scissor_enabled) {
        glScissor(prev_scissor[0], prev_scissor[1], prev_scissor[2], prev_scissor[3]);
    } else {
        glDisable(GL_SCISSOR_TEST);
    }
}

static void CaptureTabMorphRegionSnapshot(TabMorphRegion& region,
                                          const ImVec2& min,
                                          const ImVec2& max,
                                          int display_h) {
    const int w = std::max(1, (int)std::ceil(max.x - min.x));
    const int h = std::max(1, (int)std::ceil(max.y - min.y));
    EnsureTabMorphTexture(region, w, h);
    if (region.prev_tex == 0) {
        return;
    }
    region.has_prev = CaptureRegionToTexture(region.prev_tex, region.tex_w, region.tex_h, min, max, display_h);
}

static bool CaptureTabMorphRegionCurrent(TabMorphRegion& region,
                                         const ImVec2& min,
                                         const ImVec2& max,
                                         int display_h) {
    const int w = std::max(1, (int)std::ceil(max.x - min.x));
    const int h = std::max(1, (int)std::ceil(max.y - min.y));
    EnsureTabMorphTexture(region, w, h);
    if (region.curr_tex == 0) {
        return false;
    }
    return CaptureRegionToTexture(region.curr_tex, region.tex_w, region.tex_h, min, max, display_h);
}

static inline void FreezeTabMorphRectsOnce() {
    if (tabMorphFx.rects_frozen) {
        return;
    }
    tabMorphFx.frozen_module_min = tabMorphFx.module_min;
    tabMorphFx.frozen_module_max = tabMorphFx.module_max;
    tabMorphFx.frozen_content_min = tabMorphFx.content_min;
    tabMorphFx.frozen_content_max = tabMorphFx.content_max;
    tabMorphFx.rects_frozen = true;
}

static inline void ResetTabMorphFrozenRects() {
    tabMorphFx.rects_frozen = false;
    tabMorphFx.frozen_module_min = ImVec2(0.0f, 0.0f);
    tabMorphFx.frozen_module_max = ImVec2(0.0f, 0.0f);
    tabMorphFx.frozen_content_min = ImVec2(0.0f, 0.0f);
    tabMorphFx.frozen_content_max = ImVec2(0.0f, 0.0f);
}

void RenderTabMorphOverlayImpl(ClickGUI* gui, int display_w, int display_h) {
    if (display_w <= 0 || display_h <= 0) {
        return;
    }
    const bool menu_visible = gui && (gui->open || gui->animation.Alpha > 0.001f || gui->animation.animationProgress > 0.001f);
    if (!menu_visible && !tabMorphFx.active && !tabMorphFx.start_requested && !tabMorphFx.recapture_pending) {
        tabMorphFx.module_valid = false;
        tabMorphFx.content_valid = false;
        return;
    }
    const bool use_module = tabMorphFx.animate_module && tabMorphFx.module_valid;
    const bool use_content = tabMorphFx.animate_content && tabMorphFx.content_valid;
    if (!use_module && !use_content) {
        return;
    }
    auto fit_rect = [display_w, display_h](ImVec2 mn, ImVec2 mx, float inset) {
        mn.x = std::max(0.0f, mn.x + inset);
        mn.y = std::max(0.0f, mn.y + inset);
        mx.x = std::min((float)display_w, mx.x - inset);
        mx.y = std::min((float)display_h, mx.y - inset);
        if (mx.x <= mn.x + 1.0f) mx.x = std::min((float)display_w, mn.x + 1.0f);
        if (mx.y <= mn.y + 1.0f) mx.y = std::min((float)display_h, mn.y + 1.0f);
        return std::pair<ImVec2, ImVec2>(mn, mx);
    };
    if (tabMorphFx.active) {
        FreezeTabMorphRectsOnce();
        bool module_curr_ready = tabMorphFx.primed || !use_module;
        bool content_curr_ready = tabMorphFx.primed || !use_content;
        if (!tabMorphFx.primed) {
            if (use_module) {
                auto [mn, mx] = fit_rect(tabMorphFx.frozen_module_min, tabMorphFx.frozen_module_max, 0.0f);
                module_curr_ready = CaptureTabMorphRegionCurrent(tabMorphFx.module, mn, mx, display_h);
            }
            if (use_content) {
                auto [mn, mx] = fit_rect(tabMorphFx.frozen_content_min, tabMorphFx.frozen_content_max, 0.0f);
                content_curr_ready = CaptureTabMorphRegionCurrent(tabMorphFx.content, mn, mx, display_h);
            }
            tabMorphFx.primed = module_curr_ready && content_curr_ready;
        }
        if (use_module) {
            auto [mn, mx] = fit_rect(tabMorphFx.frozen_module_min, tabMorphFx.frozen_module_max, 0.0f);
            RenderTabMorphRegion(tabMorphFx.module, mn, mx, display_w, display_h, tabMorphFx.progress,
                                 !module_curr_ready, ImVec2(0.0f, 0.0f));
        }
        if (use_content) {
            auto [mn, mx] = fit_rect(tabMorphFx.frozen_content_min, tabMorphFx.frozen_content_max, 0.0f);
            RenderTabMorphRegion(tabMorphFx.content, mn, mx, display_w, display_h, tabMorphFx.progress,
                                 !content_curr_ready, ImVec2(1.0f, 0.0f));
        }
    } else {
        static int idle_capture_cooldown = 0;
        const bool missing_prev_module = use_module && !tabMorphFx.module.has_prev;
        const bool missing_prev_content = use_content && !tabMorphFx.content.has_prev;
        const bool force_capture = tabMorphFx.recapture_pending || missing_prev_module || missing_prev_content;
        if (!force_capture) {
            const int capture_interval = menu_visible ? 2 : 12;
            if (idle_capture_cooldown < capture_interval) {
                ++idle_capture_cooldown;
                return;
            }
        }
        idle_capture_cooldown = 0;
        ResetTabMorphFrozenRects();
        if (tabMorphFx.start_requested && !tabMorphFx.recapture_pending && !force_capture) {
            return; 
        }
        bool captured_any = false;
        if (tabMorphFx.module_valid) {
            auto [mn, mx] = fit_rect(tabMorphFx.module_min, tabMorphFx.module_max, 0.0f);
            CaptureTabMorphRegionSnapshot(tabMorphFx.module, mn, mx, display_h);
            captured_any = true;
        }
        if (tabMorphFx.content_valid) {
            auto [mn, mx] = fit_rect(tabMorphFx.content_min, tabMorphFx.content_max, 0.0f);
            CaptureTabMorphRegionSnapshot(tabMorphFx.content, mn, mx, display_h);
            captured_any = true;
        }
        if (tabMorphFx.recapture_pending) {
            if (captured_any) {
                tabMorphFx.recapture_pending = false;
                tabMorphFx.recapture_frames = 0;
            } else if (--tabMorphFx.recapture_frames <= 0) {
                tabMorphFx.recapture_pending = false;
                tabMorphFx.recapture_frames = 0;
            }
        }
    }
}

void UpdateMenuRippleInput(ClickGUI* gui, float dt, const ImVec2& mouse_pos, bool mouse_down, bool mouse_clicked, bool mouse_released) {
    UpdateMenuRippleInputImpl(gui, dt, mouse_pos, mouse_down, mouse_clicked, mouse_released);
}

void RenderMenuRippleOverlay(ClickGUI* gui, int display_w, int display_h) {
    RenderMenuRippleOverlayImpl(gui, display_w, display_h);
}

void RenderPopupRippleOverlay(ClickGUI* gui, int display_w, int display_h) {
    RenderPopupRippleOverlayImpl(gui, display_w, display_h);
}

void RenderWatermarkRippleOverlay(ClickGUI* gui, int display_w, int display_h) {
    RenderWatermarkRippleOverlayImpl(gui, display_w, display_h);
}

void RenderTabMorphOverlay(ClickGUI* gui, int display_w, int display_h) {
    RenderTabMorphOverlayImpl(gui, display_w, display_h);
}

void NotifyWatermarkRippleInteraction(ClickGUI* gui, const ImVec2& pos, float strength) {
    if (!gui || !gui->menuRippleEnabled) {
        return;
    }
    (void)pos;
    menuRippleFx.touch_follow_active = false;
    menuRippleFx.flow_vel = ImVec2(0.0f, -420.0f);
    menuRippleFx.flow_clip = 1.0f;
    const float press_strength = std::clamp(gui->rippleTuning.pressStrength, 0.20f, 3.0f);
    menuRippleFx.flow_amp = std::max(menuRippleFx.flow_amp, std::clamp(strength * 0.46f * press_strength, 0.12f, 0.82f));
    menuRippleFx.flow_phase += 0.16f;
}

void NotifyWatermarkRippleVisualMotion(ClickGUI* gui, const ImVec2& velocity, float amp, float dt) {
    if (!gui || !gui->menuRippleEnabled) {
        return;
    }
    const float dt_safe = std::max(dt, 1e-4f);
    const float blend = 1.0f - std::exp(-8.0f * dt_safe);
    menuRippleFx.flow_vel = ImVec2(
        menuRippleFx.flow_vel.x + (velocity.x - menuRippleFx.flow_vel.x) * blend,
        menuRippleFx.flow_vel.y + (velocity.y - menuRippleFx.flow_vel.y) * blend
    );
    menuRippleFx.flow_amp = std::max(menuRippleFx.flow_amp, std::clamp(amp, 0.0f, 0.88f));
    menuRippleFx.flow_round = gui->theme ? std::max(6.0f, GetEffectiveCornerRadius(gui)) : 12.0f;
    menuRippleFx.flow_clip = 1.0f;
    menuRippleFx.flow_phase += dt_safe * (2.4f + 6.6f * menuRippleFx.flow_amp);
}
