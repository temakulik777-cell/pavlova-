#pragma once

static const char* kBlurVS = R"(#version 300 es
layout(location=0) in vec2 aPos;
layout(location=1) in vec2 aUV;
out vec2 vUV;
void main() {
    vUV = aUV;
    gl_Position = vec4(aPos, 0.0, 1.0);
}
)";

static const char* kBlurFS = R"(#version 300 es
precision mediump float;
in vec2 vUV;
uniform sampler2D uTex;
uniform vec2 uDirection;
uniform vec2 uTexel;
out vec4 FragColor;
void main() {
    vec2 off = uDirection * uTexel;
    vec4 c = texture(uTex, vUV) * 0.227027;
    c += texture(uTex, vUV + off * 1.384615) * 0.316216;
    c += texture(uTex, vUV - off * 1.384615) * 0.316216;
    c += texture(uTex, vUV + off * 3.230769) * 0.070270;
    c += texture(uTex, vUV - off * 3.230769) * 0.070270;
    FragColor = vec4(c.rgb, 1.0);
}
)";

static const char* kBoxFS = R"(#version 300 es
precision mediump float;
in vec2 vUV;
uniform sampler2D uTex;
uniform vec2 uDirection;
uniform vec2 uTexel;
out vec4 FragColor;
void main() {
    vec2 off = uDirection * uTexel;
    vec4 c = texture(uTex, vUV) * 0.2;
    c += texture(uTex, vUV + off) * 0.2;
    c += texture(uTex, vUV - off) * 0.2;
    c += texture(uTex, vUV + off * 2.0) * 0.2;
    c += texture(uTex, vUV - off * 2.0) * 0.2;
    FragColor = vec4(c.rgb, 1.0);
}
)";

static const char* kFrostedFS = R"(#version 300 es
precision mediump float;
in vec2 vUV;
uniform sampler2D uTex;
uniform vec2 uDirection;
uniform vec2 uTexel;
uniform float uStrength;
out vec4 FragColor;
float hash(vec2 p) {
    p = vec2(dot(p, vec2(127.1, 311.7)), dot(p, vec2(269.5, 183.3)));
    return fract(sin(p.x + p.y) * 43758.5453123);
}
void main() {
    vec2 rnd = vec2(hash(vUV), hash(vUV.yx)) - 0.5;
    vec2 off = uDirection * uTexel;
    vec2 jitter = rnd * uTexel * uStrength;
    vec4 c = texture(uTex, vUV + jitter) * 0.35;
    c += texture(uTex, vUV + off + jitter) * 0.25;
    c += texture(uTex, vUV - off + jitter) * 0.25;
    c += texture(uTex, vUV + off * 2.0 + jitter) * 0.075;
    c += texture(uTex, vUV - off * 2.0 + jitter) * 0.075;
    FragColor = vec4(c.rgb, 1.0);
}
)";

static const char* kKawaseFS = R"(#version 300 es
precision mediump float;
in vec2 vUV;
uniform sampler2D uTex;
uniform vec2 uDirection;
uniform vec2 uTexel;
uniform float uStrength;
out vec4 FragColor;
void main() {
    vec2 o = uDirection * uTexel * max(1.0, uStrength);
    vec4 c = vec4(0.0);
    c += texture(uTex, vUV + vec2( o.x,  o.y));
    c += texture(uTex, vUV + vec2(-o.x,  o.y));
    c += texture(uTex, vUV + vec2( o.x, -o.y));
    c += texture(uTex, vUV + vec2(-o.x, -o.y));
    FragColor = vec4((c * 0.25).rgb, 1.0);
}
)";

static const char* kBokehFS = R"(#version 300 es
precision mediump float;
in vec2 vUV;
uniform sampler2D uTex;
uniform vec2 uDirection;
uniform vec2 uTexel;
uniform float uStrength;
out vec4 FragColor;
void main() {
    vec2 o = uDirection * uTexel * max(1.0, uStrength);
    vec4 c = texture(uTex, vUV) * 0.2;
    c += texture(uTex, vUV + o) * 0.18;
    c += texture(uTex, vUV - o) * 0.18;
    c += texture(uTex, vUV + vec2(-o.y, o.x)) * 0.18;
    c += texture(uTex, vUV + vec2(o.y, -o.x)) * 0.18;
    c += texture(uTex, vUV + o * 1.7) * 0.14;
    c += texture(uTex, vUV - o * 1.7) * 0.14;
    FragColor = vec4(min(c.rgb, vec3(1.0)), 1.0);
}
)";

static const char* kMotionFS = R"(#version 300 es
precision mediump float;
in vec2 vUV;
uniform sampler2D uTex;
uniform vec2 uDirection;
uniform vec2 uTexel;
uniform float uStrength;
out vec4 FragColor;
void main() {
    vec2 dir = normalize(vec2(max(0.0001, uDirection.x), max(0.0001, uDirection.y)));
    vec2 stepv = dir * uTexel * max(1.0, uStrength);
    vec4 c = vec4(0.0);
    c += texture(uTex, vUV - stepv * 3.0) * 0.10;
    c += texture(uTex, vUV - stepv * 2.0) * 0.15;
    c += texture(uTex, vUV - stepv * 1.0) * 0.20;
    c += texture(uTex, vUV) * 0.10;
    c += texture(uTex, vUV + stepv * 1.0) * 0.20;
    c += texture(uTex, vUV + stepv * 2.0) * 0.15;
    c += texture(uTex, vUV + stepv * 3.0) * 0.10;
    FragColor = vec4(c.rgb, 1.0);
}
)";

static const char* kZoomFS = R"(#version 300 es
precision mediump float;
in vec2 vUV;
uniform sampler2D uTex;
uniform vec2 uDirection;
uniform vec2 uTexel;
uniform float uStrength;
out vec4 FragColor;
void main() {
    vec2 center = vec2(0.5, 0.5);
    vec2 dir = center - vUV;
    float s = max(0.5, uStrength * 0.5);
    vec4 c = texture(uTex, vUV) * 0.2;
    c += texture(uTex, vUV + dir * 0.04 * s) * 0.2;
    c += texture(uTex, vUV + dir * 0.08 * s) * 0.2;
    c += texture(uTex, vUV - dir * 0.04 * s) * 0.2;
    c += texture(uTex, vUV - dir * 0.08 * s) * 0.2;
    FragColor = vec4(c.rgb, 1.0);
}
)";

static const char* kPixelateFS = R"(#version 300 es
precision mediump float;
in vec2 vUV;
uniform sampler2D uTex;
uniform vec2 uDirection;
uniform vec2 uTexel;
uniform float uStrength;
out vec4 FragColor;
void main() {
    float blocks = max(8.0, 96.0 / max(1.0, uStrength));
    vec2 uv = floor(vUV * blocks) / blocks;
    vec4 c = texture(uTex, uv) * 0.6;
    c += texture(uTex, uv + uTexel * 0.5) * 0.4;
    FragColor = vec4(c.rgb, 1.0);
}
)";

static const char* kYorozkaFS = R"(#version 300 es
precision mediump float;
in vec2 vUV;
uniform sampler2D uTex;
uniform vec2 uDirection;
uniform vec2 uTexel;
uniform float uStrength;
out vec4 FragColor;

float hash21(vec2 p) {
    p = fract(p * vec2(123.34, 456.21));
    p += dot(p, p + 45.32);
    return fract(p.x * p.y);
}

void main() {
    float matte = clamp(uStrength / 40.0, 0.0, 1.0);
    float radius_px = mix(0.8, 6.0, matte);
    vec2 px = vUV / uTexel;
    vec2 cell_id = floor(px / 3.0);
    float jitter_seed = hash21(cell_id);
    float jitter_angle = jitter_seed * 6.2831853;
    vec2 jitter_dir = vec2(cos(jitter_angle), sin(jitter_angle));
    vec2 jitter = jitter_dir * uTexel * radius_px * 0.35;
    vec2 rx = vec2(radius_px, 0.0) * uTexel;
    vec2 ry = vec2(0.0, radius_px) * uTexel;

    vec4 src = texture(uTex, vUV);
    vec4 c = vec4(0.0);
    c += texture(uTex, vUV + jitter) * 0.20;
    c += texture(uTex, vUV + rx + jitter) * 0.12;
    c += texture(uTex, vUV - rx - jitter) * 0.12;
    c += texture(uTex, vUV + ry + jitter) * 0.12;
    c += texture(uTex, vUV - ry - jitter) * 0.12;
    c += texture(uTex, vUV + rx + ry + jitter) * 0.08;
    c += texture(uTex, vUV + rx - ry - jitter) * 0.08;
    c += texture(uTex, vUV - rx + ry + jitter) * 0.08;
    c += texture(uTex, vUV - rx - ry - jitter) * 0.08;

    const vec3 LUMA = vec3(0.299, 0.587, 0.114);
    float src_l = dot(src.rgb, LUMA);
    float out_l = max(dot(c.rgb, LUMA), 0.0001);
    float luma_fix = src_l / out_l;
    vec3 frosted = c.rgb * mix(1.0, luma_fix, 0.85);

    // Matte glass: suppress micro-contrast a bit, but keep color neutral.
    float gray = dot(frosted, LUMA);
    frosted = mix(vec3(gray), frosted, 1.0 - 0.08 * matte);

    // Never brighten the source perceptibly.
    frosted = min(frosted, src.rgb + vec3(0.01));
    FragColor = vec4(frosted, 1.0);
}
)";

static const char* kBlitVS = R"(#version 300 es
layout(location=0) in vec2 aPos;
layout(location=1) in vec2 aUV;
out vec2 vUV;
void main() {
    vUV = aUV;
    gl_Position = vec4(aPos, 0.0, 1.0);
}
)";

static const char* kBlitFS = R"(#version 300 es
precision mediump float;
in vec2 vUV;
uniform sampler2D uTex;
out vec4 FragColor;
void main() {
    FragColor = vec4(texture(uTex, vUV).rgb, 1.0);
}
)";

static const char* kDownsampleFS = R"(#version 300 es
precision mediump float;
in vec2 vUV;
uniform sampler2D uTex;
out vec4 FragColor;
void main() {
    vec2 texel = 1.0 / vec2(textureSize(uTex, 0));
    vec4 c = texture(uTex, vUV) * 4.0;
    c += texture(uTex, vUV + vec2(texel.x, 0.0)) * 2.0;
    c += texture(uTex, vUV - vec2(texel.x, 0.0)) * 2.0;
    c += texture(uTex, vUV + vec2(0.0, texel.y)) * 2.0;
    c += texture(uTex, vUV - vec2(0.0, texel.y)) * 2.0;
    c += texture(uTex, vUV + vec2(texel.x, texel.y));
    c += texture(uTex, vUV + vec2(texel.x, -texel.y));
    c += texture(uTex, vUV + vec2(-texel.x, texel.y));
    c += texture(uTex, vUV + vec2(-texel.x, -texel.y));
    FragColor = vec4((c * (1.0 / 16.0)).rgb, 1.0);
}
)";

static const char* kTemporalMixFS = R"(#version 300 es
precision mediump float;
in vec2 vUV;
uniform sampler2D uCurrTex;
uniform sampler2D uHistTex;
uniform float uHistoryFactor;
out vec4 FragColor;
void main() {
    vec4 curr = texture(uCurrTex, vUV);
    vec4 hist = texture(uHistTex, vUV);
    vec2 texel = 1.0 / vec2(textureSize(uCurrTex, 0));
    vec3 c0 = curr.rgb;
    vec3 c1 = texture(uCurrTex, vUV + vec2(texel.x, 0.0)).rgb;
    vec3 c2 = texture(uCurrTex, vUV - vec2(texel.x, 0.0)).rgb;
    vec3 c3 = texture(uCurrTex, vUV + vec2(0.0, texel.y)).rgb;
    vec3 c4 = texture(uCurrTex, vUV - vec2(0.0, texel.y)).rgb;
    vec3 nmin = min(min(min(c0, c1), min(c2, c3)), c4);
    vec3 nmax = max(max(max(c0, c1), max(c2, c3)), c4);
    vec3 hist_clamped = clamp(hist.rgb, nmin, nmax);
    float diff = dot(abs(c0 - hist_clamped), vec3(0.299, 0.587, 0.114));
    float anti_ghost = 1.0 - smoothstep(0.02, 0.12, diff);
    float f = clamp(uHistoryFactor, 0.0, 0.95) * anti_ghost;
    FragColor = vec4(mix(c0, hist_clamped, f), 1.0);
}
)";
