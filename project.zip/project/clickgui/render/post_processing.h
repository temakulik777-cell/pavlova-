#pragma once
#include "../imgui/imgui.h"
#include "../imgui/imgui_internal.h"
#include "../../good_luck/glegl/glegl.h"
#include "../../assets/images.h"
#include "blur/blur.h"
#include <memory>
#include <string>
#include <vector>
#include <array>

class ClickGUI;

struct ColorWithBrightness {
    float r;
    float g;
    float b;
    float brightness;
};

struct GlowEffect {
    std::vector<unsigned char> glow_data;
    int glow_width = 0;
    int glow_height = 0;
    GLuint glow_texture = 0;
    bool needs_update = true;
    ImageRegion last_uv = {};
    std::string last_category = "";
};

struct PostProcessing {
    PostProcessing();
    static void BeginFadeMaskBlendCallback(const ImDrawList*, const ImDrawCmd*);
    static void BeginFadeBackgroundAddCallback(const ImDrawList*, const ImDrawCmd*);

    struct Effect {
        virtual ~Effect() = default;
        virtual void Apply(ImDrawList* draw_list, PostProcessing& post) const = 0;
    };

    struct RadialGradient final : Effect {
        ImVec2 center;
        float radius = 0.0f;
        ImU32 color_in = 0;
        ImU32 color_out = 0;

        RadialGradient(const ImVec2& center_in, float radius_in, ImU32 col_in, ImU32 col_out)
            : center(center_in), radius(radius_in), color_in(col_in), color_out(col_out) {}

        void Apply(ImDrawList* draw_list, PostProcessing& post) const override;
    };

    struct SmoothSquareShadow final : Effect {
        ImVec2 center;
        ImVec2 size;
        ImU32 color_center = 0;
        ImU32 color_edge = 0;
        int blur_steps = 16;

        SmoothSquareShadow(const ImVec2& center_in, const ImVec2& size_in, ImU32 col_center, ImU32 col_edge, int steps = 16)
            : center(center_in), size(size_in), color_center(col_center), color_edge(col_edge), blur_steps(steps) {}

        void Apply(ImDrawList* draw_list, PostProcessing& post) const override;
    };

    struct GaussianShadow final : Effect {
        ImVec2 center;
        ImVec2 size;
        ImU32 color_center = 0;
        ImU32 color_edge = 0;
        int blur_steps = 0;
        float sigma = 1.0f;

        GaussianShadow(const ImVec2& center_in, const ImVec2& size_in, ImU32 col_center, ImU32 col_edge, int steps, float sigma_in)
            : center(center_in), size(size_in), color_center(col_center), color_edge(col_edge), blur_steps(steps), sigma(sigma_in) {}

        void Apply(ImDrawList* draw_list, PostProcessing& post) const override;
    };

    struct ArrowGlow final : Effect {
        ImVec2 center;
        float radius = 0.0f;
        ImU32 inner_color = 0;
        int steps = 8;

        ArrowGlow(const ImVec2& center_in, float radius_in, ImU32 color_in, int steps_in = 8)
            : center(center_in), radius(radius_in), inner_color(color_in), steps(steps_in) {}

        void Apply(ImDrawList* draw_list, PostProcessing& post) const override;
    };

    struct RectGlow final : Effect {
        enum class Style {
            Slider,
            Scrollbar,
            Combo
        };

        ImRect rect;
        ImU32 color = 0;
        int blur_steps = -1;
        float intensity = 1.0f;
        Style style = Style::Slider;

        RectGlow(const ImRect& rect_in, ImU32 fill_color, Style style_in, int steps = -1, float intensity_in = 1.0f)
            : rect(rect_in), color(fill_color), blur_steps(steps), intensity(intensity_in), style(style_in) {}

        RectGlow(const ImVec2& min, const ImVec2& max, ImU32 fill_color, Style style_in, int steps = -1, float intensity_in = 1.0f)
            : rect(min, max), color(fill_color), blur_steps(steps), intensity(intensity_in), style(style_in) {}

        void Apply(ImDrawList* draw_list, PostProcessing& post) const override;
    };

    struct GradientGlow final : Effect {
        ImRect rect;
        ImVec4 color1;
        ImVec4 color2;
        int blur_steps = 0;
        bool rainbow_mode = false;
        float intensity = 1.0f;

        GradientGlow(const ImRect& rect_in, ImVec4 c1, ImVec4 c2, int steps, bool rainbow, float intensity_in)
            : rect(rect_in), color1(c1), color2(c2), blur_steps(steps), rainbow_mode(rainbow), intensity(intensity_in) {}

        void Apply(ImDrawList* draw_list, PostProcessing& post) const override;
    };

    struct UserIcon final : Effect {
        GLuint texture_id = 0;
        ImVec2 icon_pos;
        ImVec2 icon_size;
        ImVec2 uv_min;
        ImVec2 uv_max;
        AtlasKind atlas_kind = AtlasKind::Icon;
        ImVec4 icon_color;

        UserIcon(GLuint texture_id_in, const ImVec2& icon_pos_in, const ImVec2& icon_size_in,
                 const ImVec2& uv_min_in, const ImVec2& uv_max_in, AtlasKind atlas_kind_in, ImVec4 icon_color_in)
            : texture_id(texture_id_in), icon_pos(icon_pos_in), icon_size(icon_size_in),
              uv_min(uv_min_in), uv_max(uv_max_in), atlas_kind(atlas_kind_in), icon_color(icon_color_in) {}

        void Apply(ImDrawList* draw_list, PostProcessing& post) const override;
    };

    struct TextGlow final : Effect {
        ImVec2 pos;
        ImFont* font = nullptr;
        float font_size = 0.0f;
        const char* text = nullptr;
        ImVec4 color;
        float blur_intensity = 0.0f;
        int blur_steps = 0;
        float alpha_intensity = 0.0f;

        TextGlow(const ImVec2& pos_in, ImFont* font_in, float font_size_in, const char* text_in,
                 const ImVec4& color_in, float blur_intensity_in, int blur_steps_in, float alpha_intensity_in)
            : pos(pos_in), font(font_in), font_size(font_size_in), text(text_in),
              color(color_in), blur_intensity(blur_intensity_in), blur_steps(blur_steps_in),
              alpha_intensity(alpha_intensity_in) {}

        void Apply(ImDrawList* draw_list, PostProcessing& post) const override;
    };

    struct Flags {
        bool blur = true;
        bool glow = false;
        bool shadow = false;
        float glow_alpha_scale = 0.6f;
    };

    struct ColorGradingPreset {
        float saturation = 1.0f;
        float contrast = 1.0f;
        float brightness = 0.0f;
        float vibrance = 0.0f;
        float gamma = 1.0f;
        float tint_r = 1.0f;
        float tint_g = 1.0f;
        float tint_b = 1.0f;
    };

    struct ColorGrading {
        bool enabled = false;
        int preset_index = 0;
        std::array<ColorGradingPreset, 8> presets{};
        ColorGradingPreset current{};
    };

    void RenderBlur(ImDrawList* draw_list, const ImVec2& window_pos, int sidebar_width, int sidebar_height,
                    float alpha, bool scalled, float corner_radius, int downscale_factor,
                    float blur_radius, Blur::Type blur_type, const ImVec4& tint_color,
                    ImDrawFlags corner_flags = ImDrawFlags_RoundCornersLeft);
    void RenderBlurGradientFade(ImDrawList* draw_list, const ImVec2& rect_min, const ImVec2& rect_size,
                                float gradient_h, float top_alpha, float bottom_alpha,
                                int downscale_factor, float blur_radius, Blur::Type blur_type,
                                float corner_radius);

    void Apply(const Effect& effect, ImDrawList* draw_list);
    void CleanupGlowCache();

    void DrawGlowTexture(ImDrawList* draw_list, const char* icon_name,
                         const ImVec2& min, const ImVec2& max,
                         const ImVec4& color, float alpha = 0.4f,
                         const ImVec2* uv_min_override = nullptr,
                         const ImVec2* uv_max_override = nullptr) const;
    void DrawTextGlow(ImDrawList* draw_list, ImFont* font, float font_size, const char* text,
                      const ImVec2& pos, const ImVec4& color, float blur_radius,
                      float alpha, int downscale = 2);
    void SetTextGlowRenderActive(bool active);
    void SetTextGlowIntensity(float value);
    float GetTextGlowIntensity() const;
    void SetTextGlowRadiusScale(float value);
    float GetTextGlowRadiusScale() const;
    void SetTextGlowAlphaScale(float value);
    float GetTextGlowAlphaScale() const;
    void SetTextGlowSteps(int steps);
    int GetTextGlowSteps() const;
    void SetTextGlowDownscale(int value);
    int GetTextGlowDownscale() const;
    void ApplyColorGrading(int width, int height);
    bool ExportLogoTextPng(ImFont* font, float font_size, const char* out_path) const;
    bool ExportUiTextGlowPngs(ImFont* font, float font_size, const char* out_dir) const;

    Flags flags;
    ColorGrading color_grading;
    std::unique_ptr<Blur> blur;
    GlowEffect glow_cache;
};

extern PostProcessing post_processing;

float calculateBrightnessFloat(float r, float g, float b);
void getTwoBrightestColorsFromTexture(GLuint textureId, int width, int height, float color1[3], float color2[3]);
void getTwoBrightestColorsFromRegion(AtlasKind atlas_kind, const ImVec2& uv_min, const ImVec2& uv_max, float color1[3], float color2[3]);

ImU32 ImLerpColor(ImU32 col_a, ImU32 col_b, float t);
void DrawTextWithEllipsis(ImDrawList* draw_list, ImVec2 pos, ImFont* font, float font_size, const char* text, float max_width, ImU32 color);
void DrawTextWithSmallerSeparators(ImDrawList* draw_list, ImFont* font, float font_size, ImVec2 pos, ImU32 color, const char* text);
void DrawTextWithCustomSizeAndWrapping(ImDrawList* draw_list, ImVec2 pos, ImFont* font, float font_size, const char* text, float max_width, ImU32 color);
ImVec2 ImCubicBezier(const ImVec2& p0, const ImVec2& p1, const ImVec2& p2, const ImVec2& p3, float t);
void DrawMenuShadowBox(const ImVec2& min, const ImVec2& max, float rounding, float alpha_mul, ClickGUI* gui, bool blur_mode);

struct TabMorphRegion {
    GLuint prev_tex = 0;
    GLuint curr_tex = 0;
    int tex_w = 0;
    int tex_h = 0;
    bool has_prev = false;
};

struct TabMorphFxState {
    GLuint program = 0;
    GLint u_prev = -1;
    GLint u_curr = -1;
    GLint u_res = -1;
    GLint u_rect = -1;
    GLint u_t = -1;
    GLint u_force = -1;
    GLint u_blur = -1;
    GLint u_dir = -1;
    GLint u_origin = -1;
    TabMorphRegion module;
    TabMorphRegion content;
    ImVec2 module_min = ImVec2(0.0f, 0.0f);
    ImVec2 module_max = ImVec2(0.0f, 0.0f);
    ImVec2 content_min = ImVec2(0.0f, 0.0f);
    ImVec2 content_max = ImVec2(0.0f, 0.0f);
    ImVec2 frozen_module_min = ImVec2(0.0f, 0.0f);
    ImVec2 frozen_module_max = ImVec2(0.0f, 0.0f);
    ImVec2 frozen_content_min = ImVec2(0.0f, 0.0f);
    ImVec2 frozen_content_max = ImVec2(0.0f, 0.0f);
    bool module_valid = false;
    bool content_valid = false;
    bool rects_frozen = false;
    bool animate_module = true;
    bool animate_content = true;
    float progress = 1.0f;
    bool active = false;
    bool primed = false;
    bool start_requested = false;
    bool recapture_pending = false;
    int recapture_frames = 0;
    float speed_boost = 1.0f;
    int start_delay_frames = 0;
    float force_motion = 0.0f;
    int from_tab = -1;
    int to_tab = -1;
    float switch_dir = 1.0f;
    float play_dir = 1.0f;
    bool is_module_switch = false;
    int switch_module_tab = -1;
    int from_module = -1;
    int to_module = -1;
};

extern TabMorphFxState tabMorphFx;

void UpdateMenuRippleInput(ClickGUI* gui, float dt, const ImVec2& mouse_pos, bool mouse_down, bool mouse_clicked, bool mouse_released);
void RenderMenuRippleOverlay(ClickGUI* gui, int display_w, int display_h);
void RenderPopupRippleOverlay(ClickGUI* gui, int display_w, int display_h);
void RenderWatermarkRippleOverlay(ClickGUI* gui, int display_w, int display_h);
void RenderTabMorphOverlay(ClickGUI* gui, int display_w, int display_h);
void NotifyWatermarkRippleInteraction(ClickGUI* gui, const ImVec2& pos, float strength);
void NotifyWatermarkRippleVisualMotion(ClickGUI* gui, const ImVec2& velocity, float amp, float dt);
