#pragma once
#ifndef DISABLE_IMGUI_EXAMPLE_INCLUDES
#include "imgui.h"
#include "math.h"
#include "../../good_luck/oxo/include.h"

ImVec2 operator+(ImVec2 p1, ImVec2 p2);
inline ImVec2 operator-(ImVec2 p1, ImVec2 p2);
inline ImVec2 operator/(ImVec2 p1, ImVec2 p2);
inline ImVec2 operator*(ImVec2 p1, int value);
ImVec2 operator*(ImVec2 p1, float value);
inline ImVec2 operator/(ImVec2 p1, int value);
inline ImVec2 operator/(ImVec2 p1, float value);
inline ImVec4 operator+(float val, ImVec4 p2);
inline ImVec4 operator*(float val, ImVec4 p2);
ImVec4 operator*(ImVec4 p2, float val);
inline ImVec4 operator-(ImVec4 p1, ImVec4 p2);
inline ImVec4 operator*(ImVec4 p1, ImVec4 p2);
inline ImVec4 operator/(ImVec4 p1, ImVec4 p2);
#endif

ImVec4 boxGaussianIntegral(ImVec4 x);
ImVec4 boxLinearInterpolation(ImVec4 x);
float boxShadow(ImVec2 lower, ImVec2 upper, ImVec2 point, float sigma, bool linearInterpolation);

struct RectangleShadowSettings
{
    bool    linear       = false;
    float   sigma        = 3;
    ImVec2  padding      = ImVec2(50, 50);
    ImVec2  rectPos      = ImVec2(50, 50);
    ImVec2  rectSize     = ImVec2(120, 120);
    ImVec2  shadowOffset = ImVec2(0, 0);
    ImVec2  shadowSize   = ImVec2(120, 50);
    ImColor shadowColor  = ImColor(0.6f, 0.6f, 0.6f, 1.0f);

    int  rings                    = 3;
    int  spacingBetweenRings      = 6;
    int  samplesPerCornerSide     = 1;
    int  spacingBetweenSamples    = 15;

    // Outputs
    int totalVertices = 0;
    int totalIndices  = 0;

    bool enableDebugVisualization = false;
};

void drawRectangleShadowVerticesAdaptive(RectangleShadowSettings& settings, bool foreground = false);
void drawRoundedRectShadow(const ImVec2& min, const ImVec2& max, float rounding, ImColor color,
                           float alpha_mul = 1.0f, int rings = 8, float step = 2.0f, bool foreground = false);
void drawShadowTestExampleWindow();

extern RectangleShadowSettings shadowSettings;
