#include "box_shadow.h"
#include <algorithm>

#ifndef DISABLE_IMGUI_EXAMPLE_INCLUDES
ImVec2 operator+(ImVec2 p1, ImVec2 p2){ return ImVec2(p1.x + p2.x, p1.y + p2.y);}
inline ImVec2 operator-(ImVec2 p1, ImVec2 p2){ return ImVec2(p1.x - p2.x, p1.y - p2.y);}
inline ImVec2 operator/(ImVec2 p1, ImVec2 p2){ return ImVec2(p1.x / p2.x, p1.y / p2.y);}
inline ImVec2 operator*(ImVec2 p1, int value){ return ImVec2(p1.x*value, p1.y*value);}
ImVec2 operator*(ImVec2 p1, float value){ return ImVec2(p1.x*value, p1.y*value);}
inline ImVec2 operator/(ImVec2 p1, int value){ return ImVec2(p1.x/value, p1.y/value);}
inline ImVec2 operator/(ImVec2 p1, float value){ return ImVec2(p1.x/value, p1.y/value);}
inline ImVec4 operator+(float val, ImVec4 p2){ return ImVec4(val + p2.x, val + p2.y, val + p2.z, val + p2.w);}
inline ImVec4 operator*(float val, ImVec4 p2){ return ImVec4(val * p2.x, val * p2.y, val * p2.z, val * p2.w);}
ImVec4 operator*(ImVec4 p2, float val){ return ImVec4(val * p2.x, val * p2.y, val * p2.z, val * p2.w);}
inline ImVec4 operator-(ImVec4 p1, ImVec4 p2){ return ImVec4(p1.x - p2.x, p1.y - p2.y, p1.z - p2.z, p1.w - p2.w);}
inline ImVec4 operator*(ImVec4 p1, ImVec4 p2){ return ImVec4(p1.x * p2.x, p1.y * p2.y, p1.z * p2.z, p1.w * p2.w);}
inline ImVec4 operator/(ImVec4 p1, ImVec4 p2){ return ImVec4(p1.x / p2.x, p1.y / p2.y, p1.z / p2.z, p1.w / p2.w);}
#endif

ImVec4 boxGaussianIntegral(ImVec4 x)
{
     ImVec4 s          = ImVec4(x.x > 0 ? 1.0f : -1.0f, x.y > 0 ? 1.0f : -1.0f, x.z > 0 ? 1.0f : -1.0f, x.w > 0 ? 1.0f : -1.0f);
     ImVec4 a          = ImVec4(fabsf(x.x), fabsf(x.y), fabsf(x.z), fabsf(x.w));
     ImVec4 res        = 1.0f + (0.278393f + (0.230389f + 0.078108f * (a * a)) * a) * a;
     ImVec4 resSquared = res * res;
    return s - s / (resSquared * resSquared);
}

ImVec4 boxLinearInterpolation(ImVec4 x)
{
     float maxClamp = 1.0f;
     float minClamp = -1.0f;
    return ImVec4(x.x > maxClamp ? maxClamp : x.x < minClamp ? minClamp : x.x,
                  x.y > maxClamp ? maxClamp : x.y < minClamp ? minClamp : x.y,
                  x.z > maxClamp ? maxClamp : x.z < minClamp ? minClamp : x.z,
                  x.w > maxClamp ? maxClamp : x.w < minClamp ? minClamp : x.w);
}

float boxShadow(ImVec2 lower, ImVec2 upper, ImVec2 point, float sigma, bool linearInterpolation)
{
     ImVec2 pointLower    = point - lower;
     ImVec2 pointUpper    = point - upper;
     ImVec4 query         = ImVec4(pointLower.x, pointLower.y, pointUpper.x, pointUpper.y);
     ImVec4 pointToSample = query * (sqrtf(0.5f) / sigma);
     ImVec4 integral      = linearInterpolation ? 0.5f + 0.5f * boxLinearInterpolation(pointToSample) : 0.5f + 0.5f * boxGaussianIntegral(pointToSample);
    return (integral.z - integral.x) * (integral.w - integral.y);
}

void drawRectangleShadowVerticesAdaptive(RectangleShadowSettings& settings, bool foreground)
{
     int    samplesSpan            = settings.samplesPerCornerSide * settings.spacingBetweenSamples;
     int    halfWidth              = static_cast<int>(settings.rectSize.x / 2);
     int    numSamplesInHalfWidth  = (halfWidth / settings.spacingBetweenSamples) == 0 ? 1 : halfWidth / settings.spacingBetweenSamples;
     int    numSamplesWidth        = samplesSpan > halfWidth ? numSamplesInHalfWidth : settings.samplesPerCornerSide;
     int    halfHeight             = static_cast<int>(settings.rectSize.y / 2);
     int    numSamplesInHalfHeight = (halfHeight / settings.spacingBetweenSamples) == 0 ? 1 : halfHeight / settings.spacingBetweenSamples;
     int    numSamplesHeight       = samplesSpan > halfHeight ? numSamplesInHalfHeight : settings.samplesPerCornerSide;
     int    numVerticesInARing     = numSamplesWidth * 4 + numSamplesHeight * 4 + 4;
     ImVec2 whiteTexelUV           = ImGui::GetIO().Fonts->TexUvWhitePixel;
     ImVec2 origin                 = ImGui::GetWindowPos();
     ImVec2 rectangleTopLeft       = origin + settings.rectPos;
     ImVec2 rectangleBottomRight   = rectangleTopLeft + settings.rectSize;
     ImVec2 rectangleTopRight      = rectangleTopLeft + ImVec2(settings.rectSize.x, 0);
     ImVec2 rectangleBottomLeft    = rectangleTopLeft + ImVec2(0, settings.rectSize.y);

    ImColor shadowColor    = settings.shadowColor;
    settings.totalVertices = numVerticesInARing * settings.rings;
    settings.totalIndices  = 6 * (numVerticesInARing) * (settings.rings - 1);

    ImDrawList* drawList;

    if (foreground) drawList = ImGui::GetForegroundDrawList();
    else drawList = ImGui::GetBackgroundDrawList();

    drawList->PrimReserve(settings.totalIndices, settings.totalVertices);
     ImDrawVert* shadowVertices = drawList->_VtxWritePtr;
    ImDrawVert* vertexPointer  = drawList->_VtxWritePtr;

    for (int r = 0; r < settings.rings; ++r)
    {
         float  adaptiveScale = (r / 2.5f) + 1;
         ImVec2 ringOffset    = ImVec2(adaptiveScale * r * settings.spacingBetweenRings, adaptiveScale * r * settings.spacingBetweenRings);
        for (int j = 0; j < 4; ++j)
        {
            ImVec2      corner;
            ImVec2      direction[2];
             float spacingBetweenSamplesOnARing = static_cast<float>(settings.spacingBetweenSamples);
            switch (j)
            {
                case 0:
                    corner       = rectangleTopLeft + ImVec2(-ringOffset.x, -ringOffset.y);
                    direction[0] = ImVec2(1, 0) * spacingBetweenSamplesOnARing;
                    direction[1] = ImVec2(0, 1) * spacingBetweenSamplesOnARing;
                    for (int i = 0; i < numSamplesWidth; ++i)
                    {
                         ImVec2 point  = corner + direction[0] * (numSamplesWidth - i);
                        shadowColor.Value.w = boxShadow(rectangleTopLeft, rectangleBottomRight, point - settings.shadowOffset, settings.sigma, settings.linear);
                        vertexPointer->pos  = point;
                        vertexPointer->uv   = whiteTexelUV;
                        vertexPointer->col  = shadowColor;
                        vertexPointer++;
                    }

                    shadowColor.Value.w = boxShadow(rectangleTopLeft, rectangleBottomRight, corner - settings.shadowOffset, settings.sigma, settings.linear);
                    vertexPointer->pos  = corner;
                    vertexPointer->uv   = whiteTexelUV;
                    vertexPointer->col  = shadowColor;
                    vertexPointer++;

                    for (int i = 0; i < numSamplesHeight; ++i)
                    {
                         ImVec2 point  = corner + direction[1] * (i + 1);
                        shadowColor.Value.w = boxShadow(rectangleTopLeft, rectangleBottomRight, point - settings.shadowOffset, settings.sigma, settings.linear);
                        vertexPointer->pos  = point;
                        vertexPointer->uv   = whiteTexelUV;
                        vertexPointer->col  = shadowColor;
                        vertexPointer++;
                    }
                    break;
                case 1:
                    corner       = rectangleBottomLeft + ImVec2(-ringOffset.x, +ringOffset.y);
                    direction[0] = ImVec2(1, 0) * spacingBetweenSamplesOnARing;
                    direction[1] = ImVec2(0, -1) * spacingBetweenSamplesOnARing;
                    for (int i = 0; i < numSamplesHeight; ++i)
                    {
                         ImVec2 point  = corner + direction[1] * (numSamplesHeight - i);
                        shadowColor.Value.w = boxShadow(rectangleTopLeft, rectangleBottomRight, point - settings.shadowOffset, settings.sigma, settings.linear);
                        vertexPointer->pos  = point;
                        vertexPointer->uv   = whiteTexelUV;
                        vertexPointer->col  = shadowColor;
                        vertexPointer++;
                    }

                    shadowColor.Value.w = boxShadow(rectangleTopLeft, rectangleBottomRight, corner - settings.shadowOffset, settings.sigma, settings.linear);
                    vertexPointer->pos  = corner;
                    vertexPointer->uv   = whiteTexelUV;
                    vertexPointer->col  = shadowColor;
                    vertexPointer++;

                    for (int i = 0; i < numSamplesWidth; ++i)
                    {
                         ImVec2 point  = corner + direction[0] * (i + 1);
                        shadowColor.Value.w = boxShadow(rectangleTopLeft, rectangleBottomRight, point - settings.shadowOffset, settings.sigma, settings.linear);
                        vertexPointer->pos  = point;
                        vertexPointer->uv   = whiteTexelUV;
                        vertexPointer->col  = shadowColor;
                        vertexPointer++;
                    }
                    break;
                case 2:
                    corner       = rectangleBottomRight + ImVec2(+ringOffset.x, +ringOffset.y);
                    direction[0] = ImVec2(-1, 0) * spacingBetweenSamplesOnARing;
                    direction[1] = ImVec2(0, -1) * spacingBetweenSamplesOnARing;
                    for (int i = 0; i < numSamplesWidth; ++i)
                    {
                         ImVec2 point  = corner + direction[0] * (numSamplesWidth - i);
                        shadowColor.Value.w = boxShadow(rectangleTopLeft, rectangleBottomRight, point - settings.shadowOffset, settings.sigma, settings.linear);
                        vertexPointer->pos  = point;
                        vertexPointer->uv   = whiteTexelUV;
                        vertexPointer->col  = shadowColor;
                        vertexPointer++;
                    }

                    shadowColor.Value.w = boxShadow(rectangleTopLeft, rectangleBottomRight, corner - settings.shadowOffset, settings.sigma, settings.linear);
                    vertexPointer->pos  = corner;
                    vertexPointer->uv   = whiteTexelUV;
                    vertexPointer->col  = shadowColor;
                    vertexPointer++;

                    for (int i = 0; i < numSamplesHeight; ++i)
                    {
                         ImVec2 point  = corner + direction[1] * (i + 1);
                        shadowColor.Value.w = boxShadow(rectangleTopLeft, rectangleBottomRight, point - settings.shadowOffset, settings.sigma, settings.linear);
                        vertexPointer->pos  = point;
                        vertexPointer->uv   = whiteTexelUV;
                        vertexPointer->col  = shadowColor;
                        vertexPointer++;
                    }
                    break;
                case 3:
                    corner       = rectangleTopRight + ImVec2(+ringOffset.x, -ringOffset.y);
                    direction[0] = ImVec2(-1, 0) * spacingBetweenSamplesOnARing;
                    direction[1] = ImVec2(0, 1) * spacingBetweenSamplesOnARing;
                    for (int i = 0; i < numSamplesHeight; ++i)
                    {
                         ImVec2 point  = corner + direction[1] * (numSamplesHeight - i);
                        shadowColor.Value.w = boxShadow(rectangleTopLeft, rectangleBottomRight, point - settings.shadowOffset, settings.sigma, settings.linear);
                        vertexPointer->pos  = point;
                        vertexPointer->uv   = whiteTexelUV;
                        vertexPointer->col  = shadowColor;
                        vertexPointer++;
                    }

                    shadowColor.Value.w = boxShadow(rectangleTopLeft, rectangleBottomRight, corner - settings.shadowOffset, settings.sigma, settings.linear);
                    vertexPointer->pos  = corner;
                    vertexPointer->uv   = whiteTexelUV;
                    vertexPointer->col  = shadowColor;
                    vertexPointer++;

                    for (int i = 0; i < numSamplesWidth; ++i)
                    {
                         ImVec2 point  = corner + direction[0] * (i + 1);
                        shadowColor.Value.w = boxShadow(rectangleTopLeft, rectangleBottomRight, point - settings.shadowOffset, settings.sigma, settings.linear);
                        vertexPointer->pos  = point;
                        vertexPointer->uv   = whiteTexelUV;
                        vertexPointer->col  = shadowColor;
                        vertexPointer++;
                    }
                    break;
            }
        }
    }

    ImDrawIdx idx = (ImDrawIdx)drawList->_VtxCurrentIdx;

    for (int r = 0; r < settings.rings - 1; ++r)
    {
         ImDrawIdx startOfRingIndex = idx;
        for (int i = 0; i < numVerticesInARing - 1; ++i)
        {
            drawList->_IdxWritePtr[0] = idx + 0;
            drawList->_IdxWritePtr[1] = idx + 1;
            drawList->_IdxWritePtr[2] = idx + numVerticesInARing;
            drawList->_IdxWritePtr[3] = idx + 1;
            drawList->_IdxWritePtr[4] = idx + numVerticesInARing + 1;
            drawList->_IdxWritePtr[5] = idx + numVerticesInARing;

            idx += 1;
            drawList->_IdxWritePtr += 6;
        }

        drawList->_IdxWritePtr[0] = idx + 0;
        drawList->_IdxWritePtr[1] = startOfRingIndex + 0;
        drawList->_IdxWritePtr[2] = startOfRingIndex + numVerticesInARing;
        drawList->_IdxWritePtr[3] = idx + 0;
        drawList->_IdxWritePtr[4] = startOfRingIndex + numVerticesInARing;
        drawList->_IdxWritePtr[5] = idx + numVerticesInARing;

        drawList->_IdxWritePtr += 6;
        idx += 1;
    }
    drawList->_VtxCurrentIdx += settings.totalVertices;

    if (settings.enableDebugVisualization)
    {
         ImColor lineColor(0, 0, 255, 50);
        for (int r = 0; r < settings.rings - 1; ++r)
        {
           ImDrawIdx startOfRingIndex = r * numVerticesInARing;

            ImVec2 a;
            ImVec2 b;
            for (int i = 0; i < numVerticesInARing - 1; ++i)
            {
                a = shadowVertices[startOfRingIndex + i + 1].pos;
                b = shadowVertices[startOfRingIndex + i + numVerticesInARing].pos;
                drawList->AddLine(a, b, lineColor);
                a = shadowVertices[startOfRingIndex + i + 0].pos;
                b = shadowVertices[startOfRingIndex + i + numVerticesInARing].pos;
                drawList->AddLine(a, b, lineColor);
                a = shadowVertices[startOfRingIndex + i + numVerticesInARing + 1].pos;
                b = shadowVertices[startOfRingIndex + i + numVerticesInARing].pos;
                drawList->AddLine(a, b, lineColor);
            }

            a = shadowVertices[startOfRingIndex + numVerticesInARing - 1].pos;
            b = shadowVertices[startOfRingIndex + numVerticesInARing].pos;
            drawList->AddLine(a, b, lineColor);
            a = shadowVertices[startOfRingIndex + numVerticesInARing + numVerticesInARing - 1].pos;
            b = shadowVertices[startOfRingIndex + numVerticesInARing].pos;
            drawList->AddLine(a, b, lineColor);
        }

        for (int i = 0; i < settings.totalVertices; ++i)
        {
            ImVec2 bmin = shadowVertices[i].pos - ImVec2(2, 2);
            ImVec2 bmax = shadowVertices[i].pos + ImVec2(2, 2);
            drawList->AddRectFilled(bmin, bmax, ImColor(255, 0, 0, 50));
        }
    }
}

void drawRoundedRectShadow(const ImVec2& min, const ImVec2& max, float rounding, ImColor color,
                           float alpha_mul, int rings, float step, bool foreground)
{
    if (alpha_mul <= 0.0001f || rings <= 0 || step <= 0.0f) {
        return;
    }
    ImDrawList* drawList = foreground ? ImGui::GetForegroundDrawList() : ImGui::GetBackgroundDrawList();
    const float base_alpha = std::clamp(color.Value.w * alpha_mul, 0.0f, 1.0f);
    if (base_alpha <= 0.0001f) {
        return;
    }

    const float max_expand = step * (float)rings;
    const int smooth_rings = std::max(rings * 2, 18);
    const float thickness = std::max(1.0f, (max_expand / (float)smooth_rings) * 1.35f);
    {
        ImVec4 c = color.Value;
        c.w = std::clamp(base_alpha * 0.26f, 0.0f, 1.0f);
        drawList->AddRectFilled(
            ImVec2(min.x - 1.1f, min.y - 1.1f),
            ImVec2(max.x + 1.1f, max.y + 1.1f),
            ImGui::GetColorU32(c),
            std::max(0.0f, rounding + 1.1f),
            ImDrawFlags_RoundCornersAll
        );
        c.w = std::clamp(base_alpha * 0.30f, 0.0f, 1.0f);
        drawList->AddRect(
            ImVec2(min.x - 0.35f, min.y - 0.35f),
            ImVec2(max.x + 0.35f, max.y + 0.35f),
            ImGui::GetColorU32(c),
            std::max(0.0f, rounding + 0.35f),
            ImDrawFlags_RoundCornersAll,
            std::max(1.0f, thickness * 1.08f)
        );
    }

    for (int i = 0; i < smooth_rings; ++i) {
        const float u = ((float)i + 0.5f) / (float)smooth_rings; // 0 near edge -> 1 outer
        const float edge = 1.0f - u;
        const float expand = max_expand * ((float)i / (float)std::max(1, smooth_rings - 1));
        const float falloff = expf(-3.6f * u * u);
        ImVec4 c = color.Value;
        c.w = std::clamp(base_alpha * falloff * (0.58f + 0.42f * edge), 0.0f, 1.0f);
        const float outer_expand = expand + thickness * 0.48f;
        const float rad = std::max(0.0f, rounding + outer_expand);
        drawList->AddRect(
            ImVec2(min.x - outer_expand, min.y - outer_expand),
            ImVec2(max.x + outer_expand, max.y + outer_expand),
            ImGui::GetColorU32(c),
            rad,
            ImDrawFlags_RoundCornersAll,
            thickness
        );
    }
}

RectangleShadowSettings shadowSettings;

void drawShadowTestExampleWindow()
{
    ImGui::SetNextWindowSize(ImVec2(400,800), ImGuiCond_Once);
    ImGui::Begin(oxorany("Test Shadows"));
    static bool showRectangles          = true;
    static bool calculateMinimumPadding = false;
    static ImColor backgroundColor(255, 255, 255, 255);
    static ImColor rectangleColor(240, 240, 240, 255);
    ImGui::Checkbox(oxorany("Wireframe"), &shadowSettings.enableDebugVisualization);
    ImGui::Checkbox(oxorany("Draw Rectangle"), &showRectangles);
    ImGui::Checkbox(oxorany("Recalculate Padding"), &calculateMinimumPadding);
    ImGui::Checkbox(oxorany("Linear Falloff"), &shadowSettings.linear);
    ImGui::SliderFloat2(oxorany("Rectangle Size"), &shadowSettings.rectSize.x, 10, 256);
    ImGui::SliderFloat(oxorany("Shadow Sigma"), &shadowSettings.sigma, 0, 50);
    ImGui::SliderFloat2(oxorany("Shadow Offset"), &shadowSettings.shadowOffset.x, -10, 10);
    ImGui::SliderInt(oxorany("Rings number"), &shadowSettings.rings, 1, 10);
    ImGui::SliderInt(oxorany("Rings spacing"), &shadowSettings.spacingBetweenRings, 1, 20);
    ImGui::SliderInt(oxorany("Corner samples"), &shadowSettings.samplesPerCornerSide, 1, 20);
    ImGui::SliderInt(oxorany("Corner spacing"), &shadowSettings.spacingBetweenSamples, 1, 20);
    ImGui::ColorPicker3(oxorany("Shadow Color"), &shadowSettings.shadowColor.Value.x, ImGuiColorEditFlags_PickerHueWheel);
    ImGui::ColorPicker3(oxorany("Rectangle Color"), &rectangleColor.Value.x, ImGuiColorEditFlags_PickerHueWheel);
    ImGui::ColorPicker3(oxorany("Background Color"), &backgroundColor.Value.x, ImGuiColorEditFlags_PickerHueWheel);
    ImGui::End();

    if (calculateMinimumPadding)
    {
        shadowSettings.padding = ImVec2(3 * shadowSettings.sigma, 3 * shadowSettings.sigma);
    }
    shadowSettings.rectPos    = shadowSettings.padding;
    shadowSettings.shadowSize = shadowSettings.rectSize + shadowSettings.padding * 2;

    ImGui::SetNextWindowPos(ImVec2(700, 0), ImGuiCond_Once);
    ImGui::Begin(oxorany("Shadow Outputs"));
    ImGui::PushStyleColor(ImGuiCol_WindowBg, (ImU32)backgroundColor);
    ImGui::Text(oxorany("rings:%d, spacingH:%d, spacingR:%d\ntotalVertices:%d totalIndices:%d"), shadowSettings.rings, shadowSettings.spacingBetweenRings, shadowSettings.spacingBetweenSamples, shadowSettings.totalVertices, shadowSettings.totalIndices);
    if (ImGui::BeginChild(oxorany("Adaptive Rectangle Shadow"), shadowSettings.shadowSize))
    {
        drawRectangleShadowVerticesAdaptive(shadowSettings);
        ImDrawList*  drawList = ImGui::GetForegroundDrawList();
        ImVec2 origin(ImGui::GetCursorScreenPos());
        if (showRectangles)
            drawList->AddRectFilled(shadowSettings.rectPos, shadowSettings.rectPos + shadowSettings.rectSize, rectangleColor);
        drawList->AddRect(origin, shadowSettings.shadowSize, ImColor(255, 0, 0, 255));
    }
    ImGui::EndChild();
    ImGui::PopStyleColor();
    ImGui::End();
}
