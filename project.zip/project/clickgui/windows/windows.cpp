#include "windows.h"
#include "imgui/imgui.h"
#include <algorithm>

void WindowManager::hello(const char* name, ImVec2 pos, ImVec2 size, ImGuiWindowFlags flags) {
    ImGui::SetNextWindowPos(pos, ImGuiCond_Always);
    ImGui::SetNextWindowSize(size, ImGuiCond_Always);
    ImGui::Begin(name, nullptr, flags);
}

void WindowManager::hello(const char* name, int width, int height, float scale, int glWidth, int glHeight, ImGuiWindowFlags flags) {
    int currentWindowWidth = static_cast<int>(width * scale);
    int currentWindowHeight = static_cast<int>(height * scale);
    int clampedWindowWidth = std::min(currentWindowWidth, glWidth);
    int clampedWindowHeight = std::min(currentWindowHeight, glHeight);
    float centeredX = (glWidth - clampedWindowWidth) / 2.0f;
    float centeredY = (glHeight - clampedWindowHeight) / 2.0f;
    ImVec2 clampedWindowPos = ImVec2(centeredX, centeredY);

    ImGui::SetNextWindowPos(clampedWindowPos, ImGuiCond_Always);
    ImGui::SetNextWindowSize(ImVec2(static_cast<float>(clampedWindowWidth), static_cast<float>(clampedWindowHeight)), ImGuiCond_Always);
    ImGui::Begin(name, nullptr, flags);
}

void WindowManager::hello(const char* name, int width, int height, float scale, int glWidth, int glHeight, ImVec2 animatedPos, ImGuiWindowFlags flags) {
    int currentWindowWidth = static_cast<int>(width * scale);
    int currentWindowHeight = static_cast<int>(height * scale);
    int clampedWindowWidth = std::min(currentWindowWidth, glWidth);
    int clampedWindowHeight = std::min(currentWindowHeight, glHeight);

    
    ImVec2 clampedWindowPos = animatedPos;

    ImGui::SetNextWindowPos(clampedWindowPos, ImGuiCond_Always);
    ImGui::SetNextWindowSize(ImVec2(static_cast<float>(clampedWindowWidth), static_cast<float>(clampedWindowHeight)), ImGuiCond_Always);
    ImGui::Begin(name, nullptr, flags);
}

void WindowManager::End() {
    ImGui::End();
}
