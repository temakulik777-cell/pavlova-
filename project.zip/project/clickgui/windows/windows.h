#pragma once
#include "imgui/imgui.h"

class WindowManager {
public:
    void hello(const char* name, ImVec2 pos, ImVec2 size, ImGuiWindowFlags flags);
    void hello(const char* name, int width, int height, float scale, int glWidth, int glHeight, ImGuiWindowFlags flags);
    void hello(const char* name, int width, int height, float scale, int glWidth, int glHeight, ImVec2 animatedPos, ImGuiWindowFlags flags);
    void End();
};
