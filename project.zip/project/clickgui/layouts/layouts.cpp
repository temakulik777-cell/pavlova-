#include "layouts.h"
#include "../render/blur/blur.h"
#include "../clickgui.h"
#include "../widgets/wigdets.h"
#include "../imgui/imgui_internal.h"
#include "../../unity_engine/Input/Touch.h"
#include <algorithm>
#include <cmath>


int ActiveWidgetsCount = 0;



static std::weak_ptr<VerticalLayout> currentlyScrollingLayoutWeak;


static bool isInputCaptured = false;
static std::weak_ptr<VerticalLayout> capturedLayout;

bool IsLayoutInputCaptured() {
    return isInputCaptured || !capturedLayout.expired();
}

bool VerticalLayout::IsPointInBounds(ImVec2 point) {
    return (point.x >= contentMinBounds.x && point.x <= contentMaxBounds.x &&
            point.y >= contentMinBounds.y && point.y <= contentMaxBounds.y);
}

void VerticalLayout::ProcessScrolling() {
    const float kTouchSlop = 8.0f; 
    const float kMaxClickDuration = 0.25f; 
    const float kMinScrollDistance = 15.0f; 
    const float kScrollSensitivity = 1.0f;
    const float kDragFollowHz = 24.0f;
    const float kFreeFollowHz = 14.0f;
    const float kMomentumDampingHz = 8.0f;

    
    const ImGuiIO& io = ImGui::GetIO();
    const bool popupBlocksInput = ComboPopupBlocksInput() || ColorPickerPopupBlocksInput();

    
    bool isCapturedByThis = false;
    auto capturedShared = capturedLayout.lock();
    if (capturedShared.get() == this) {
        isCapturedByThis = true;
    }

    
    ImGuiID layoutTouchId = 0;
    if (isCapturedByThis) {
        layoutTouchId = this->assignedTouchId; 
    }

    
    ImVec2 currentTouchPos;
    bool isMouseDown = false;
    bool isMouseClicked = false;
    bool isMouseReleased = false;
    TouchPhase touchPhase = TouchPhase_Canceled;

    if (layoutTouchId != 0) {
        
        currentTouchPos = GetTouchSystem.GetTouchPosition(layoutTouchId);
        touchPhase = GetTouchSystem.GetTouchPhase(layoutTouchId);

        
        isMouseClicked = (touchPhase == TouchPhase_Began);
        isMouseDown = (touchPhase == TouchPhase_Began || touchPhase == TouchPhase_Moved || touchPhase == TouchPhase_Stationary);
        isMouseReleased = (touchPhase == TouchPhase_Ended || touchPhase == TouchPhase_Canceled);
    } else {
        
        currentTouchPos = io.MousePos;
        isMouseClicked = io.MouseClicked[0];
        isMouseReleased = io.MouseReleased[0];
        isMouseDown = io.MouseDown[0];
    }

    
    bool isWithinBounds = IsPointInBounds(currentTouchPos);

    if (popupBlocksInput) {
        if (isInputCaptured && isCapturedByThis) {
            isInputCaptured = false;
            capturedLayout.reset();
            currentlyScrollingLayoutWeak.reset();
            if (layoutTouchId != 0 && this->assignedTouchId != 0) {
                GetTouchSystem.MarkTouchUsed(layoutTouchId, false);
                this->assignedTouchId = 0;
            }
            this->isScrolling = false;
            this->suppressLayoutScrollUntilRelease = false;
        }
        return;
    }

    if (isMouseClicked) {
        
        if (isWithinBounds && !isInputCaptured) {
            ImGuiWindow* window = ImGui::GetCurrentWindow();
            const bool hasVerticalScrollbar = (window != nullptr) && window->ScrollbarY;
            const float scrollbarZoneWidth = std::max(12.0f, ImGui::GetStyle().ScrollbarSize + 6.0f);
            const bool startedOnScrollbarZone = hasVerticalScrollbar &&
                currentTouchPos.x >= (contentMaxBounds.x - scrollbarZoneWidth) &&
                currentTouchPos.x <= contentMaxBounds.x;
            
            ImVector<ImGuiID> unused_touches;
            GetTouchSystem.GetUnusedTouchIDs(unused_touches);

            
            if (unused_touches.Size > 0) {
                
                layoutTouchId = unused_touches[0];
                this->assignedTouchId = layoutTouchId;

                
                
                currentlyScrollingLayoutWeak = std::dynamic_pointer_cast<VerticalLayout>(shared_from_this());
                capturedLayout = currentlyScrollingLayoutWeak;
                isInputCaptured = true;

                this->touchStartPos = currentTouchPos;
                this->hasMovedSignificantly = false;
                this->wasScrolling = false;
                this->isScrolling = false; 
                this->isClickGesture = true; 
                this->touchStartTime = ImGui::GetTime(); 
                this->suppressLayoutScrollUntilRelease = startedOnScrollbarZone;

                scrollStartPos = currentTouchPos;
                scrollCurrentPos = currentTouchPos;
            scrollVelocity = ImVec2(0, 0);
            scrollTargetY = ImGui::GetScrollY();
            hasScrollTarget = true;

                
                GetTouchSystem.MarkTouchUsed(layoutTouchId, true);
            } else {
                
                
                layoutTouchId = 0; 
                this->assignedTouchId = 0;

                
                currentlyScrollingLayoutWeak = std::dynamic_pointer_cast<VerticalLayout>(shared_from_this());
                capturedLayout = currentlyScrollingLayoutWeak;
                isInputCaptured = true;

                this->touchStartPos = currentTouchPos;
                this->hasMovedSignificantly = false;
                this->wasScrolling = false;
                this->isScrolling = false; 
                this->isClickGesture = true; 
                this->touchStartTime = ImGui::GetTime(); 
                this->suppressLayoutScrollUntilRelease = startedOnScrollbarZone;

                scrollStartPos = currentTouchPos;
                scrollCurrentPos = currentTouchPos;
                scrollVelocity = ImVec2(0, 0);
                scrollTargetY = ImGui::GetScrollY();
                hasScrollTarget = true;
            }
        }
    }
    else if (isMouseDown && isCapturedByThis) {
        if (!this->isScrolling && !this->suppressLayoutScrollUntilRelease &&
            IsAnyWidgetActive()) {
            this->suppressLayoutScrollUntilRelease = true;
        }
        if (!this->isScrolling && this->suppressLayoutScrollUntilRelease) {
            scrollCurrentPos = currentTouchPos;
            return;
        }
        
        ImVec2 delta = ImVec2(currentTouchPos.x - scrollCurrentPos.x, currentTouchPos.y - scrollCurrentPos.y);

        
        float startX = currentTouchPos.x - this->touchStartPos.x;
        float startY = currentTouchPos.y - this->touchStartPos.y;
        float distance = sqrtf(startX * startX + startY * startY);

        
        float currentTime = ImGui::GetTime();
        float touchDuration = currentTime - this->touchStartTime;

        
        if (distance > kMinScrollDistance || touchDuration > kMaxClickDuration) {
            this->isClickGesture = false;
        }

        
        float absDeltaX = fabsf(delta.x);
        float absDeltaY = fabsf(delta.y);

        if (distance > kTouchSlop) {
            if (!this->wasScrolling) {
                
                
                
                if (absDeltaY > absDeltaX * 2.0f) { 
                    
                    this->wasScrolling = true;
                    this->isScrolling = true;
                    this->isClickGesture = false; 
                    ImGui::ClearActiveID();
                }
                
                
            }

            if (this->isScrolling) {
                const float dt = std::clamp(io.DeltaTime > 0.0f ? io.DeltaTime : (1.0f / 60.0f), 1.0f / 240.0f, 1.0f / 20.0f);
                const float scrollStep = delta.y * kScrollSensitivity;
                const float currentScrollY = ImGui::GetScrollY();
                const float maxScrollY = ImGui::GetScrollMaxY();

                if (!hasScrollTarget) {
                    scrollTargetY = currentScrollY;
                    hasScrollTarget = true;
                }

                // Finger-drag to target position (FPS-invariant: no dt multiplier on pixel delta).
                scrollTargetY -= scrollStep;
                scrollTargetY = std::clamp(scrollTargetY, 0.0f, maxScrollY);

                // Capture drag velocity for post-release momentum.
                const float instVelocity = (-scrollStep) / std::max(1e-4f, dt);
                const float velBlend = 1.0f - std::exp(-dt * 20.0f);
                scrollMomentum = scrollMomentum + (instVelocity - scrollMomentum) * velBlend;

                // Smoothly follow target during drag.
                const float follow = 1.0f - std::exp(-dt * kDragFollowHz);
                const float smoothed = currentScrollY + (scrollTargetY - currentScrollY) * follow;
                ImGui::SetScrollY(std::clamp(smoothed, 0.0f, maxScrollY));

                
                ImGui::SetItemDefaultFocus();

                
                
                scrollVelocity = ImVec2(0, 0);
                scrollCurrentPos = currentTouchPos;
            }
        }
    }
    else if (isMouseReleased && isCapturedByThis) {
        // Keep momentum only when actual scrolling happened; tap releases should stop immediately.
        if (!this->wasScrolling) {
            scrollMomentum = 0.0f;
        }
        this->isScrolling = false;
        this->suppressLayoutScrollUntilRelease = false;

        
        isInputCaptured = false;
        capturedLayout.reset();

        
        currentlyScrollingLayoutWeak.reset();

        
        if (layoutTouchId != 0 && this->assignedTouchId != 0) {
            GetTouchSystem.MarkTouchUsed(layoutTouchId, false);
            this->assignedTouchId = 0; 
        }
    }

    
    if (hasScrollTarget && !isScrolling) {
        const float dt = std::clamp(io.DeltaTime > 0.0f ? io.DeltaTime : (1.0f / 60.0f), 1.0f / 240.0f, 1.0f / 20.0f);
        const float currentScrollY = ImGui::GetScrollY();
        const float maxScrollY = ImGui::GetScrollMaxY();

        // Inertial continuation after release.
        if (std::fabs(scrollMomentum) > 1.0f) {
            scrollTargetY += scrollMomentum * dt;
            scrollTargetY = std::clamp(scrollTargetY, 0.0f, maxScrollY);
            const float damp = std::exp(-dt * kMomentumDampingHz);
            scrollMomentum *= damp;
        } else {
            scrollMomentum = 0.0f;
        }

        scrollTargetY = std::clamp(scrollTargetY, 0.0f, maxScrollY);
        const float follow = 1.0f - std::exp(-dt * kFreeFollowHz);
        float smoothed = currentScrollY + (scrollTargetY - currentScrollY) * follow;
        smoothed = std::clamp(smoothed, 0.0f, maxScrollY);
        if (std::fabs(scrollTargetY - smoothed) < 0.25f && std::fabs(scrollMomentum) < 2.0f) {
            smoothed = scrollTargetY;
            hasScrollTarget = false;
            scrollMomentum = 0.0f;
        }
        ImGui::SetScrollY(smoothed);
    }

    
    if (!isMouseDown) {
        
        auto currentlyScrollingShared = currentlyScrollingLayoutWeak.lock();
        bool isCurrentlyScrolling = (currentlyScrollingShared.get() == this);

        if (isCurrentlyScrolling) {
            wasScrolling = false;
            hasMovedSignificantly = false;
            isScrolling = false; 
            isClickGesture = false; 
            touchStartTime = 0.0f; 
            suppressLayoutScrollUntilRelease = false;
            currentlyScrollingLayoutWeak.reset();

            
            if (layoutTouchId != 0 && this->assignedTouchId != 0) {
                GetTouchSystem.MarkTouchUsed(layoutTouchId, false);
                this->assignedTouchId = 0; 
            }
        }

        
        if (isInputCaptured) {
            isInputCaptured = false;
            capturedLayout.reset();
            suppressLayoutScrollUntilRelease = false;

            
            if (layoutTouchId != 0 && this->assignedTouchId != 0) {
                GetTouchSystem.MarkTouchUsed(layoutTouchId, false);
                this->assignedTouchId = 0; 
            }
        }
    }
}


void VerticalLayout::Begin() {
    if (isScrollable) {
        
        ImVec2 actualSize = childSize;
        if (actualSize.x == 0.0f) actualSize.x = ImGui::GetContentRegionAvail().x;
        if (actualSize.y == 0.0f) actualSize.y = ImGui::GetContentRegionAvail().y;

        ImGuiWindowFlags window_flags = ImGuiWindowFlags_NoScrollbar;
        ImGui::BeginChild(childId ? childId : "VerticalLayoutChild", actualSize, childFlags, window_flags);

        // One-shot hard restore for saved tab scroll: apply before any momentum logic.
        if (hasForcedScrollRestore) {
            const float maxScrollY = ImGui::GetScrollMaxY();
            const float y = std::clamp(forcedScrollRestoreY, 0.0f, maxScrollY);
            ImGui::SetScrollY(y);
            scrollTargetY = y;
            hasScrollTarget = false;
            scrollMomentum = 0.0f;
            isScrolling = false;
            wasScrolling = false;
            hasForcedScrollRestore = false;
        }

        
        ImVec2 winPos = ImGui::GetWindowPos();
        ImVec2 winSize = ImGui::GetWindowSize();
        ImVec2 boundsMin = winPos;
        ImVec2 boundsMax = ImVec2(winPos.x + winSize.x, winPos.y + winSize.y);
        SetBounds(boundsMin, boundsMax);

        
        ProcessScrolling();

        auto currentlyScrollingShared = currentlyScrollingLayoutWeak.lock();
        bool isCurrentlyScrolling = (currentlyScrollingShared.get() == this);
        if (isCurrentlyScrolling) {
            
            ImGui::SetItemDefaultFocus();
        }
    } else {
        ImGui::BeginGroup();
    }
    ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(0.0f, 5.0f));
}

void VerticalLayout::DrawDebugVisualization() {
    (void)debugVisualization;
}

void VerticalLayout::End() {
    ImGui::PopStyleVar();
    if (isScrollable) {
        ImGui::EndChild();
    } else {
        ImGui::EndGroup();
    }
}

void HorizontalLayout::Begin() {
    if (ImGui::BeginTable(tableId, 3, ImGuiTableFlags_SizingStretchSame)) {  
        tableActive = true;

        float calculatedWidth;
        if (useFixedColumnWidth && fixedColumnWidth > 0.0f) {
            calculatedWidth = fixedColumnWidth;
        } else {
            ImGuiStyle& style = ImGui::GetStyle();
            float window_padding_x = style.WindowPadding.x;

            float base_width = (baseWindowWidth > 0.0f) ? baseWindowWidth : ImGui::GetWindowSize().x;
            float available_width = base_width - (window_padding_x * 2.0f);
            calculatedWidth = available_width * 0.25f;  
        }

        float tabsWidth = useTabsColumnWidth ? tabsColumnWidth : calculatedWidth;
        float sidebarWidth = useSidebarColumnWidth ? sidebarColumnWidth : calculatedWidth;

        ImGui::TableSetupColumn("Tabs", ImGuiTableColumnFlags_WidthFixed, tabsWidth);
        ImGui::TableSetupColumn("SidebarContent", ImGuiTableColumnFlags_WidthFixed, sidebarWidth);
        ImGui::TableSetupColumn("Content", ImGuiTableColumnFlags_WidthStretch);

        ImGui::TableNextRow();
        ImGui::TableSetColumnIndex(0);

        float contentWidth = ImGui::GetContentRegionAvail().x;
        actualColumnWidth = contentWidth + (ImGui::GetStyle().CellPadding.x * 2.0f);
    }
}

void HorizontalLayout::End() {
    if (tableActive) {
        ImGui::EndTable();
        tableActive = false;
    }
}

LayoutManager::LayoutManager() : contentLayout(nullptr), sidebarLayout(nullptr) {
}

void LayoutManager::Init() {
    verticalLayout = std::make_shared<VerticalLayout>(this);
    horizontalLayout = std::make_shared<HorizontalLayout>(this);
}

template<typename T>
std::shared_ptr<T> LayoutManager::Type() {
    if constexpr (std::is_same_v<T, VerticalLayout>) {
        return verticalLayout;
    } else if constexpr (std::is_same_v<T, HorizontalLayout>) {
        return horizontalLayout;
    } else {
        return nullptr;
    }
}

std::shared_ptr<VerticalLayout> LayoutManager::GetScrollableVerticalLayout(ImVec2 size, const char* id) {
    auto layout = std::make_shared<VerticalLayout>(this);
    layout->SetScrollable(true);
    layout->SetChildSize(size);
    if (id) {
        layout->SetChildId(id);
    }
    return layout;
}

std::shared_ptr<HorizontalLayout> LayoutManager::GetTabbedHorizontalLayout(float leftColumnWidth) {
    if (!horizontalLayout) {
        horizontalLayout = std::make_shared<HorizontalLayout>(this);
    }
    horizontalLayout->SetColumnWidth(leftColumnWidth);
    return horizontalLayout;
}

std::shared_ptr<VerticalLayout> LayoutManager::GetContentLayout() {
    if (!contentLayout) {
        contentLayout = std::make_shared<VerticalLayout>(this);
        contentLayout->SetScrollable(true);
        contentLayout->SetChildId("ContentRegion");
    }
    return contentLayout;
}

std::shared_ptr<VerticalLayout> LayoutManager::GetSidebarLayout() {
    if (!sidebarLayout) {
        sidebarLayout = std::make_shared<VerticalLayout>(this);
        sidebarLayout->SetScrollable(true);
        sidebarLayout->SetChildId("SidebarSizedLayout");
    }
    return sidebarLayout;
}


template std::shared_ptr<VerticalLayout> LayoutManager::Type<VerticalLayout>();
template std::shared_ptr<HorizontalLayout> LayoutManager::Type<HorizontalLayout>();
