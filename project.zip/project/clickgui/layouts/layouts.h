#pragma once
#include <memory>
#include <vector>
#include "imgui/imgui.h"


extern int ActiveWidgetsCount;
inline bool IsAnyWidgetActive() { return ActiveWidgetsCount > 0; }
bool IsLayoutInputCaptured();

class BlurredTexture;
class LayoutManager;

class ILayout {
public:
    virtual ~ILayout() = default;
    virtual void Begin() = 0;
    virtual void End() = 0;
};

class VerticalLayout : public ILayout, public std::enable_shared_from_this<VerticalLayout> {
private:
    float width = 0.0f;
    bool isScrollable = false;
    ImVec2 childSize = ImVec2(0, 0);
    const char* childId = nullptr;
    ImGuiChildFlags childFlags = ImGuiChildFlags_None;
    LayoutManager* layoutManager = nullptr;
    float cornerRadius = 0.0f;
    int downscaleFactor = 4;

    
    ImVec2 scrollStartPos = ImVec2(0, 0);
    ImVec2 scrollCurrentPos = ImVec2(0, 0);
    ImVec2 scrollVelocity = ImVec2(0, 0);
    float scrollMomentum = 0.0f;
    float scrollTargetY = 0.0f;
    bool hasScrollTarget = false;
    bool hasForcedScrollRestore = false;
    float forcedScrollRestoreY = 0.0f;
    bool isScrolling = false;
    bool wasScrolling = false;
    bool hasMovedSignificantly = false;
    ImVec2 touchStartPos = ImVec2(0, 0);
    ImVec2 contentMinBounds = ImVec2(0, 0);
    ImVec2 contentMaxBounds = ImVec2(0, 0);

    
    bool isClickGesture = false;
    float touchStartTime = 0.0f;
    bool suppressLayoutScrollUntilRelease = false;

    
    ImGuiID assignedTouchId = 0; 

    
    bool debugVisualization = false;

public:
    VerticalLayout(LayoutManager* manager) : layoutManager(manager) {
        
        
    }

    void Begin() override;
    void End() override;
    void New(const char* id = nullptr) { Begin(); }
    void SetWidth(float w) { width = w; }
    float GetWidth() const { return width; }
    void SetScrollable(bool scrollable) { isScrollable = scrollable; }
    void SetChildSize(ImVec2 size) { childSize = size; }
    void SetChildId(const char* id) { childId = id; }
    void SetChildFlags(ImGuiChildFlags flags) { childFlags = flags; }
    ImGuiChildFlags GetChildFlags() const { return childFlags; }
    void SetCornerRadius(float radius) { cornerRadius = radius; }
    void SetDownscaleFactor(int factor) { downscaleFactor = factor; }

    
    bool IsPointInBounds(ImVec2 point);
    void ProcessScrolling();
    void SetBounds(ImVec2 min, ImVec2 max) { contentMinBounds = min; contentMaxBounds = max; }
    ImVec2 GetBoundsMin() const { return contentMinBounds; }
    ImVec2 GetBoundsMax() const { return contentMaxBounds; }
    bool GetIsScrolling() const { return isScrolling; }
    void SetIsScrolling(bool scrolling) { isScrolling = scrolling; }
    void SetScrollMomentum(float momentum) { scrollMomentum = momentum; }
    float GetScrollMomentum() const { return scrollMomentum; }
    float GetScrollTargetY() const { return scrollTargetY; }
    void SyncScrollState(float targetY) {
        scrollTargetY = targetY;
        hasScrollTarget = true;
        scrollMomentum = 0.0f;
        isScrolling = false;
        wasScrolling = false;
    }
    void ForceScrollRestore(float targetY) {
        forcedScrollRestoreY = targetY;
        hasForcedScrollRestore = true;
        scrollTargetY = targetY;
        hasScrollTarget = false;
        scrollMomentum = 0.0f;
        isScrolling = false;
        wasScrolling = false;
    }

    
    void SetDebugVisualization(bool enabled) { debugVisualization = enabled; }
    bool GetDebugVisualization() const { return debugVisualization; }
    void DrawDebugVisualization();
};

class HorizontalLayout : public ILayout {
private:
    float columnWidth = 150.0f;
    const char* tableId = "tabs_content";
    bool tableActive = false;
    float actualColumnWidth = 0.0f;
    LayoutManager* layoutManager = nullptr;
    ImVec2 windowPosition = ImVec2(0, 0);
    ImVec2 windowSize = ImVec2(0, 0);
    float cornerRadius = 0.0f;
    float tabsColumnWidth = 0.0f;
    float sidebarColumnWidth = 0.0f;
    bool useTabsColumnWidth = false;
    bool useSidebarColumnWidth = false;

public:
    HorizontalLayout(LayoutManager* manager) : layoutManager(manager) {}

    void SetWindowInfo(ImVec2 pos, ImVec2 size) {
        windowPosition = pos;
        windowSize = size;
    }

    void Begin() override;
    void End() override;
    void New(const char* id = nullptr) { Begin(); }
    void SetColumnWidth(float width) { columnWidth = width; }
    void SetTabsColumnWidth(float width) { tabsColumnWidth = width; useTabsColumnWidth = true; }
    void SetSidebarColumnWidth(float width) { sidebarColumnWidth = width; useSidebarColumnWidth = true; }
    float GetColumnWidth() const { return columnWidth; }
    float GetActualColumnWidth() const { return actualColumnWidth; }
    void NextColumn() {
        if (tableActive) {
            int currentColumn = ImGui::TableGetColumnIndex();
            ImGui::TableSetColumnIndex(currentColumn + 1);
        }
    }

    
    void SetColumn(int columnIndex) {
        if (tableActive && columnIndex >= 0 && columnIndex < 3) {
            ImGui::TableSetColumnIndex(columnIndex);
        }
    }

    void SetCornerRadius(float radius) { cornerRadius = radius; }
    void SetBaseWindowWidth(float width) { baseWindowWidth = width; }
    float GetBaseWindowWidth() const { return baseWindowWidth; }
    void SetFixedColumnWidth(float width) { fixedColumnWidth = width; useFixedColumnWidth = true; }
    float GetActualContentWidth() const { return actualColumnWidth; }
private:
    float baseWindowWidth = 0.0f;
    float fixedColumnWidth = 0.0f;
    bool useFixedColumnWidth = false;
};

class LayoutManager {
public:
    template<typename T>
    std::shared_ptr<T> Type();

    std::shared_ptr<VerticalLayout> GetScrollableVerticalLayout(ImVec2 size = ImVec2(0, 0), const char* id = nullptr);
    std::shared_ptr<HorizontalLayout> GetTabbedHorizontalLayout(float leftColumnWidth = 150.0f);

    
    std::shared_ptr<VerticalLayout> GetContentLayout();
    std::shared_ptr<VerticalLayout> GetSidebarLayout();

    std::shared_ptr<VerticalLayout> verticalLayout;
    std::shared_ptr<HorizontalLayout> horizontalLayout;

    
    std::shared_ptr<VerticalLayout> contentLayout;
    std::shared_ptr<VerticalLayout> sidebarLayout;

    LayoutManager();
    void Init();


};
