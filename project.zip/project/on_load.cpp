#include <jni.h>
#include "good_luck/good_luck.h"
#include "axlebolt/player_controller.h"

extern "C" __attribute__((used, visibility("default"))) JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM *vm, void *key) {
    if ((uintptr_t)key != (uintptr_t)oxorany(1337))
        return JNI_ERR;
    JNIEnv *env; lolw();
    jint result = vm->GetEnv((void **) &env, JNI_VERSION_1_6);
    if (result != JNI_OK)
        vm->AttachCurrentThread(&env, NULL);
    return JNI_VERSION_1_6;
}

extern "C" __attribute__((used, visibility("default"))) JNIEXPORT void JNICALL JNI_OnUnload(JavaVM *vm, void *reserved) {
    (void)vm;
    (void)reserved;
}
