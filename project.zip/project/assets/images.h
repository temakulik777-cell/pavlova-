#pragma once

#include <array>
#include <atomic>
#include <string>
#include <vector>

#include "../good_luck/glegl/glegl.h"
#include "atlas.h"

using ImageRegion = atlas::ImageRegion;
using AtlasKind = atlas::AtlasKind;
using ImageId = atlas::ImageId;

class Images {
public:
    void Init();
    bool Load();
    void Unload();

    bool Ready() const;

    ImageRegion RegionForName(const std::string& name, AtlasKind atlas = AtlasKind::Icon) const;
    ImageRegion RegionForId(ImageId id) const;

    GLuint TextureForAtlas(AtlasKind atlas) const;
    GLuint TextureForRegion(const ImageRegion& region) const;

    static std::vector<unsigned char> DecompressZlib(const unsigned char* compressed,
                                                     int compressed_size,
                                                     unsigned long original_size_hint = 0);

private:
    bool LoadAtlasTexture(AtlasKind atlas_kind, GLuint& out_texture);

    std::array<GLuint, 3> atlas_textures_{{0, 0, 0}};
    std::atomic<bool> ready_{false};
};

extern Images images;
