#define STB_IMAGE_IMPLEMENTATION
#include "../good_luck/stb/stb_image.h"
#include "../good_luck/libz/libz.h"
#include "images.h"

Images images;

void Images::Init() {
    if (Ready()) {
        return;
    }

    ready_.store(Load(), std::memory_order_release);
}

bool Images::Ready() const {
    return ready_.load(std::memory_order_acquire);
}

std::vector<unsigned char> Images::DecompressZlib(const unsigned char* compressed,
                                                  int compressed_size,
                                                  unsigned long original_size_hint) {
    constexpr int kZok = 0;
    std::vector<unsigned char> decompressed;
    if (!uncompressFn || compressed_size <= 0) {
        return decompressed;
    }

    unsigned long decompressed_size = (original_size_hint > 0) ? original_size_hint : compressed_size * 3;
    decompressed.resize(decompressed_size);

    int result = uncompressFn(
        reinterpret_cast<Bytef_*>(decompressed.data()),
        &decompressed_size,
        reinterpret_cast<const Bytef_*>(compressed),
        static_cast<uLong_>(compressed_size));

    if (result != kZok) {
        decompressed_size = compressed_size * 10;
        decompressed.resize(decompressed_size);

        result = uncompressFn(
            reinterpret_cast<Bytef_*>(decompressed.data()),
            &decompressed_size,
            reinterpret_cast<const Bytef_*>(compressed),
            static_cast<uLong_>(compressed_size));

        if (result != kZok) {
            decompressed.clear();
            return decompressed;
        }
    }

    decompressed.resize(decompressed_size);
    return decompressed;
}

bool Images::LoadAtlasTexture(AtlasKind atlas_kind, GLuint& out_texture) {
    if (out_texture != 0) {
        glDeleteTextures(1, &out_texture);
        out_texture = 0;
    }

    const unsigned char* compressed_data = atlas::AtlasData(atlas_kind);
    const int compressed_size = atlas::AtlasDataSize(atlas_kind);
    const int original_size = atlas::AtlasOriginalSize(atlas_kind);
    if (!compressed_data || compressed_size <= 0) {
        return false;
    }

    std::vector<unsigned char> png_data = DecompressZlib(
        compressed_data, compressed_size, static_cast<unsigned long>(original_size));
    if (png_data.empty()) {
        png_data.assign(compressed_data, compressed_data + compressed_size);
    }

    int width = 0;
    int height = 0;
    int channels = 0;
    unsigned char* image_data = stbi_load_from_memory(
        png_data.data(),
        static_cast<int>(png_data.size()),
        &width,
        &height,
        &channels,
        STBI_rgb_alpha);
    if (!image_data) {
        return false;
    }

    glGenTextures(1, &out_texture);
    glBindTexture(GL_TEXTURE_2D, out_texture);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image_data);
    stbi_image_free(image_data);
    return true;
}

bool Images::Load() {
    if (Ready() &&
        atlas_textures_[static_cast<int>(AtlasKind::Icon)] != 0 &&
        atlas_textures_[static_cast<int>(AtlasKind::Glow)] != 0 &&
        atlas_textures_[static_cast<int>(AtlasKind::Misc)] != 0) {
        return true;
    }

    if (!LoadAtlasTexture(AtlasKind::Icon, atlas_textures_[static_cast<int>(AtlasKind::Icon)])) {
        Unload();
        return false;
    }
    if (!LoadAtlasTexture(AtlasKind::Glow, atlas_textures_[static_cast<int>(AtlasKind::Glow)])) {
        Unload();
        return false;
    }
    if (!LoadAtlasTexture(AtlasKind::Misc, atlas_textures_[static_cast<int>(AtlasKind::Misc)])) {
        Unload();
        return false;
    }

    glBindTexture(GL_TEXTURE_2D, 0);
    ready_.store(true, std::memory_order_release);
    return true;
}

void Images::Unload() {
    for (GLuint& texture : atlas_textures_) {
        if (texture != 0) {
            glDeleteTextures(1, &texture);
            texture = 0;
        }
    }
    ready_.store(false, std::memory_order_release);
}

ImageRegion Images::RegionForName(const std::string& name, AtlasKind atlas_kind) const {
    auto is_valid = [](const ImageRegion& r) {
        return r.width > 0 && r.height > 0 &&
               r.u_max > r.u_min && r.v_max > r.v_min &&
               r.atlas != AtlasKind::Unknown;
    };

    ImageRegion r = atlas::ResolveRegionByName(name, atlas_kind);
    if (is_valid(r)) {
        return r;
    }

    auto from_uv = [&](const atlas::IconUV& uv) -> ImageRegion {
        return ImageRegion{
            uv.u_min, uv.v_min, uv.u_max, uv.v_max,
            uv.width, uv.height, atlas::AtlasKindFromString(uv.atlas_type)
        };
    };

    // Glow must never silently fall back to a regular icon region.
    // Otherwise it looks like a second icon instead of halo.
    if (atlas_kind == AtlasKind::Glow) {
        // Accept exact glow keys (e.g. "text_aimbot_glow") first.
        atlas::IconUV uv = atlas::GetIconUV(name, "glow");
        ImageRegion strict = from_uv(uv);
        if (is_valid(strict)) {
            return strict;
        }

        // Fallback for legacy callers that pass base icon names.
        uv = atlas::GetIconUV(name + "_glow", "glow");
        strict = from_uv(uv);
        if (is_valid(strict)) {
            return strict;
        }

        uv = atlas::GetIconUV(name + "_glow", "misc");
        strict = from_uv(uv);
        if (is_valid(strict)) {
            return strict;
        }
        return {};
    }

    const std::string atlas_name = atlas::AtlasKindToString(atlas_kind);

    atlas::IconUV uv = atlas::GetIconUV(name, atlas_name);
    r = from_uv(uv);
    if (is_valid(r)) {
        return r;
    }

    if (atlas_kind == AtlasKind::Icon) {
        uv = atlas::GetIconUV(name, "misc");
        r = from_uv(uv);
        if (is_valid(r)) {
            return r;
        }
    }

    return {};
}

ImageRegion Images::RegionForId(ImageId id) const {
    return atlas::ResolveRegion(id);
}

GLuint Images::TextureForAtlas(AtlasKind atlas_kind) const {
    switch (atlas_kind) {
        case AtlasKind::Icon:
        case AtlasKind::Glow:
        case AtlasKind::Misc:
            return atlas_textures_[static_cast<int>(atlas_kind)];
        default:
            return atlas_textures_[static_cast<int>(AtlasKind::Icon)];
    }
}

GLuint Images::TextureForRegion(const ImageRegion& region) const {
    if (region.atlas == AtlasKind::Unknown ||
        region.width <= 0 || region.height <= 0 ||
        region.u_max <= region.u_min || region.v_max <= region.v_min) {
        return 0;
    }
    return TextureForAtlas(region.atlas);
}
