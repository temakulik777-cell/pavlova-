#!/usr/bin/env sh
set -eu

ASSETS_DIR="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
TOOLS_DIR="$ASSETS_DIR/tools"
ATLAS_DIR="$ASSETS_DIR/atlas"

OUT_HEADER="$ASSETS_DIR/atlas.h"

"$TOOLS_DIR/max_compress_pngs.sh" \
  "$ATLAS_DIR/icons" \
  "$ATLAS_DIR/text/glow" \
  "$ATLAS_DIR/miku.png" \
  "$ATLAS_DIR/yorozka.png" \
  "$ATLAS_DIR/user.png"

python3 "$TOOLS_DIR/generate_atlas_header.py" \
  --base-dir "$ATLAS_DIR" \
  --out "$OUT_HEADER"

echo "Atlas assets pipeline complete."
