#!/usr/bin/env python3
import argparse
import io
import zlib
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from PIL import Image


PADDING = 2
DEFAULT_BG = (0, 0, 0, 0)


@dataclass
class PackedRegion:
    name: str
    atlas: str
    x: int
    y: int
    width: int
    height: int
    atlas_w: int
    atlas_h: int

    def uv(self) -> Tuple[float, float, float, float]:
        # Keep full UVs for glow atlas to preserve soft outer halo pixels.
        # For icon/misc atlas keep half-pixel inset to reduce bleeding.
        inset = 0.0 if self.atlas == "glow" else 0.5
        u_min = (self.x + inset) / self.atlas_w
        v_min = (self.y + inset) / self.atlas_h
        u_max = (self.x + self.width - inset) / self.atlas_w
        v_max = (self.y + self.height - inset) / self.atlas_h
        return u_min, v_min, u_max, v_max


def read_rgba(path: Path) -> Image.Image:
    with Image.open(path) as im:
        return im.convert("RGBA")


def collect_icon_sources(icon_dir: Path, base_dir: Path) -> List[Tuple[str, Image.Image]]:
    out: List[Tuple[str, Image.Image]] = []
    for p in sorted(icon_dir.glob("*.png")):
        if not p.is_file():
            continue
        if p.stem in {"melrere", "miku"}:
            continue
        out.append((p.stem, read_rgba(p)))

    yorozka_path = first_existing([
        icon_dir / "yorozka.png",
        base_dir / "yorozka.png",
    ])
    if yorozka_path is not None and not any(name == "yorozka" for name, _ in out):
        out.append(("yorozka", read_rgba(yorozka_path)))
    return out


def collect_glow_sources(glow_dir: Path, icon_dir: Path) -> List[Tuple[str, Image.Image]]:
    out: List[Tuple[str, Image.Image]] = []
    for p in sorted(glow_dir.glob("*.png")):
        if not p.is_file():
            continue
        glow_name = p.stem
        glow_im = read_rgba(p)

        # Keep glow canvas untouched.
        # Runtime scales glow by glow/icon size ratio, so larger glow canvases
        # preserve soft halo outside the icon footprint.
        base_name = glow_name[:-5] if glow_name.endswith("_glow") else glow_name
        icon_path = icon_dir / f"{base_name}.png"
        if icon_path.is_file():
            icon_im = read_rgba(icon_path)
            if glow_im.size != icon_im.size:
                print(
                    f"[atlas] glow/icon size mismatch for '{base_name}': "
                    f"glow={glow_im.size}, icon={icon_im.size}"
                )
        out.append((glow_name, glow_im))
    return out

def collect_text_glow_sources(text_glow_dir: Path) -> List[Tuple[str, Image.Image]]:
    out: List[Tuple[str, Image.Image]] = []
    for p in sorted(text_glow_dir.glob("*.png")):
        if not p.is_file():
            continue
        # Keep text glow names in dedicated key-space to avoid collisions with icon glow names.
        out.append((f"text_{p.stem}", read_rgba(p)))
    return out


def first_existing(paths: List[Path]) -> Optional[Path]:
    for p in paths:
        if p.is_file():
            return p
    return None


def collect_misc_sources(base_dir: Path, icon_dir: Path) -> Tuple[List[Tuple[str, Image.Image]], Dict[str, str]]:
    out: List[Tuple[str, Image.Image]] = []
    aliases: Dict[str, str] = {}

    miku_path = first_existing([
        base_dir / "miku.png",
        icon_dir / "miku.png",
    ])
    if miku_path is not None:
        out.append(("miku", read_rgba(miku_path)))

    user_path = first_existing([
        icon_dir / "user.png",
        base_dir / "user.png",
    ])
    if user_path is not None:
        out.append(("user", read_rgba(user_path)))

    return out, aliases


def try_pack(items: List[Tuple[str, Image.Image]], size: int) -> Optional[Tuple[Image.Image, Dict[str, Tuple[int, int, int, int]]]]:
    atlas = Image.new("RGBA", (size, size), DEFAULT_BG)
    placements: Dict[str, Tuple[int, int, int, int]] = {}

    x = PADDING
    y = PADDING
    row_h = 0

    for name, img in sorted(items, key=lambda t: (max(t[1].size), t[1].size[1], t[1].size[0]), reverse=True):
        w, h = img.size
        if w + (PADDING * 2) > size or h + (PADDING * 2) > size:
            return None

        if x + w + PADDING > size:
            x = PADDING
            y += row_h + PADDING
            row_h = 0

        if y + h + PADDING > size:
            return None

        # Do not use the source image as mask here.
        # Using paste(..., mask=img) attenuates alpha and weakens soft glow.
        atlas.paste(img, (x, y))
        placements[name] = (x, y, w, h)
        x += w + PADDING
        row_h = max(row_h, h)

    return atlas, placements


def pack_atlas(items: List[Tuple[str, Image.Image]]) -> Tuple[Image.Image, Dict[str, Tuple[int, int, int, int]]]:
    for size in (512, 1024, 2048, 4096):
        result = try_pack(items, size)
        if result is not None:
            return result
    raise RuntimeError("Failed to pack atlas: too many or too large images.")


def png_bytes(img: Image.Image) -> bytes:
    buf = io.BytesIO()
    img.save(buf, format="PNG", optimize=True)
    return buf.getvalue()

def write_debug_atlas_pngs(out_header: Path,
                           icon_img: Image.Image,
                           misc_img: Image.Image) -> None:
    out_dir = out_header.parent
    icon_out = out_dir / "icon_atlas.png"
    misc_out = out_dir / "misc_atlas.png"

    icon_img.save(icon_out, format="PNG")
    misc_img.save(misc_out, format="PNG")

    glow_out = out_dir / "glow_atlas.png"
    if glow_out.exists():
        glow_out.unlink()

    print("Atlas PNGs:")
    print(" -", icon_out)
    print(" - glow shares icon atlas texture")
    print(" -", misc_out)


def fmt_hex_array(data: bytes, width: int = 12) -> str:
    parts = [f"0x{b:02x}" for b in data]
    lines = []
    for i in range(0, len(parts), width):
        lines.append("        " + ", ".join(parts[i:i + width]))
    return ",\n".join(lines)


def build_regions(atlas_name: str,
                  atlas_size: Tuple[int, int],
                  placements: Dict[str, Tuple[int, int, int, int]],
                  aliases: Optional[Dict[str, str]] = None) -> List[PackedRegion]:
    regions: List[PackedRegion] = []
    w_all, h_all = atlas_size

    for name, (x, y, w, h) in placements.items():
        regions.append(PackedRegion(name=name, atlas=atlas_name, x=x, y=y,
                                    width=w, height=h, atlas_w=w_all, atlas_h=h_all))

    if aliases:
        for alias_name, target_name in aliases.items():
            if target_name not in placements:
                continue
            x, y, w, h = placements[target_name]
            regions.append(PackedRegion(name=alias_name, atlas=atlas_name, x=x, y=y,
                                        width=w, height=h, atlas_w=w_all, atlas_h=h_all))

    return regions


def write_header(out_path: Path,
                 icon_png: bytes,
                 misc_png: bytes,
                 icon_size: Tuple[int, int],
                 misc_size: Tuple[int, int],
                 regions: List[PackedRegion]) -> None:
    icon_z = zlib.compress(icon_png, 9)
    misc_z = zlib.compress(misc_png, 9)

    region_lines = []
    for r in regions:
        u_min, v_min, u_max, v_max = r.uv()
        region_lines.append(
            '        {"%s:%s", {%.6ff, %.6ff, %.6ff, %.6ff, %d, %d, "%s"}}' % (
                r.atlas, r.name, u_min, v_min, u_max, v_max, r.width, r.height, r.atlas
            )
        )

    content = f"""#pragma once

#include <string>
#include <unordered_map>
#include <vector>

namespace atlas {{

struct IconUV {{
    float u_min, v_min;
    float u_max, v_max;
    int width, height;
    std::string atlas_type;
}};

enum class AtlasKind {{
    Icon = 0,
    Glow = 1,
    Misc = 2,
    Unknown = 3
}};

enum class ImageId {{
    Search,
    Cui,
    Ghost,
    Misc,
    Combat,
    Custom,
    Hud,
    Movement,
    Render,
    World,
    Miku,
    Yorozka,
    User,
    Unknown
}};

struct ImageRegion {{
    float u_min = 0.0f;
    float v_min = 0.0f;
    float u_max = 0.0f;
    float v_max = 0.0f;
    int width = 0;
    int height = 0;
    AtlasKind atlas = AtlasKind::Unknown;
}};

namespace data {{
    const unsigned char icon_atlas_data[] = {{
{fmt_hex_array(icon_z)}
    }};
    const int icon_atlas_data_size = {len(icon_z)};
    const int icon_atlas_original_size = {len(icon_png)};
    const int icon_atlas_width = {icon_size[0]};
    const int icon_atlas_height = {icon_size[1]};

    inline const unsigned char* glow_atlas_data = icon_atlas_data;
    const int glow_atlas_data_size = icon_atlas_data_size;
    const int glow_atlas_original_size = icon_atlas_original_size;
    const int glow_atlas_width = icon_atlas_width;
    const int glow_atlas_height = icon_atlas_height;

    const unsigned char misc_atlas_data[] = {{
{fmt_hex_array(misc_z)}
    }};
    const int misc_atlas_data_size = {len(misc_z)};
    const int misc_atlas_original_size = {len(misc_png)};
    const int misc_atlas_width = {misc_size[0]};
    const int misc_atlas_height = {misc_size[1]};

    inline std::unordered_map<std::string, IconUV> icon_uvs = {{
{",\n".join(region_lines)}
    }};
}}

inline AtlasKind AtlasKindFromString(const std::string& atlas_name) {{
    if (atlas_name == "icon") return AtlasKind::Icon;
    if (atlas_name == "glow") return AtlasKind::Glow;
    if (atlas_name == "misc") return AtlasKind::Misc;
    return AtlasKind::Unknown;
}}

inline const char* AtlasKindToString(AtlasKind kind) {{
    switch (kind) {{
        case AtlasKind::Icon: return "icon";
        case AtlasKind::Glow: return "glow";
        case AtlasKind::Misc: return "misc";
        default: return "";
    }}
}}

inline std::string MakeKey(const std::string& name, const std::string& atlas_type) {{
    return atlas_type + ":" + name;
}}

inline IconUV GetIconUV(const std::string& name, const std::string& atlas_type) {{
    auto it = data::icon_uvs.find(MakeKey(name, atlas_type));
    if (it != data::icon_uvs.end()) {{
        return it->second;
    }}
    return {{0.0f, 0.0f, 0.0f, 0.0f, 0, 0, ""}};
}}

inline ImageRegion BuildRegion(const IconUV& uv) {{
    return {{
        uv.u_min,
        uv.v_min,
        uv.u_max,
        uv.v_max,
        uv.width,
        uv.height,
        AtlasKindFromString(uv.atlas_type),
    }};
}}

inline const unsigned char* AtlasData(AtlasKind kind) {{
    switch (kind) {{
        case AtlasKind::Icon: return data::icon_atlas_data;
        case AtlasKind::Glow: return data::glow_atlas_data;
        case AtlasKind::Misc: return data::misc_atlas_data;
        default: return nullptr;
    }}
}}

inline int AtlasDataSize(AtlasKind kind) {{
    switch (kind) {{
        case AtlasKind::Icon: return data::icon_atlas_data_size;
        case AtlasKind::Glow: return data::glow_atlas_data_size;
        case AtlasKind::Misc: return data::misc_atlas_data_size;
        default: return 0;
    }}
}}

inline int AtlasOriginalSize(AtlasKind kind) {{
    switch (kind) {{
        case AtlasKind::Icon: return data::icon_atlas_original_size;
        case AtlasKind::Glow: return data::glow_atlas_original_size;
        case AtlasKind::Misc: return data::misc_atlas_original_size;
        default: return 0;
    }}
}}

inline ImageId ImageIdFromString(const std::string& name) {{
    static const std::unordered_map<std::string, ImageId> kNameMap = {{
        {{"search", ImageId::Search}},
        {{"cui", ImageId::Cui}},
        {{"ghost", ImageId::Ghost}},
        {{"misc", ImageId::Misc}},
        {{"combat", ImageId::Combat}},
        {{"custom", ImageId::Custom}},
        {{"hud", ImageId::Hud}},
        {{"movement", ImageId::Movement}},
        {{"render", ImageId::Render}},
        {{"world", ImageId::World}},
        {{"miku", ImageId::Miku}},
        {{"yorozka", ImageId::Yorozka}},
        {{"user", ImageId::User}}
    }};

    auto it = kNameMap.find(name);
    return (it != kNameMap.end()) ? it->second : ImageId::Unknown;
}}

inline const char* ImageIdToString(ImageId id) {{
    switch (id) {{
        case ImageId::Search: return "search";
        case ImageId::Cui: return "cui";
        case ImageId::Ghost: return "ghost";
        case ImageId::Misc: return "misc";
        case ImageId::Combat: return "combat";
        case ImageId::Custom: return "custom";
        case ImageId::Hud: return "hud";
        case ImageId::Movement: return "movement";
        case ImageId::Render: return "render";
        case ImageId::World: return "world";
        case ImageId::Miku: return "miku";
        case ImageId::Yorozka: return "yorozka";
        case ImageId::User: return "user";
        default: return "";
    }}
}}

inline ImageRegion ResolveRegion(ImageId id, AtlasKind atlas_kind = AtlasKind::Icon) {{
    auto empty = []() {{ return ImageRegion{{}}; }};
    auto is_valid = [](const IconUV& uv) {{
        return (uv.u_min != 0.0f || uv.v_min != 0.0f || uv.u_max != 0.0f || uv.v_max != 0.0f);
    }};
    auto resolve = [&](const char* base, const char* legacy) -> ImageRegion {{
        const char* atlas_name = AtlasKindToString(atlas_kind);
        IconUV uv = GetIconUV(base, atlas_name);
        if (!is_valid(uv) && atlas_kind == AtlasKind::Icon) {{
            uv = GetIconUV(base, "misc");
        }}
        if (!is_valid(uv) && atlas_kind == AtlasKind::Glow) {{
            uv = GetIconUV(std::string(base) + "_glow", "glow");
        }}
        if (!is_valid(uv) && atlas_kind == AtlasKind::Glow) {{
            uv = GetIconUV(std::string(base) + "_glow", "misc");
        }}
        if (!is_valid(uv) && atlas_kind == AtlasKind::Glow) {{
            uv = GetIconUV(base, "misc");
        }}
        if (!is_valid(uv) && legacy && *legacy) {{
            uv = GetIconUV(legacy, atlas_name);
            if (!is_valid(uv) && atlas_kind == AtlasKind::Icon) {{
                uv = GetIconUV(legacy, "misc");
            }}
            if (!is_valid(uv) && atlas_kind == AtlasKind::Glow) {{
                uv = GetIconUV(std::string(legacy) + "_glow", "glow");
            }}
            if (!is_valid(uv) && atlas_kind == AtlasKind::Glow) {{
                uv = GetIconUV(std::string(legacy) + "_glow", "misc");
            }}
            if (!is_valid(uv) && atlas_kind == AtlasKind::Glow) {{
                uv = GetIconUV(legacy, "misc");
            }}
        }}
        if (!is_valid(uv)) return empty();
        return BuildRegion(uv);
    }};

    if (id == ImageId::Yorozka) {{
        return resolve("yorozka", "");
    }}

    const char* name = ImageIdToString(id);
    if (!name || !*name) return empty();
    return resolve(name, "");
}}

inline ImageRegion ResolveRegionByName(const std::string& name, AtlasKind atlas_kind = AtlasKind::Icon) {{
    return ResolveRegion(ImageIdFromString(name), atlas_kind);
}}

inline AtlasKind ParseAtlasKind(const std::string& atlas_name) {{ return AtlasKindFromString(atlas_name); }}
inline const char* AtlasKindName(AtlasKind kind) {{ return AtlasKindToString(kind); }}
inline ImageId ParseImageId(const std::string& name) {{ return ImageIdFromString(name); }}
inline const char* ImageIdName(ImageId id) {{ return ImageIdToString(id); }}
inline ImageRegion GetImageRegion(ImageId id, AtlasKind atlas_kind = AtlasKind::Icon) {{ return ResolveRegion(id, atlas_kind); }}
inline ImageRegion GetImageRegionByName(const std::string& name, AtlasKind atlas_kind = AtlasKind::Icon) {{
    return ResolveRegionByName(name, atlas_kind);
}}

}}  // namespace atlas
"""

    out_path.write_text(content, encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate single-file atlas.h from atlas image folders.")
    parser.add_argument("--base-dir", required=True, help="Path to project/assets/atlas directory.")
    parser.add_argument("--out", required=True, help="Output atlas.h path.")
    args = parser.parse_args()

    base_dir = Path(args.base_dir)
    icon_dir = base_dir / "icons"
    glow_dir = icon_dir / "glow"
    text_glow_dir = base_dir / "text" / "glow"

    icon_sources = collect_icon_sources(icon_dir, base_dir)
    glow_sources = collect_glow_sources(glow_dir, icon_dir)
    text_glow_sources = collect_text_glow_sources(text_glow_dir)
    misc_sources, misc_aliases = collect_misc_sources(base_dir, icon_dir)

    if not icon_sources:
        raise SystemExit("No icon sources found in atlas/icons")
    if not glow_sources and not text_glow_sources:
        raise SystemExit("No glow sources found in atlas/icons/glow")
    if not misc_sources:
        raise SystemExit("No misc sources found (expected yorozka/misc assets)")

    merged_sources = icon_sources + glow_sources + text_glow_sources
    merged_img, merged_places = pack_atlas(merged_sources)
    icon_places = {name: merged_places[name] for name, _ in icon_sources}
    glow_places = {name: merged_places[name] for name, _ in glow_sources}
    text_glow_places = {name: merged_places[name] for name, _ in text_glow_sources}
    misc_img, misc_places = pack_atlas(misc_sources)

    write_debug_atlas_pngs(Path(args.out), merged_img, misc_img)

    regions: List[PackedRegion] = []
    regions.extend(build_regions("icon", merged_img.size, icon_places))
    regions.extend(build_regions("glow", merged_img.size, glow_places))
    regions.extend(build_regions("glow", merged_img.size, text_glow_places))
    regions.extend(build_regions("misc", misc_img.size, misc_places, aliases=misc_aliases))

    write_header(
        out_path=Path(args.out),
        icon_png=png_bytes(merged_img),
        misc_png=png_bytes(misc_img),
        icon_size=merged_img.size,
        misc_size=misc_img.size,
        regions=regions,
    )

    icon_names = sorted([name for name, _ in icon_sources])
    glow_names = sorted([name for name, _ in glow_sources])
    text_glow_names = sorted([name for name, _ in text_glow_sources])
    misc_names = sorted([name for name, _ in misc_sources] + list(misc_aliases.keys()))
    print("Generated:", args.out)
    print("Icon names:", ", ".join(icon_names))
    print("Glow names:", ", ".join(glow_names))
    print("Text glow names:", ", ".join(text_glow_names))
    print("Misc names:", ", ".join(misc_names))


if __name__ == "__main__":
    main()
