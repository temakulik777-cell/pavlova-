#!/usr/bin/env sh
set -eu

if [ "$#" -lt 1 ]; then
  echo "Usage: $0 <png-file-or-dir> [more paths...]"
  exit 1
fi

compress_one() {
  file="$1"
  [ -f "$file" ] || return 0
  case "$file" in
    *.png|*.PNG) ;;
    *) return 0 ;;
  esac

  if command -v oxipng >/dev/null 2>&1; then
    oxipng -o max --strip all --fix --zopfli "$file" >/dev/null 2>&1 || true
  fi

  if command -v zopflipng >/dev/null 2>&1; then
    zopflipng -y --iterations=50 --filters=01234mepb "$file" "$file" >/dev/null 2>&1 || true
  fi

  is_glow_file=0
  case "$file" in
    */icons/glow/*) is_glow_file=1 ;;
    */text/glow/*) is_glow_file=1 ;;
  esac

  if [ "$is_glow_file" -eq 0 ] && command -v pngquant >/dev/null 2>&1; then
    tmp="${file}.qtmp.png"
    pngquant --quality=70-100 --speed 1 --force --output "$tmp" "$file" >/dev/null 2>&1 || true
    if [ -f "$tmp" ]; then
      if [ "$(wc -c <"$tmp")" -lt "$(wc -c <"$file")" ]; then
        mv "$tmp" "$file"
      else
        rm -f "$tmp"
      fi
    fi
  fi

  if command -v advpng >/dev/null 2>&1; then
    advpng -z4 "$file" >/dev/null 2>&1 || true
  fi

  if command -v optipng >/dev/null 2>&1; then
    optipng -o7 -strip all "$file" >/dev/null 2>&1 || true
  fi
}

for path in "$@"; do
  if [ -d "$path" ]; then
    find "$path" -type f \( -name '*.png' -o -name '*.PNG' \) | while IFS= read -r png; do
      compress_one "$png"
    done
  else
    compress_one "$path"
  fi
done

echo "PNG max compression pass complete."
