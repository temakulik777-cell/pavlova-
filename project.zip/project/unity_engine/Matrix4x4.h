#pragma once
#include <math.h>
#include "Vector3.h"
#include "Quaternion.h"

struct Matrix4x4 {
    float m[4][4];
 
    Matrix4x4() {
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                m[i][j] = (i == j) ? 1.0f : 0.0f;
            }
        }
    }

    static Matrix4x4 Identity() {
        Matrix4x4 mat;
        return mat;
    }
    
    static Matrix4x4 Translate(const Vector3& translation) {
        Matrix4x4 mat = Identity();
        mat.m[0][3] = translation.x;
        mat.m[1][3] = translation.y;
        mat.m[2][3] = translation.z;
        return mat;
    }
    
    static Matrix4x4 Scale(const Vector3& scale) {
        Matrix4x4 mat = Identity();
        mat.m[0][0] = scale.x;
        mat.m[1][1] = scale.y;
        mat.m[2][2] = scale.z;
        return mat;
    }
    
    static Matrix4x4 Rotate(const Quaternion& rotation) {
        Matrix4x4 mat;
        
        float x2 = rotation.x * 2.0f;
        float y2 = rotation.y * 2.0f;
        float z2 = rotation.z * 2.0f;
        
        float xx2 = rotation.x * x2;
        float yy2 = rotation.y * y2;
        float zz2 = rotation.z * z2;
        float xy2 = rotation.x * y2;
        float xz2 = rotation.x * z2;
        float yz2 = rotation.y * z2;
        float wx2 = rotation.w * x2;
        float wy2 = rotation.w * y2;
        float wz2 = rotation.w * z2;
        
        mat.m[0][0] = 1.0f - yy2 - zz2;
        mat.m[0][1] = xy2 - wz2;
        mat.m[0][2] = xz2 + wy2;
        mat.m[0][3] = 0.0f;
        
        mat.m[1][0] = xy2 + wz2;
        mat.m[1][1] = 1.0f - xx2 - zz2;
        mat.m[1][2] = yz2 - wx2;
        mat.m[1][3] = 0.0f;
        
        mat.m[2][0] = xz2 - wy2;
        mat.m[2][1] = yz2 + wx2;
        mat.m[2][2] = 1.0f - xx2 - yy2;
        mat.m[2][3] = 0.0f;
        
        mat.m[3][0] = 0.0f;
        mat.m[3][1] = 0.0f;
        mat.m[3][2] = 0.0f;
        mat.m[3][3] = 1.0f;
        
        return mat;
    }
    
    static Matrix4x4 TRS(const Vector3& position, const Quaternion& rotation, const Vector3& scale) {
        Matrix4x4 translate = Translate(position);
        Matrix4x4 rotate = Rotate(rotation);
        Matrix4x4 scaleMat = Scale(scale);
        
        return translate * rotate * scaleMat;
    }

    Matrix4x4 operator*(const Matrix4x4& other) const {
        Matrix4x4 result;
        
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                result.m[i][j] = 0;
                for (int k = 0; k < 4; k++) {
                    result.m[i][j] += m[i][k] * other.m[k][j];
                }
            }
        }
        
        return result;
    }
    
    Vector3 operator*(const Vector3& point) const {
        Vector3 result;
        result.x = m[0][0] * point.x + m[0][1] * point.y + m[0][2] * point.z + m[0][3];
        result.y = m[1][0] * point.x + m[1][1] * point.y + m[1][2] * point.z + m[1][3];
        result.z = m[2][0] * point.x + m[2][1] * point.y + m[2][2] * point.z + m[2][3];
        
        float w = m[3][0] * point.x + m[3][1] * point.y + m[3][2] * point.z + m[3][3];
        if (w != 0 && w != 1) {
            result.x /= w;
            result.y /= w;
            result.z /= w;
        }
        
        return result;
    }

    float& operator()(int row, int col) {
        return m[row][col];
    }
    
    float operator()(int row, int col) const {
        return m[row][col];
    }
};