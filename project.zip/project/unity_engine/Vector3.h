#pragma once
#include <math.h>

struct Vector3 {
    float x, y, z;

    Vector3() : x(0), y(0), z(0) {}
    Vector3(float x_, float y_, float z_) : x(x_), y(y_), z(z_) {}
    
    static Vector3 zero() { return Vector3(0, 0, 0); }
    static Vector3 one() { return Vector3(1, 1, 1); }
    static Vector3 forward() { return Vector3(0, 0, 1); }
    static Vector3 back() { return Vector3(0, 0, -1); }
    static Vector3 up() { return Vector3(0, 1, 0); }
    static Vector3 down() { return Vector3(0, -1, 0); }
    static Vector3 left() { return Vector3(-1, 0, 0); }
    static Vector3 right() { return Vector3(1, 0, 0); }

    Vector3 operator+(const Vector3& other) const {
        return Vector3(x + other.x, y + other.y, z + other.z);
    }
    
    Vector3 operator-(const Vector3& other) const {
        return Vector3(x - other.x, y - other.y, z - other.z);
    }
    
    Vector3 operator*(float scalar) const {
        return Vector3(x * scalar, y * scalar, z * scalar);
    }
    
    Vector3 operator/(float scalar) const {
        return Vector3(x / scalar, y / scalar, z / scalar);
    }
    
    Vector3& operator+=(const Vector3& other) {
        x += other.x;
        y += other.y;
        z += other.z;
        return *this;
    }
    
    Vector3& operator-=(const Vector3& other) {
        x -= other.x;
        y -= other.y;
        z -= other.z;
        return *this;
    }
    
    Vector3& operator*=(float scalar) {
        x *= scalar;
        y *= scalar;
        z *= scalar;
        return *this;
    }
    
    Vector3& operator/=(float scalar) {
        x /= scalar;
        y /= scalar;
        z /= scalar;
        return *this;
    }
    
    bool operator==(const Vector3& other) const {
        return x == other.x && y == other.y && z == other.z;
    }
    
    bool operator!=(const Vector3& other) const {
        return !(*this == other);
    }

    float magnitude() const {
        return sqrtf(x*x + y*y + z*z);
    }
    
    float sqrMagnitude() const {
        return x*x + y*y + z*z;
    }
    
    Vector3 normalized() const {
        float mag = magnitude();
        if (mag == 0) return Vector3(0, 0, 0);
        return *this / mag;
    }
    
    void Normalize() {
        *this = normalized();
    }
    
    static float Dot(const Vector3& lhs, const Vector3& rhs) {
        return lhs.x * rhs.x + lhs.y * rhs.y + lhs.z * rhs.z;
    }
    
    static Vector3 Cross(const Vector3& lhs, const Vector3& rhs) {
        return Vector3(
            lhs.y * rhs.z - lhs.z * rhs.y,
            lhs.z * rhs.x - lhs.x * rhs.z,
            lhs.x * rhs.y - lhs.y * rhs.x
        );
    }
    
    static float Distance(const Vector3& a, const Vector3& b) {
        return (a - b).magnitude();
    }
    
    static Vector3 Lerp(const Vector3& a, const Vector3& b, float t) {
        t = fmaxf(0, fminf(1, t));
        return a + (b - a) * t;
    }
};