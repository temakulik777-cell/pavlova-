#pragma once

#include <cstddef>
#include <cstdint>
#include <cstdio>

typedef void (*Il2CppMethodPointer)();
typedef void (*InvokerMethod)(Il2CppMethodPointer, const void*, void*, void**, void*);

typedef struct Il2CppVTableSlot { void* methodPtr; const void* method; } Il2CppVTableSlot;
typedef struct Il2CppClass Il2CppClass;
typedef struct MethodInfo MethodInfo;
typedef Il2CppVTableSlot VirtualInvokeData;

typedef struct Il2CppClass_1 {
    uint8_t reserved_000[0x10]; uint32_t flags; uint8_t flags_14; uint8_t reserved_015[0x23];
    uint16_t event_count; uint8_t reserved_03A[0x02]; uint32_t thread_static_fields_size;
    const void** methods; uint32_t instance_size; uint8_t reserved_04C[0x04];
    struct Il2CppClass* element_class; uint8_t reserved_058[0x08]; uint8_t byval_arg[0x18];
    uint16_t vtable_count; uint8_t flags_07A; uint8_t reserved_07B; int32_t native_size;
    uint16_t value_080; uint8_t reserved_082[0x06]; const char* namespaze; const void* type_metadata_handle;
    const char* name; uint8_t reserved_0A0[0x08]; uint16_t value_0A8; uint8_t reserved_0AA[0x02];
    int32_t thread_static_fields_offset; uint8_t reserved_0B0; uint8_t value_0B1; uint8_t flags_0B2;
    uint8_t reserved_0B3[0x0D]; uint16_t field_count; uint8_t flags_0C2; uint8_t reserved_0C3;
    uint32_t actualSize; uint32_t static_fields_size; uint8_t reserved_0CC[0x24];
    uint32_t cctor_finished_or_no_cctor; uint8_t reserved_0F4[0x0C]; Il2CppClass* parent;
    const void* interopData; uint8_t reserved_110[0x08]; Il2CppClass* declaringType;
    uint8_t reserved_120[0x08]; uint16_t interfaces_count; uint16_t property_count; uint8_t reserved_12C[0x04];
} Il2CppClass_1;

typedef struct Il2CppClass_2 {
    uint8_t reserved_138[0x02]; uint16_t method_count; uint8_t flags_13C; uint8_t reserved_13D[0x03];
    uint8_t this_arg[0x18]; uint8_t reserved_158[0x10]; Il2CppClass* klass; uint32_t token;
    uint8_t reserved_174[0x04]; void* interfaceOffsets; Il2CppClass* castClass; uint8_t reserved_188[0x08];
    void* generic_class;
} Il2CppClass_2;

typedef struct Il2CppClass { Il2CppClass_1 _1; void* static_fields; Il2CppClass_2 _2; VirtualInvokeData vtable[1]; } Il2CppClass;

struct MethodInfo {
    uint8_t flags_00; uint8_t reserved_001[0x07]; const void* return_type; Il2CppMethodPointer methodPointer;
    uint16_t slot; uint8_t flags_1A; uint8_t reserved_01B; uint8_t reserved_01C[0x04];
    const void* rgctx_or_method_metadata_handle; InvokerMethod invoker_method; uint8_t reserved_030[0x08];
    const void* generic_method_or_container; uint16_t iflags; uint16_t flags; uint8_t reserved_044[0x04];
    const void** parameters; uint8_t parameters_count; uint8_t reserved_051[0x07]; const char* name;
    Il2CppClass* klass; Il2CppMethodPointer virtualMethodPointer;
};

typedef struct Il2CppThread Il2CppThread;
typedef struct Il2CppDomain Il2CppDomain;
typedef struct Il2CppAssembly Il2CppAssembly;
typedef struct Il2CppImage Il2CppImage;
typedef struct Il2CppAssemblyVector { const Il2CppAssembly** begin; const Il2CppAssembly** end; const Il2CppAssembly** cap; } Il2CppAssemblyVector;

typedef uint16_t Il2CppChar;
typedef uintptr_t il2cpp_array_size_t;

typedef struct Il2CppType { uint32_t bits; uint32_t reserved_04; void* data; uint8_t type; uint8_t flags_11; uint8_t flags_12; uint8_t flags_13; uint8_t flags_14; uint8_t reserved_15[3]; } Il2CppType;
typedef struct Il2CppGenericInst1 { const Il2CppType** type_argv; uint32_t type_argc; uint32_t reserved_0C; } Il2CppGenericInst_0_37_1;
typedef struct Il2CppGenericClass { Il2CppClass* cached_class; const void* generic_type_definition_or_container; const Il2CppGenericInst_0_37_1* class_inst; const void* reserved_18; uint8_t reserved_20; } Il2CppGenericClass_0_37_1;

typedef struct Il2CppObject { union { Il2CppClass* klass; Il2CppClass* vtable; }; void* monitor; } Il2CppObject;
typedef struct Il2CppArrayBounds { il2cpp_array_size_t length; int32_t lower_bound; } Il2CppArrayBounds;
typedef struct Il2CppArray { Il2CppObject obj; Il2CppArrayBounds* bounds; il2cpp_array_size_t max_length; } Il2CppArray;
typedef struct Il2CppString { Il2CppObject object; int32_t length; Il2CppChar chars[0]; } Il2CppString;
typedef struct FieldInfo { const Il2CppType* type; const char* name; uint32_t token; int32_t offset; Il2CppClass* parent; } FieldInfo;
typedef struct Il2CppCustomAttrInfo Il2CppCustomAttrInfo;

enum {
    IL2CPP_API_THREAD_CURRENT = 0, IL2CPP_API_THREAD_ATTACH, IL2CPP_API_THREAD_DETACH,
    IL2CPP_API_CLASS_GET_FIELD_FROM_NAME, IL2CPP_API_CLASS_GET_FIELDS, IL2CPP_API_CLASS_GET_INTERFACES,
    IL2CPP_API_CLASS_GET_METHODS, IL2CPP_API_CLASS_GET_NAMESPACE, IL2CPP_API_CLASS_FROM_TYPE,
    IL2CPP_API_CLASS_FROM_NAME, IL2CPP_API_METADATA_IMAGE_GET_TYPE, IL2CPP_API_METADATA_IMAGE_GET_EXPORTED_TYPE,
    IL2CPP_API_METADATA_TYPE_TO_CLASS, IL2CPP_API_OBJECT_NEW, IL2CPP_API_ARRAY_NEW, IL2CPP_API_STRING_NEW,
    IL2CPP_API_DOMAIN_GET, IL2CPP_API_DOMAIN_GET_ROOT, IL2CPP_API_DOMAIN_GET_ASSEMBLIES,
    IL2CPP_API_DOMAIN_ASSEMBLY_OPEN, IL2CPP_API_ASSEMBLY_GET_IMAGE, IL2CPP_API_IMAGE_GET_CLASS_COUNT,
    IL2CPP_API_IMAGE_GET_CLASS, IL2CPP_API_FIELD_STATIC_GET_VALUE, IL2CPP_API_METHOD_GET_PARAM_NAME,
    IL2CPP_API_METHOD_GET_PARAM_TOKEN, IL2CPP_API_METHOD_GET_PARAM_DEFAULT_VALUE, IL2CPP_API_RESOLVE_ICALL,
    IL2CPP_API_RESOLVE_ICALL_UNITY, IL2CPP_API_CUSTOM_ATTRS_FROM_CLASS, IL2CPP_API_CUSTOM_ATTRS_FROM_METHOD,
    IL2CPP_API_CUSTOM_ATTRS_HAS_ATTR, IL2CPP_API_CUSTOM_ATTRS_GET_ATTR, IL2CPP_API_CUSTOM_ATTRS_CONSTRUCT,
    IL2CPP_API_CUSTOM_ATTRS_FREE, IL2CPP_API_COUNT
};

static constexpr uint32_t IL2CPP_CODE_REGISTRATION = 0x7C6FB60;
static constexpr uint32_t IL2CPP_METADATA_REGISTRATION = 0x7F02EE8;

extern void* _il2cpp_api[IL2CPP_API_COUNT];
extern uintptr_t _il2cpp_base;

void il2cpp_init_api(uintptr_t base);
Il2CppThread* il2cpp_thread_current(void);
Il2CppThread* il2cpp_thread_attach(Il2CppDomain* domain);
void il2cpp_thread_detach(Il2CppThread* thread);

FieldInfo* il2cpp_class_get_field_from_name(Il2CppClass* klass, const char* name);
FieldInfo* il2cpp_class_get_fields(Il2CppClass* klass, void** iter);
Il2CppClass* il2cpp_class_get_interfaces(Il2CppClass* klass, void** iter);
const MethodInfo* il2cpp_class_get_methods(Il2CppClass* klass, void** iter);
const char* il2cpp_class_get_namespace(Il2CppClass* klass);
Il2CppClass* il2cpp_class_from_type(const Il2CppType* type);
Il2CppClass* il2cpp_class_from_name(const Il2CppImage* image, const char* namespaze, const char* clazz);

Il2CppObject* il2cpp_object_new(Il2CppClass* klass);
Il2CppArray* il2cpp_array_new(Il2CppClass* element_class, std::size_t size);
Il2CppString* il2cpp_string_new(const char* text);

Il2CppDomain* il2cpp_domain_get();
Il2CppDomain* il2cpp_domain_get_root();
const Il2CppAssembly** il2cpp_domain_get_assemblies(const Il2CppDomain* domain, std::size_t* size);
const Il2CppAssembly* il2cpp_domain_assembly_open(Il2CppDomain* domain, const char* assembly);
const Il2CppImage* il2cpp_assembly_get_image(const Il2CppAssembly* assembly);

std::size_t il2cpp_image_get_class_count(const Il2CppImage* image);
Il2CppClass* il2cpp_image_get_class(const Il2CppImage* image, std::size_t index);
uint32_t il2cpp_image_get_type_count_internal(const Il2CppImage* image);
uint32_t il2cpp_image_get_exported_type_count_internal(const Il2CppImage* image);
Il2CppClass* il2cpp_image_get_class_internal(const Il2CppImage* image, std::size_t index);
const Il2CppAssembly** il2cpp_domain_get_assemblies_internal(const Il2CppDomain* domain, std::size_t* size);

void il2cpp_field_static_get_value(FieldInfo* field, void* value);
const char* il2cpp_method_get_param_name(const MethodInfo* method, uint32_t index);
uint32_t il2cpp_method_get_param_token(const MethodInfo* method, int32_t index);
const uint8_t* il2cpp_method_get_param_default_value(const MethodInfo* method, int32_t index, const Il2CppType** type, uint8_t* is_explicit_null);

void* il2cpp_resolve_icall(void* method);
void* il2cpp_resolve_icall_unity(void* name);

const Il2CppCustomAttrInfo* il2cpp_custom_attrs_from_class(Il2CppClass* klass);
const Il2CppCustomAttrInfo* il2cpp_custom_attrs_from_method(const MethodInfo* method);
int il2cpp_custom_attrs_has_attr(const Il2CppCustomAttrInfo* info, Il2CppClass* attr_klass);
Il2CppObject* il2cpp_custom_attrs_get_attr(const Il2CppCustomAttrInfo* info, Il2CppClass* attr_klass);
Il2CppArray* il2cpp_custom_attrs_construct(const Il2CppCustomAttrInfo* info);
void il2cpp_custom_attrs_free(const Il2CppCustomAttrInfo* info);
