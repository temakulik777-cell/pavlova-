#include "Il2CppUtils.h"

#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>

enum {
    IL2CPP_TYPE_BITS_BYREF = 1u << 0,
    IL2CPP_TYPE_BITS_ATTRS_SHIFT = 1u,
    IL2CPP_TYPE_BITS_ATTRS_MASK = 0xFFFFu
};

static inline uint16_t il2cpp_type_attrs(const Il2CppType* type) {
    return (uint16_t)((type->bits >> IL2CPP_TYPE_BITS_ATTRS_SHIFT) & IL2CPP_TYPE_BITS_ATTRS_MASK);
}

static inline int il2cpp_type_is_byref(const Il2CppType* type) {
    return (type->bits & IL2CPP_TYPE_BITS_BYREF) != 0;
}

static inline uint8_t il2cpp_type_get_type(const Il2CppType* type) {
    return type->type;
}

static inline int il2cpp_ptr_likely_valid(uintptr_t p);
static inline uint32_t il2cpp_method_token_guess(const MethodInfo* method);

static inline int il2cpp_is_reasonable_param_name(const char* s) {
    size_t i = 0;
    if (!s || !il2cpp_ptr_likely_valid((uintptr_t)s)) {
        return 0;
    }
    for (i = 0; i < 64; ++i) {
        unsigned char c = (unsigned char)s[i];
        if (c == '\0') {
            return i > 0;
        }
        if (!(c == '_' ||
              (c >= '0' && c <= '9') ||
              (c >= 'A' && c <= 'Z') ||
              (c >= 'a' && c <= 'z'))) {
            return 0;
        }
    }
    return 0;
}

static inline const char* il2cpp_method_get_param_name_safe(const MethodInfo* method, uint32_t index) {
    const char* n = NULL;
    uint32_t token = 0;

    if (!method) {
        return NULL;
    }
    if (!_il2cpp_api[IL2CPP_API_METHOD_GET_PARAM_NAME]) {
        return NULL;
    }
    if (!method->parameters || index >= (uint32_t)method->parameters_count || method->parameters_count > 32) {
        return NULL;
    }
    token = il2cpp_method_token_guess(method);
    if ((token & 0xFF000000u) != 0x06000000u) {
        return NULL;
    }

    n = il2cpp_method_get_param_name(method, index);
    if (!il2cpp_is_reasonable_param_name(n)) {
        return NULL;
    }
    return n;
}
enum {
    IL2CPP_DUMP_OK = 0,
    IL2CPP_DUMP_MISSING_DOMAIN_GET_ASSEMBLIES = 1 << 0,
    IL2CPP_DUMP_MISSING_IMAGE_GET_CLASS_COUNT = 1 << 1,
    IL2CPP_DUMP_MISSING_IMAGE_GET_CLASS = 1 << 2,
    IL2CPP_DUMP_MISSING_CLASS_GET_FIELDS = 1 << 3,
    IL2CPP_DUMP_MISSING_CLASS_GET_METHODS = 1 << 4
};

enum {
    IL2CPP_TYPE_END = 0x00,
    IL2CPP_TYPE_VOID = 0x01,
    IL2CPP_TYPE_BOOLEAN = 0x02,
    IL2CPP_TYPE_CHAR = 0x03,
    IL2CPP_TYPE_I1 = 0x04,
    IL2CPP_TYPE_U1 = 0x05,
    IL2CPP_TYPE_I2 = 0x06,
    IL2CPP_TYPE_U2 = 0x07,
    IL2CPP_TYPE_I4 = 0x08,
    IL2CPP_TYPE_U4 = 0x09,
    IL2CPP_TYPE_I8 = 0x0A,
    IL2CPP_TYPE_U8 = 0x0B,
    IL2CPP_TYPE_R4 = 0x0C,
    IL2CPP_TYPE_R8 = 0x0D,
    IL2CPP_TYPE_STRING = 0x0E,
    IL2CPP_TYPE_PTR = 0x0F,
    IL2CPP_TYPE_BYREF = 0x10,
    IL2CPP_TYPE_VALUETYPE = 0x11,
    IL2CPP_TYPE_CLASS = 0x12,
    IL2CPP_TYPE_VAR = 0x13,
    IL2CPP_TYPE_ARRAY = 0x14,
    IL2CPP_TYPE_GENERICINST = 0x15,
    IL2CPP_TYPE_TYPEDBYREF = 0x16,
    IL2CPP_TYPE_I = 0x18,
    IL2CPP_TYPE_U = 0x19,
    IL2CPP_TYPE_FNPTR = 0x1B,
    IL2CPP_TYPE_OBJECT = 0x1C,
    IL2CPP_TYPE_SZARRAY = 0x1D,
    IL2CPP_TYPE_MVAR = 0x1E
};

static inline void il2cpp_append_text(char* dst, size_t cap, const char* text) {
    size_t len = strlen(dst);
    if (!text || len >= cap - 1) {
        return;
    }
    snprintf(dst + len, cap - len, "%s", text);
}

static inline void il2cpp_strip_generic_arity(const char* in, char* out, size_t out_size) {
    size_t i = 0;
    if (!out || out_size == 0) {
        return;
    }
    out[0] = '\0';
    if (!in) {
        return;
    }
    while (in[i] && in[i] != '`' && i + 1 < out_size) {
        out[i] = in[i];
        ++i;
    }
    out[i] = '\0';
}

static inline uint32_t il2cpp_parse_generic_arity(const char* name) {
    const char* p = NULL;
    uint32_t n = 0;
    if (!name) {
        return 0;
    }
    p = strchr(name, '`');
    if (!p) {
        return 0;
    }
    ++p;
    while (*p >= '0' && *p <= '9') {
        n = (n * 10u) + (uint32_t)(*p - '0');
        ++p;
    }
    return n;
}

static inline void il2cpp_pretty_name(const char* in, char* out, size_t out_size) {
    const char* p = NULL;
    const char* gt = NULL;
    const char* suffix = NULL;
    size_t len = 0;

    if (!out || out_size == 0) {
        return;
    }
    out[0] = '\0';
    if (!in || !in[0]) {
        return;
    }

    if (strcmp(in, "<>c") == 0) {
        snprintf(out, out_size, "__AnonStorey");
        return;
    }
    if (strcmp(in, "<>9") == 0) {
        snprintf(out, out_size, "__cache");
        return;
    }
    if (strncmp(in, "<>9__", 5) == 0) {
        snprintf(out, out_size, "__cached_%s", in + 5);
        return;
    }

    p = in;
    if (p[0] == '<') {
        gt = strchr(p, '>');
        if (gt && gt > p + 1) {
            suffix = gt + 1;
            len = (size_t)(gt - (p + 1));
            if (strcmp(suffix, "k__BackingField") == 0) {
                if (len >= out_size) {
                    len = out_size - 1;
                }
                memcpy(out, p + 1, len);
                out[len] = '\0';
                return;
            }
            if (strncmp(suffix, "b__", 3) == 0) {
                snprintf(out, out_size, "__lambda_%.*s_%s", (int)len, p + 1, suffix);
                return;
            }
            snprintf(out, out_size, "__cg_%.*s%s", (int)len, p + 1, suffix);
            return;
        }
    }

    snprintf(out, out_size, "%s", in);
}

static inline int il2cpp_ptr_likely_valid(uintptr_t p) {
    if (p == 0 || (p & 0x7u) != 0u) {
        return 0;
    }
    if (_il2cpp_base != 0) {
        uintptr_t lo = _il2cpp_base - 0x600000000ull;
        uintptr_t hi = _il2cpp_base + 0x600000000ull;
        if (p < lo || p > hi) {
            return 0;
        }
    }
    return 1;
}

static inline const char* il2cpp_type_builtin_name(uint8_t t) {
    switch (t) {
        case IL2CPP_TYPE_VOID: return "void";
        case IL2CPP_TYPE_BOOLEAN: return "bool";
        case IL2CPP_TYPE_CHAR: return "char";
        case IL2CPP_TYPE_I1: return "int8_t";
        case IL2CPP_TYPE_U1: return "uint8_t";
        case IL2CPP_TYPE_I2: return "int16_t";
        case IL2CPP_TYPE_U2: return "uint16_t";
        case IL2CPP_TYPE_I4: return "int32_t";
        case IL2CPP_TYPE_U4: return "uint32_t";
        case IL2CPP_TYPE_I8: return "int64_t";
        case IL2CPP_TYPE_U8: return "uint64_t";
        case IL2CPP_TYPE_R4: return "float";
        case IL2CPP_TYPE_R8: return "double";
        case IL2CPP_TYPE_STRING: return "string";
        case IL2CPP_TYPE_I: return "intptr_t";
        case IL2CPP_TYPE_U: return "uintptr_t";
        case IL2CPP_TYPE_OBJECT: return "object";
        case IL2CPP_TYPE_VAR: return "T";
        case IL2CPP_TYPE_MVAR: return "TMethod";
        case IL2CPP_TYPE_TYPEDBYREF: return "typedref";
        case IL2CPP_TYPE_FNPTR: return "method_ptr";
        default: return NULL;
    }
}

static inline int il2cpp_try_get_generic_args(const Il2CppType* type, const Il2CppType*** out_args, uint32_t* out_argc) {
    const Il2CppGenericClass_0_37_1* gklass = NULL;
    const Il2CppGenericInst_0_37_1* inst = NULL;
    const Il2CppType** args = NULL;
    uint32_t argc = 0;

    if (!out_args || !out_argc) {
        return 0;
    }
    *out_args = NULL;
    *out_argc = 0;

    if (!type || !il2cpp_ptr_likely_valid((uintptr_t)type->data)) {
        return 0;
    }

    gklass = (const Il2CppGenericClass_0_37_1*)type->data;
    if (!il2cpp_ptr_likely_valid((uintptr_t)gklass->class_inst)) {
        return 0;
    }

    inst = gklass->class_inst;
    if (!il2cpp_ptr_likely_valid((uintptr_t)inst->type_argv)) {
        return 0;
    }

    argc = inst->type_argc;
    if (argc == 0 || argc > 32) {
        return 0;
    }

    args = inst->type_argv;
    if (!il2cpp_ptr_likely_valid((uintptr_t)args[0])) {
        return 0;
    }

    *out_args = args;
    *out_argc = argc;
    return 1;
}

static inline void il2cpp_type_to_string_ex(const Il2CppType* type, char* out, size_t out_size, int depth) {
    const char* builtin = NULL;
    uint8_t type_code = 0xFF;
    char simple_name[128];
    char base_name[128];
    char pretty_name[128];
    const Il2CppClass* rk = NULL;
    uint32_t arity = 0;
    const Il2CppType** gargs = NULL;
    uint32_t gargc = 0;

    if (!out || out_size == 0) {
        return;
    }
    out[0] = '\0';

    if (!type) {
        snprintf(out, out_size, "void*");
        return;
    }
    if (depth > 3) {
        snprintf(out, out_size, "...");
        return;
    }

    type_code = il2cpp_type_get_type(type);
    builtin = il2cpp_type_builtin_name(type_code);
    if (builtin) {
        snprintf(out, out_size, "%s", builtin);
    } else if (type_code == IL2CPP_TYPE_CLASS ||
               type_code == IL2CPP_TYPE_VALUETYPE ||
               type_code == IL2CPP_TYPE_GENERICINST ||
               type_code == IL2CPP_TYPE_SZARRAY ||
               type_code == IL2CPP_TYPE_ARRAY) {
        rk = il2cpp_class_from_type(type);
        if (rk && rk->_1.name && rk->_1.name[0]) {
            il2cpp_strip_generic_arity(rk->_1.name, simple_name, sizeof(simple_name));
            il2cpp_pretty_name(simple_name[0] ? simple_name : rk->_1.name, pretty_name, sizeof(pretty_name));
            if (type_code == IL2CPP_TYPE_GENERICINST) {
                arity = il2cpp_parse_generic_arity(rk->_1.name);
                snprintf(base_name, sizeof(base_name), "%s", pretty_name[0] ? pretty_name : (simple_name[0] ? simple_name : rk->_1.name));
                snprintf(out, out_size, "%s", base_name);
                if (il2cpp_try_get_generic_args(type, &gargs, &gargc)) {
                    il2cpp_append_text(out, out_size, "<");
                    for (uint32_t i = 0; i < gargc; ++i) {
                        char arg_name[128];
                        if (i != 0) {
                            il2cpp_append_text(out, out_size, ", ");
                        }
                        il2cpp_type_to_string_ex(gargs[i], arg_name, sizeof(arg_name), depth + 1);
                        il2cpp_append_text(out, out_size, arg_name);
                    }
                    il2cpp_append_text(out, out_size, ">");
                } else if (arity > 0 && arity <= 8) {
                    il2cpp_append_text(out, out_size, "<");
                    for (uint32_t i = 0; i < arity; ++i) {
                        if (i != 0) {
                            il2cpp_append_text(out, out_size, ", ");
                        }
                        snprintf(base_name, sizeof(base_name), "T%u", (unsigned)(i + 1u));
                        il2cpp_append_text(out, out_size, base_name);
                    }
                    il2cpp_append_text(out, out_size, ">");
                }
            } else if (type_code == IL2CPP_TYPE_SZARRAY || type_code == IL2CPP_TYPE_ARRAY) {
                const char* arr_base = pretty_name[0] ? pretty_name : (simple_name[0] ? simple_name : rk->_1.name);
                size_t arr_len = strlen(arr_base);
                if (arr_len >= 2 && arr_base[arr_len - 2] == '[' && arr_base[arr_len - 1] == ']') {
                    snprintf(out, out_size, "%s", arr_base);
                } else {
                    snprintf(out, out_size, "%s[]", arr_base);
                }
            } else {
                snprintf(out, out_size, "%s", pretty_name[0] ? pretty_name : (simple_name[0] ? simple_name : rk->_1.name));
            }
        } else if (type_code == IL2CPP_TYPE_CLASS) {
            snprintf(out, out_size, "class");
        } else if (type_code == IL2CPP_TYPE_VALUETYPE) {
            snprintf(out, out_size, "valuetype");
        } else if (type_code == IL2CPP_TYPE_GENERICINST) {
            snprintf(out, out_size, "generic");
        } else {
            snprintf(out, out_size, "array");
        }
    } else if (type_code == IL2CPP_TYPE_PTR || type_code == IL2CPP_TYPE_BYREF) {
        snprintf(out, out_size, "void*");
    } else {
        snprintf(out, out_size, "type_0x%02X", (unsigned)type_code);
    }

    if (il2cpp_type_is_byref(type)) {
        il2cpp_append_text(out, out_size, "&");
    }
}

static inline void il2cpp_type_to_string(const Il2CppType* type, char* out, size_t out_size) {
    il2cpp_type_to_string_ex(type, out, out_size, 0);
}

static inline void il2cpp_class_modifiers_to_string(uint32_t flags, char* out, size_t out_size) {
    uint32_t vis = flags & 0x7u;
    int is_abstract = (flags & 0x80u) != 0u;
    int is_sealed = (flags & 0x100u) != 0u;

    if (!out || out_size == 0) {
        return;
    }
    out[0] = '\0';

    switch (vis) {
        case 0x1: il2cpp_append_text(out, out_size, "public "); break;
        case 0x2: il2cpp_append_text(out, out_size, "public "); break;
        case 0x3: il2cpp_append_text(out, out_size, "private "); break;
        case 0x4: il2cpp_append_text(out, out_size, "protected "); break;
        case 0x5: il2cpp_append_text(out, out_size, "internal "); break;
        case 0x6: il2cpp_append_text(out, out_size, "private protected "); break;
        case 0x7: il2cpp_append_text(out, out_size, "protected internal "); break;
        default: il2cpp_append_text(out, out_size, "internal "); break;
    }

    if (is_abstract && is_sealed) {
        il2cpp_append_text(out, out_size, "static ");
    } else {
        if (is_abstract) {
            il2cpp_append_text(out, out_size, "abstract ");
        }
        if (is_sealed) {
            il2cpp_append_text(out, out_size, "sealed ");
        }
    }
}

static inline void il2cpp_method_modifiers_to_string(uint16_t flags, char* out, size_t out_size) {
    uint16_t access = (uint16_t)(flags & 0x0007u);

    if (!out || out_size == 0) {
        return;
    }
    out[0] = '\0';

    switch (access) {
        case 0x0001: il2cpp_append_text(out, out_size, "private "); break;
        case 0x0002: il2cpp_append_text(out, out_size, "private protected "); break;
        case 0x0003: il2cpp_append_text(out, out_size, "internal "); break;
        case 0x0004: il2cpp_append_text(out, out_size, "protected "); break;
        case 0x0005: il2cpp_append_text(out, out_size, "protected internal "); break;
        case 0x0006: il2cpp_append_text(out, out_size, "public "); break;
        default: break;
    }

    if ((flags & 0x0010u) != 0u) il2cpp_append_text(out, out_size, "static ");
    if ((flags & 0x0040u) != 0u) il2cpp_append_text(out, out_size, "virtual ");
    if ((flags & 0x0400u) != 0u) il2cpp_append_text(out, out_size, "abstract ");
    if ((flags & 0x0020u) != 0u) il2cpp_append_text(out, out_size, "final ");
}

static inline void il2cpp_field_modifiers_to_string(const FieldInfo* field, char* out, size_t out_size) {
    uint16_t attrs = 0;
    uint16_t access = 0;
    int has_static = 0;
    int has_initonly = 0;
    int has_literal = 0;

    if (!out || out_size == 0) {
        return;
    }
    out[0] = '\0';

    if (field && field->type) {
        attrs = il2cpp_type_attrs(field->type);
    }
    access = (uint16_t)(attrs & 0x0007u);
    has_static = ((attrs & 0x0010u) != 0u) || (field && field->offset < 0);
    has_initonly = (attrs & 0x0020u) != 0u;
    has_literal = (attrs & 0x0040u) != 0u;

    switch (access) {
        case 0x1: il2cpp_append_text(out, out_size, "private "); break;
        case 0x2: il2cpp_append_text(out, out_size, "private protected "); break;
        case 0x3: il2cpp_append_text(out, out_size, "internal "); break;
        case 0x4: il2cpp_append_text(out, out_size, "protected "); break;
        case 0x5: il2cpp_append_text(out, out_size, "protected internal "); break;
        case 0x6: il2cpp_append_text(out, out_size, "public "); break;
        default: il2cpp_append_text(out, out_size, "private "); break;
    }

    if (has_static) {
        il2cpp_append_text(out, out_size, "static ");
    }
    if (has_initonly) {
        il2cpp_append_text(out, out_size, "readonly ");
    }
    if (has_literal) {
        il2cpp_append_text(out, out_size, "const ");
    }
}

static inline uint32_t il2cpp_method_token_guess(const MethodInfo* method) {
    const uint8_t* p = (const uint8_t*)method;
    uint32_t token_34 = 0;
    uintptr_t raw = 0;
    uint32_t lo = 0;

    if (!method) {
        return 0;
    }

    token_34 = *(const uint32_t*)(p + 0x34);
    if ((token_34 & 0xFF000000u) == 0x06000000u) {
        return token_34;
    }

    raw = (uintptr_t)method->rgctx_or_method_metadata_handle;
    lo = (uint32_t)raw;
    if ((lo & 0xFF000000u) == 0x06000000u) {
        return lo;
    }
    return 0;
}

static inline uintptr_t il2cpp_method_rva(const MethodInfo* method) {
    uintptr_t mp = (uintptr_t)method->methodPointer;
    if (!_il2cpp_base || mp < _il2cpp_base) {
        return 0;
    }
    if ((mp - _il2cpp_base) > 0x20000000u) {
        return 0;
    }
    return mp - _il2cpp_base;
}

static inline void il2cpp_field_offset_to_string(int32_t offset, char* out, size_t out_size) {
    if (!out || out_size == 0) {
        return;
    }
    if (offset >= 0) {
        snprintf(out, out_size, "0x%X", (unsigned)offset);
    } else {
        snprintf(out, out_size, "-0x%X", (unsigned)(-offset));
    }
}

typedef struct Il2CppPropEntry {
    char name[128];
    const MethodInfo* getter;
    const MethodInfo* setter;
} Il2CppPropEntry;

typedef struct Il2CppEventEntry {
    char name[128];
    const MethodInfo* adder;
    const MethodInfo* remover;
} Il2CppEventEntry;

static inline int il2cpp_name_has_prefix(const char* s, const char* pfx) {
    size_t n = 0;
    if (!s || !pfx) {
        return 0;
    }
    n = strlen(pfx);
    return strncmp(s, pfx, n) == 0;
}

static inline int il2cpp_find_prop_index(Il2CppPropEntry* arr, unsigned count, const char* name) {
    unsigned i = 0;
    for (i = 0; i < count; ++i) {
        if (strcmp(arr[i].name, name) == 0) {
            return (int)i;
        }
    }
    return -1;
}

static inline int il2cpp_find_event_index(Il2CppEventEntry* arr, unsigned count, const char* name) {
    unsigned i = 0;
    for (i = 0; i < count; ++i) {
        if (strcmp(arr[i].name, name) == 0) {
            return (int)i;
        }
    }
    return -1;
}

enum {
    IL2CPP_PARAM_ATTR_IN = 0x0001,
    IL2CPP_PARAM_ATTR_OUT = 0x0002,
    IL2CPP_PARAM_ATTR_OPTIONAL = 0x0010
};

static inline void il2cpp_trim_type_byref_suffix(char* type_name) {
    size_t n = 0;
    if (!type_name) {
        return;
    }
    n = strlen(type_name);
    if (n > 0 && type_name[n - 1] == '&') {
        type_name[n - 1] = '\0';
    }
}

static inline void il2cpp_param_modifiers_to_string(const Il2CppType* type, char* out, size_t out_size) {
    uint16_t attrs = 0;
    int byref = 0;

    if (!out || out_size == 0) {
        return;
    }
    out[0] = '\0';

    if (!type) {
        return;
    }

    attrs = il2cpp_type_attrs(type);
    byref = il2cpp_type_is_byref(type);

    if (byref) {
        if ((attrs & IL2CPP_PARAM_ATTR_OUT) != 0 && (attrs & IL2CPP_PARAM_ATTR_IN) == 0) {
            il2cpp_append_text(out, out_size, "out ");
            return;
        }
        if ((attrs & IL2CPP_PARAM_ATTR_IN) != 0 && (attrs & IL2CPP_PARAM_ATTR_OUT) == 0) {
            il2cpp_append_text(out, out_size, "in ");
            return;
        }
        il2cpp_append_text(out, out_size, "ref ");
        return;
    }

    if ((attrs & IL2CPP_PARAM_ATTR_IN) != 0) {
        il2cpp_append_text(out, out_size, "in ");
    }
}

static inline uint8_t il2cpp_read_u8_advance(const char** p) {
    uint8_t v = 0;
    memcpy(&v, *p, sizeof(v));
    *p += sizeof(v);
    return v;
}

static inline uint16_t il2cpp_read_u16_advance(const char** p) {
    uint16_t v = 0;
    memcpy(&v, *p, sizeof(v));
    *p += sizeof(v);
    return v;
}

static inline uint64_t il2cpp_read_u64_advance(const char** p) {
    uint64_t v = 0;
    memcpy(&v, *p, sizeof(v));
    *p += sizeof(v);
    return v;
}

static inline float il2cpp_read_f32_advance(const char** p) {
    float v = 0.0f;
    memcpy(&v, *p, sizeof(v));
    *p += sizeof(v);
    return v;
}

static inline double il2cpp_read_f64_advance(const char** p) {
    double v = 0.0;
    memcpy(&v, *p, sizeof(v));
    *p += sizeof(v);
    return v;
}

static inline uint32_t il2cpp_read_compressed_u32(const char** p) {
    uint8_t lead = il2cpp_read_u8_advance(p);
    uint32_t val = 0;

    if ((lead & 0x80u) == 0) {
        return (uint32_t)lead;
    }
    if ((lead & 0xC0u) == 0x80u) {
        val = (uint32_t)(lead & ~0x80u) << 8;
        val |= il2cpp_read_u8_advance(p);
        return val;
    }
    if ((lead & 0xE0u) == 0xC0u) {
        val = (uint32_t)(lead & ~0xC0u) << 24;
        val |= (uint32_t)il2cpp_read_u8_advance(p) << 16;
        val |= (uint32_t)il2cpp_read_u8_advance(p) << 8;
        val |= il2cpp_read_u8_advance(p);
        return val;
    }
    if (lead == 0xF0u) {
        uint32_t raw = 0;
        memcpy(&raw, *p, sizeof(raw));
        *p += sizeof(raw);
        return raw;
    }
    if (lead == 0xFEu) {
        return 0xFFFFFFFEu;
    }
    if (lead == 0xFFu) {
        return 0xFFFFFFFFu;
    }
    return 0;
}

static inline int32_t il2cpp_read_compressed_i32(const char** p) {
    uint32_t encoded = il2cpp_read_compressed_u32(p);
    if (encoded == 0xFFFFFFFFu) {
        return (int32_t)0x80000000u;
    }
    if ((encoded & 1u) != 0u) {
        return -(int32_t)((encoded >> 1) + 1u);
    }
    return (int32_t)(encoded >> 1);
}

static inline int il2cpp_try_format_param_default_value(const MethodInfo* method, int32_t index, char* out, size_t out_size) {
    const Il2CppType* dv_type = NULL;
    uint8_t is_explicit_null = 0;
    const uint8_t* blob = NULL;
    const char* p = NULL;
    uint8_t tc = 0xFF;

    if (!out || out_size == 0) {
        return 0;
    }
    out[0] = '\0';

    if (!_il2cpp_api[IL2CPP_API_METHOD_GET_PARAM_DEFAULT_VALUE] || !method) {
        return 0;
    }

    blob = il2cpp_method_get_param_default_value(method, index, &dv_type, &is_explicit_null);
    if (is_explicit_null) {
        snprintf(out, out_size, "null");
        return 1;
    }
    if (!blob || !dv_type || !il2cpp_ptr_likely_valid((uintptr_t)blob)) {
        return 0;
    }

    p = (const char*)blob;
    tc = il2cpp_type_get_type(dv_type);

    switch (tc) {
        case IL2CPP_TYPE_BOOLEAN:
            snprintf(out, out_size, "%s", il2cpp_read_u8_advance(&p) ? "True" : "False");
            return 1;
        case IL2CPP_TYPE_I1:
            snprintf(out, out_size, "%d", (int)(int8_t)il2cpp_read_u8_advance(&p));
            return 1;
        case IL2CPP_TYPE_U1:
            snprintf(out, out_size, "%u", (unsigned)il2cpp_read_u8_advance(&p));
            return 1;
        case IL2CPP_TYPE_CHAR:
            snprintf(out, out_size, "0x%X", (unsigned)il2cpp_read_u16_advance(&p));
            return 1;
        case IL2CPP_TYPE_I2:
            snprintf(out, out_size, "%d", (int)(int16_t)il2cpp_read_u16_advance(&p));
            return 1;
        case IL2CPP_TYPE_U2:
            snprintf(out, out_size, "%u", (unsigned)il2cpp_read_u16_advance(&p));
            return 1;
        case IL2CPP_TYPE_I4:
            snprintf(out, out_size, "%d", il2cpp_read_compressed_i32(&p));
            return 1;
        case IL2CPP_TYPE_U4:
            snprintf(out, out_size, "%u", il2cpp_read_compressed_u32(&p));
            return 1;
        case IL2CPP_TYPE_I8:
            snprintf(out, out_size, "%lld", (long long)(int64_t)il2cpp_read_u64_advance(&p));
            return 1;
        case IL2CPP_TYPE_U8:
            snprintf(out, out_size, "%llu", (unsigned long long)il2cpp_read_u64_advance(&p));
            return 1;
        case IL2CPP_TYPE_R4:
            snprintf(out, out_size, "%g", (double)il2cpp_read_f32_advance(&p));
            return 1;
        case IL2CPP_TYPE_R8:
            snprintf(out, out_size, "%g", il2cpp_read_f64_advance(&p));
            return 1;
        case IL2CPP_TYPE_STRING: {
            int32_t len = il2cpp_read_compressed_i32(&p);
            size_t n = 0;
            if (len == -1) {
                snprintf(out, out_size, "null");
                return 1;
            }
            if (len < 0 || len > 1024) {
                return 0;
            }
            il2cpp_append_text(out, out_size, "\"");
            while (n < (size_t)len) {
                char c = *p++;
                if (c == '"' || c == '\\') {
                    char esc[3];
                    esc[0] = '\\';
                    esc[1] = c;
                    esc[2] = '\0';
                    il2cpp_append_text(out, out_size, esc);
                } else if ((unsigned char)c < 0x20u) {
                    il2cpp_append_text(out, out_size, "?");
                } else {
                    char one[2];
                    one[0] = c;
                    one[1] = '\0';
                    il2cpp_append_text(out, out_size, one);
                }
                ++n;
            }
            il2cpp_append_text(out, out_size, "\"");
            return 1;
        }
        case IL2CPP_TYPE_CLASS:
        case IL2CPP_TYPE_OBJECT:
        case IL2CPP_TYPE_GENERICINST:
            snprintf(out, out_size, "null");
            return 1;
        default:
            return 0;
    }
}

static inline void il2cpp_param_fallback_name(unsigned index, char* out, size_t out_size) {
    static const char* k_names[] = {
        "first", "second", "third", "fourth", "fifth", "sixth", "seventh", "eighth",
        "ninth", "tenth", "eleventh", "twelfth", "thirteenth", "fourteenth", "fifteenth",
        "sixteenth", "seventeenth", "eighteenth", "nineteenth", "twentieth", "twentyFirst",
        "twentySecond", "twentyThird", "twentyFourth", "twentyFifth", "twentySixth",
        "twentySeventh", "twentyEighth", "twentyNinth", "thirtieth", "thirtyFirst", "thirtySecond"
    };
    if (!out || out_size == 0) {
        return;
    }
    out[0] = '\0';
    if (index < (sizeof(k_names) / sizeof(k_names[0]))) {
        snprintf(out, out_size, "%s", k_names[index]);
    } else {
        snprintf(out, out_size, "param%u", index + 1u);
    }
}

static inline const char* il2cpp_image_name_internal(const Il2CppImage* image) {
    const uint8_t* p = (const uint8_t*)image;
    const char* name_a = *(const char* const*)(p + 0x18);
    const char* name_b = *(const char* const*)(p + 0x00);
    if (name_a && name_a[0]) {
        return name_a;
    }
    if (name_b && name_b[0]) {
        return name_b;
    }
    return "<unknown>";
}

static inline void il2cpp_trim_attribute_suffix(const char* in, char* out, size_t out_size) {
    size_t len = 0;

    if (!out || out_size == 0) {
        return;
    }
    out[0] = '\0';

    if (!in || !in[0]) {
        return;
    }

    snprintf(out, out_size, "%s", in);
    len = strlen(out);
    if (len > 9 && strcmp(out + (len - 9), "Attribute") == 0) {
        out[len - 9] = '\0';
    }
}

static inline size_t il2cpp_string_to_utf8(const Il2CppString* s, char* out, size_t out_size) {
    size_t n = 0;

    if (!out || out_size == 0) {
        return 0;
    }
    out[0] = '\0';

    if (!s || s->length <= 0) {
        return 0;
    }

    while (n + 1 < out_size && (int32_t)n < s->length) {
        Il2CppChar ch = s->chars[n];
        out[n] = (ch <= 0x7Fu) ? (char)ch : '?';
        ++n;
    }
    out[n] = '\0';
    return n;
}

static inline int il2cpp_attr_is_type_field(const FieldInfo* field) {
    Il2CppClass* fk = NULL;
    if (!field || !field->type) {
        return 0;
    }
    if (il2cpp_type_get_type(field->type) != IL2CPP_TYPE_CLASS) {
        return 0;
    }
    fk = il2cpp_class_from_type(field->type);
    if (!fk || !fk->_1.name) {
        return 0;
    }
    return (strcmp(fk->_1.name, "Type") == 0);
}

static inline int il2cpp_try_format_klass_name(Il2CppClass* klass, char* out, size_t out_size) {
    char simple[128];
    char pretty[128];

    if (!out || out_size == 0) {
        return 0;
    }
    out[0] = '\0';
    if (!il2cpp_ptr_likely_valid((uintptr_t)klass) || !klass->_1.name || !klass->_1.name[0]) {
        return 0;
    }

    il2cpp_strip_generic_arity(klass->_1.name, simple, sizeof(simple));
    il2cpp_pretty_name(simple[0] ? simple : klass->_1.name, pretty, sizeof(pretty));
    snprintf(out, out_size, "%s", pretty[0] ? pretty : (simple[0] ? simple : klass->_1.name));
    return out[0] != '\0';
}

static inline int il2cpp_try_format_type_ptr(const Il2CppType* type, char* out, size_t out_size) {
    Il2CppClass* klass = NULL;
    if (!out || out_size == 0) {
        return 0;
    }
    out[0] = '\0';
    if (!il2cpp_ptr_likely_valid((uintptr_t)type)) {
        return 0;
    }

    klass = il2cpp_class_from_type(type);
    if (!klass) {
        return 0;
    }
    return il2cpp_try_format_klass_name(klass, out, out_size);
}

static inline int il2cpp_enum_is_enum_class(Il2CppClass* klass) {
    if (!klass || !klass->_1.parent || !klass->_1.parent->_1.name) {
        return 0;
    }
    return strcmp(klass->_1.parent->_1.name, "Enum") == 0;
}

static inline uint8_t il2cpp_enum_underlying_type_code(Il2CppClass* enum_klass) {
    void* iter = NULL;
    FieldInfo* f = NULL;
    unsigned guard = 0;

    if (!enum_klass || !_il2cpp_api[IL2CPP_API_CLASS_GET_FIELDS]) {
        return IL2CPP_TYPE_I4;
    }

    while ((f = il2cpp_class_get_fields(enum_klass, &iter)) != NULL) {
        if (++guard > 128) {
            break;
        }
        if (!f->name || !f->type) {
            continue;
        }
        if (strcmp(f->name, "value__") == 0) {
            return il2cpp_type_get_type(f->type);
        }
    }
    return IL2CPP_TYPE_I4;
}

static inline uint64_t il2cpp_read_integral_u64(const uint8_t* p, uint8_t type_code) {
    switch (type_code) {
        case IL2CPP_TYPE_BOOLEAN: return (uint64_t)(*(const uint8_t*)p ? 1u : 0u);
        case IL2CPP_TYPE_I1: return (uint64_t)(uint8_t)*(const int8_t*)p;
        case IL2CPP_TYPE_U1: return (uint64_t)*(const uint8_t*)p;
        case IL2CPP_TYPE_I2: return (uint64_t)(uint16_t)*(const int16_t*)p;
        case IL2CPP_TYPE_U2: return (uint64_t)*(const uint16_t*)p;
        case IL2CPP_TYPE_I4: return (uint64_t)(uint32_t)*(const int32_t*)p;
        case IL2CPP_TYPE_U4: return (uint64_t)*(const uint32_t*)p;
        case IL2CPP_TYPE_I8: return (uint64_t)*(const int64_t*)p;
        case IL2CPP_TYPE_U8: return (uint64_t)*(const uint64_t*)p;
        default: return (uint64_t)*(const uint32_t*)p;
    }
}

static inline int il2cpp_try_enum_value_name(Il2CppClass* enum_klass, uint64_t value_u64, uint8_t underlying_tc, char* out, size_t out_size) {
    void* iter = NULL;
    FieldInfo* f = NULL;
    unsigned guard = 0;

    if (!out || out_size == 0) {
        return 0;
    }
    out[0] = '\0';

    if (!enum_klass || !_il2cpp_api[IL2CPP_API_CLASS_GET_FIELDS] || !_il2cpp_api[IL2CPP_API_FIELD_STATIC_GET_VALUE]) {
        return 0;
    }

    while ((f = il2cpp_class_get_fields(enum_klass, &iter)) != NULL) {
        uint8_t tmp[8] = {0};
        uint64_t field_val = 0;
        if (++guard > 512) {
            break;
        }
        if (!f->name || !f->name[0] || strcmp(f->name, "value__") == 0 || f->offset >= 0) {
            continue;
        }

        il2cpp_field_static_get_value(f, tmp);
        field_val = il2cpp_read_integral_u64(tmp, underlying_tc);
        if (field_val == value_u64) {
            char n[128];
            il2cpp_strip_generic_arity(f->name, n, sizeof(n));
            snprintf(out, out_size, "%s", n[0] ? n : f->name);
            return 1;
        }
    }

    return 0;
}

static inline int il2cpp_try_format_type_name_from_string(const Il2CppString* full_name, char* out, size_t out_size) {
    char tmp[192];
    const char* p = NULL;

    if (!out || out_size == 0) {
        return 0;
    }
    out[0] = '\0';

    if (!il2cpp_ptr_likely_valid((uintptr_t)full_name) ||
        !il2cpp_ptr_likely_valid((uintptr_t)full_name->object.klass) ||
        full_name->length <= 0 || full_name->length > 512) {
        return 0;
    }

    il2cpp_string_to_utf8(full_name, tmp, sizeof(tmp));
    if (!tmp[0]) {
        return 0;
    }

    p = strrchr(tmp, '.');
    if (p && p[1]) {
        snprintf(out, out_size, "%s", p + 1);
    } else {
        snprintf(out, out_size, "%s", tmp);
    }

    p = strrchr(out, '+');
    if (p && p[1]) {
        memmove(out, p + 1, strlen(p + 1) + 1);
    }
    return out[0] != '\0';
}

static inline int il2cpp_try_format_system_type_object(const Il2CppObject* type_obj, char* out, size_t out_size) {
    Il2CppClass* tk = NULL;
    FieldInfo* fi_impl = NULL;
    FieldInfo* fi_type_info = NULL;
    FieldInfo* fi_full_name = NULL;
    const Il2CppObject* type_info_obj = NULL;
    const Il2CppString* full_name = NULL;
    const uint8_t* type_base = NULL;
    uintptr_t impl_raw = 0;
    uintptr_t impl_masked = 0;

    if (!out || out_size == 0) {
        return 0;
    }
    out[0] = '\0';

    if (!il2cpp_ptr_likely_valid((uintptr_t)type_obj) ||
        !il2cpp_ptr_likely_valid((uintptr_t)type_obj->klass) ||
        !_il2cpp_api[IL2CPP_API_CLASS_GET_FIELDS]) {
        return 0;
    }

    tk = type_obj->klass;

    /* path 0: System.Type._impl (RuntimeTypeHandle.value) */
    fi_impl = il2cpp_class_get_field_from_name(tk, "_impl");
    if (fi_impl && fi_impl->offset >= 0 && fi_impl->offset <= 0x100) {
        impl_raw = *(const uintptr_t*)((const uint8_t*)type_obj + fi_impl->offset);
        impl_masked = impl_raw & ~(uintptr_t)0x1u;

        if (il2cpp_try_format_type_ptr((const Il2CppType*)impl_raw, out, out_size) ||
            il2cpp_try_format_type_ptr((const Il2CppType*)impl_masked, out, out_size) ||
            il2cpp_try_format_klass_name((Il2CppClass*)impl_raw, out, out_size) ||
            il2cpp_try_format_klass_name((Il2CppClass*)impl_masked, out, out_size)) {
            return 1;
        }
    }

    fi_type_info = il2cpp_class_get_field_from_name(tk, "type_info");
    if (!fi_type_info || fi_type_info->offset < 0 || fi_type_info->offset > 0x200) {
        return 0;
    }

    type_base = (const uint8_t*)type_obj + fi_type_info->offset;

    /* path 1: type_info is object reference */
    type_info_obj = *(const Il2CppObject* const*)type_base;
    if (il2cpp_ptr_likely_valid((uintptr_t)type_info_obj) &&
        il2cpp_ptr_likely_valid((uintptr_t)type_info_obj->klass)) {
        fi_full_name = il2cpp_class_get_field_from_name(type_info_obj->klass, "full_name");
        if (fi_full_name && fi_full_name->offset >= 0 && fi_full_name->offset <= 0x100) {
            full_name = *(const Il2CppString* const*)((const uint8_t*)type_info_obj + fi_full_name->offset);
            if (il2cpp_try_format_type_name_from_string(full_name, out, out_size)) {
                return 1;
            }
        }
    }

    /* path 2: type_info is inline valuetype; try common placements */
    full_name = *(const Il2CppString* const*)(type_base + 0x0);
    if (il2cpp_try_format_type_name_from_string(full_name, out, out_size)) {
        return 1;
    }
    full_name = *(const Il2CppString* const*)(type_base + 0x10);
    if (il2cpp_try_format_type_name_from_string(full_name, out, out_size)) {
        return 1;
    }
    return 0;
}

static inline void il2cpp_attr_field_value_to_text(Il2CppObject* attr_obj, const FieldInfo* field, char* out, size_t out_size) {
    uint8_t t = 0xFF;
    uint8_t* base = NULL;

    if (!out || out_size == 0) {
        return;
    }
    out[0] = '\0';

    if (!attr_obj || !field || !field->type || field->offset < 0 || field->offset > 0x1000) {
        return;
    }
    base = (uint8_t*)attr_obj + field->offset;
    t = il2cpp_type_get_type(field->type);

    switch (t) {
        case IL2CPP_TYPE_BOOLEAN:
            snprintf(out, out_size, (*(const uint8_t*)base) ? "True" : "False");
            return;
        case IL2CPP_TYPE_I1:
            snprintf(out, out_size, "%d", (int)*(const int8_t*)base);
            return;
        case IL2CPP_TYPE_U1:
            snprintf(out, out_size, "%u", (unsigned)*(const uint8_t*)base);
            return;
        case IL2CPP_TYPE_I2:
            snprintf(out, out_size, "%d", (int)*(const int16_t*)base);
            return;
        case IL2CPP_TYPE_U2:
            snprintf(out, out_size, "%u", (unsigned)*(const uint16_t*)base);
            return;
        case IL2CPP_TYPE_I4:
            snprintf(out, out_size, "%d", *(const int32_t*)base);
            return;
        case IL2CPP_TYPE_U4:
            snprintf(out, out_size, "%u", *(const uint32_t*)base);
            return;
        case IL2CPP_TYPE_I8:
            snprintf(out, out_size, "%lld", (long long)*(const int64_t*)base);
            return;
        case IL2CPP_TYPE_U8:
            snprintf(out, out_size, "%llu", (unsigned long long)*(const uint64_t*)base);
            return;
        case IL2CPP_TYPE_R4:
            snprintf(out, out_size, "%g", (double)*(const float*)base);
            return;
        case IL2CPP_TYPE_R8:
            snprintf(out, out_size, "%g", *(const double*)base);
            return;
        case IL2CPP_TYPE_STRING: {
            const Il2CppString* s = *(const Il2CppString* const*)base;
            char tmp[128];
            if (!il2cpp_ptr_likely_valid((uintptr_t)s) ||
                !il2cpp_ptr_likely_valid((uintptr_t)s->object.klass) ||
                s->length < 0 || s->length > 512) {
                snprintf(out, out_size, "null");
                return;
            }
            il2cpp_string_to_utf8(s, tmp, sizeof(tmp));
            snprintf(out, out_size, "\"%s\"", tmp);
            return;
        }
        case IL2CPP_TYPE_CLASS:
        case IL2CPP_TYPE_OBJECT: {
            const Il2CppObject* o = *(const Il2CppObject* const*)base;
            if (!il2cpp_ptr_likely_valid((uintptr_t)o) || !il2cpp_ptr_likely_valid((uintptr_t)o->klass)) {
                snprintf(out, out_size, "null");
                return;
            }
            if (il2cpp_attr_is_type_field(field)) {
                char tname[128];
                if (il2cpp_try_format_system_type_object(o, tname, sizeof(tname))) {
                    if (strcmp(tname, "RuntimeType") == 0 || strcmp(tname, "Type") == 0) {
                        snprintf(out, out_size, "typeof(?)");
                    } else {
                    snprintf(out, out_size, "typeof(%s)", tname);
                    }
                } else {
                    snprintf(out, out_size, "typeof(unknown)");
                }
            } else {
                snprintf(out, out_size, "object");
            }
            return;
        }
        case IL2CPP_TYPE_VALUETYPE: {
            Il2CppClass* vk = il2cpp_class_from_type(field->type);
            uint32_t v = *(const uint32_t*)base;
            if (vk && vk->_1.name && strcmp(vk->_1.name, "AttributeTargets") == 0) {
                int wrote = 0;
                struct {
                    uint32_t bit;
                    const char* name;
                } m[] = {
                    {0x0001u, "Assembly"},
                    {0x0002u, "Module"},
                    {0x0004u, "Class"},
                    {0x0008u, "Struct"},
                    {0x0010u, "Enum"},
                    {0x0020u, "Constructor"},
                    {0x0040u, "Method"},
                    {0x0080u, "Property"},
                    {0x0100u, "Field"},
                    {0x0200u, "Event"},
                    {0x0400u, "Interface"},
                    {0x0800u, "Parameter"},
                    {0x1000u, "Delegate"},
                    {0x2000u, "ReturnValue"},
                    {0x4000u, "GenericParameter"}
                };
                uint32_t known = 0;
                size_t i = 0;
                if (v == 0x7FFFu) {
                    snprintf(out, out_size, "All");
                    return;
                }
                out[0] = '\0';
                for (i = 0; i < (sizeof(m) / sizeof(m[0])); ++i) {
                    if ((v & m[i].bit) == 0) {
                        continue;
                    }
                    known |= m[i].bit;
                    if (wrote) {
                        il2cpp_append_text(out, out_size, " | ");
                    }
                    il2cpp_append_text(out, out_size, m[i].name);
                    wrote = 1;
                }
                if (!wrote || (v & ~known) != 0u) {
                    if (wrote) {
                        il2cpp_append_text(out, out_size, " | ");
                    }
                    snprintf(out + strlen(out), out_size - strlen(out), "0x%X", v & ~known);
                }
                return;
            }
            if (vk && il2cpp_enum_is_enum_class(vk)) {
                uint8_t utc = il2cpp_enum_underlying_type_code(vk);
                uint64_t vu = il2cpp_read_integral_u64(base, utc);
                if (il2cpp_try_enum_value_name(vk, vu, utc, out, out_size)) {
                    return;
                }
                snprintf(out, out_size, "0x%llX", (unsigned long long)vu);
                return;
            }
            snprintf(out, out_size, "0x%X", v);
            return;
        }
        default:
            snprintf(out, out_size, "?");
            return;
    }
}

static inline void il2cpp_dump_one_attribute(FILE* out, Il2CppObject* attr_obj, Il2CppClass* attr_class) {
    const char* raw_name = NULL;
    char simple_name[128];
    char pretty_name[128];
    char attr_name[128];
    void* field_iter = NULL;
    FieldInfo* field = NULL;
    int wrote_any = 0;
    unsigned guard = 0;

    if (!out || !attr_obj || !attr_class || !attr_class->_1.name) {
        return;
    }

    raw_name = attr_class->_1.name;
    il2cpp_strip_generic_arity(raw_name, simple_name, sizeof(simple_name));
    il2cpp_pretty_name(simple_name[0] ? simple_name : raw_name, pretty_name, sizeof(pretty_name));
    il2cpp_trim_attribute_suffix(pretty_name[0] ? pretty_name : (simple_name[0] ? simple_name : raw_name), attr_name, sizeof(attr_name));
    fprintf(out, "// %s", attr_name[0] ? attr_name : "Attribute");

    if (!_il2cpp_api[IL2CPP_API_CLASS_GET_FIELDS]) {
        fprintf(out, "\n");
        return;
    }

    while ((field = il2cpp_class_get_fields(attr_class, &field_iter)) != NULL) {
        char v[192];
        if (++guard > 64) {
            break;
        }
        if (field->parent != attr_class) {
            continue;
        }
        if (field->offset < 0) {
            continue;
        }
        il2cpp_attr_field_value_to_text(attr_obj, field, v, sizeof(v));
        if (!v[0]) {
            continue;
        }
        if (strcmp(v, "null") == 0) {
            continue;
        }
        if (strcmp(v, "object") == 0) {
            continue;
        }
        if (strncmp(v, "typeof(", 7) == 0) {
            size_t len = strlen(v);
            if (len > 8 && v[len - 1] == ')') {
                memmove(v, v + 7, len - 8);
                v[len - 8] = '\0';
            }
        }
        if (!wrote_any) {
            fprintf(out, " (");
            wrote_any = 1;
        } else {
            fprintf(out, ", ");
        }
        fprintf(out, "%s", v);
    }

    if (wrote_any) {
        fprintf(out, ")");
    }
    fprintf(out, "\n");
}

static inline int il2cpp_dump_class_attributes(FILE* out, Il2CppClass* klass) {
    const Il2CppCustomAttrInfo* cai = NULL;
    Il2CppArray* attrs = NULL;
    uintptr_t data_ptr = 0;
    il2cpp_array_size_t count = 0;
    il2cpp_array_size_t i = 0;
    const char* ns = NULL;

    if (!out || !klass) {
        return 0;
    }
    if (!_il2cpp_api[IL2CPP_API_CUSTOM_ATTRS_FROM_CLASS] ||
        !_il2cpp_api[IL2CPP_API_CUSTOM_ATTRS_CONSTRUCT] ||
        !_il2cpp_api[IL2CPP_API_CUSTOM_ATTRS_FREE]) {
        return 0;
    }

    ns = klass->_1.namespaze ? klass->_1.namespaze : "";
    if (strncmp(ns, "System", 6) == 0 ||
        strncmp(ns, "Unity", 5) == 0 ||
        strncmp(ns, "Mono", 4) == 0 ||
        strncmp(ns, "mscorlib", 8) == 0) {
        return 0;
    }

    cai = il2cpp_custom_attrs_from_class(klass);
    if (!cai) {
        return 0;
    }

    attrs = il2cpp_custom_attrs_construct(cai);
    if (!attrs) {
        il2cpp_custom_attrs_free(cai);
        return 0;
    }
    if (!il2cpp_ptr_likely_valid((uintptr_t)attrs)) {
        il2cpp_custom_attrs_free(cai);
        return 0;
    }
    if (!il2cpp_ptr_likely_valid((uintptr_t)attrs->obj.klass)) {
        il2cpp_custom_attrs_free(cai);
        return 0;
    }

    count = attrs->max_length;
    if (count == 0 || count > 32) {
        il2cpp_custom_attrs_free(cai);
        return 0;
    }

    data_ptr = (uintptr_t)attrs + sizeof(Il2CppArray);
    if (!il2cpp_ptr_likely_valid(data_ptr)) {
        il2cpp_custom_attrs_free(cai);
        return 0;
    }

    {
        int printed = 0;
    for (i = 0; i < count; ++i) {
        Il2CppObject* attr_obj = ((Il2CppObject**)data_ptr)[i];
        Il2CppClass* attr_class = NULL;

        if (!il2cpp_ptr_likely_valid((uintptr_t)attr_obj)) {
            continue;
        }

        attr_class = attr_obj->klass;
        if (!il2cpp_ptr_likely_valid((uintptr_t)attr_class) ||
            !attr_class->_1.name || !attr_class->_1.name[0]) {
            continue;
        }

        il2cpp_dump_one_attribute(out, attr_obj, attr_class);
        ++printed;
    }

    il2cpp_custom_attrs_free(cai);
        return printed;
    }
}

static inline uintptr_t il2cpp_typeinfo_var_lookup(Il2CppClass* klass);

static inline int il2cpp_dump_class(FILE* out, Il2CppClass* klass) {
    void* field_iter = NULL;
    void* iface_iter = NULL;
    void* method_iter = NULL;
    FieldInfo* field = NULL;
    Il2CppClass* iface = NULL;
    const MethodInfo* method = NULL;
    const char* ns = NULL;
    const char* name = NULL;
    const char* parent_name = NULL;
    const char* kind = "class";
    unsigned field_count = 0;
    unsigned method_count = 0;
    char class_mods[128];
    char class_name_simple[128];
    char class_name_pretty[128];
    char parent_name_simple[128];
    char parent_name_pretty[128];
    int has_fields_block = 0;
    int has_methods_block = 0;
    int has_inherit = 0;
    const MethodInfo** methods_cache = NULL;
    unsigned methods_cache_count = 0;
    Il2CppPropEntry* prop_entries = NULL;
    unsigned prop_count = 0;
    Il2CppEventEntry* event_entries = NULL;
    unsigned event_count = 0;

    if (!out || !klass) {
        return -1;
    }

    ns = klass->_1.namespaze ? klass->_1.namespaze : "";
    name = klass->_1.name ? klass->_1.name : "<null>";
    parent_name = (klass->_1.parent && klass->_1.parent->_1.name) ? klass->_1.parent->_1.name : NULL;
    field_count = (unsigned)klass->_1.field_count;
    method_count = (unsigned)klass->_2.method_count;
    has_fields_block = (field_count > 0) && (_il2cpp_api[IL2CPP_API_CLASS_GET_FIELDS] != NULL);
    has_methods_block = (method_count > 0) && (_il2cpp_api[IL2CPP_API_CLASS_GET_METHODS] != NULL);
    il2cpp_class_modifiers_to_string(klass->_1.flags, class_mods, sizeof(class_mods));
    il2cpp_strip_generic_arity(name, class_name_simple, sizeof(class_name_simple));
    il2cpp_pretty_name(class_name_simple[0] ? class_name_simple : name, class_name_pretty, sizeof(class_name_pretty));
    il2cpp_strip_generic_arity(parent_name, parent_name_simple, sizeof(parent_name_simple));
    il2cpp_pretty_name(parent_name_simple[0] ? parent_name_simple : parent_name, parent_name_pretty, sizeof(parent_name_pretty));

    if ((klass->_1.flags & 0x20u) != 0u) {
        kind = "interface";
    } else if (parent_name && strcmp(parent_name, "Enum") == 0) {
        kind = "enum";
    } else if (parent_name && strcmp(parent_name, "ValueType") == 0) {
        kind = "struct";
    }

    if (ns[0]) {
        fprintf(out, "// Namespace: %s\n", ns);
    }
    il2cpp_dump_class_attributes(out, klass);
    {
        uintptr_t typeinfo_slot = il2cpp_typeinfo_var_lookup(klass);
        uintptr_t runtime_typeinfo = (uintptr_t)klass;
        uintptr_t metadata_typeinfo = (uintptr_t)klass->_1.type_metadata_handle;
        unsigned long long typeinfo_slot_view = 0ull;
        unsigned long long runtime_typeinfo_view = 0ull;
        unsigned long long metadata_typeinfo_view = 0ull;

        if (typeinfo_slot != 0) {
            if (_il2cpp_base && typeinfo_slot >= _il2cpp_base) {
                typeinfo_slot_view = (unsigned long long)(typeinfo_slot - _il2cpp_base);
            } else {
                typeinfo_slot_view = (unsigned long long)typeinfo_slot;
            }
        } else if (_il2cpp_base && runtime_typeinfo >= _il2cpp_base) {
            typeinfo_slot_view = (unsigned long long)(runtime_typeinfo - _il2cpp_base);
        } else {
            typeinfo_slot_view = (unsigned long long)runtime_typeinfo;
        }

        if (_il2cpp_base && runtime_typeinfo >= _il2cpp_base) {
            runtime_typeinfo_view = (unsigned long long)(runtime_typeinfo - _il2cpp_base);
        } else {
            runtime_typeinfo_view = (unsigned long long)runtime_typeinfo;
        }

        if (_il2cpp_base && metadata_typeinfo >= _il2cpp_base) {
            metadata_typeinfo_view = (unsigned long long)(metadata_typeinfo - _il2cpp_base);
        } else {
            metadata_typeinfo_view = (unsigned long long)metadata_typeinfo;
        }

        fprintf(out, "// TypeInfo: %llu\n", typeinfo_slot_view);
        fprintf(out, "// Runtime TypeInfo: %llu\n", runtime_typeinfo_view);
        fprintf(out, "// Metadata TypeInfo: %llu Token: 0x%X\n", metadata_typeinfo_view, klass->_2.token);
    }
    fprintf(out, "%s%s %s", class_mods, kind, class_name_pretty[0] ? class_name_pretty : (class_name_simple[0] ? class_name_simple : name));
    if (parent_name && strcmp(parent_name, "Object") != 0 && strcmp(parent_name, "ValueType") != 0) {
        fprintf(out, " : %s", parent_name_pretty[0] ? parent_name_pretty : (parent_name_simple[0] ? parent_name_simple : parent_name));
        has_inherit = 1;
    }
    if (_il2cpp_api[IL2CPP_API_CLASS_GET_INTERFACES]) {
        while ((iface = il2cpp_class_get_interfaces(klass, &iface_iter)) != NULL) {
            if (!iface->_1.name || !iface->_1.name[0]) {
                continue;
            }
            il2cpp_strip_generic_arity(iface->_1.name, parent_name_simple, sizeof(parent_name_simple));
            il2cpp_pretty_name(parent_name_simple[0] ? parent_name_simple : iface->_1.name, parent_name_pretty, sizeof(parent_name_pretty));
            fprintf(out, "%s %s", has_inherit ? "," : " :", parent_name_pretty[0] ? parent_name_pretty : (parent_name_simple[0] ? parent_name_simple : iface->_1.name));
            has_inherit = 1;
        }
    }
    if (field_count == 0 && method_count == 0) {
        fprintf(out, " { }\n\n");
        return 0;
    }

    if (has_fields_block || has_methods_block) {
        fprintf(out, " {\n\n");
    } else {
        fprintf(out, " {\n");
    }

    if (klass->_2.generic_class) {
        fprintf(out, "    // Generic class: 0x%lX\n\n", (unsigned long)(uintptr_t)klass->_2.generic_class);
    }

    if (has_fields_block) {
        fprintf(out, "    // Fields\n");
        fprintf(out, "    // Fields count: %u\n\n", field_count);
    }
    if (has_fields_block) {
        unsigned field_index = 0;
        while ((field = il2cpp_class_get_fields(klass, &field_iter)) != NULL) {
            const char* field_name = field->name ? field->name : "<null>";
            char field_mods[128];
            char field_type_name[128];
            char offset_text[32];
            char field_name_pretty[128];
            il2cpp_field_modifiers_to_string(field, field_mods, sizeof(field_mods));
            il2cpp_type_to_string(field->type, field_type_name, sizeof(field_type_name));
            il2cpp_pretty_name(field_name, field_name_pretty, sizeof(field_name_pretty));
            il2cpp_field_offset_to_string(field->offset, offset_text, sizeof(offset_text));

            fprintf(out, "    %s%s %s; // %s\n",
                field_mods,
                field_type_name,
                field_name_pretty[0] ? field_name_pretty : field_name,
                offset_text);
            ++field_index;
        }
        (void)field_index;
    }

    if (has_methods_block) {
        methods_cache = (const MethodInfo**)calloc(method_count ? method_count : 1u, sizeof(const MethodInfo*));
        if (methods_cache) {
            while ((method = il2cpp_class_get_methods(klass, &method_iter)) != NULL) {
                if (methods_cache_count >= method_count) {
                    break;
                }
                methods_cache[methods_cache_count++] = method;
            }
        }
    }

    if (methods_cache && methods_cache_count > 0) {
        prop_entries = (Il2CppPropEntry*)calloc(methods_cache_count, sizeof(Il2CppPropEntry));
        event_entries = (Il2CppEventEntry*)calloc(methods_cache_count, sizeof(Il2CppEventEntry));

        if (prop_entries) {
            for (unsigned i = 0; i < methods_cache_count; ++i) {
                const MethodInfo* m = methods_cache[i];
                const char* mname = m && m->name ? m->name : NULL;
                const char* prop_name = NULL;
                int idx = -1;
                if (!mname) {
                    continue;
                }
                if (il2cpp_name_has_prefix(mname, "get_")) {
                    prop_name = mname + 4;
                } else if (il2cpp_name_has_prefix(mname, "set_")) {
                    prop_name = mname + 4;
                } else {
                    continue;
                }
                if (!prop_name[0]) {
                    continue;
                }
                idx = il2cpp_find_prop_index(prop_entries, prop_count, prop_name);
                if (idx < 0) {
                    if (prop_count >= methods_cache_count) {
                        continue;
                    }
                    snprintf(prop_entries[prop_count].name, sizeof(prop_entries[prop_count].name), "%s", prop_name);
                    idx = (int)prop_count;
                    ++prop_count;
                }
                if (il2cpp_name_has_prefix(mname, "get_")) {
                    prop_entries[idx].getter = m;
                } else {
                    prop_entries[idx].setter = m;
                }
            }
        }

        if (event_entries) {
            for (unsigned i = 0; i < methods_cache_count; ++i) {
                const MethodInfo* m = methods_cache[i];
                const char* mname = m && m->name ? m->name : NULL;
                const char* event_name = NULL;
                int idx = -1;
                if (!mname) {
                    continue;
                }
                if (il2cpp_name_has_prefix(mname, "add_")) {
                    event_name = mname + 4;
                } else if (il2cpp_name_has_prefix(mname, "remove_")) {
                    event_name = mname + 7;
                } else {
                    continue;
                }
                if (!event_name[0]) {
                    continue;
                }
                idx = il2cpp_find_event_index(event_entries, event_count, event_name);
                if (idx < 0) {
                    if (event_count >= methods_cache_count) {
                        continue;
                    }
                    snprintf(event_entries[event_count].name, sizeof(event_entries[event_count].name), "%s", event_name);
                    idx = (int)event_count;
                    ++event_count;
                }
                if (il2cpp_name_has_prefix(mname, "add_")) {
                    event_entries[idx].adder = m;
                } else {
                    event_entries[idx].remover = m;
                }
            }
        }
    }

    if (prop_count > 0) {
        if (has_fields_block) {
            fprintf(out, "\n");
        }
        fprintf(out, "    // Properties\n");
        fprintf(out, "    // Properties count: %u\n\n", prop_count);
        for (unsigned i = 0; i < prop_count; ++i) {
            const MethodInfo* g = prop_entries[i].getter;
            const MethodInfo* s = prop_entries[i].setter;
            const MethodInfo* m = g ? g : s;
            char mods[128];
            char type_name[128];
            char prop_name_pretty[128];
            const Il2CppType* ptype = NULL;
            FieldInfo* backing = NULL;
            char backing_name[196];
            char backing_off[32];

            il2cpp_method_modifiers_to_string(m ? m->flags : 0u, mods, sizeof(mods));
            if (g) {
                ptype = (const Il2CppType*)g->return_type;
            } else if (s && s->parameters_count > 0 && s->parameters) {
                ptype = (const Il2CppType*)s->parameters[0];
            }
            il2cpp_type_to_string(ptype, type_name, sizeof(type_name));
            il2cpp_pretty_name(prop_entries[i].name, prop_name_pretty, sizeof(prop_name_pretty));

            fprintf(out, "    %s%s %s { %s%s }\n",
                mods,
                type_name,
                prop_name_pretty[0] ? prop_name_pretty : prop_entries[i].name,
                g ? "get; " : "",
                s ? "set;" : "");

            snprintf(backing_name, sizeof(backing_name), "<%s>k__BackingField", prop_entries[i].name);
            backing = il2cpp_class_get_field_from_name(klass, backing_name);
            if (backing) {
                il2cpp_field_offset_to_string(backing->offset, backing_off, sizeof(backing_off));
                fprintf(out, "    // backing field: %s // %s\n",
                    prop_name_pretty[0] ? prop_name_pretty : prop_entries[i].name,
                    backing_off);
            }
        }
    }

    if (event_count > 0) {
        if (has_fields_block || prop_count > 0) {
            fprintf(out, "\n");
        }
        fprintf(out, "    // Events\n");
        fprintf(out, "    // Events count: %u\n\n", event_count);
        for (unsigned i = 0; i < event_count; ++i) {
            const MethodInfo* a = event_entries[i].adder;
            const MethodInfo* r = event_entries[i].remover;
            const MethodInfo* m = a ? a : r;
            char mods[128];
            char type_name[128];
            char event_name_pretty[128];
            const Il2CppType* etype = NULL;

            il2cpp_method_modifiers_to_string(m ? m->flags : 0u, mods, sizeof(mods));
            if (a && a->parameters_count > 0 && a->parameters) {
                etype = (const Il2CppType*)a->parameters[0];
            } else if (r && r->parameters_count > 0 && r->parameters) {
                etype = (const Il2CppType*)r->parameters[0];
            }
            il2cpp_type_to_string(etype, type_name, sizeof(type_name));
            il2cpp_pretty_name(event_entries[i].name, event_name_pretty, sizeof(event_name_pretty));

            fprintf(out, "    %sevent %s %s;\n",
                mods,
                type_name,
                event_name_pretty[0] ? event_name_pretty : event_entries[i].name);
        }
    }

    if (has_methods_block) {
        if (has_fields_block || prop_count > 0 || event_count > 0) {
            fprintf(out, "\n");
        }
        fprintf(out, "    // Methods\n");
        fprintf(out, "    // Methods count: %u\n\n", method_count);
    }

    if (has_methods_block) {
        unsigned method_index = 0;
        if (methods_cache && methods_cache_count > 0) {
            for (method_index = 0; method_index < methods_cache_count; ++method_index) {
                method = methods_cache[method_index];
                if (!method) {
                    continue;
                }
                {
                    const char* method_name = method->name ? method->name : "<null>";
                    char ret_type_name[128];
                    char method_name_pretty[128];
                    char method_mods[128];
                    uint32_t token = il2cpp_method_token_guess(method);
                    uintptr_t rva = il2cpp_method_rva(method);

                    il2cpp_type_to_string((const Il2CppType*)method->return_type, ret_type_name, sizeof(ret_type_name));
                    il2cpp_pretty_name(method_name, method_name_pretty, sizeof(method_name_pretty));
                    il2cpp_method_modifiers_to_string(method->flags, method_mods, sizeof(method_mods));

                    fprintf(out, "    // Token: 0x%X RVA: 0x%lX\n", token, (unsigned long)rva);
                    fprintf(out, "    %s%s %s(",
                        method_mods,
                        ret_type_name,
                        method_name_pretty[0] ? method_name_pretty : method_name);

                    for (unsigned i = 0; i < (unsigned)method->parameters_count; ++i) {
                        const Il2CppType* ptype = NULL;
                        char param_type_name[128];
                        char param_name_buf[64];
                        char param_default_buf[192];
                        char param_mods[32];
                        const char* param_name = NULL;
                        int has_param_default = 0;
                        if (method->parameters) {
                            ptype = (const Il2CppType*)method->parameters[i];
                        }
                        il2cpp_type_to_string(ptype, param_type_name, sizeof(param_type_name));
                        il2cpp_param_modifiers_to_string(ptype, param_mods, sizeof(param_mods));
                        if (param_mods[0]) {
                            il2cpp_trim_type_byref_suffix(param_type_name);
                        }
                        param_name = il2cpp_method_get_param_name_safe(method, i);
                        if (!param_name || !param_name[0]) {
                            il2cpp_param_fallback_name(i, param_name_buf, sizeof(param_name_buf));
                            param_name = param_name_buf;
                        }
                        if (i != 0) {
                            fprintf(out, ", ");
                        }
                        has_param_default = il2cpp_try_format_param_default_value(method, (int32_t)i, param_default_buf, sizeof(param_default_buf));
                        fprintf(out, "%s%s %s", param_mods, param_type_name, param_name);
                        if (has_param_default) {
                            fprintf(out, " = %s", param_default_buf);
                        } else if (ptype && (il2cpp_type_attrs(ptype) & IL2CPP_PARAM_ATTR_OPTIONAL) != 0) {
                            fprintf(out, " = default");
                        }
                    }
                    fprintf(out, ") { }\n\n");
                }
            }
        } else {
            while ((method = il2cpp_class_get_methods(klass, &method_iter)) != NULL) {
                const char* method_name = method->name ? method->name : "<null>";
                char ret_type_name[128];
                char method_name_pretty[128];
                char method_mods[128];
                uint32_t token = il2cpp_method_token_guess(method);
                uintptr_t rva = il2cpp_method_rva(method);

                il2cpp_type_to_string((const Il2CppType*)method->return_type, ret_type_name, sizeof(ret_type_name));
                il2cpp_pretty_name(method_name, method_name_pretty, sizeof(method_name_pretty));
                il2cpp_method_modifiers_to_string(method->flags, method_mods, sizeof(method_mods));

                fprintf(out, "    // Token: 0x%X RVA: 0x%lX\n", token, (unsigned long)rva);
                fprintf(out, "    %s%s %s(",
                    method_mods,
                    ret_type_name,
                    method_name_pretty[0] ? method_name_pretty : method_name);

                for (unsigned i = 0; i < (unsigned)method->parameters_count; ++i) {
                    const Il2CppType* ptype = NULL;
                    char param_type_name[128];
                    char param_name_buf[64];
                    char param_default_buf[192];
                    char param_mods[32];
                    const char* param_name = NULL;
                    int has_param_default = 0;
                    if (method->parameters) {
                        ptype = (const Il2CppType*)method->parameters[i];
                    }
                    il2cpp_type_to_string(ptype, param_type_name, sizeof(param_type_name));
                    il2cpp_param_modifiers_to_string(ptype, param_mods, sizeof(param_mods));
                    if (param_mods[0]) {
                        il2cpp_trim_type_byref_suffix(param_type_name);
                    }
                    param_name = il2cpp_method_get_param_name_safe(method, i);
                    if (!param_name || !param_name[0]) {
                        il2cpp_param_fallback_name(i, param_name_buf, sizeof(param_name_buf));
                        param_name = param_name_buf;
                    }
                    if (i != 0) {
                        fprintf(out, ", ");
                    }
                    has_param_default = il2cpp_try_format_param_default_value(method, (int32_t)i, param_default_buf, sizeof(param_default_buf));
                    fprintf(out, "%s%s %s", param_mods, param_type_name, param_name);
                    if (has_param_default) {
                        fprintf(out, " = %s", param_default_buf);
                    } else if (ptype && (il2cpp_type_attrs(ptype) & IL2CPP_PARAM_ATTR_OPTIONAL) != 0) {
                        fprintf(out, " = default");
                    }
                }
                fprintf(out, ") { }\n\n");
            }
        }
    }

    if (methods_cache) {
        free(methods_cache);
    }
    if (prop_entries) {
        free(prop_entries);
    }
    if (event_entries) {
        free(event_entries);
    }

    fprintf(out, "}\n\n");
    return 0;
}

typedef struct Il2CppRegistrationView {
    uintptr_t code_registration;
    uintptr_t metadata_registration;
    uint64_t method_pointers_count;
    uintptr_t method_pointers_ptr;
    uint64_t reverse_pinvoke_count;
    uintptr_t reverse_pinvoke_ptr;
    uint64_t generic_method_pointers_count;
    uintptr_t generic_method_pointers_ptr;
    uintptr_t codegen_modules_ptr;
    uint64_t codegen_modules_count;
    uint64_t invoker_pointers_count;
    uintptr_t invoker_pointers_ptr;
    uintptr_t generic_classes_ptr;
    uint64_t generic_classes_count;
    uint64_t generic_insts_count;
    uintptr_t generic_insts_ptr;
    uintptr_t generic_method_table_ptr;
    uint64_t generic_method_table_count;
    uintptr_t types_ptr;
    uint64_t types_count;
    uintptr_t method_specs_ptr;
    uint64_t method_specs_count;
    uintptr_t field_offsets_ptr;
    uint64_t field_offsets_count;
    uint64_t metadata_usages_count;
    uintptr_t metadata_usages_ptr;
} Il2CppRegistrationView;

typedef struct Il2CppTypeInfoVarEntry {
    Il2CppClass* klass;
    uintptr_t slot_ptr;
} Il2CppTypeInfoVarEntry;

typedef struct Il2CppEncodedSlotEntry {
    uint32_t encoded;
    uintptr_t slot_ptr;
} Il2CppEncodedSlotEntry;

static Il2CppTypeInfoVarEntry* _il2cpp_typeinfo_var_map = NULL;
static size_t _il2cpp_typeinfo_var_map_count = 0;
static size_t _il2cpp_typeinfo_var_map_cap = 0;

typedef struct Il2CppMapRange {
    uintptr_t start;
    uintptr_t end;
} Il2CppMapRange;

static Il2CppMapRange _il2cpp_maps[4096];
static size_t _il2cpp_maps_count = 0;
static int _il2cpp_maps_ready = 0;

typedef struct Il2CppRwRange {
    uintptr_t start;
    uintptr_t end;
} Il2CppRwRange;

static inline uint64_t il2cpp_read_u64_at(uintptr_t p) {
    return *(const uint64_t*)p;
}

static inline uint32_t il2cpp_read_u32_at(uintptr_t p) {
    return *(const uint32_t*)p;
}

static inline int il2cpp_addr_likely_readable(uintptr_t p) {
    FILE* fp = NULL;
    char line[256];
    if (!_il2cpp_maps_ready) {
        _il2cpp_maps_count = 0;
        fp = fopen("/proc/self/maps", "r");
        if (fp) {
            while (fgets(line, sizeof(line), fp)) {
                unsigned long long s = 0ull;
                unsigned long long e = 0ull;
                if (sscanf(line, "%llx-%llx", &s, &e) == 2) {
                    if (_il2cpp_maps_count < (sizeof(_il2cpp_maps) / sizeof(_il2cpp_maps[0]))) {
                        _il2cpp_maps[_il2cpp_maps_count].start = (uintptr_t)s;
                        _il2cpp_maps[_il2cpp_maps_count].end = (uintptr_t)e;
                        ++_il2cpp_maps_count;
                    }
                }
            }
            fclose(fp);
        }
        _il2cpp_maps_ready = 1;
    }

    if (p == 0) {
        return 0;
    }
    if (_il2cpp_base != 0) {
        uintptr_t lo = _il2cpp_base - 0x600000000ull;
        uintptr_t hi = _il2cpp_base + 0x600000000ull;
        if (p < lo || p > hi) {
            return 0;
        }
    }

    for (size_t i = 0; i < _il2cpp_maps_count; ++i) {
        if (p >= _il2cpp_maps[i].start && (p + 7u) < _il2cpp_maps[i].end) {
            return 1;
        }
    }
    if (_il2cpp_maps_count == 0) {
        return 1;
    }
    return 0;
}

static inline int il2cpp_ptr_likely_mapped_no_align(uintptr_t p) {
    if (p == 0) {
        return 0;
    }
    if (_il2cpp_base != 0) {
        uintptr_t lo = _il2cpp_base - 0x600000000ull;
        uintptr_t hi = _il2cpp_base + 0x600000000ull;
        if (p < lo || p > hi) {
            return 0;
        }
    }
    if (!il2cpp_addr_likely_readable(p)) {
        return 0;
    }
    return 1;
}

static inline uintptr_t il2cpp_map_region_end(uintptr_t p) {
    size_t i = 0;
    if (p == 0) {
        return 0;
    }
    if (!_il2cpp_maps_ready) {
        (void)il2cpp_addr_likely_readable(p);
    }
    for (i = 0; i < _il2cpp_maps_count; ++i) {
        if (p >= _il2cpp_maps[i].start && p < _il2cpp_maps[i].end) {
            return _il2cpp_maps[i].end;
        }
    }
    return 0;
}

static inline uint64_t il2cpp_read_count_flexible(uintptr_t p) {
    uint64_t v64 = 0;
    uint32_t v32 = 0;
    if (!il2cpp_addr_likely_readable(p)) {
        return 0;
    }
    v64 = il2cpp_read_u64_at(p);
    if (v64 > 0 && v64 < 20000000ull) {
        return v64;
    }
    v32 = il2cpp_read_u32_at(p);
    return (uint64_t)v32;
}

static inline uintptr_t il2cpp_read_ptr_at(uintptr_t p) {
    uintptr_t v = 0;
    if (!il2cpp_addr_likely_readable(p)) {
        return 0;
    }
    v = (uintptr_t)il2cpp_read_u64_at(p);
    if (v != 0 && !il2cpp_ptr_likely_mapped_no_align(v)) {
        return 0;
    }
    return v;
}

static inline int il2cpp_metadata_usage_type(uint32_t encoded);
static inline uint32_t il2cpp_metadata_usage_decoded_index(uint32_t encoded);
static inline int il2cpp_type_ptr_seems_valid(const Il2CppType* t);
static inline int il2cpp_typeinfo_var_map_push(Il2CppClass* klass, uintptr_t slot_ptr);

static inline int il2cpp_metadata_usage_encoded_likely(uint32_t encoded) {
    int t = il2cpp_metadata_usage_type(encoded);
    return t >= 1 && t <= 6;
}

static inline size_t il2cpp_score_metadata_usages_table(uintptr_t table_ptr) {
    size_t score = 0;
    size_t probes = 0;
    size_t encoded_hits = 0;
    size_t i = 0;

    if (!il2cpp_addr_likely_readable(table_ptr)) {
        return 0;
    }

    for (i = 0; i < 128; ++i) {
        uintptr_t entry_addr = table_ptr + i * sizeof(uintptr_t);
        uintptr_t slot_ptr = 0;
        uintptr_t slot_val = 0;
        if (!il2cpp_addr_likely_readable(entry_addr)) {
            break;
        }
        slot_ptr = il2cpp_read_u64_at(entry_addr);
        ++probes;
        if (!slot_ptr || !il2cpp_ptr_likely_mapped_no_align(slot_ptr)) {
            continue;
        }
        if (!il2cpp_addr_likely_readable(slot_ptr)) {
            continue;
        }
        slot_val = il2cpp_read_u64_at(slot_ptr);
        if (slot_val == 0) {
            continue;
        }
        if ((slot_val >> 32) == 0 && il2cpp_metadata_usage_encoded_likely((uint32_t)slot_val)) {
            score += 4;
            ++encoded_hits;
        }
    }

    if (probes < 8) {
        return 0;
    }
    if (encoded_hits < 6) {
        return 0;
    }
    return score;
}

static inline uint64_t il2cpp_compute_metadata_usages_count(uintptr_t table_ptr) {
    uintptr_t end = 0;
    uint64_t limit = 0;
    uint64_t i = 0;
    uint64_t max_index = 0;
    int have_any = 0;

    if (!table_ptr) {
        return 0;
    }
    end = il2cpp_map_region_end(table_ptr);
    if (end <= table_ptr) {
        return 0;
    }
    limit = (uint64_t)((end - table_ptr) / sizeof(uintptr_t));
    if (limit > 2000000ull) {
        limit = 2000000ull;
    }

    for (i = 0; i < limit; ++i) {
        uintptr_t entry_addr = table_ptr + (uintptr_t)i * sizeof(uintptr_t);
        uintptr_t slot_ptr = 0;
        uintptr_t slot_val = 0;
        if (!il2cpp_addr_likely_readable(entry_addr)) {
            break;
        }
        slot_ptr = il2cpp_read_u64_at(entry_addr);
        if (!slot_ptr || !il2cpp_ptr_likely_mapped_no_align(slot_ptr) || !il2cpp_addr_likely_readable(slot_ptr)) {
            if (have_any && i > max_index + 8192ull) {
                break;
            }
            continue;
        }
        slot_val = il2cpp_read_u64_at(slot_ptr);
        if (slot_val == 0 || ((slot_val >> 32) == 0 && il2cpp_metadata_usage_encoded_likely((uint32_t)slot_val))) {
            have_any = 1;
            max_index = i;
        }
    }

    if (!have_any) {
        return 0;
    }
    return max_index + 1ull;
}

static inline uintptr_t il2cpp_find_metadata_usages_ptr(uintptr_t metadata_registration) {
    uintptr_t best_ptr = 0;
    size_t best_score = 0;
    uintptr_t off = 0;

    if (!metadata_registration) {
        return 0;
    }

    for (off = 0x50; off <= 0xB0; off += sizeof(uintptr_t)) {
        uintptr_t candidate_addr = metadata_registration + off;
        uintptr_t candidate_ptr = 0;
        size_t score = 0;
        if (!il2cpp_addr_likely_readable(candidate_addr)) {
            continue;
        }
        candidate_ptr = il2cpp_read_u64_at(candidate_addr);
        if (!candidate_ptr || !il2cpp_ptr_likely_mapped_no_align(candidate_ptr)) {
            continue;
        }
        score = il2cpp_score_metadata_usages_table(candidate_ptr);
        if (score > best_score) {
            best_score = score;
            best_ptr = candidate_ptr;
        }
    }

    if (best_score < 24) {
        return 0;
    }
    return best_ptr;
}

static inline int il2cpp_typeinfo_var_map_push(Il2CppClass* klass, uintptr_t slot_ptr) {
    size_t i = 0;
    Il2CppTypeInfoVarEntry* next = NULL;

    if (!klass || slot_ptr == 0) {
        return 0;
    }
    for (i = 0; i < _il2cpp_typeinfo_var_map_count; ++i) {
        if (_il2cpp_typeinfo_var_map[i].klass == klass) {
            return 1;
        }
    }

    if (_il2cpp_typeinfo_var_map_count >= _il2cpp_typeinfo_var_map_cap) {
        size_t new_cap = _il2cpp_typeinfo_var_map_cap ? _il2cpp_typeinfo_var_map_cap * 2u : 4096u;
        next = (Il2CppTypeInfoVarEntry*)realloc(_il2cpp_typeinfo_var_map, new_cap * sizeof(Il2CppTypeInfoVarEntry));
        if (!next) {
            return 0;
        }
        _il2cpp_typeinfo_var_map = next;
        _il2cpp_typeinfo_var_map_cap = new_cap;
    }

    _il2cpp_typeinfo_var_map[_il2cpp_typeinfo_var_map_count].klass = klass;
    _il2cpp_typeinfo_var_map[_il2cpp_typeinfo_var_map_count].slot_ptr = slot_ptr;
    ++_il2cpp_typeinfo_var_map_count;
    return 1;
}

static inline uintptr_t il2cpp_typeinfo_var_lookup(Il2CppClass* klass) {
    size_t i = 0;
    if (!klass || !_il2cpp_typeinfo_var_map) {
        return 0;
    }
    for (i = 0; i < _il2cpp_typeinfo_var_map_count; ++i) {
        if (_il2cpp_typeinfo_var_map[i].klass == klass) {
            return _il2cpp_typeinfo_var_map[i].slot_ptr;
        }
    }
    return 0;
}

static inline int il2cpp_metadata_usage_type(uint32_t encoded) {
    return (int)((encoded & 0xE0000000u) >> 29);
}

static inline uint32_t il2cpp_metadata_usage_decoded_index(uint32_t encoded) {
    return (encoded & 0x1FFFFFFEu) >> 1;
}

static inline int il2cpp_type_ptr_seems_valid(const Il2CppType* t) {
    uint8_t tc = 0;
    if (!il2cpp_ptr_likely_mapped_no_align((uintptr_t)t)) {
        return 0;
    }
    tc = t->type;
    if (tc > 0x40u) {
        return 0;
    }
    return 1;
}

static int il2cpp_encoded_slot_cmp(const void* a, const void* b) {
    const Il2CppEncodedSlotEntry* aa = (const Il2CppEncodedSlotEntry*)a;
    const Il2CppEncodedSlotEntry* bb = (const Il2CppEncodedSlotEntry*)b;
    if (aa->encoded < bb->encoded) {
        return -1;
    }
    if (aa->encoded > bb->encoded) {
        return 1;
    }
    if (aa->slot_ptr < bb->slot_ptr) {
        return -1;
    }
    if (aa->slot_ptr > bb->slot_ptr) {
        return 1;
    }
    return 0;
}

static inline uintptr_t il2cpp_find_slot_for_encoded(const Il2CppEncodedSlotEntry* arr, size_t n, uint32_t encoded) {
    size_t lo = 0;
    size_t hi = n;
    while (lo < hi) {
        size_t mid = lo + ((hi - lo) >> 1);
        uint32_t x = arr[mid].encoded;
        if (x == encoded) {
            return arr[mid].slot_ptr;
        }
        if (x < encoded) {
            lo = mid + 1;
        } else {
            hi = mid;
        }
    }
    return 0;
}

static inline int il2cpp_collect_typeinfo_encoded_slots(const Il2CppRegistrationView* v, Il2CppEncodedSlotEntry** out, size_t* out_count) {
    uintptr_t usage_region_end = 0;
    uint64_t limit = 0;
    uint64_t i = 0;
    size_t probe_ok = 0;
    size_t probe_total = 0;
    Il2CppEncodedSlotEntry* arr = NULL;
    size_t cap = 0;
    size_t count = 0;

    if (!out || !out_count || !v || !v->metadata_usages_ptr) {
        return 0;
    }
    *out = NULL;
    *out_count = 0;

    /*
     * Safety: on some 0.37.1 builds metadataUsages does not point to a
     * canonical void** const* table layout. Probe first entries and abort if
     * they are not pointer-like to avoid invalid pointer chains.
     */
    for (i = 0; i < 16; ++i) {
        uintptr_t entry_addr = v->metadata_usages_ptr + (uintptr_t)(i * sizeof(uintptr_t));
        uintptr_t entry_val = 0;
        if (!il2cpp_addr_likely_readable(entry_addr)) {
            break;
        }
        entry_val = il2cpp_read_u64_at(entry_addr);
        ++probe_total;
        if (entry_val && il2cpp_ptr_likely_mapped_no_align(entry_val)) {
            ++probe_ok;
        }
    }
    if (probe_total == 0 || probe_ok < 2) {
        return 0;
    }

    if (v->metadata_usages_count > 0 && v->metadata_usages_count <= 2000000ull) {
        limit = v->metadata_usages_count;
    } else {
        usage_region_end = il2cpp_map_region_end(v->metadata_usages_ptr);
        if (usage_region_end <= v->metadata_usages_ptr) {
            return 0;
        }
        limit = (uint64_t)((usage_region_end - v->metadata_usages_ptr) / sizeof(uintptr_t));
        if (limit > 600000ull) {
            limit = 600000ull;
        }
    }

    for (i = 0; i < limit; ++i) {
        uintptr_t usage_entry_ptr_addr = v->metadata_usages_ptr + (uintptr_t)(i * sizeof(uintptr_t));
        uintptr_t slot_ptr = 0;
        uintptr_t slot_val = 0;
        uint32_t encoded = 0;
        int usage_type = 0;

        if (!il2cpp_addr_likely_readable(usage_entry_ptr_addr)) {
            break;
        }
        slot_ptr = il2cpp_read_ptr_at(usage_entry_ptr_addr);
        if (!il2cpp_addr_likely_readable(slot_ptr)) {
            continue;
        }
        slot_val = il2cpp_read_ptr_at(slot_ptr);
        if (slot_val == 0 || (slot_val >> 32) != 0) {
            continue;
        }

        encoded = (uint32_t)slot_val;
        usage_type = il2cpp_metadata_usage_type(encoded);
        if (usage_type != 1) {
            continue;
        }

        if (count >= cap) {
            size_t new_cap = cap ? cap * 2u : 8192u;
            Il2CppEncodedSlotEntry* next = (Il2CppEncodedSlotEntry*)realloc(arr, new_cap * sizeof(Il2CppEncodedSlotEntry));
            if (!next) {
                free(arr);
                return 0;
            }
            arr = next;
            cap = new_cap;
        }
        arr[count].encoded = encoded;
        arr[count].slot_ptr = slot_ptr;
        ++count;
    }

    if (count == 0) {
        free(arr);
        return 0;
    }

    qsort(arr, count, sizeof(Il2CppEncodedSlotEntry), il2cpp_encoded_slot_cmp);
    {
        size_t w = 1;
        for (size_t k = 1; k < count; ++k) {
            if (arr[k].encoded != arr[w - 1].encoded) {
                arr[w++] = arr[k];
            }
        }
        count = w;
    }

    *out = arr;
    *out_count = count;
    return 1;
}

static int il2cpp_u64_cmp(const void* a, const void* b) {
    uint64_t av = *(const uint64_t*)a;
    uint64_t bv = *(const uint64_t*)b;
    if (av < bv) {
        return -1;
    }
    if (av > bv) {
        return 1;
    }
    return 0;
}

static inline int il2cpp_u64_contains(const uint64_t* arr, size_t n, uint64_t v) {
    size_t lo = 0;
    size_t hi = n;
    while (lo < hi) {
        size_t mid = lo + ((hi - lo) >> 1);
        uint64_t x = arr[mid];
        if (x == v) {
            return 1;
        }
        if (x < v) {
            lo = mid + 1;
        } else {
            hi = mid;
        }
    }
    return 0;
}

static inline size_t il2cpp_collect_data_ranges_for_module(const char* module_name, Il2CppRwRange* out, size_t cap) {
    FILE* fp = NULL;
    char line[512];
    size_t count = 0;
    if (!module_name || !out || cap == 0) {
        return 0;
    }
    fp = fopen("/proc/self/maps", "r");
    if (!fp) {
        return 0;
    }
    while (fgets(line, sizeof(line), fp)) {
        unsigned long long s = 0ull;
        unsigned long long e = 0ull;
        char perms[8];
        if (!strstr(line, module_name)) {
            continue;
        }
        if (sscanf(line, "%llx-%llx %7s", &s, &e, perms) != 3) {
            continue;
        }
        /* include both rw- (data/.bss) and r-- (RELRO/data.rel.ro), exclude executable */
        if (perms[0] != 'r' || perms[2] == 'x') {
            continue;
        }
        if (count < cap) {
            out[count].start = (uintptr_t)s;
            out[count].end = (uintptr_t)e;
            ++count;
        }
    }
    fclose(fp);
    return count;
}

static inline int il2cpp_collect_all_class_ptrs(const Il2CppAssembly** assemblies, size_t assembly_count, uint64_t** out_ptrs, size_t* out_count) {
    uint64_t* arr = NULL;
    size_t cap = 0;
    size_t count = 0;
    size_t i = 0;

    if (!assemblies || !out_ptrs || !out_count) {
        return 0;
    }
    *out_ptrs = NULL;
    *out_count = 0;

    for (i = 0; i < assembly_count; ++i) {
        const Il2CppImage* image = il2cpp_assembly_get_image(assemblies[i]);
        size_t class_count = 0;
        size_t j = 0;
        if (!image) {
            continue;
        }
        class_count = il2cpp_image_get_class_count(image);
        if (class_count == 0) {
            class_count = (size_t)il2cpp_image_get_type_count_internal(image) +
                          (size_t)il2cpp_image_get_exported_type_count_internal(image);
        }
        for (j = 0; j < class_count; ++j) {
            Il2CppClass* klass = NULL;
            if (_il2cpp_api[IL2CPP_API_IMAGE_GET_CLASS]) {
                klass = il2cpp_image_get_class(image, j);
            } else {
                klass = il2cpp_image_get_class_internal(image, j);
            }
            if (!klass) {
                continue;
            }
            if (count >= cap) {
                size_t new_cap = cap ? cap * 2u : 16384u;
                uint64_t* next = (uint64_t*)realloc(arr, new_cap * sizeof(uint64_t));
                if (!next) {
                    free(arr);
                    return 0;
                }
                arr = next;
                cap = new_cap;
            }
            arr[count++] = (uint64_t)(uintptr_t)klass;
        }
    }

    if (count == 0) {
        free(arr);
        return 0;
    }

    qsort(arr, count, sizeof(uint64_t), il2cpp_u64_cmp);
    {
        size_t w = 1;
        for (i = 1; i < count; ++i) {
            if (arr[i] != arr[w - 1]) {
                arr[w++] = arr[i];
            }
        }
        count = w;
    }

    *out_ptrs = arr;
    *out_count = count;
    return 1;
}

static inline void il2cpp_build_typeinfo_var_map_from_rw_segments(const Il2CppAssembly** assemblies, size_t assembly_count) {
    uint64_t* class_ptrs = NULL;
    size_t class_count = 0;
    Il2CppRwRange ranges[128];
    size_t rc = 0;
    size_t r = 0;

    _il2cpp_typeinfo_var_map_count = 0;
    if (!il2cpp_collect_all_class_ptrs(assemblies, assembly_count, &class_ptrs, &class_count)) {
        return;
    }

    rc = il2cpp_collect_data_ranges_for_module("libunity.so", ranges, sizeof(ranges) / sizeof(ranges[0]));
    for (r = 0; r < rc; ++r) {
        uintptr_t p = ranges[r].start;
        uintptr_t e = ranges[r].end;
        while (p + sizeof(uintptr_t) <= e) {
            uintptr_t val = *(const uintptr_t*)p;
            if (val != 0 && il2cpp_u64_contains(class_ptrs, class_count, (uint64_t)val)) {
                il2cpp_typeinfo_var_map_push((Il2CppClass*)val, p);
            }
            p += sizeof(uintptr_t);
        }
    }
    free(class_ptrs);
}

static inline void il2cpp_build_typeinfo_var_map(const Il2CppRegistrationView* v) {
    Il2CppEncodedSlotEntry* slots = NULL;
    size_t slots_count = 0;
    size_t i = 0;

    if (!v || !v->metadata_usages_ptr || !v->types_ptr || v->types_count == 0 || v->types_count > 200000) {
        return;
    }
    if (!_il2cpp_api[IL2CPP_API_CLASS_FROM_TYPE]) {
        return;
    }
    _il2cpp_typeinfo_var_map_count = 0;
    if (il2cpp_score_metadata_usages_table(v->metadata_usages_ptr) == 0) {
        return;
    }
    if (!il2cpp_collect_typeinfo_encoded_slots(v, &slots, &slots_count)) {
        return;
    }

    for (i = 0; i < slots_count; ++i) {
        uint32_t type_index = il2cpp_metadata_usage_decoded_index(slots[i].encoded);
        uintptr_t type_addr = 0;
        const Il2CppType* t = NULL;
        Il2CppClass* k = NULL;

        if (type_index >= v->types_count) {
            continue;
        }

        type_addr = v->types_ptr + (uintptr_t)type_index * sizeof(uintptr_t);
        if (!il2cpp_addr_likely_readable(type_addr)) {
            continue;
        }

        t = (const Il2CppType*)il2cpp_read_ptr_at(type_addr);
        if (!il2cpp_type_ptr_seems_valid(t)) {
            continue;
        }

        k = il2cpp_class_from_type(t);
        if (!il2cpp_ptr_likely_valid((uintptr_t)k)) {
            continue;
        }
        il2cpp_typeinfo_var_map_push(k, slots[i].slot_ptr);
    }
    free(slots);
}

static inline void il2cpp_parse_registration_view(Il2CppRegistrationView* v) {
    uintptr_t cr = 0;
    uintptr_t mr = 0;

    if (!v) {
        return;
    }
    memset(v, 0, sizeof(*v));
    if (!_il2cpp_base) {
        return;
    }

    cr = _il2cpp_base + (uintptr_t)IL2CPP_CODE_REGISTRATION;
    mr = _il2cpp_base + (uintptr_t)IL2CPP_METADATA_REGISTRATION;
    if (!il2cpp_ptr_likely_valid(cr) || !il2cpp_ptr_likely_valid(mr)) {
        return;
    }

    v->code_registration = cr;
    v->metadata_registration = mr;

    /* 0.37.1 runtime layout (validated at runtime after relocations) */
    v->method_pointers_count = il2cpp_read_count_flexible(cr + 0x00);
    v->method_pointers_ptr = il2cpp_read_ptr_at(cr + 0x18);
    v->reverse_pinvoke_count = il2cpp_read_count_flexible(cr + 0x28);
    v->reverse_pinvoke_ptr = il2cpp_read_ptr_at(cr + 0x30);
    v->generic_method_pointers_count = il2cpp_read_count_flexible(cr + 0x48);
    v->generic_method_pointers_ptr = il2cpp_read_ptr_at(cr + 0x50);
    v->codegen_modules_ptr = il2cpp_read_ptr_at(cr + 0x60);
    v->codegen_modules_count = il2cpp_read_count_flexible(cr + 0x70);
    v->invoker_pointers_count = il2cpp_read_count_flexible(cr + 0x70);
    v->invoker_pointers_ptr = il2cpp_read_ptr_at(cr + 0x78);

    v->generic_classes_ptr = il2cpp_read_ptr_at(mr + 0x00);
    v->generic_classes_count = il2cpp_read_count_flexible(mr + 0x0C);
    v->generic_insts_count = il2cpp_read_count_flexible(mr + 0x08);
    v->generic_insts_ptr = il2cpp_read_ptr_at(mr + 0x10);
    v->generic_method_table_ptr = il2cpp_read_ptr_at(mr + 0x18);
    v->generic_method_table_count = il2cpp_read_count_flexible(mr + 0x60);
    v->types_ptr = il2cpp_read_ptr_at(mr + 0x20);
    v->types_count = il2cpp_read_count_flexible(mr + 0x30);
    v->method_specs_ptr = il2cpp_read_ptr_at(mr + 0x28);
    v->method_specs_count = il2cpp_read_count_flexible(mr + 0x40);
    v->field_offsets_ptr = il2cpp_read_ptr_at(mr + 0x48);
    v->field_offsets_count = il2cpp_read_count_flexible(mr + 0x50);
    /* metadataUsagesCount is computed at runtime from the usages table itself. */
    v->metadata_usages_count = 0;
    v->metadata_usages_ptr = il2cpp_read_ptr_at(mr + 0x68);
    if (v->metadata_usages_ptr) {
        v->metadata_usages_count = il2cpp_compute_metadata_usages_count(v->metadata_usages_ptr);
    }
}

static inline unsigned long long il2cpp_ptr_as_rva_or_abs(uintptr_t p) {
    if (_il2cpp_base && p >= _il2cpp_base) {
        return (unsigned long long)(p - _il2cpp_base);
    }
    return (unsigned long long)p;
}

static inline void il2cpp_dump_registration_view(FILE* out) {
    Il2CppRegistrationView v;
    if (!out) {
        return;
    }
    il2cpp_parse_registration_view(&v);
    if (!v.code_registration || !v.metadata_registration) {
        fprintf(out, "// Registration: unavailable\n\n");
        return;
    }

    fprintf(out, "// Registration\n");
    fprintf(out, "// CodeRegistration RVA: 0x%X\n", IL2CPP_CODE_REGISTRATION);
    fprintf(out, "// MetadataRegistration RVA: 0x%X\n", IL2CPP_METADATA_REGISTRATION);
    fprintf(out, "// methodPointers: count=%llu ptr=0x%llX\n",
        (unsigned long long)v.method_pointers_count,
        il2cpp_ptr_as_rva_or_abs(v.method_pointers_ptr));
    fprintf(out, "// reversePInvokeWrappers: count=%llu ptr=0x%llX\n",
        (unsigned long long)v.reverse_pinvoke_count,
        il2cpp_ptr_as_rva_or_abs(v.reverse_pinvoke_ptr));
    fprintf(out, "// genericMethodPointers: count=%llu ptr=0x%llX\n",
        (unsigned long long)v.generic_method_pointers_count,
        il2cpp_ptr_as_rva_or_abs(v.generic_method_pointers_ptr));
    fprintf(out, "// codeGenModules: ptr=0x%llX count=%llu\n",
        il2cpp_ptr_as_rva_or_abs(v.codegen_modules_ptr),
        (unsigned long long)v.codegen_modules_count);
    fprintf(out, "// invokerPointers: count=%llu ptr=0x%llX\n",
        (unsigned long long)v.invoker_pointers_count,
        il2cpp_ptr_as_rva_or_abs(v.invoker_pointers_ptr));
    fprintf(out, "// genericClasses: ptr=0x%llX count=%llu\n",
        il2cpp_ptr_as_rva_or_abs(v.generic_classes_ptr),
        (unsigned long long)v.generic_classes_count);
    fprintf(out, "// genericInsts: count=%llu ptr=0x%llX\n",
        (unsigned long long)v.generic_insts_count,
        il2cpp_ptr_as_rva_or_abs(v.generic_insts_ptr));
    fprintf(out, "// genericMethodTable: ptr=0x%llX count=%llu\n",
        il2cpp_ptr_as_rva_or_abs(v.generic_method_table_ptr),
        (unsigned long long)v.generic_method_table_count);
    fprintf(out, "// types: ptr=0x%llX count=%llu\n",
        il2cpp_ptr_as_rva_or_abs(v.types_ptr),
        (unsigned long long)v.types_count);
    fprintf(out, "// methodSpecs: ptr=0x%llX count=%llu\n",
        il2cpp_ptr_as_rva_or_abs(v.method_specs_ptr),
        (unsigned long long)v.method_specs_count);
    fprintf(out, "// fieldOffsets: ptr=0x%llX count=%llu\n",
        il2cpp_ptr_as_rva_or_abs(v.field_offsets_ptr),
        (unsigned long long)v.field_offsets_count);
    if (v.metadata_usages_count) {
        fprintf(out, "// metadataUsages: count=%llu ptr=0x%llX\n\n",
            (unsigned long long)v.metadata_usages_count,
            il2cpp_ptr_as_rva_or_abs(v.metadata_usages_ptr));
    } else {
        fprintf(out, "// metadataUsages: count=unknown ptr=0x%llX\n\n",
            il2cpp_ptr_as_rva_or_abs(v.metadata_usages_ptr));
    }
}

static inline int il2cpp_dump_all(FILE* out) {
    Il2CppDomain* root_domain = NULL;
    Il2CppThread* attached_thread = NULL;
    const Il2CppAssembly** assemblies = NULL;
    Il2CppRegistrationView v;
    size_t assembly_count = 0;
    int err = IL2CPP_DUMP_OK;

    if (!out) {
        return -1;
    }

    if (!_il2cpp_api[IL2CPP_API_DOMAIN_GET_ASSEMBLIES]) {
        if (!_il2cpp_api[IL2CPP_API_DOMAIN_GET]) {
            err |= IL2CPP_DUMP_MISSING_DOMAIN_GET_ASSEMBLIES;
        }
    }
    if (!_il2cpp_api[IL2CPP_API_IMAGE_GET_CLASS_COUNT]) {
        err |= IL2CPP_DUMP_MISSING_IMAGE_GET_CLASS_COUNT;
    }
    if (!_il2cpp_api[IL2CPP_API_IMAGE_GET_CLASS] &&
        (!_il2cpp_api[IL2CPP_API_METADATA_IMAGE_GET_TYPE] ||
         !_il2cpp_api[IL2CPP_API_METADATA_IMAGE_GET_EXPORTED_TYPE] ||
         !_il2cpp_api[IL2CPP_API_METADATA_TYPE_TO_CLASS])) {
        err |= IL2CPP_DUMP_MISSING_IMAGE_GET_CLASS;
    }
    if (!_il2cpp_api[IL2CPP_API_CLASS_GET_FIELDS]) {
        err |= IL2CPP_DUMP_MISSING_CLASS_GET_FIELDS;
    }
    if (!_il2cpp_api[IL2CPP_API_CLASS_GET_METHODS]) {
        err |= IL2CPP_DUMP_MISSING_CLASS_GET_METHODS;
    }
    if (err != IL2CPP_DUMP_OK) {
        return err;
    }

    root_domain = il2cpp_domain_get_root();
    if (!root_domain) {
        return -2;
    }
    if (_il2cpp_api[IL2CPP_API_THREAD_ATTACH]) {
        attached_thread = il2cpp_thread_attach(root_domain);
        (void)attached_thread;
    }

    if (_il2cpp_api[IL2CPP_API_DOMAIN_GET_ASSEMBLIES]) {
        assemblies = il2cpp_domain_get_assemblies(root_domain, &assembly_count);
    } else {
        assemblies = il2cpp_domain_get_assemblies_internal(root_domain, &assembly_count);
    }
    if (!assemblies || assembly_count == 0) {
        return -3;
    }

    il2cpp_dump_registration_view(out);
    memset(&v, 0, sizeof(v));
    il2cpp_parse_registration_view(&v);
    il2cpp_build_typeinfo_var_map(&v);

    fprintf(out, "// Assemly count: %zu\n", assembly_count);

    for (size_t i = 0; i < assembly_count; ++i) {
        const Il2CppImage* image = il2cpp_assembly_get_image(assemblies[i]);
        size_t class_count = 0;
        if (!image) {
            continue;
        }

        class_count = il2cpp_image_get_class_count(image);
        if (class_count == 0) {
            class_count = (size_t)il2cpp_image_get_type_count_internal(image) +
                          (size_t)il2cpp_image_get_exported_type_count_internal(image);
        }

        fprintf(out, "// Assemly %zu: %s, %zu\n", i + 1, il2cpp_image_name_internal(image), class_count);
    }

    fprintf(out, "\n");

    for (size_t i = 0; i < assembly_count; ++i) {
        const Il2CppImage* image = il2cpp_assembly_get_image(assemblies[i]);
        size_t class_count = 0;
        if (!image) {
            continue;
        }

        class_count = il2cpp_image_get_class_count(image);
        if (class_count == 0) {
            class_count = (size_t)il2cpp_image_get_type_count_internal(image) +
                          (size_t)il2cpp_image_get_exported_type_count_internal(image);
        }

        fprintf(out, "// %s\n\n", il2cpp_image_name_internal(image));

        for (size_t j = 0; j < class_count; ++j) {
            Il2CppClass* klass = NULL;
            if (_il2cpp_api[IL2CPP_API_IMAGE_GET_CLASS]) {
                klass = il2cpp_image_get_class(image, j);
            } else {
                klass = il2cpp_image_get_class_internal(image, j);
            }
            if (!klass) {
                continue;
            }
            il2cpp_dump_class(out, klass);
        }
    }

    return IL2CPP_DUMP_OK;
}

Il2CppUtils il2cpp;

Il2CppUtils::Il2CppUtils(uintptr_t base_addr) : il2cpp_base(base_addr) {
    init_api();
}

void Il2CppUtils::init_api() {
    if (il2cpp_base == 0) return;
    ::il2cpp_init_api(il2cpp_base);
}

Il2CppString* Il2CppUtils::string_new(const char* text) {
    if (il2cpp_base == 0 || text == nullptr) return nullptr;
    return ::il2cpp_string_new(text);
}

Il2CppArray* Il2CppUtils::create_array(Il2CppClass* element_class, std::size_t size) {
    if (!element_class || size == 0) return nullptr;
    return ::il2cpp_array_new(element_class, size);
}

void* Il2CppUtils::resolve_icall(void* method) { return ::il2cpp_resolve_icall(method); }
void* Il2CppUtils::resolve_icall_unity(const char* name) { return ::il2cpp_resolve_icall_unity((void*)name); }

Il2CppClass* Il2CppUtils::get_class_from_assembly(const char* assembly, const char* namespaze, const char* clazz) {
    Il2CppDomain* domain = ::il2cpp_domain_get();
    const Il2CppAssembly* asm_ref = ::il2cpp_domain_assembly_open(domain, assembly);
    const Il2CppImage* image = ::il2cpp_assembly_get_image(asm_ref);
    return ::il2cpp_class_from_name(image, namespaze, clazz);
}

Il2CppClass* Il2CppUtils::get_class_from_address(uintptr_t type_info_addr) {
    auto** pp_class = reinterpret_cast<Il2CppClass**>(type_info_addr);
    return pp_class ? *pp_class : nullptr;
}

Il2CppClass* Il2CppUtils::get_class_from_rva(uint32_t type_info_rva) {
    return get_class_from_address(il2cpp_base + type_info_rva);
}

MethodInfo* Il2CppUtils::get_method_by_index(Il2CppClass* klass, uint16_t index) {
    if (!klass) return nullptr;

    if (_il2cpp_api[IL2CPP_API_CLASS_GET_METHODS]) {
        void* iter = nullptr;
        uint16_t i = 0;
        while (const MethodInfo* method = ::il2cpp_class_get_methods(klass, &iter)) {
            if (i == index) {
                return const_cast<MethodInfo*>(method);
            }
            ++i;
        }
        return nullptr;
    }

    if (!klass->_1.methods || index >= klass->_2.method_count) return nullptr;
    auto methods = reinterpret_cast<const MethodInfo* const*>(klass->_1.methods);
    return methods ? const_cast<MethodInfo*>(methods[index]) : nullptr;
}

MethodInfo* Il2CppUtils::get_method_by_name(Il2CppClass* klass, const char* name) {
    if (!klass || !klass->_1.methods || !name) return nullptr;
    auto methods = reinterpret_cast<const MethodInfo* const*>(klass->_1.methods);
    if (!methods) return nullptr;
    for (uint16_t i = 0; i < klass->_2.method_count; i++) {
        MethodInfo* method = const_cast<MethodInfo*>(methods[i]);
        if (method && method->name && std::strcmp(method->name, name) == 0) return method;
    }
    return nullptr;
}

MethodInfo* Il2CppUtils::get_method_by_rva(Il2CppClass* klass, uint32_t rva) {
    if (!klass || !klass->_1.methods) return nullptr;
    return get_method_by_address(klass, il2cpp_base + rva);
}

MethodInfo* Il2CppUtils::get_method_by_address(Il2CppClass* klass, uintptr_t address) {
    if (!klass || !klass->_1.methods) return nullptr;
    auto methods = reinterpret_cast<const MethodInfo* const*>(klass->_1.methods);
    if (!methods) return nullptr;
    for (uint16_t i = 0; i < klass->_2.method_count; i++) {
        MethodInfo* method = const_cast<MethodInfo*>(methods[i]);
        if (!method) continue;
        if ((uintptr_t)method->methodPointer == address || (uintptr_t)method->virtualMethodPointer == address) return method;
    }
    return nullptr;
}

MethodInfo* Il2CppUtils::get_method_recursive_by_name(Il2CppClass* klass, const char* name, int param_count) {
    while (klass) {
        auto methods = reinterpret_cast<const MethodInfo* const*>(klass->_1.methods);
        if (methods) {
            for (uint16_t i = 0; i < klass->_2.method_count; i++) {
                MethodInfo* method = const_cast<MethodInfo*>(methods[i]);
                if (method && method->name && std::strcmp(method->name, name) == 0) {
                    if (param_count < 0 || method->parameters_count == param_count) return method;
                }
            }
        }
        klass = klass->_1.parent;
    }
    return nullptr;
}

MethodInfo* Il2CppUtils::get_method_recursive_by_address(Il2CppClass* klass, uintptr_t address) {
    while (klass) {
        MethodInfo* method = get_method_by_address(klass, address);
        if (method) return method;
        klass = klass->_1.parent;
    }
    return nullptr;
}

MethodInfo* Il2CppUtils::get_method_recursive_by_rva(Il2CppClass* klass, uint32_t rva) {
    return get_method_recursive_by_address(klass, il2cpp_base + rva);
}

MethodInfo** Il2CppUtils::get_methods_array(Il2CppClass* klass) {
    if (!klass || !klass->_1.methods) return nullptr;
    return const_cast<MethodInfo**>(reinterpret_cast<const MethodInfo* const*>(klass->_1.methods));
}

uint16_t Il2CppUtils::get_method_count(Il2CppClass* klass) { return klass ? klass->_2.method_count : 0; }
const char* Il2CppUtils::get_class_name(Il2CppClass* klass) { return klass ? klass->_1.name : nullptr; }
const char* Il2CppUtils::get_class_namespace(Il2CppClass* klass) {
    if (!klass) return nullptr;
    const char* ns = ::il2cpp_class_get_namespace(klass);
    return ns ? ns : klass->_1.namespaze;
}

const Il2CppAssembly** Il2CppUtils::get_assemblies(std::size_t* size) {
    Il2CppDomain* domain = ::il2cpp_domain_get();
    const Il2CppAssembly** assemblies = ::il2cpp_domain_get_assemblies(domain, size);
    if (assemblies) return assemblies;
    return ::il2cpp_domain_get_assemblies_internal(domain, size);
}

std::size_t Il2CppUtils::get_image_class_count(const Il2CppImage* image) {
    std::size_t count = ::il2cpp_image_get_class_count(image);
    if (count != 0) return count;
    return static_cast<std::size_t>(::il2cpp_image_get_type_count_internal(image)) +
           static_cast<std::size_t>(::il2cpp_image_get_exported_type_count_internal(image));
}

Il2CppClass* Il2CppUtils::get_image_class(const Il2CppImage* image, std::size_t index) {
    Il2CppClass* klass = ::il2cpp_image_get_class(image, index);
    if (klass) return klass;
    return ::il2cpp_image_get_class_internal(image, index);
}

int Il2CppUtils::dump_all(FILE* out) { return ::il2cpp_dump_all(out); }
int Il2CppUtils::dump_class(FILE* out, Il2CppClass* klass) { return ::il2cpp_dump_class(out, klass); }
void Il2CppUtils::dump_registration_view(FILE* out) { ::il2cpp_dump_registration_view(out); }
