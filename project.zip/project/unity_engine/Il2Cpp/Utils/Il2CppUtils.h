#pragma once

#include <cstddef>
#include <cstdint>
#include <cstdio>

#include "../Il2Cpp.h"

class Il2CppUtils {
public:
    uintptr_t il2cpp_base;

    explicit Il2CppUtils(uintptr_t base_addr = 0);

    void init_api();
    Il2CppString* string_new(const char* text);
    Il2CppArray* create_array(Il2CppClass* element_class, std::size_t size);

    void* resolve_icall(void* method);
    void* resolve_icall_unity(const char* name);

    Il2CppClass* get_class_from_assembly(const char* assembly, const char* namespaze, const char* clazz);
    Il2CppClass* get_class_from_address(uintptr_t type_info_addr);
    Il2CppClass* get_class_from_rva(uint32_t type_info_rva);

    MethodInfo* get_method_by_index(Il2CppClass* klass, uint16_t index);
    MethodInfo* get_method_by_name(Il2CppClass* klass, const char* name);
    MethodInfo* get_method_by_rva(Il2CppClass* klass, uint32_t rva);
    MethodInfo* get_method_by_address(Il2CppClass* klass, uintptr_t address);

    MethodInfo* get_method_recursive_by_name(Il2CppClass* klass, const char* name, int param_count = -1);
    MethodInfo* get_method_recursive_by_address(Il2CppClass* klass, uintptr_t address);
    MethodInfo* get_method_recursive_by_rva(Il2CppClass* klass, uint32_t rva);

    MethodInfo** get_methods_array(Il2CppClass* klass);
    uint16_t get_method_count(Il2CppClass* klass);
    const char* get_class_name(Il2CppClass* klass);
    const char* get_class_namespace(Il2CppClass* klass);

    const Il2CppAssembly** get_assemblies(std::size_t* size);
    std::size_t get_image_class_count(const Il2CppImage* image);
    Il2CppClass* get_image_class(const Il2CppImage* image, std::size_t index);

    int dump_all(FILE* out);
    int dump_class(FILE* out, Il2CppClass* klass);
    void dump_registration_view(FILE* out);
};

extern Il2CppUtils il2cpp;
