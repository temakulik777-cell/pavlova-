#include "Il2Cpp.h"
#include "../../good_luck/hks/icall.h"

#include <cstddef>
#include <cstdint>
#include <vector>

void* _il2cpp_api[IL2CPP_API_COUNT] = {0};
uintptr_t _il2cpp_base = 0;

long mono_address = 0;
std::vector<hook_info*> hooked_funcs;

namespace {
template <typename T>
inline T api_fn(int idx) {
    return reinterpret_cast<T>(_il2cpp_api[idx]);
}
}

void il2cpp_init_api(uintptr_t base) {
    _il2cpp_base = base;
    _il2cpp_api[IL2CPP_API_THREAD_CURRENT] = (void*)(base + 0x7731C60);
    _il2cpp_api[IL2CPP_API_THREAD_ATTACH] = (void*)(base + 0x7734EA0);
    _il2cpp_api[IL2CPP_API_THREAD_DETACH] = (void*)(base + 0x7734F40);
    _il2cpp_api[IL2CPP_API_CLASS_GET_FIELD_FROM_NAME] = (void*)(base + 0x7702D10);
    _il2cpp_api[IL2CPP_API_CLASS_GET_FIELDS] = (void*)(base + 0x7702C4C);
    _il2cpp_api[IL2CPP_API_CLASS_GET_INTERFACES] = (void*)(base + 0x7702DC0);
    _il2cpp_api[IL2CPP_API_CLASS_GET_METHODS] = (void*)(base + 0x7702E88);
    _il2cpp_api[IL2CPP_API_CLASS_GET_NAMESPACE] = (void*)(base + 0x770307C);
    _il2cpp_api[IL2CPP_API_CLASS_FROM_TYPE] = (void*)(base + 0x4728A10);
    _il2cpp_api[IL2CPP_API_CLASS_FROM_NAME] = (void*)(base + 0x773FB28);
    _il2cpp_api[IL2CPP_API_METADATA_IMAGE_GET_TYPE] = (void*)(base + 0x7705DCC);
    _il2cpp_api[IL2CPP_API_METADATA_IMAGE_GET_EXPORTED_TYPE] = (void*)(base + 0x7705DD0);
    _il2cpp_api[IL2CPP_API_METADATA_TYPE_TO_CLASS] = (void*)(base + 0x77076F8);
    _il2cpp_api[IL2CPP_API_OBJECT_NEW] = (void*)(base + 0x4729A7C);
    _il2cpp_api[IL2CPP_API_ARRAY_NEW] = (void*)(base + 0x47291C0);
    _il2cpp_api[IL2CPP_API_STRING_NEW] = (void*)(base + 0x4741818);
    _il2cpp_api[IL2CPP_API_DOMAIN_GET] = (void*)(base + 0x7731C70);
    _il2cpp_api[IL2CPP_API_DOMAIN_GET_ROOT] = (void*)(base + 0x7731B8C);
    _il2cpp_api[IL2CPP_API_DOMAIN_GET_ASSEMBLIES] = nullptr;
    _il2cpp_api[IL2CPP_API_DOMAIN_ASSEMBLY_OPEN] = (void*)(base + 0x4729434);
    _il2cpp_api[IL2CPP_API_ASSEMBLY_GET_IMAGE] = (void*)(base + 0x472942C);
    _il2cpp_api[IL2CPP_API_IMAGE_GET_CLASS_COUNT] = (void*)(base + 0x773FEC4);
    _il2cpp_api[IL2CPP_API_IMAGE_GET_CLASS] = nullptr;
    _il2cpp_api[IL2CPP_API_FIELD_STATIC_GET_VALUE] = (void*)(base + 0x4743C7C);
    _il2cpp_api[IL2CPP_API_METHOD_GET_PARAM_NAME] = (void*)(base + 0x773416C);
    _il2cpp_api[IL2CPP_API_METHOD_GET_PARAM_TOKEN] = (void*)(base + 0x77342EC);
    _il2cpp_api[IL2CPP_API_METHOD_GET_PARAM_DEFAULT_VALUE] = (void*)(base + 0x77342E8);
    _il2cpp_api[IL2CPP_API_RESOLVE_ICALL] = (void*)(base + 0x474A8A0);
    _il2cpp_api[IL2CPP_API_RESOLVE_ICALL_UNITY] = (void*)(base + 0x474A164);
    _il2cpp_api[IL2CPP_API_CUSTOM_ATTRS_FROM_CLASS] = (void*)(base + 0x4728DB4);
    _il2cpp_api[IL2CPP_API_CUSTOM_ATTRS_FROM_METHOD] = (void*)(base + 0x4728DC4);
    _il2cpp_api[IL2CPP_API_CUSTOM_ATTRS_HAS_ATTR] = (void*)(base + 0x4728DD8);
    _il2cpp_api[IL2CPP_API_CUSTOM_ATTRS_GET_ATTR] = (void*)(base + 0x4728DDC);
    _il2cpp_api[IL2CPP_API_CUSTOM_ATTRS_CONSTRUCT] = (void*)(base + 0x4728DE0);
    _il2cpp_api[IL2CPP_API_CUSTOM_ATTRS_FREE] = (void*)(base + 0x4728DE4);
}

Il2CppThread* il2cpp_thread_current(void) { auto fn = api_fn<Il2CppThread* (*)()>(IL2CPP_API_THREAD_CURRENT); return fn ? fn() : nullptr; }
Il2CppThread* il2cpp_thread_attach(Il2CppDomain* domain) { auto fn = api_fn<Il2CppThread* (*)(Il2CppDomain*)>(IL2CPP_API_THREAD_ATTACH); return fn ? fn(domain) : nullptr; }
void il2cpp_thread_detach(Il2CppThread* thread) { auto fn = api_fn<void (*)(Il2CppThread*)>(IL2CPP_API_THREAD_DETACH); if (fn) fn(thread); }

FieldInfo* il2cpp_class_get_field_from_name(Il2CppClass* klass, const char* name) { auto fn = api_fn<FieldInfo* (*)(Il2CppClass*, const char*)>(IL2CPP_API_CLASS_GET_FIELD_FROM_NAME); return fn ? fn(klass, name) : nullptr; }
FieldInfo* il2cpp_class_get_fields(Il2CppClass* klass, void** iter) { auto fn = api_fn<FieldInfo* (*)(Il2CppClass*, void**)>(IL2CPP_API_CLASS_GET_FIELDS); return fn ? fn(klass, iter) : nullptr; }
Il2CppClass* il2cpp_class_get_interfaces(Il2CppClass* klass, void** iter) { auto fn = api_fn<Il2CppClass* (*)(Il2CppClass*, void**)>(IL2CPP_API_CLASS_GET_INTERFACES); return fn ? fn(klass, iter) : nullptr; }
const MethodInfo* il2cpp_class_get_methods(Il2CppClass* klass, void** iter) { auto fn = api_fn<const MethodInfo* (*)(Il2CppClass*, void**)>(IL2CPP_API_CLASS_GET_METHODS); return fn ? fn(klass, iter) : nullptr; }
const char* il2cpp_class_get_namespace(Il2CppClass* klass) { auto fn = api_fn<const char* (*)(Il2CppClass*)>(IL2CPP_API_CLASS_GET_NAMESPACE); return fn ? fn(klass) : nullptr; }
Il2CppClass* il2cpp_class_from_type(const Il2CppType* type) { auto fn = api_fn<Il2CppClass* (*)(const Il2CppType*)>(IL2CPP_API_CLASS_FROM_TYPE); return fn ? fn(type) : nullptr; }
Il2CppClass* il2cpp_class_from_name(const Il2CppImage* image, const char* namespaze, const char* clazz) { auto fn = api_fn<Il2CppClass* (*)(const Il2CppImage*, const char*, const char*)>(IL2CPP_API_CLASS_FROM_NAME); return fn ? fn(image, namespaze, clazz) : nullptr; }

Il2CppObject* il2cpp_object_new(Il2CppClass* klass) { auto fn = api_fn<Il2CppObject* (*)(Il2CppClass*)>(IL2CPP_API_OBJECT_NEW); return fn ? fn(klass) : nullptr; }
Il2CppArray* il2cpp_array_new(Il2CppClass* element_class, std::size_t size) { auto fn = api_fn<Il2CppArray* (*)(Il2CppClass*, std::size_t)>(IL2CPP_API_ARRAY_NEW); return fn ? fn(element_class, size) : nullptr; }
Il2CppString* il2cpp_string_new(const char* text) { auto fn = api_fn<Il2CppString* (*)(const char*)>(IL2CPP_API_STRING_NEW); return fn ? fn(text) : nullptr; }

Il2CppDomain* il2cpp_domain_get() { auto fn = api_fn<Il2CppDomain* (*)()>(IL2CPP_API_DOMAIN_GET); return fn ? fn() : nullptr; }
Il2CppDomain* il2cpp_domain_get_root() { auto fn = api_fn<Il2CppDomain* (*)()>(IL2CPP_API_DOMAIN_GET_ROOT); return fn ? fn() : nullptr; }
const Il2CppAssembly** il2cpp_domain_get_assemblies(const Il2CppDomain* domain, std::size_t* size) { auto fn = api_fn<const Il2CppAssembly** (*)(const Il2CppDomain*, std::size_t*)>(IL2CPP_API_DOMAIN_GET_ASSEMBLIES); if (!fn) { if (size) *size = 0; return nullptr; } return fn(domain, size); }
const Il2CppAssembly* il2cpp_domain_assembly_open(Il2CppDomain* domain, const char* assembly) { auto fn = api_fn<const Il2CppAssembly* (*)(Il2CppDomain*, const char*)>(IL2CPP_API_DOMAIN_ASSEMBLY_OPEN); return fn ? fn(domain, assembly) : nullptr; }
const Il2CppImage* il2cpp_assembly_get_image(const Il2CppAssembly* assembly) { auto fn = api_fn<const Il2CppImage* (*)(const Il2CppAssembly*)>(IL2CPP_API_ASSEMBLY_GET_IMAGE); return fn ? fn(assembly) : nullptr; }

std::size_t il2cpp_image_get_class_count(const Il2CppImage* image) { auto fn = api_fn<std::size_t (*)(const Il2CppImage*)>(IL2CPP_API_IMAGE_GET_CLASS_COUNT); return fn ? fn(image) : 0; }
Il2CppClass* il2cpp_image_get_class(const Il2CppImage* image, std::size_t index) { auto fn = api_fn<Il2CppClass* (*)(const Il2CppImage*, std::size_t)>(IL2CPP_API_IMAGE_GET_CLASS); return fn ? fn(image, index) : nullptr; }
uint32_t il2cpp_image_get_type_count_internal(const Il2CppImage* image) { if (!image) return 0; const auto* p = reinterpret_cast<const uint8_t*>(image); return *reinterpret_cast<const uint32_t*>(p + 0x14); }
uint32_t il2cpp_image_get_exported_type_count_internal(const Il2CppImage* image) { if (!image) return 0; const auto* p = reinterpret_cast<const uint8_t*>(image); return *reinterpret_cast<const uint32_t*>(p + 0x08); }

Il2CppClass* il2cpp_image_get_class_internal(const Il2CppImage* image, std::size_t index) {
    if (!image) return nullptr;
    void* metadata_type = nullptr;
    uint32_t type_count = il2cpp_image_get_type_count_internal(image);
    if (index < static_cast<std::size_t>(type_count)) {
        auto fn = api_fn<void* (*)(const Il2CppImage*, int)>(IL2CPP_API_METADATA_IMAGE_GET_TYPE);
        metadata_type = fn ? fn(image, static_cast<int>(index)) : nullptr;
    } else {
        uint32_t exported_index = static_cast<uint32_t>(index - static_cast<std::size_t>(type_count));
        auto fn = api_fn<void* (*)(const Il2CppImage*, int)>(IL2CPP_API_METADATA_IMAGE_GET_EXPORTED_TYPE);
        metadata_type = fn ? fn(image, static_cast<int>(exported_index)) : nullptr;
    }
    if (!metadata_type) return nullptr;
    auto fn_to_class = api_fn<Il2CppClass* (*)(const void*)>(IL2CPP_API_METADATA_TYPE_TO_CLASS);
    return fn_to_class ? fn_to_class(metadata_type) : nullptr;
}

const Il2CppAssembly** il2cpp_domain_get_assemblies_internal(const Il2CppDomain* domain, std::size_t* size) {
    (void)domain;
    if (!_il2cpp_base) { if (size) *size = 0; return nullptr; }
    const auto* vec = reinterpret_cast<const Il2CppAssemblyVector*>(_il2cpp_base + 0x8658538);
    if (!vec || !vec->begin || !vec->end || vec->end < vec->begin) { if (size) *size = 0; return nullptr; }
    if (size) *size = static_cast<std::size_t>(vec->end - vec->begin);
    return vec->begin;
}

void il2cpp_field_static_get_value(FieldInfo* field, void* value) { auto fn = api_fn<void (*)(FieldInfo*, void*)>(IL2CPP_API_FIELD_STATIC_GET_VALUE); if (fn) fn(field, value); }
const char* il2cpp_method_get_param_name(const MethodInfo* method, uint32_t index) { auto fn = api_fn<const char* (*)(const MethodInfo*, uint32_t)>(IL2CPP_API_METHOD_GET_PARAM_NAME); return (fn && method) ? fn(method, index) : nullptr; }
uint32_t il2cpp_method_get_param_token(const MethodInfo* method, int32_t index) { auto fn = api_fn<uint32_t (*)(const MethodInfo*, int32_t)>(IL2CPP_API_METHOD_GET_PARAM_TOKEN); return (fn && method) ? fn(method, index) : 0; }
const uint8_t* il2cpp_method_get_param_default_value(const MethodInfo* method, int32_t index, const Il2CppType** type, uint8_t* is_explicit_null) {
    auto fn = api_fn<const uint8_t* (*)(const MethodInfo*, int32_t, const Il2CppType**, uint8_t*)>(IL2CPP_API_METHOD_GET_PARAM_DEFAULT_VALUE);
    if (!fn || !method) { if (type) *type = nullptr; if (is_explicit_null) *is_explicit_null = 0; return nullptr; }
    return fn(method, index, type, is_explicit_null);
}

void* il2cpp_resolve_icall(void* method) { auto fn = api_fn<void* (*)(void*)>(IL2CPP_API_RESOLVE_ICALL); return fn ? fn(method) : nullptr; }
void* il2cpp_resolve_icall_unity(void* name) { auto fn = api_fn<void* (*)(void*)>(IL2CPP_API_RESOLVE_ICALL_UNITY); return fn ? fn(name) : nullptr; }

const Il2CppCustomAttrInfo* il2cpp_custom_attrs_from_class(Il2CppClass* klass) { auto fn = api_fn<const Il2CppCustomAttrInfo* (*)(Il2CppClass*)>(IL2CPP_API_CUSTOM_ATTRS_FROM_CLASS); return (fn && klass) ? fn(klass) : nullptr; }
const Il2CppCustomAttrInfo* il2cpp_custom_attrs_from_method(const MethodInfo* method) { auto fn = api_fn<const Il2CppCustomAttrInfo* (*)(const MethodInfo*)>(IL2CPP_API_CUSTOM_ATTRS_FROM_METHOD); return (fn && method) ? fn(method) : nullptr; }
int il2cpp_custom_attrs_has_attr(const Il2CppCustomAttrInfo* info, Il2CppClass* attr_klass) { auto fn = api_fn<int (*)(const Il2CppCustomAttrInfo*, Il2CppClass*)>(IL2CPP_API_CUSTOM_ATTRS_HAS_ATTR); return (fn && info && attr_klass) ? fn(info, attr_klass) : 0; }
Il2CppObject* il2cpp_custom_attrs_get_attr(const Il2CppCustomAttrInfo* info, Il2CppClass* attr_klass) { auto fn = api_fn<Il2CppObject* (*)(const Il2CppCustomAttrInfo*, Il2CppClass*)>(IL2CPP_API_CUSTOM_ATTRS_GET_ATTR); return (fn && info && attr_klass) ? fn(info, attr_klass) : nullptr; }
Il2CppArray* il2cpp_custom_attrs_construct(const Il2CppCustomAttrInfo* info) { auto fn = api_fn<Il2CppArray* (*)(const Il2CppCustomAttrInfo*)>(IL2CPP_API_CUSTOM_ATTRS_CONSTRUCT); return (fn && info) ? fn(info) : nullptr; }
void il2cpp_custom_attrs_free(const Il2CppCustomAttrInfo* info) { auto fn = api_fn<void (*)(const Il2CppCustomAttrInfo*)>(IL2CPP_API_CUSTOM_ATTRS_FREE); if (fn && info) fn(info); }
