#include "Touch.h"

TouchSystem GetTouchSystem;
