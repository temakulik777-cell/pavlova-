#ifndef TOUCH_H
#define TOUCH_H

#include "../Vector2.h"
#include "../../v_memory.h"

extern uintptr_t base;

enum TouchPhase {
    TouchPhase_Began = 0,
    TouchPhase_Moved = 1,
    TouchPhase_Stationary = 2,
    TouchPhase_Ended = 3,
    TouchPhase_Canceled = 4
};

enum TouchType {
    TouchType_Direct = 0,
    TouchType_Indirect = 1,
    TouchType_Stylus = 2
};

#pragma pack(push, 1)
struct UnityTouch {
    int m_FingerId;                // 0x0
    Vector2 m_Position;            // 0x4
    Vector2 m_RawPosition;         // 0xC
    Vector2 m_PositionDelta;       // 0x14
    float m_TimeDelta;             // 0x1C
    int m_TapCount;                // 0x20
    TouchPhase m_Phase;            // 0x24
    TouchType m_Type;              // 0x28
    float m_Pressure;              // 0x2C
    float m_maximumPossiblePressure; // 0x30
    float m_Radius;                // 0x34
    float m_RadiusVariance;        // 0x38
    float m_AltitudeAngle;         // 0x3C
    float m_AzimuthAngle;          // 0x40
};
#pragma pack(pop)

inline UnityTouch GetTouch(int index) {
    using GetTouchFn = void(*)(int, UnityTouch*);
    static uintptr_t cached_base = 0;
    static GetTouchFn get_touch_injected = nullptr;

    if (base != cached_base || get_touch_injected == nullptr) {
        cached_base = base;
        get_touch_injected = (base != 0)
            ? reinterpret_cast<GetTouchFn>(reinterpret_cast<uintptr_t>(base) + vMemory::UnityEngine::Input::GetTouch)
            : nullptr;
    }

    UnityTouch touch = {};
    if (get_touch_injected) {
        get_touch_injected(index, &touch);
    }
    return touch;
}

inline void ConvertUnityTouchToImGui(const UnityTouch& unity_touch, ImGuiIO& io) {
    float screen_x = unity_touch.m_Position.x;
    float screen_y = ImGui::GetIO().DisplaySize.y - unity_touch.m_Position.y;

    bool is_touch_down = false;
    bool is_touch_up = false;

    switch (unity_touch.m_Phase) {
        case TouchPhase_Began:
            is_touch_down = true;
            break;
        case TouchPhase_Moved:
            break;
        case TouchPhase_Ended:
        case TouchPhase_Canceled:
            is_touch_up = true;
            break;
        case TouchPhase_Stationary:
            break;
    }

    if (unity_touch.m_FingerId == 0) {
        io.MousePos = ImVec2(screen_x, screen_y);

        if (is_touch_down) {
            io.MouseDown[0] = true;
            io.MouseClicked[0] = true;
            io.MouseClickedPos[0] = io.MousePos;
        }

        if (is_touch_up) {
            io.MouseDown[0] = false;
        }
    }
}

struct TouchSystem {
    ImVector<ImGuiID> ActiveTouchIDs;
    ImVector<ImVec2> TouchPositions;
    ImVector<ImVec2> TouchStartPositions;
    ImVector<TouchPhase> TouchPhases;
    ImVector<bool> TouchUsed;

    void Update(ImGuiIO& io, int touch_count) {
        ImVector<ImGuiID> preservedTouchIDs;
        ImVector<ImVec2> preservedTouchPositions;
        ImVector<ImVec2> preservedTouchStartPositions;
        ImVector<TouchPhase> preservedTouchPhases;
        ImVector<bool> preservedTouchUsed;

        for (int i = 0; i < ActiveTouchIDs.Size; i++) {
            ImGuiID id = ActiveTouchIDs[i];
            ImVec2 pos = TouchPositions[i];
            ImVec2 startPos = TouchStartPositions[i];
            TouchPhase phase = TouchPhases[i];
            bool used = TouchUsed[i];

            bool stillActive = false;
            for (int j = 0; j < touch_count; j++) {
                UnityTouch unity_touch = GetTouch(j);
                ImGuiID unity_id = 1000 + unity_touch.m_FingerId;
                if (unity_id == id) {
                    stillActive = true;
                    pos = ImVec2(unity_touch.m_Position.x, io.DisplaySize.y - unity_touch.m_Position.y);
                    phase = unity_touch.m_Phase;
                    break;
                }
            }

            if (stillActive) {
                preservedTouchIDs.push_back(id);
                preservedTouchPositions.push_back(pos);
                preservedTouchStartPositions.push_back(startPos);
                preservedTouchPhases.push_back(phase);
                preservedTouchUsed.push_back(used);
            }
        }

        ActiveTouchIDs.swap(preservedTouchIDs);
        TouchPositions.swap(preservedTouchPositions);
        TouchStartPositions.swap(preservedTouchStartPositions);
        TouchPhases.swap(preservedTouchPhases);
        TouchUsed.swap(preservedTouchUsed);

        for (int i = 0; i < touch_count; i++) {
            UnityTouch unity_touch = GetTouch(i);
            float x = unity_touch.m_Position.x;
            float y = io.DisplaySize.y - unity_touch.m_Position.y;
            ImVec2 touch_pos(x, y);
            ImGuiID touch_id = 1000 + unity_touch.m_FingerId;

            bool exists = false;
            for (int j = 0; j < ActiveTouchIDs.Size; j++) {
                if (ActiveTouchIDs[j] == touch_id) {
                    TouchPositions[j] = touch_pos;
                    TouchPhases[j] = unity_touch.m_Phase;
                    exists = true;
                    break;
                }
            }

            if (!exists) {
                switch (unity_touch.m_Phase) {
                    case TouchPhase_Began:
                        ActiveTouchIDs.push_back(touch_id);
                        TouchPositions.push_back(touch_pos);
                        TouchStartPositions.push_back(touch_pos);
                        TouchPhases.push_back(unity_touch.m_Phase);
                        TouchUsed.push_back(false);
                        break;
                    case TouchPhase_Moved:
                    case TouchPhase_Stationary:
                        // If Began was missed between frames, recover by creating touch here.
                        ActiveTouchIDs.push_back(touch_id);
                        TouchPositions.push_back(touch_pos);
                        TouchStartPositions.push_back(touch_pos);
                        TouchPhases.push_back(unity_touch.m_Phase);
                        TouchUsed.push_back(false);
                        break;
                    case TouchPhase_Ended:
                    case TouchPhase_Canceled:
                        break;
                }
            }
        }
    }

    bool IsTouchActive(ImGuiID id) const {
        for (int i = 0; i < ActiveTouchIDs.Size; i++) {
            if (ActiveTouchIDs[i] == id) {
                return true;
            }
        }
        return false;
    }

    bool IsTouchUsed(ImGuiID id) const {
        for (int i = 0; i < ActiveTouchIDs.Size; i++) {
            if (ActiveTouchIDs[i] == id) {
                return TouchUsed[i];
            }
        }
        return false;
    }

    void MarkTouchUsed(ImGuiID id, bool used = true) {
        for (int i = 0; i < ActiveTouchIDs.Size; i++) {
            if (ActiveTouchIDs[i] == id) {
                TouchUsed[i] = used;
                return;
            }
        }
    }

    ImVec2 GetTouchPosition(ImGuiID id) const {
        for (int i = 0; i < ActiveTouchIDs.Size; i++) {
            if (ActiveTouchIDs[i] == id) {
                return TouchPositions[i];
            }
        }
        return ImVec2(-1, -1);
    }

    ImVec2 GetTouchStartPosition(ImGuiID id) const {
        for (int i = 0; i < ActiveTouchIDs.Size; i++) {
            if (ActiveTouchIDs[i] == id) {
                return TouchStartPositions[i];
            }
        }
        return ImVec2(-1, -1);
    }

    TouchPhase GetTouchPhase(ImGuiID id) const {
        for (int i = 0; i < ActiveTouchIDs.Size; i++) {
            if (ActiveTouchIDs[i] == id) {
                return TouchPhases[i];
            }
        }
        return TouchPhase_Canceled;
    }

    ImGuiID GetFirstUnusedTouchID() const {
        for (int i = 0; i < ActiveTouchIDs.Size; i++) {
            if (!TouchUsed[i]) {
                return ActiveTouchIDs[i];
            }
        }
        return 0;
    }

    void GetUnusedTouchIDs(ImVector<ImGuiID>& out_ids) const {
        out_ids.clear();
        for (int i = 0; i < ActiveTouchIDs.Size; i++) {
            if (!TouchUsed[i] &&
                TouchPhases[i] != TouchPhase_Ended &&
                TouchPhases[i] != TouchPhase_Canceled) {
                out_ids.push_back(ActiveTouchIDs[i]);
            }
        }
    }
};

static TouchSystem GetTouchSystem;

#endif // TOUCH_H
