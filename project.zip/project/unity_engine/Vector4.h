#pragma once
#include <math.h>

struct Vector4 {
    float x, y, z, w;
    
    Vector4() : x(0), y(0), z(0), w(0) {}
    Vector4(float x_, float y_, float z_, float w_) : x(x_), y(y_), z(z_), w(w_) {}
    Vector4(float x_, float y_, float z_) : x(x_), y(y_), z(z_), w(0) {}

    static Vector4 zero() { return Vector4(0, 0, 0, 0); }
    static Vector4 one() { return Vector4(1, 1, 1, 1); }

    Vector4 operator+(const Vector4& other) const {
        return Vector4(x + other.x, y + other.y, z + other.z, w + other.w);
    }
    
    Vector4 operator-(const Vector4& other) const {
        return Vector4(x - other.x, y - other.y, z - other.z, w - other.w);
    }
    
    Vector4 operator*(float scalar) const {
        return Vector4(x * scalar, y * scalar, z * scalar, w * scalar);
    }
    
    Vector4 operator/(float scalar) const {
        return Vector4(x / scalar, y / scalar, z / scalar, w / scalar);
    }
    
    Vector4& operator+=(const Vector4& other) {
        x += other.x;
        y += other.y;
        z += other.z;
        w += other.w;
        return *this;
    }
    
    Vector4& operator-=(const Vector4& other) {
        x -= other.x;
        y -= other.y;
        z -= other.z;
        w -= other.w;
        return *this;
    }
    
    Vector4& operator*=(float scalar) {
        x *= scalar;
        y *= scalar;
        z *= scalar;
        w *= scalar;
        return *this;
    }
    
    Vector4& operator/=(float scalar) {
        x /= scalar;
        y /= scalar;
        z /= scalar;
        w /= scalar;
        return *this;
    }
    
    bool operator==(const Vector4& other) const {
        return x == other.x && y == other.y && z == other.z && w == other.w;
    }
    
    bool operator!=(const Vector4& other) const {
        return !(*this == other);
    }

    float magnitude() const {
        return sqrtf(x*x + y*y + z*z + w*w);
    }
    
    float sqrMagnitude() const {
        return x*x + y*y + z*z + w*w;
    }
    
    Vector4 normalized() const {
        float mag = magnitude();
        if (mag == 0) return Vector4(0, 0, 0, 0);
        return *this / mag;
    }
    
    void Normalize() {
        *this = normalized();
    }
    
    static float Dot(const Vector4& lhs, const Vector4& rhs) {
        return lhs.x * rhs.x + lhs.y * rhs.y + lhs.z * rhs.z + lhs.w * rhs.w;
    }
    
    static Vector4 Lerp(const Vector4& a, const Vector4& b, float t) {
        t = fmaxf(0, fminf(1, t));
        return a + (b - a) * t;
    }
};