#pragma once
#include <math.h>

struct Vector2 {
    float x, y;

    Vector2() : x(0), y(0) {}
    Vector2(float x_, float y_) : x(x_), y(y_) {}

    static Vector2 zero() { return Vector2(0, 0); }
    static Vector2 one() { return Vector2(1, 1); }
    static Vector2 up() { return Vector2(0, 1); }
    static Vector2 down() { return Vector2(0, -1); }
    static Vector2 left() { return Vector2(-1, 0); }
    static Vector2 right() { return Vector2(1, 0); }

    Vector2 operator+(const Vector2& other) const {
        return Vector2(x + other.x, y + other.y);
    }
    
    Vector2 operator-(const Vector2& other) const {
        return Vector2(x - other.x, y - other.y);
    }

    friend Vector2 operator*(float scalar, const Vector2& vec) {
        return Vector2(scalar * vec.x, scalar * vec.y);
    }
    
    Vector2 operator*(float scalar) const {
        return Vector2(x * scalar, y * scalar);
    }
    
    Vector2 operator/(float scalar) const {
        return Vector2(x / scalar, y / scalar);
    }
    
    Vector2& operator+=(const Vector2& other) {
        x += other.x;
        y += other.y;
        return *this;
    }
    
    Vector2& operator-=(const Vector2& other) {
        x -= other.x;
        y -= other.y;
        return *this;
    }
    
    Vector2& operator*=(float scalar) {
        x *= scalar;
        y *= scalar;
        return *this;
    }
    
    Vector2& operator/=(float scalar) {
        x /= scalar;
        y /= scalar;
        return *this;
    }
    
    bool operator==(const Vector2& other) const {
        return x == other.x && y == other.y;
    }
    
    bool operator!=(const Vector2& other) const {
        return !(*this == other);
    }

    float magnitude() const {
        return sqrtf(x*x + y*y);
    }
    
    float sqrMagnitude() const {
        return x*x + y*y;
    }
    
    Vector2 normalized() const {
        float mag = magnitude();
        if (mag == 0) return Vector2(0, 0);
        return *this / mag;
    }
    
    void Normalize() {
        *this = normalized();
    }
    
    static float Dot(const Vector2& lhs, const Vector2& rhs) {
        return lhs.x * rhs.x + lhs.y * rhs.y;
    }
    
    static float Distance(const Vector2& a, const Vector2& b) {
        return (a - b).magnitude();
    }
    
    static Vector2 Lerp(const Vector2& a, const Vector2& b, float t) {
        t = fmaxf(0, fminf(1, t));
        return a + (b - a) * t;
    }
    
    static Vector2 MoveTowards(const Vector2& current, const Vector2& target, float maxDistanceDelta) {
        Vector2 d = target - current;
        float m = d.magnitude();
        if (m <= maxDistanceDelta || m == 0)
            return target;
        return current + d / m * maxDistanceDelta;
    }
    
    static float Angle(const Vector2& from, const Vector2& to) {
        float dot = Dot(from.normalized(), to.normalized());
        dot = fmaxf(-1.0f, fminf(1.0f, dot));
        return acosf(dot) * 180.0f / M_PI;
    }
    
    static Vector2 Reflect(const Vector2& inDirection, const Vector2& inNormal) {
        return inDirection - 2 * Dot(inDirection, inNormal) * inNormal;
    }
    
    static Vector2 Perpendicular(const Vector2& inDirection) {
        return Vector2(-inDirection.y, inDirection.x);
    }
};