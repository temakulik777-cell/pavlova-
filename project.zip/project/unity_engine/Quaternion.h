#pragma once
#include <math.h>
#include "Vector3.h"

struct Quaternion {
    float x, y, z, w;
    
    Quaternion() : x(0), y(0), z(0), w(1) {}
    Quaternion(float x_, float y_, float z_, float w_) : x(x_), y(y_), z(z_), w(w_) {}
   
    static Quaternion identity() { return Quaternion(0, 0, 0, 1); }

    Quaternion operator*(const Quaternion& other) const {
        return Quaternion(
            w * other.x + x * other.w + y * other.z - z * other.y,
            w * other.y + y * other.w + z * other.x - x * other.z,
            w * other.z + z * other.w + x * other.y - y * other.x,
            w * other.w - x * other.x - y * other.y - z * other.z
        );
    }
    
    Vector3 operator*(const Vector3& point) const {
        Vector3 q(x, y, z);
        Vector3 t = Vector3::Cross(q, point) * 2.0f;
        Vector3 cross = Vector3::Cross(q, t);
        return point + t * w + cross;
    }
    
    Quaternion operator*(float scalar) const {
        return Quaternion(x * scalar, y * scalar, z * scalar, w * scalar);
    }

    Quaternion operator/(float scalar) const {
        if (scalar == 0.0f) {
            return identity();
        }
        const float inv = 1.0f / scalar;
        return Quaternion(x * inv, y * inv, z * inv, w * inv);
    }
    
    Quaternion& operator*=(const Quaternion& other) {
        *this = *this * other;
        return *this;
    }
    
    bool operator==(const Quaternion& other) const {
        return x == other.x && y == other.y && z == other.z && w == other.w;
    }
    
    bool operator!=(const Quaternion& other) const {
        return !(*this == other);
    }
    
    float magnitude() const {
        return sqrtf(x*x + y*y + z*z + w*w);
    }
    
    float sqrMagnitude() const {
        return x*x + y*y + z*z + w*w;
    }
    
    Quaternion normalized() const {
        float mag = magnitude();
        if (mag == 0) return Quaternion(0, 0, 0, 1);
        return *this / mag;
    }
    
    void Normalize() {
        *this = normalized();
    }
    
    Quaternion conjugate() const {
        return Quaternion(-x, -y, -z, w);
    }
    
    Quaternion inverse() const {
        Quaternion conj = conjugate();
        float normSq = sqrMagnitude();
        if (normSq == 0) return identity();
        return conj / normSq;
    }
    
    static Quaternion FromToRotation(const Vector3& from, const Vector3& to) {
        Vector3 cross = Vector3::Cross(from.normalized(), to.normalized());
        float dot = Vector3::Dot(from.normalized(), to.normalized());
        float s = sqrtf((1.0f + dot) * 2.0f);
        
        return Quaternion(
            cross.x / s,
            cross.y / s,
            cross.z / s,
            s / 2.0f
        ).normalized();
    }
    
    static Quaternion LookRotation(const Vector3& forward, const Vector3& upwards = Vector3::up()) {
        Vector3 f = forward.normalized();
        Vector3 u = upwards.normalized();
        Vector3 r = Vector3::Cross(u, f).normalized();
        u = Vector3::Cross(f, r);
        
        float m00 = r.x, m01 = r.y, m02 = r.z;
        float m10 = u.x, m11 = u.y, m12 = u.z;
        float m20 = f.x, m21 = f.y, m22 = f.z;
        
        float trace = m00 + m11 + m22;
        
        if (trace > 0) {
            float s = sqrtf(trace + 1.0f) * 2.0f;
            float invS = 1.0f / s;
            
            return Quaternion(
                (m21 - m12) * invS,
                (m02 - m20) * invS,
                (m10 - m01) * invS,
                s * 0.25f
            );
        } else if ((m00 >= m11) && (m00 >= m22)) {
            float s = sqrtf(1.0f + m00 - m11 - m22) * 2.0f;
            float invS = 1.0f / s;
            
            return Quaternion(
                0.25f * s,
                (m01 + m10) * invS,
                (m02 + m20) * invS,
                (m21 - m12) * invS
            );
        } else if (m11 > m22) {
            float s = sqrtf(1.0f + m11 - m00 - m22) * 2.0f;
            float invS = 1.0f / s;
            
            return Quaternion(
                (m01 + m10) * invS,
                0.25f * s,
                (m12 + m21) * invS,
                (m02 - m20) * invS
            );
        } else {
            float s = sqrtf(1.0f + m22 - m00 - m11) * 2.0f;
            float invS = 1.0f / s;
            
            return Quaternion(
                (m02 + m20) * invS,
                (m12 + m21) * invS,
                0.25f * s,
                (m10 - m01) * invS
            );
        }
    }
    
    Vector3 eulerAngles() const {
        float sinr_cosp = 2 * (w * x + y * z);
        float cosr_cosp = 1 - 2 * (x * x + y * y);
        float roll = atan2f(sinr_cosp, cosr_cosp);

        float sinp = 2 * (w * y - z * x);
        float pitch;
        if (fabsf(sinp) >= 1)
            pitch = copysignf(M_PI / 2, sinp);
        else
            pitch = asinf(sinp);

        float siny_cosp = 2 * (w * z + x * y);
        float cosy_cosp = 1 - 2 * (y * y + z * z);
        float yaw = atan2f(siny_cosp, cosy_cosp);

        return Vector3(pitch * 180.0f / M_PI, yaw * 180.0f / M_PI, roll * 180.0f / M_PI);
    }
    
    static Quaternion Euler(float x, float y, float z) {
        x *= M_PI / 180.0f;
        y *= M_PI / 180.0f;
        z *= M_PI / 180.0f;

        float cx = cosf(x * 0.5f);
        float cy = cosf(y * 0.5f);
        float cz = cosf(z * 0.5f);
        float sx = sinf(x * 0.5f);
        float sy = sinf(y * 0.5f);
        float sz = sinf(z * 0.5f);

        return Quaternion(
            cx * cy * sz - sx * sy * cz,
            cx * sy * cz + sx * cy * sz,
            sx * cy * cz - cx * sy * sz,
            cx * cy * cz + sx * sy * sz
        );
    }
    
    static Quaternion Euler(const Vector3& rotation) {
        return Euler(rotation.x, rotation.y, rotation.z);
    }
};
