#pragma once

#include <cstdint>
#include <functional>
#include <string>

#include "clickgui/clickgui.h"

class WidgetManager;

struct vMemory {
    struct Unity {
        static constexpr uintptr_t eglSwapBuffers = 0x81197D8;
        static constexpr uintptr_t PresentFrame = 0x7C4CBD0;

        struct IL2CPP {
            static constexpr uintptr_t il2cpp_string_new = 0x4741818;
            static constexpr uintptr_t class_from_name = 0x773FB28;
            static constexpr uintptr_t object_new = 0x4729A7C;
            static constexpr uintptr_t field_static_get_value = 0x4743C7C;
            static constexpr uintptr_t class_get_field_from_name = 0x7702C4C;
            static constexpr uintptr_t domain_assembly_open = 0x4729434;
            static constexpr uintptr_t assembly_get_image = 0x47434B4;
            static constexpr uintptr_t resolve_icall = 0x474A8A0;
            static constexpr uintptr_t resolve_icall_unity = 0x474A164;
            static constexpr uintptr_t class_get_methods = 0x76CBD08;
            static constexpr uintptr_t thread_current = 0x7731C60;
            static constexpr uintptr_t thread_attach = 0x7734EA0;
            static constexpr uintptr_t class_from_type = 0x77025DC;
            static constexpr uintptr_t domain_get = 0x76FAAB8;
            static constexpr uintptr_t thread_detach_ptr = 0x7734F40;
            static constexpr uintptr_t class_get_interfaces = 0x76CBC40;
            static constexpr uintptr_t array_new = 0x47291C0;
        };
    };

    struct Axlebolt {
        struct Photon {
            static constexpr uintptr_t PhotonView_get_isMine = 0x4C28390;
        };

        struct Player {
            struct PlayerController {
                static constexpr uintptr_t TypeInfo = 0x8156A88;
                static constexpr uintptr_t Update = 0x5644538;
                static constexpr uint16_t UpdateMethodIndex = 67;
                static constexpr uintptr_t CharacterControllerField = 0x110;
                static constexpr uintptr_t PhotonViewField = 0x148;
            };
        };
    };

    struct UnityEngine {
        struct Input {
            static constexpr uintptr_t GetTouchCount = 0x6b00874;
            static constexpr uintptr_t GetTouch = 0x6b00ef0;
            struct Delegate { static constexpr uintptr_t GetTouchCount = 0x866F670; };
        };

        struct TouchScreenKeyboard {
            static constexpr uintptr_t Open = 0x5F23CC4;
            static constexpr uintptr_t Destroy = 0x5F23724;
            static constexpr uintptr_t get_text = 0x5F23E54;
            static constexpr uintptr_t get_status = 0x5F2400C;
        };
    };

    struct Metadata {
            struct Data {
                using ModuleCallback = std::function<void(WidgetManager*, const ClickGUI::Settings*, int, int)>;

            struct Module {
                std::string name;
                std::string description;
                bool enabled = false;
                bool bound = false;
                bool showActiveToggle = true;
                    bool hasSettings = false;
                    ModuleCallback renderSettings;
                };

                struct ModuleArray {
                    Module** items = nullptr;
                    int count = 0;

                    Module** data() { return items; }
                    Module* const* data() const { return items; }
                    int size() const { return count; }
                };

                struct Text {
                    const char** globals = nullptr;
                    int globalsCount = 0;
                    const char** messages = nullptr;
                    int messagesCount = 0;
                };

            struct Features {
                struct String {
                    const char* label = nullptr;
                    const char* desc = nullptr;
                };
                struct Bool {
                    bool value = false;
                    String text = {};
                };
                struct Float {
                    float value = 0.0f;
                    String text = {};
                };
                struct Action {
                    const char* label = nullptr;
                };
                template <std::size_t N>
                struct Choice {
                    String text = {};
                    const char* items[N] = {};
                };
                template <std::size_t N>
                struct NamedList {
                    const char* names[N] = {};
                };

                struct AimbotTab {
                    Module module = {};
                    int mode = 0;
                    Choice<3> modeChoice = {};
                    Float fov = {90.0f, {}};
                    Bool silentAim = {};
                    Bool smoothAim = {};
                    Float smoothFactor = {5.0f, {}};
                    Bool silentAutoShot = {};
                    Float silentReaction = {0.10f, {}};
                    Bool rotationCompensate = {};
                    Float rotationSpeed = {35.0f, {}};
                    Bool aiRotationAdaptive = {};
                    Float aiRotationConfidence = {0.65f, {}};
                } aimbot;

                struct MovementTab {
                    Module bunnyHop = {};
                    Module recorder = {};
                    Module noClip = {};
                    Module flyHack = {};
                    Bool autoStrafe = {};
                    Bool recorderAutoReturn = {true, {}};
                    Bool recorderShowPath = {true, {}};
                    Float speedMultiplier = {1.18f, {}};
                    Float strafeStrength = {0.42f, {}};
                    Float forwardPush = {0.92f, {}};
                    Float sideLimit = {0.72f, {}};
                    Float forwardLimit = {1.18f, {}};
                    Float recorderStartRadius = {0.40f, {}};
                    Float recorderSeekSpeed = {3.6f, {}};
                    Choice<4> recorderSlot = {};
                    String recorderPosition = {};
                    const char* recorderRecordAction = nullptr;
                    const char* recorderStopAction = nullptr;
                    const char* recorderClearAction = nullptr;
                    const char* recorderPathAction = nullptr;
                } movement;

                struct RenderTab {
                    Module esp = {};
                    Module colorGrading = {};
                    Bool boxEsp = {};
                    Bool skeletonEsp = {};
                    Bool nameEsp = {};
                    Bool healthBar = {};
                    Float renderDistance = {100.0f, {}};
                    Choice<8> colorGradingPreset = {};
                    String tintColor = {};
                    String gradingCurve = {};
                    NamedList<5> gradingCurveNames = {};
                } render;

                struct MiscTab {
                    Module radar = {};
                    Module recoil = {};
                    Module noFlash = {};
                    Module autoPistol = {};
                    Module fastReload = {};
                    Module audio = {};
                    Float masterVolume = {1.0f, {}};
                } misc;

                struct ConfigTab {
                    Module module = {};
                    Choice<5> selectConfig = {};
                    Action scrollbarSize = {};
                    Action applyTheme = {};
                    Action downscaleFactor = {};
                    Action cornerRadius = {};
                } config;

                struct HudTab {
                    Module module = {};
                    Module watermark = {};
                    Module speedGraph = {};
                    float hudScale = 1.0f;
                    String showFpsCounter = {};
                    String showPing = {};
                    String showCoordinates = {};
                    String showCustomCrosshair = {};
                    Choice<5> crosshairStyle = {};
                    String watermarkPosition = {};
                    String watermarkBgAlphaNoBlur = {};
                    String watermarkScale = {};
                    String watermarkTextAlpha = {};
                    String watermarkSeparatorAlpha = {};
                    String watermarkPaddingScale = {};
                    String watermarkInfoFlags = {};
                    String watermarkNicknameColor = {};
                    String watermarkNicknameUserColors = {};
                    String speedGraphPosition = {};
                    const char* valueTextTag = nullptr;
                    const char* prefixWindowSize = nullptr;
                    const char* prefixScaledDimensions = nullptr;
                    const char* prefixDownscale = nullptr;
                } hud;

                struct CuiTab {
                    Module clickgui = {};
                    Module appearance = {};
                    Module animation = {};
                    Module devTools = {};
                    String scale = {};
                    Action applyScale = {};
                    String showSidebarIcon = {};
                    String sidebarIconScale = {};
                    Choice<3> accentType = {};
                    Choice<2> accentGradientDirection = {};
                    String accentColor = {};
                    String glowEffect = {};
                    String shadowEffect = {};
                    String blurEffect = {};
                    String glowAlpha = {};
                    String downscaleFactor = {};
                    String blurRadius = {};
                    String shadowRadius = {};
                    String shadowSmoothness = {};
                    String animationSpeed = {};
                    String tabsAnimationSpeed = {};
                    String popupAnimationSpeed = {};
                    String rippleEnabled = {};
                    String ripplePressRadius = {};
                    String ripplePressSpeed = {};
                    String ripplePressStrength = {};
                    String rippleDragRadius = {};
                    String rippleDragStrength = {};
                    String rippleMotionStrength = {};
                    Bool movementTelemetry = {};
                    Bool movementTelemetryVerbose = {};
                    Action movementTelemetryClear = {};
                } cui;

                int activeByTab[7] = { -1, -1, -1, -1, -1, -1, -1 };

                ModuleArray aimbotList = {};
                ModuleArray movementList = {};
                ModuleArray renderList = {};
                ModuleArray miscList = {};
                ModuleArray configList = {};
                ModuleArray hudList = {};
                ModuleArray cuiList = {};
            };

            struct Runtime {
                Features features;
                Text text;
            };
        };
    };
};

using ModuleEntry = vMemory::Metadata::Data::Module;
using Features = vMemory::Metadata::Data::Features;
using FeaturePointers = vMemory::Metadata::Data::Features*;
using ModuleCallback = vMemory::Metadata::Data::ModuleCallback;
using Runtime = vMemory::Metadata::Data::Runtime;
extern Runtime vrt;
