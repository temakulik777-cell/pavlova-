#pragma once
#include "../clickgui/widgets/wigdets.h"
#include "../v_memory.h"

struct ModuleReg {
    ModuleCallback Aimbot(FeaturePointers features);
    ModuleCallback Movement(FeaturePointers features);
    ModuleCallback MovementRecorder(FeaturePointers features);
    ModuleCallback Render(FeaturePointers features);
    ModuleCallback RenderColorGrading(FeaturePointers features);
    ModuleCallback MiscAudio(FeaturePointers features);
    ModuleCallback Config(FeaturePointers features);
    ModuleCallback HUD(FeaturePointers features);
    ModuleCallback HUDWatermark(FeaturePointers features);
    ModuleCallback HUDSpeedGraph(FeaturePointers features);
    ModuleCallback ClickG(FeaturePointers features);
    ModuleCallback Appearance(FeaturePointers features);
    ModuleCallback Animation(FeaturePointers features);
    ModuleCallback DevTools(FeaturePointers features);
};

struct Metadata {
    static void Aimbot(FeaturePointers features);
    static void Movement(FeaturePointers features);
    static void Render(FeaturePointers features);
    static void Misc(FeaturePointers features);
    static void Config(FeaturePointers features);
    static void HUD(FeaturePointers features);
    static void CUI(FeaturePointers features);
};

extern ModuleReg* modules;
