#include "modules.h"

Runtime vrt;
static ModuleReg mod;
ModuleReg* modules = &mod;

namespace {
	using MetadataInit = void (*) (FeaturePointers);

    void BindRuntimeArrays(Runtime& rt) {
        static const char* kGlobals[] = {
            "Проект",
            "Йор",
            "Хмм, я ищу...",
            "weekahrin",
            "Designer",
            "Unknown"
        };
        static const char* kMessages[] = {
            "Select a function to edit its settings.",
            "No functions in this tab."
        };

        auto& f = rt.features;
        static ModuleEntry* kAimbotList[] = {
            &f.aimbot.module
        };
        static ModuleEntry* kMovementList[] = {
            &f.movement.recorder,
            &f.movement.noClip,
            &f.movement.flyHack
        };
        static ModuleEntry* kRenderList[] = {
            &f.render.esp,
            &f.render.colorGrading
        };
        static ModuleEntry* kMiscList[] = {
            &f.misc.radar,
            &f.misc.recoil,
            &f.misc.noFlash,
            &f.misc.autoPistol,
            &f.misc.fastReload,
            &f.misc.audio
        };
        static ModuleEntry* kConfigList[] = {
            &f.config.module
        };
        static ModuleEntry* kHudList[] = {
            &f.hud.watermark,
            &f.hud.speedGraph
        };
        static ModuleEntry* kCuiList[] = {
            &f.cui.clickgui,
            &f.cui.appearance,
            &f.cui.animation,
            &f.cui.devTools
        };

        rt.text.globals = kGlobals;
        rt.text.globalsCount = sizeof(kGlobals) / sizeof(kGlobals[0]);
        rt.text.messages = kMessages;
        rt.text.messagesCount = sizeof(kMessages) / sizeof(kMessages[0]);

        f.aimbotList.items = kAimbotList;
        f.aimbotList.count = sizeof(kAimbotList) / sizeof(kAimbotList[0]);
        f.movementList.items = kMovementList;
        f.movementList.count = sizeof(kMovementList) / sizeof(kMovementList[0]);
        f.renderList.items = kRenderList;
        f.renderList.count = sizeof(kRenderList) / sizeof(kRenderList[0]);
        f.miscList.items = kMiscList;
        f.miscList.count = sizeof(kMiscList) / sizeof(kMiscList[0]);
        f.configList.items = kConfigList;
        f.configList.count = sizeof(kConfigList) / sizeof(kConfigList[0]);
        f.hudList.items = kHudList;
        f.hudList.count = sizeof(kHudList) / sizeof(kHudList[0]);
        f.cuiList.items = kCuiList;
        f.cuiList.count = sizeof(kCuiList) / sizeof(kCuiList[0]);
    }

	void MetadataReg(Runtime& rt) {
		FeaturePointers features = &rt.features;
        BindRuntimeArrays(rt);
		static constexpr MetadataInit Inits[] = {
			&Metadata::Aimbot,
			&Metadata::Movement,
			&Metadata::Render,
			&Metadata::Misc,
			&Metadata::Config,
			&Metadata::HUD,
			&Metadata::CUI
		};
		for (MetadataInit Init : Inits) {
			Init(features);
		}

		auto& f = rt.features;
		f.aimbot.module.renderSettings = modules->Aimbot(features);
        f.movement.recorder.renderSettings = modules->MovementRecorder(features);
		f.render.esp.renderSettings = modules->Render(features);
		f.render.colorGrading.renderSettings = modules->RenderColorGrading(features);
		f.misc.audio.renderSettings = modules->MiscAudio(features);
		f.config.module.renderSettings = modules->Config(features);
		f.hud.module.renderSettings = modules->HUD(features);
		f.hud.watermark.renderSettings = modules->HUDWatermark(features);
		f.hud.speedGraph.renderSettings = modules->HUDSpeedGraph(features);
		f.cui.clickgui.renderSettings = modules->ClickG(features);
		f.cui.appearance.renderSettings = modules->Appearance(features);
		f.cui.animation.renderSettings = modules->Animation(features);
		f.cui.devTools.renderSettings = modules->DevTools(features);
	}

	struct MetadataRuntime {
		MetadataRuntime() {
			MetadataReg(vrt);
		}
	} metadata_runtime;
}
