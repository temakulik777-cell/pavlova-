#include "../modules.h"
#include "../../clickgui/render/post_processing.h"
#include "../../axlebolt/player_controller.h"
#include <algorithm>
#include <cmath>

void Metadata::CUI(FeaturePointers features) {
    auto& c = features->cui;
    c.clickgui.name = "Theme";
    c.clickgui.description = "Theme and accent settings";
    c.clickgui.showActiveToggle = false;
    c.clickgui.hasSettings = true;
    c.appearance.name = "Appearance";
    c.appearance.description = "Visual effects and post style";
    c.appearance.showActiveToggle = false;
    c.appearance.hasSettings = true;
    c.animation.name = "Animation";
    c.animation.description = "Menu, tabs, popups and ripple animation tuning";
    c.animation.showActiveToggle = false;
    c.animation.hasSettings = true;
    c.devTools.name = "Dev Tools";
    c.devTools.description = "Runtime capture and debug helpers";
    c.devTools.showActiveToggle = false;
    c.devTools.hasSettings = true;
    c.scale.label = "Scale";
    c.scale.desc = "Global ClickGUI scale";
    c.applyScale.label = "APPLY SCALE";
    c.accentType.text.label = "Accent Type";
    c.accentType.text.desc = "Accent source mode";
    c.accentType.items[0] = "Accent";
    c.accentType.items[1] = "Accent Gradient";
    c.accentType.items[2] = "User";
    c.accentGradientDirection.text.label = "Gradient Direction";
    c.accentGradientDirection.text.desc = "Gradient direction mode";
    c.accentGradientDirection.items[0] = "Horizontal";
    c.accentGradientDirection.items[1] = "Vertical";
    c.accentColor.label = "Accent Color";
    c.accentColor.desc = "Primary and secondary accent colors";
    c.glowEffect.label = "Glow Effect";
    c.glowEffect.desc = "Enables glow on UI elements";
    c.shadowEffect.label = "Shadow";
    c.shadowEffect.desc = "Enables UI shadows on menus, popups and panels";
    c.blurEffect.label = "Blur";
    c.blurEffect.desc = "Applies blur to menu and popups";
    c.glowAlpha.label = "Glow Alpha";
    c.glowAlpha.desc = "Global glow alpha multiplier";
    c.downscaleFactor.label = "Blur Downscale";
    c.downscaleFactor.desc = "Lower value = better quality, higher cost";
    c.blurRadius.label = "Blur Radius";
    c.blurRadius.desc = "Blur spread strength";
    c.shadowRadius.label = "Shadow Radius";
    c.shadowRadius.desc = "Shadow shell radius";
    c.shadowSmoothness.label = "Shadow Smoothness";
    c.shadowSmoothness.desc = "Shadow edge smoothness";
    c.animationSpeed.label = "Menu Animation Speed";
    c.animationSpeed.desc = "Menu open/close speed";
    c.tabsAnimationSpeed.label = "Tabs Animation Speed";
    c.tabsAnimationSpeed.desc = "Sidebar tab icon/text animation speed";
    c.popupAnimationSpeed.label = "Popup Animation Speed";
    c.popupAnimationSpeed.desc = "Combo/Color popup open-close speed";
    c.rippleEnabled.label = "Ripple";
    c.rippleEnabled.desc = "Enables water ripple simulation";
    c.ripplePressRadius.label = "Press Radius";
    c.ripplePressRadius.desc = "Ripple radius for tap actions";
    c.ripplePressSpeed.label = "Press Speed";
    c.ripplePressSpeed.desc = "Ripple expansion speed on taps";
    c.ripplePressStrength.label = "Press Strength";
    c.ripplePressStrength.desc = "Ripple intensity on taps";
    c.rippleDragRadius.label = "Drag Radius";
    c.rippleDragRadius.desc = "Ripple radius while finger is moving";
    c.rippleDragStrength.label = "Drag Strength";
    c.rippleDragStrength.desc = "Ripple intensity while dragging";
    c.rippleMotionStrength.label = "Motion Strength";
    c.rippleMotionStrength.desc = "Wake strength for menu/popup movement";
    c.movementTelemetry.text.label = "Movement Telemetry";
    c.movementTelemetry.text.desc = "Write per-frame local movement samples to a separate motion log";
    c.movementTelemetryVerbose.text.label = "Verbose Telemetry";
    c.movementTelemetryVerbose.text.desc = "Include extra aim and input columns in motion log";
    c.movementTelemetryClear.label = "Clear Telemetry Log";
}

ModuleCallback ModuleReg::ClickG(FeaturePointers features) {
    return [features](WidgetManager* widgets, const ClickGUI::Settings* settings, int windowWidth, int windowHeight) {
        auto& c = features->cui;
        if (settings && settings->scale) {
            *settings->scale = widgets->add<float>(c.scale.label, *settings->scale, 0.8f, 1.5f, c.scale.desc);
            widgets->add(c.applyScale.label, [settings]() {
                if (settings && settings->gui) {
                    settings->gui->scale.Dirty = true;
                }
            });
        }

        if (settings && settings->gui) {
            if (settings->gui->theme) {
                static ClickGUI::Theme* s_accent_theme = nullptr;
                static float s_accent_r = 0.294f;
                static float s_accent_g = 0.412f;
                static float s_accent_b = 0.996f;
                static float s_accent2_r = 0.545f;
                static float s_accent2_g = 0.286f;
                static float s_accent2_b = 0.996f;
                static int s_accent_mode = static_cast<int>(ClickGUI::Theme::AccentMode::User);
                static int s_grad_dir = static_cast<int>(ClickGUI::Theme::AccentGradientDirection::Horizontal);
                static bool s_animated_accent = false;
                static float s_anim_spacing = 0.18f;
                static float s_anim_speed = 0.32f;
                static float s_anim_smoothness = 0.72f;
                static float s_anim_strength = 1.0f;

                ClickGUI::Theme* current_theme = settings->gui->theme.get();
                if (s_accent_theme != current_theme) {
                    ImVec4 accent = current_theme->GetAccentColor();
                    ImVec4 accent2 = current_theme->GetAccentGradientColor();
                    s_accent_r = accent.x;
                    s_accent_g = accent.y;
                    s_accent_b = accent.z;
                    s_accent2_r = accent2.x;
                    s_accent2_g = accent2.y;
                    s_accent2_b = accent2.z;
                    s_accent_mode = static_cast<int>(current_theme->GetAccentMode());
                    s_grad_dir = static_cast<int>(current_theme->GetAccentGradientDirection());
                    s_animated_accent = current_theme->GetAnimatedAccentEnabled();
                    s_anim_spacing = current_theme->GetAnimatedAccentColorSpacing();
                    s_anim_speed = current_theme->GetAnimatedAccentSpeed();
                    s_anim_smoothness = current_theme->GetAnimatedAccentSmoothness();
                    s_anim_strength = current_theme->GetAnimatedAccentStrength();
                    s_accent_theme = current_theme;
                }

                s_accent_mode = widgets->add(
                    c.accentType.text.label,
                    s_accent_mode,
                    c.accentType.items,
                    IM_ARRAYSIZE(c.accentType.items),
                    c.accentType.text.desc
                );
                s_accent_mode = std::clamp(s_accent_mode, 0, 2);

                const ClickGUI::Theme::AccentMode mode_enum = static_cast<ClickGUI::Theme::AccentMode>(s_accent_mode);
                if (mode_enum != ClickGUI::Theme::AccentMode::Accent) {
                    s_grad_dir = static_cast<int>(ClickGUI::Theme::AccentGradientDirection::Vertical);
                }
                if (mode_enum == ClickGUI::Theme::AccentMode::User) {
                    ImVec4 user_start, user_end;
                    current_theme->GetResolvedAccentGradient(user_start, user_end);
                    s_accent_r = user_start.x;
                    s_accent_g = user_start.y;
                    s_accent_b = user_start.z;
                    s_accent2_r = user_end.x;
                    s_accent2_g = user_end.y;
                    s_accent2_b = user_end.z;
                }

                if (mode_enum == ClickGUI::Theme::AccentMode::Accent) {
                    widgets->add(
                        c.accentColor.label,
                        &s_accent_r, &s_accent_g, &s_accent_b,
                        0.0f, 1.0f,
                        c.accentColor.desc
                    );
                } else {
                    widgets->add(
                        c.accentColor.label,
                        &s_accent_r, &s_accent_g, &s_accent_b,
                        &s_accent2_r, &s_accent2_g, &s_accent2_b,
                        0.0f, 1.0f,
                        c.accentColor.desc
                    );
                }

                if (mode_enum == ClickGUI::Theme::AccentMode::AccentGradient ||
                    mode_enum == ClickGUI::Theme::AccentMode::User) {
                    s_animated_accent = widgets->add("Animated", s_animated_accent, "Animated linked tint for stripes and graph");
                    if (s_animated_accent) {
                        s_anim_spacing = widgets->add<float>("Color Interval", s_anim_spacing, 0.02f, 1.0f, "Distance between alternating accent bands");
                        s_anim_speed = widgets->add<float>("Anim Speed", s_anim_speed, 0.0f, 3.0f, "Animation speed for accent band motion");
                        s_anim_smoothness = widgets->add<float>("Smoothness", s_anim_smoothness, 0.02f, 1.0f, "Band transition softness");
                        s_anim_strength = widgets->add<float>("Strength", s_anim_strength, 0.0f, 1.5f, "Animated tint strength");
                    }
                } else {
                    s_animated_accent = false;
                }

                ImVec4 active_accent = current_theme->GetAccentColor();
                ImVec4 active_accent2 = current_theme->GetAccentGradientColor();
                const int active_mode = static_cast<int>(current_theme->GetAccentMode());
                const int active_grad_dir = static_cast<int>(current_theme->GetAccentGradientDirection());
                bool need_apply = (active_mode != s_accent_mode) || (active_grad_dir != s_grad_dir) ||
                    current_theme->GetAnimatedAccentEnabled() != s_animated_accent ||
                    fabsf(current_theme->GetAnimatedAccentColorSpacing() - s_anim_spacing) > 0.0005f ||
                    fabsf(current_theme->GetAnimatedAccentSpeed() - s_anim_speed) > 0.0005f ||
                    fabsf(current_theme->GetAnimatedAccentSmoothness() - s_anim_smoothness) > 0.0005f ||
                    fabsf(current_theme->GetAnimatedAccentStrength() - s_anim_strength) > 0.0005f;
                if (mode_enum == ClickGUI::Theme::AccentMode::Accent ||
                    mode_enum == ClickGUI::Theme::AccentMode::AccentGradient) {
                    if (fabsf(active_accent.x - s_accent_r) > 0.0005f ||
                        fabsf(active_accent.y - s_accent_g) > 0.0005f ||
                        fabsf(active_accent.z - s_accent_b) > 0.0005f) {
                        need_apply = true;
                    }
                }
                if (mode_enum == ClickGUI::Theme::AccentMode::AccentGradient) {
                    if (fabsf(active_accent2.x - s_accent2_r) > 0.0005f ||
                        fabsf(active_accent2.y - s_accent2_g) > 0.0005f ||
                        fabsf(active_accent2.z - s_accent2_b) > 0.0005f) {
                        need_apply = true;
                    }
                }
                if (need_apply) {
                    if (mode_enum == ClickGUI::Theme::AccentMode::Accent ||
                        mode_enum == ClickGUI::Theme::AccentMode::AccentGradient) {
                        current_theme->SetAccentColor(s_accent_r, s_accent_g, s_accent_b);
                    }
                    if (mode_enum == ClickGUI::Theme::AccentMode::AccentGradient) {
                        current_theme->SetAccentGradientColor(s_accent2_r, s_accent2_g, s_accent2_b);
                    }
                    current_theme->SetAccentMode(mode_enum);
                    current_theme->SetAccentGradientDirection(static_cast<ClickGUI::Theme::AccentGradientDirection>(s_grad_dir));
                    current_theme->SetAnimatedAccentEnabled(s_animated_accent);
                    current_theme->SetAnimatedAccentParams(s_anim_spacing, s_anim_speed, s_anim_smoothness, s_anim_strength);
                    current_theme->ApplyTheme();
                    settings->gui->Preload();
                }
            }

            (void)windowWidth;
            (void)windowHeight;
        }
    };
}

ModuleCallback ModuleReg::Appearance(FeaturePointers features) {
    return [features](WidgetManager* widgets, const ClickGUI::Settings* settings, int, int) {
        auto& c = features->cui;
        static const char* const effects_items[] = {"Glow", "Shadow", "Blur", "Trans"};
        uint32_t effects_mask = 0u;
        if (post_processing.flags.glow) {
            effects_mask |= (1u << 0);
        }
        if (post_processing.flags.shadow) {
            effects_mask |= (1u << 1);
        }
        if (post_processing.flags.blur) {
            effects_mask |= (1u << 2);
        }
        if (settings && settings->gui && settings->gui->tabMorphEnabled) {
            effects_mask |= (1u << 3);
        }
        SectionSeparator("Effects");
        effects_mask = widgets->addMultiCombo(
            "Effects",
            effects_mask,
            effects_items,
            IM_ARRAYSIZE(effects_items),
            "UI effects toggles"
        );
        post_processing.flags.glow = (effects_mask & (1u << 0)) != 0u;
        post_processing.flags.shadow = (effects_mask & (1u << 1)) != 0u;
        post_processing.flags.blur = (effects_mask & (1u << 2)) != 0u;
        if (settings && settings->gui) {
            settings->gui->tabMorphEnabled = (effects_mask & (1u << 3)) != 0u;
        }
        post_processing.flags.glow_alpha_scale = widgets->add<float>(
            c.glowAlpha.label,
            post_processing.flags.glow_alpha_scale,
            0.1f,
            1.5f,
            c.glowAlpha.desc
        );

        if (settings && settings->gui) {
            settings->gui->sidebar.BlurType = Blur::Type::Yorozka;
            if (settings->blurEnabled) {
                *settings->blurEnabled = post_processing.flags.blur;
            }
            SectionSeparator("Blur");
            settings->gui->sidebar.DownscaleFactor = widgets->add<int>(
                c.downscaleFactor.label,
                settings->gui->sidebar.DownscaleFactor,
                2,
                64,
                c.downscaleFactor.desc
            );
            settings->gui->sidebar.BlurRadius = widgets->add<float>(
                c.blurRadius.label,
                settings->gui->sidebar.BlurRadius,
                0.2f,
                3.5f,
                c.blurRadius.desc
            );

            SectionSeparator("Shadow");
            settings->gui->appearance.shadowRings = widgets->add<int>(
                c.shadowRadius.label,
                settings->gui->appearance.shadowRings,
                6,
                28,
                c.shadowRadius.desc
            );
            settings->gui->appearance.shadowSmoothness = widgets->add<float>(
                c.shadowSmoothness.label,
                settings->gui->appearance.shadowSmoothness,
                0.35f,
                1.60f,
                c.shadowSmoothness.desc
            );
        }
    };
}

ModuleCallback ModuleReg::DevTools(FeaturePointers features) {
    return [features](WidgetManager* widgets, const ClickGUI::Settings*, int, int) {
        auto& c = features->cui;
        c.movementTelemetry.value = widgets->add(
            c.movementTelemetry.text.label,
            c.movementTelemetry.value,
            c.movementTelemetry.text.desc
        );
        c.movementTelemetryVerbose.value = widgets->add(
            c.movementTelemetryVerbose.text.label,
            c.movementTelemetryVerbose.value,
            c.movementTelemetryVerbose.text.desc
        );
        Axlebolt::PlayerControllerHook::SetMovementTelemetryEnabled(c.movementTelemetry.value);
        Axlebolt::PlayerControllerHook::SetMovementTelemetryVerbose(c.movementTelemetryVerbose.value);
        widgets->add(c.movementTelemetryClear.label, []() {
            Axlebolt::PlayerControllerHook::ClearMovementTelemetryLog();
        });
    };
}

ModuleCallback ModuleReg::Animation(FeaturePointers features) {
    return [features](WidgetManager* widgets, const ClickGUI::Settings* settings, int, int) {
        auto& c = features->cui;
        if (!settings || !settings->gui) {
            return;
        }

        SectionSeparator("Timeline");
        settings->gui->animationTuning.menuSpeed = widgets->add<float>(
            c.animationSpeed.label,
            settings->gui->animationTuning.menuSpeed,
            0.20f, 4.00f,
            c.animationSpeed.desc
        );
        settings->gui->animationTuning.tabsSpeed = widgets->add<float>(
            c.tabsAnimationSpeed.label,
            settings->gui->animationTuning.tabsSpeed,
            0.20f, 4.00f,
            c.tabsAnimationSpeed.desc
        );
        settings->gui->animationTuning.popupSpeed = widgets->add<float>(
            c.popupAnimationSpeed.label,
            settings->gui->animationTuning.popupSpeed,
            0.20f, 4.00f,
            c.popupAnimationSpeed.desc
        );

        SectionSeparator("Ripple");
        settings->gui->menuRippleEnabled = widgets->add(
            c.rippleEnabled.label,
            settings->gui->menuRippleEnabled,
            c.rippleEnabled.desc
        );
        settings->gui->rippleTuning.pressRadius = widgets->add<float>(
            c.ripplePressRadius.label,
            settings->gui->rippleTuning.pressRadius,
            0.20f, 3.00f,
            c.ripplePressRadius.desc
        );
        settings->gui->rippleTuning.pressSpeed = widgets->add<float>(
            c.ripplePressSpeed.label,
            settings->gui->rippleTuning.pressSpeed,
            0.20f, 3.00f,
            c.ripplePressSpeed.desc
        );
        settings->gui->rippleTuning.pressStrength = widgets->add<float>(
            c.ripplePressStrength.label,
            settings->gui->rippleTuning.pressStrength,
            0.20f, 3.00f,
            c.ripplePressStrength.desc
        );
        settings->gui->rippleTuning.dragRadius = widgets->add<float>(
            c.rippleDragRadius.label,
            settings->gui->rippleTuning.dragRadius,
            0.20f, 4.00f,
            c.rippleDragRadius.desc
        );
        settings->gui->rippleTuning.dragStrength = widgets->add<float>(
            c.rippleDragStrength.label,
            settings->gui->rippleTuning.dragStrength,
            0.20f, 4.00f,
            c.rippleDragStrength.desc
        );
        settings->gui->rippleTuning.motionStrength = widgets->add<float>(
            c.rippleMotionStrength.label,
            settings->gui->rippleTuning.motionStrength,
            0.20f, 4.00f,
            c.rippleMotionStrength.desc
        );
    };
}
