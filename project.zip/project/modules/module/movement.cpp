#include "../modules.h"
#include "../../axlebolt/player_controller.h"
#include <algorithm>

void Metadata::Movement(FeaturePointers features) {
    auto& m = features->movement;
    m.recorder.name = "Movement Recorder";
    m.recorder.description = "Record and replay jump paths with timing";
    m.recorder.hasSettings = true;
    m.noClip.name = "No Clip";
    m.noClip.description = "Move freely through obstacles";
    m.flyHack.name = "Fly Hack";
    m.flyHack.description = "Allows continuous flight movement";
    m.recorderShowPath.text.label = "Show Path";
    m.recorderShowPath.text.desc = "Show recorded world path";
    m.recorderStartRadius.text.label = "Start Radius";
    m.recorderStartRadius.text.desc = "How close you must be to arm playback";
    m.recorderSeekSpeed.text.label = "Return Speed";
    m.recorderSeekSpeed.text.desc = "How fast the player is moved back to the start";
    m.recorderSlot.text.label = "Slot";
    m.recorderSlot.text.desc = "Select which movement slot to use";
    m.recorderSlot.items[0] = "Slot 1";
    m.recorderSlot.items[1] = "Slot 2";
    m.recorderSlot.items[2] = "Slot 3";
    m.recorderSlot.items[3] = "Slot 4";
    m.recorderPosition.label = "Overlay Position";
    m.recorderPosition.desc = "Move recorder overlay by screen grid";
    m.recorderRecordAction = "Rec";
    m.recorderStopAction = "Idle";
    m.recorderClearAction = "Del";
    m.recorderPathAction = "Path";
}

ModuleCallback ModuleReg::Movement(FeaturePointers features) {
    return [features](WidgetManager*, const ClickGUI::Settings*, int, int) {
        (void)features;
    };
}

ModuleCallback ModuleReg::MovementRecorder(FeaturePointers features) {
    return [features](WidgetManager* widgets, const ClickGUI::Settings* settings, int, int) {
        auto& m = features->movement;
        ClickGUI* gui = settings ? settings->gui : nullptr;

        static int selected_slot = 0;
        selected_slot = widgets->add(
            m.recorderSlot.text.label,
            selected_slot,
            m.recorderSlot.items,
            IM_ARRAYSIZE(m.recorderSlot.items),
            m.recorderSlot.text.desc
        );
        selected_slot = std::clamp(selected_slot, 0, (int)Axlebolt::PlayerControllerHook::kRecorderSlotCount - 1);
        Axlebolt::PlayerControllerHook::SetRecorderSelectedSlot((size_t)selected_slot);
        Axlebolt::PlayerControllerHook::SetRecorderAutoPlaybackEnabled(m.recorder.enabled);

        widgets->addActionQuad(
            {m.recorderClearAction, m.recorderStopAction, m.recorderRecordAction, m.recorderPathAction},
            {
                []() { Axlebolt::PlayerControllerHook::ClearMovementRecording((size_t)selected_slot); },
                []() { Axlebolt::PlayerControllerHook::StopMovementRecorder(); },
                []() { Axlebolt::PlayerControllerHook::StartMovementRecording((size_t)selected_slot); },
                []() { vrt.features.movement.recorderShowPath.value = !vrt.features.movement.recorderShowPath.value; }
            }
        );

        if (gui) {
            const int screen_w = (glWidth > 0) ? glWidth : 1920;
            const int screen_h = (glHeight > 0) ? glHeight : 1080;
            float screen_aspect = 16.0f / 9.0f;
            if (screen_w > 0 && screen_h > 0) {
                screen_aspect = (float)screen_w / (float)screen_h;
            }
            widgets->add(
                m.recorderPosition.label,
                &gui->movementRecorderNormX,
                &gui->movementRecorderNormY,
                screen_aspect,
                m.recorderPosition.desc,
                gui->movementRecorderVisibleWidthNorm,
                gui->movementRecorderVisibleHeightNorm,
                gui->movementRecorderExpandedWidthNorm
            );
        }
    };
}
