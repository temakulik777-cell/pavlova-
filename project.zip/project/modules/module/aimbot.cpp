#include "../modules.h"

void Metadata::Aimbot(FeaturePointers features) {
    auto& a = features->aimbot;
    a.module.name = "Aimbot";
    a.module.description = "Automatically aims at enemies when they come into view";
    a.module.hasSettings = true;
    a.modeChoice.text.label = "Mode";
    a.modeChoice.text.desc = "Select aiming behavior profile";
    a.modeChoice.items[0] = "Silent";
    a.modeChoice.items[1] = "Rotation";
    a.modeChoice.items[2] = "Ai Rotation";
    a.fov.text.label = "Field of View";
    a.fov.text.desc = "Targeting field of view for aim assist";
    a.silentAim.text.label = "Silent Aim";
    a.silentAim.text.desc = "Shots register without visible aim adjustment";
    a.smoothAim.text.label = "Smooth Aim";
    a.smoothAim.text.desc = "Enables gradual aim movement";
    a.smoothFactor.text.label = "Smooth Factor";
    a.smoothFactor.text.desc = "Higher values make aiming smoother but slower";
    a.silentAutoShot.text.label = "Auto Shot";
    a.silentAutoShot.text.desc = "Placeholder: auto-fire when silent lock is valid";
    a.silentReaction.text.label = "Reaction Time";
    a.silentReaction.text.desc = "Placeholder: delay before silent shot trigger";
    a.rotationCompensate.text.label = "Recoil Compensation";
    a.rotationCompensate.text.desc = "Placeholder: rotation recoil compensation";
    a.rotationSpeed.text.label = "Rotation Speed";
    a.rotationSpeed.text.desc = "Placeholder: rotation speed limit";
    a.aiRotationAdaptive.text.label = "Adaptive Targeting";
    a.aiRotationAdaptive.text.desc = "Placeholder: adaptive target movement model";
    a.aiRotationConfidence.text.label = "Confidence";
    a.aiRotationConfidence.text.desc = "Placeholder: minimum AI confidence threshold";
}

ModuleCallback ModuleReg::Aimbot(FeaturePointers features) {
    return [features](WidgetManager* widgets, const ClickGUI::Settings*, int, int) {
        auto& a = features->aimbot;

        a.mode = widgets->add(
            a.modeChoice.text.label,
            a.mode,
            a.modeChoice.items,
            static_cast<int>(sizeof(a.modeChoice.items) / sizeof(a.modeChoice.items[0])),
            a.modeChoice.text.desc
        );

        a.fov.value = widgets->add<float>(a.fov.text.label, a.fov.value, 0.0f, 100.0f, a.fov.text.desc);

        switch (a.mode) {
            case 0:
                a.silentAim.value = widgets->add(a.silentAim.text.label, a.silentAim.value, a.silentAim.text.desc);
                a.silentAutoShot.value = widgets->add(a.silentAutoShot.text.label, a.silentAutoShot.value, a.silentAutoShot.text.desc);
                a.silentReaction.value = widgets->add<float>(a.silentReaction.text.label, a.silentReaction.value, 0.0f, 1.0f, a.silentReaction.text.desc);
                break;
            case 1:
                a.smoothAim.value = widgets->add(a.smoothAim.text.label, a.smoothAim.value, a.smoothAim.text.desc);
                a.smoothFactor.value = widgets->add<float>(a.smoothFactor.text.label, a.smoothFactor.value, 0.0f, 100.0f, a.smoothFactor.text.desc);
                a.rotationCompensate.value = widgets->add(a.rotationCompensate.text.label, a.rotationCompensate.value, a.rotationCompensate.text.desc);
                a.rotationSpeed.value = widgets->add<float>(a.rotationSpeed.text.label, a.rotationSpeed.value, 1.0f, 100.0f, a.rotationSpeed.text.desc);
                break;
            case 2:
            default:
                a.smoothAim.value = widgets->add(a.smoothAim.text.label, a.smoothAim.value, a.smoothAim.text.desc);
                a.aiRotationAdaptive.value = widgets->add(a.aiRotationAdaptive.text.label, a.aiRotationAdaptive.value, a.aiRotationAdaptive.text.desc);
                a.aiRotationConfidence.value = widgets->add<float>(a.aiRotationConfidence.text.label, a.aiRotationConfidence.value, 0.0f, 1.0f, a.aiRotationConfidence.text.desc);
                break;
        }
    };
}
