#include "../modules.h"

void Metadata::Misc(FeaturePointers features) {
    auto& m = features->misc;
    m.radar.name = "Mini Map Radar";
    m.radar.description = "Shows nearby players on a radar";
    m.recoil.name = "Recoil Crosshair";
    m.recoil.description = "Shows recoil offset on crosshair";
    m.noFlash.name = "No Flash";
    m.noFlash.description = "Reduces flash effects";
    m.autoPistol.name = "Auto Pistol";
    m.autoPistol.description = "Automatically fires pistols";
    m.fastReload.name = "Fast Reload";
    m.fastReload.description = "Speeds up reload animation";
    m.audio.name = "Audio";
    m.audio.description = "Adjusts game audio settings";
    m.audio.enabled = true;
    m.audio.hasSettings = true;
    m.masterVolume.text.label = "Master Volume";
    m.masterVolume.text.desc = "Overall game volume level";
}

ModuleCallback ModuleReg::MiscAudio(FeaturePointers features) {
    return [features](WidgetManager* widgets, const ClickGUI::Settings*, int, int) {
        auto& misc = features->misc;
        misc.masterVolume.value = widgets->add<float>(misc.masterVolume.text.label, misc.masterVolume.value, 0.0f, 100.0f, misc.masterVolume.text.desc);
    };
}
