#include "../modules.h"
#include "../../clickgui/render/post_processing.h"
#include <algorithm>

void Metadata::Render(FeaturePointers features) {
    auto& r = features->render;
    r.esp.name = "ESP";
    r.esp.description = "Highlights players with visual overlays";
    r.esp.hasSettings = true;
    r.colorGrading.name = "Color Grading";
    r.colorGrading.description = "Screen tone and tint controls";
    r.colorGrading.enabled = false;
    r.colorGrading.hasSettings = true;
    r.boxEsp.text.label = "Box ESP";
    r.boxEsp.text.desc = "Draws boxes around enemies";
    r.skeletonEsp.text.label = "Skeleton ESP";
    r.skeletonEsp.text.desc = "Shows bone skeleton overlay";
    r.nameEsp.text.label = "Name ESP";
    r.nameEsp.text.desc = "Displays player names";
    r.healthBar.text.label = "Health Bar";
    r.healthBar.text.desc = "Shows current health";
    r.renderDistance.text.label = "Render Distance";
    r.renderDistance.text.desc = "Maximum distance to draw ESP elements";
    r.colorGradingPreset.text.label = "Color Grading Preset";
    r.colorGradingPreset.text.desc = "Choose grading preset";
    r.colorGradingPreset.items[0] = "Default";
    r.colorGradingPreset.items[1] = "Cinematic";
    r.colorGradingPreset.items[2] = "Vibrant";
    r.colorGradingPreset.items[3] = "Warm";
    r.colorGradingPreset.items[4] = "Cold";
    r.colorGradingPreset.items[5] = "Noir";
    r.colorGradingPreset.items[6] = "Dream";
    r.colorGradingPreset.items[7] = "Toxic";
    r.tintColor.label = "Tint Color";
    r.tintColor.desc = "RGB tint multipliers";
    r.gradingCurve.label = "Grading Curve";
    r.gradingCurve.desc = "Tone controls: saturation, contrast, brightness, vibrance, gamma";
    r.gradingCurveNames.names[0] = "Sat";
    r.gradingCurveNames.names[1] = "Ctr";
    r.gradingCurveNames.names[2] = "Bri";
    r.gradingCurveNames.names[3] = "Vib";
    r.gradingCurveNames.names[4] = "Gam";
}

ModuleCallback ModuleReg::Render(FeaturePointers features) {
    return [features](WidgetManager* widgets, const ClickGUI::Settings*, int, int) {
        auto& r = features->render;
        r.boxEsp.value = widgets->add(r.boxEsp.text.label, r.boxEsp.value, r.boxEsp.text.desc);
        r.skeletonEsp.value = widgets->add(r.skeletonEsp.text.label, r.skeletonEsp.value, r.skeletonEsp.text.desc);
        r.nameEsp.value = widgets->add(r.nameEsp.text.label, r.nameEsp.value, r.nameEsp.text.desc);
        r.healthBar.value = widgets->add(r.healthBar.text.label, r.healthBar.value, r.healthBar.text.desc);
        r.renderDistance.value = widgets->add<float>(r.renderDistance.text.label, r.renderDistance.value, 0.0f, 100.0f, r.renderDistance.text.desc);
    };
}

ModuleCallback ModuleReg::RenderColorGrading(FeaturePointers features) {
    return [features](WidgetManager* widgets, const ClickGUI::Settings*, int, int) {
        auto& r = features->render;
        post_processing.color_grading.enabled = r.colorGrading.enabled;

        int cg_idx = post_processing.color_grading.preset_index;
        cg_idx = widgets->add(r.colorGradingPreset.text.label, cg_idx, r.colorGradingPreset.items, IM_ARRAYSIZE(r.colorGradingPreset.items), r.colorGradingPreset.text.desc);
        cg_idx = std::clamp(cg_idx, 0, 7);
        static int s_prev_cg_idx = -1;
        if (s_prev_cg_idx != cg_idx) {
            post_processing.color_grading.current = post_processing.color_grading.presets[cg_idx];
            s_prev_cg_idx = cg_idx;
        }
        post_processing.color_grading.preset_index = cg_idx;

        auto& preset = post_processing.color_grading.current;
        widgets->add(
            r.tintColor.label,
            &preset.tint_r, &preset.tint_g, &preset.tint_b,
            0.7f, 1.3f,
            r.tintColor.desc
        );

        float grading_values[5] = {
            preset.saturation, preset.contrast, preset.brightness, preset.vibrance, preset.gamma
        };
        const char* const* grading_names = r.gradingCurveNames.names;
        const float grading_mins[5] = {0.0f, 0.5f, -0.25f, 0.0f, 0.6f};
        const float grading_maxs[5] = {2.5f, 2.0f, 0.25f, 1.0f, 1.8f};
        widgets->add(
            r.gradingCurve.label,
            grading_values, 5, grading_names, grading_mins, grading_maxs,
            r.gradingCurve.desc
        );
        preset.saturation = grading_values[0];
        preset.contrast = grading_values[1];
        preset.brightness = grading_values[2];
        preset.vibrance = grading_values[3];
        preset.gamma = grading_values[4];
    };
}
