#include "../modules.h"

void Metadata::Config(FeaturePointers features) {
    auto& c = features->config;
    c.module.name = "Config";
    c.module.description = "Configuration profiles";
    c.module.hasSettings = true;
    c.selectConfig.text.label = "Select Config";
    c.selectConfig.text.desc = "Choose active config profile";
    c.selectConfig.items[0] = "Config 1";
    c.selectConfig.items[1] = "Config 2";
    c.selectConfig.items[2] = "Config 3";
    c.selectConfig.items[3] = "Config 4";
    c.selectConfig.items[4] = "Config 5";
    c.scrollbarSize.label = "Scrollbar Size";
    c.applyTheme.label = "Apply Theme";
    c.downscaleFactor.label = "Downscale Factor";
    c.cornerRadius.label = "Corner Radius";
}

ModuleCallback ModuleReg::Config(FeaturePointers features) {
    return [features](WidgetManager* widgets, const ClickGUI::Settings* settings, int, int) {
        auto& cfg = features->config;
        static int selected_config = 0;
        selected_config = widgets->add(cfg.selectConfig.text.label, selected_config, cfg.selectConfig.items, IM_ARRAYSIZE(cfg.selectConfig.items), cfg.selectConfig.text.desc);

        if (settings && settings->scrollbarSize) {
            *settings->scrollbarSize = widgets->add<float>(cfg.scrollbarSize.label, *settings->scrollbarSize);
            widgets->add(cfg.applyTheme.label, [settings]() {
                if (settings && settings->updateThemeCallback) {
                    settings->updateThemeCallback(*settings->scale);
                }
            });
        }

        if (settings && settings->downscaleFactor && settings->cornerRadius) {
            *settings->downscaleFactor = widgets->add<int>(cfg.downscaleFactor.label, *settings->downscaleFactor);
            *settings->cornerRadius = widgets->add<float>(cfg.cornerRadius.label, *settings->cornerRadius);
        }
    };
}
