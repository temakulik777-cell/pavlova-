#include "../modules.h"
#include <cstdio>

void Metadata::HUD(FeaturePointers features) {
    auto& h = features->hud;
    h.module.name = "HUD";
    h.module.description = "Heads-up display options";
    h.module.hasSettings = true;
    h.watermark.name = "Watermark";
    h.watermark.description = "Position and info flags";
    h.watermark.showActiveToggle = false;
    h.watermark.hasSettings = true;
    h.speedGraph.name = "Speed Graph";
    h.speedGraph.description = "Always-on movement speed graph";
    h.speedGraph.showActiveToggle = true;
    h.speedGraph.hasSettings = true;
    h.showFpsCounter.label = "Show FPS Counter";
    h.showFpsCounter.desc = "Displays current frame rate";
    h.showPing.label = "Show Ping";
    h.showPing.desc = "Displays network latency";
    h.showCoordinates.label = "Show Coordinates";
    h.showCoordinates.desc = "Shows player world position";
    h.showCustomCrosshair.label = "Show Custom Crosshair";
    h.showCustomCrosshair.desc = "Renders custom crosshair";
    h.crosshairStyle.text.label = "Crosshair Style";
    h.crosshairStyle.text.desc = "Current crosshair preset";
    h.crosshairStyle.items[0] = "Dot";
    h.crosshairStyle.items[1] = "Cross";
    h.crosshairStyle.items[2] = "+";
    h.crosshairStyle.items[3] = "Circle";
    h.crosshairStyle.items[4] = "Square";
    h.watermarkPosition.label = "Position";
    h.watermarkPosition.desc = "Move by screen grid";
    h.watermarkBgAlphaNoBlur.label = "Background Alpha";
    h.watermarkBgAlphaNoBlur.desc = "Opacity of background when blur is disabled";
    h.watermarkScale.label = "Scale";
    h.watermarkScale.desc = "Overall size";
    h.watermarkTextAlpha.label = "Text Alpha";
    h.watermarkTextAlpha.desc = "Global text opacity";
    h.watermarkSeparatorAlpha.label = "Separator Alpha";
    h.watermarkSeparatorAlpha.desc = "Opacity of vertical separators";
    h.watermarkPaddingScale.label = "Padding Scale";
    h.watermarkPaddingScale.desc = "Inner horizontal/vertical spacing";
    h.watermarkInfoFlags.label = "Info";
    h.watermarkInfoFlags.desc = "Select which info blocks to show";
    h.watermarkNicknameColor.label = "Nickname Color";
    h.watermarkNicknameColor.desc = "Color source for nickname and user icon";
    h.watermarkNicknameUserColors.label = "Nickname User Colors";
    h.watermarkNicknameUserColors.desc = "Custom nickname gradient";
    h.speedGraphPosition.label = "Position";
    h.speedGraphPosition.desc = "Move graph by screen grid";
    h.valueTextTag = "Text";
    h.prefixWindowSize = "Window Size: ";
    h.prefixScaledDimensions = "Scaled Dimensions: ";
    h.prefixDownscale = "Downscale: ";
}

ModuleCallback ModuleReg::HUDSpeedGraph(FeaturePointers features) {
    return [features](WidgetManager* widgets, const ClickGUI::Settings* settings, int, int) {
        auto& hud = features->hud;
        if (!settings || !settings->gui) {
            return;
        }

        ClickGUI* gui = settings->gui;
        const int screen_w = (glWidth > 0) ? glWidth : 1920;
        const int screen_h = (glHeight > 0) ? glHeight : 1080;
        float screen_aspect = 16.0f / 9.0f;
        if (screen_w > 0 && screen_h > 0) {
            screen_aspect = (float)screen_w / (float)screen_h;
        }

        widgets->add(
            hud.speedGraphPosition.label,
            &gui->speedGraphNormX,
            &gui->speedGraphNormY,
            screen_aspect,
            hud.speedGraphPosition.desc,
            gui->speedGraphVisibleWidthNorm,
            gui->speedGraphVisibleHeightNorm,
            gui->speedGraphExpandedWidthNorm
        );
    };
}

ModuleCallback ModuleReg::HUD(FeaturePointers features) {
    return [features](WidgetManager* widgets, const ClickGUI::Settings* settings, int windowWidth, int windowHeight) {
        auto& hud = features->hud;
        (void)widgets->add(hud.showFpsCounter.label, true, hud.showFpsCounter.desc);
        (void)widgets->add(hud.showPing.label, true, hud.showPing.desc);
        (void)widgets->add(hud.showCoordinates.label, false, hud.showCoordinates.desc);
        (void)widgets->add(hud.showCustomCrosshair.label, true, hud.showCustomCrosshair.desc);

        static int crosshair_style = 0;
        crosshair_style = widgets->add(hud.crosshairStyle.text.label, crosshair_style, hud.crosshairStyle.items, IM_ARRAYSIZE(hud.crosshairStyle.items), hud.crosshairStyle.text.desc);

        if (settings) {
            char line0[96];
            char line1[96];
            char line2[96];
            std::snprintf(line0, sizeof(line0), "%s%dx%d", hud.prefixWindowSize, windowWidth, windowHeight);
            std::snprintf(line1, sizeof(line1), "%s%dx%d", hud.prefixScaledDimensions,
                static_cast<int>(settings->width * (*settings->scale)),
                static_cast<int>(settings->height * (*settings->scale)));
            std::snprintf(line2, sizeof(line2), "%s%d", hud.prefixDownscale, *settings->downscaleFactor);
            widgets->add(line0, hud.valueTextTag);
            widgets->add(line1, hud.valueTextTag);
            widgets->add(line2, hud.valueTextTag);
        }
    };
}

ModuleCallback ModuleReg::HUDWatermark(FeaturePointers features) {
    return [features](WidgetManager* widgets, const ClickGUI::Settings* settings, int, int) {
        auto& hud = features->hud;
        if (!settings || !settings->gui) {
            return;
        }
        ClickGUI* gui = settings->gui;
        const int screen_w = (glWidth > 0) ? glWidth : 1920;
        const int screen_h = (glHeight > 0) ? glHeight : 1080;
        float screen_aspect = 16.0f / 9.0f;
        if (screen_w > 0 && screen_h > 0) {
            screen_aspect = (float)screen_w / (float)screen_h;
        }

        widgets->add(
            hud.watermarkPosition.label,
            &gui->watermarkNormX,
            &gui->watermarkNormY,
            screen_aspect,
            hud.watermarkPosition.desc,
            gui->watermarkVisibleWidthNorm,
            gui->watermarkVisibleHeightNorm,
            gui->watermarkExpandedWidthNorm
        );
        gui->watermarkBgAlphaNoBlur = widgets->add<float>(
            hud.watermarkBgAlphaNoBlur.label,
            gui->watermarkBgAlphaNoBlur,
            0.10f,
            1.0f,
            hud.watermarkBgAlphaNoBlur.desc
        );
        gui->watermarkScale = widgets->add<float>(
            hud.watermarkScale.label,
            gui->watermarkScale,
            0.75f,
            1.85f,
            hud.watermarkScale.desc
        );
        gui->watermarkTextAlpha = widgets->add<float>(
            hud.watermarkTextAlpha.label,
            gui->watermarkTextAlpha,
            0.25f,
            1.0f,
            hud.watermarkTextAlpha.desc
        );
        gui->watermarkSeparatorAlpha = widgets->add<float>(
            hud.watermarkSeparatorAlpha.label,
            gui->watermarkSeparatorAlpha,
            0.10f,
            2.0f,
            hud.watermarkSeparatorAlpha.desc
        );
        gui->watermarkPaddingScale = widgets->add<float>(
            hud.watermarkPaddingScale.label,
            gui->watermarkPaddingScale,
            0.70f,
            1.75f,
            hud.watermarkPaddingScale.desc
        );
        static const char* const wm_items[] = {
            "Time",
            "Free RAM",
            "GPU Load"
        };
        gui->watermarkInfoMask = widgets->addMultiCombo(
            hud.watermarkInfoFlags.label,
            gui->watermarkInfoMask,
            wm_items,
            IM_ARRAYSIZE(wm_items),
            hud.watermarkInfoFlags.desc
        );
        static const char* const nick_color_items[] = {
            "Default",
            "Theme",
            "User"
        };
        gui->watermarkNicknameColorMode = widgets->add(
            hud.watermarkNicknameColor.label,
            gui->watermarkNicknameColorMode,
            nick_color_items,
            IM_ARRAYSIZE(nick_color_items),
            hud.watermarkNicknameColor.desc
        );
        if (gui->watermarkNicknameColorMode == 2) {
            widgets->add(
                hud.watermarkNicknameUserColors.label,
                &gui->watermarkNicknameColor1[0],
                &gui->watermarkNicknameColor1[1],
                &gui->watermarkNicknameColor1[2],
                &gui->watermarkNicknameColor2[0],
                &gui->watermarkNicknameColor2[1],
                &gui->watermarkNicknameColor2[2],
                0.0f,
                1.0f,
                hud.watermarkNicknameUserColors.desc
            );
        }
    };
}
