#include "libc.h"
#include "../xdl/xdl.h"

    int (*_printf)(const char* format, ...) = nullptr;
    int (*_sprintf)(char* str, const char* format, ...) = nullptr;
    int (*_snprintf)(char* str, size_t size, const char* format, ...) = nullptr;
    int (*_fprintf)(void* stream, const char* format, ...) = nullptr;
    int (*_scanf)(const char* format, ...) = nullptr;
    int (*_sscanf)(const char* str, const char* format, ...) = nullptr;
    char* (*_gets)(char* str) = nullptr;
    char* (*_fgets)(char* str, int count, void* stream) = nullptr;
    int (*_puts)(const char* str) = nullptr;
    int (*_fputs)(const char* str, void* stream) = nullptr;
    int (*_fgetc)(void* stream) = nullptr;
    int (*_getc)(void* stream) = nullptr;
    int (*_getchar)() = nullptr;
    int (*_putchar)(int ch) = nullptr;
    int (*_fputc)(int ch, void* stream) = nullptr;
    void* (*_fopen)(const char* filename, const char* mode) = nullptr;
    int (*_fclose)(void* stream) = nullptr;
    int (*_fflush_)(void* stream) = nullptr;
    size_t (*_fread)(void* ptr, size_t size, size_t count, void* stream) = nullptr;
    size_t (*_fwrite)(const void* ptr, size_t size, size_t count, void* stream) = nullptr;
    int (*_fseek)(void* stream, long offset, int origin) = nullptr;
    long (*_ftell)(void* stream) = nullptr;
    void (*_rewind)(void* stream) = nullptr;
    int (*_feof)(void* stream) = nullptr;
    int (*_ferror)(void* stream) = nullptr;
    void* (*_memcpy)(void* dest, const void* src, size_t count) = nullptr;
    void* (*_memmove)(void* dest, const void* src, size_t count) = nullptr;
    void* (*_memset)(void* dest, int ch, size_t count) = nullptr;
    int (*_memcmp)(const void* lhs, const void* rhs, size_t count) = nullptr;
    void* (*_memchr)(const void* ptr, int ch, size_t count) = nullptr;
    int (*_vsnprintf)(char* buffer, size_t count, const char* format, void* arg) = nullptr;
    char* (*_strcpy)(char* dest, const char* src) = nullptr;
    char* (*_strncpy)(char* dest, const char* src, size_t count) = nullptr;
    char* (*_strcat)(char* dest, const char* src) = nullptr;
    char* (*_strncat)(char* dest, const char* src, size_t count) = nullptr;
    int (*_strcmp)(const char* lhs, const char* rhs) = nullptr;
    int (*_strncmp)(const char* lhs, const char* rhs, size_t count) = nullptr;
    const char* (*_strchr)(const char* str, int ch) = nullptr;
    const char* (*_strrchr)(const char* str, int ch) = nullptr;
    size_t (*_strspn)(const char* dest, const char* src) = nullptr;
    size_t (*_strcspn)(const char* dest, const char* src) = nullptr;
    const char* (*_strpbrk)(const char* dest, const char* breakset) = nullptr;
    char* (*_strstr)(const char* haystack, const char* needle) = nullptr;
    char* (*_strtok)(char* str, const char* delim) = nullptr;
    size_t (*_strlen)(const char* str) = nullptr;
    char* (*_strerror)(int errnum) = nullptr;
    void* (*_malloc)(size_t size) = nullptr;
    void* (*_calloc)(size_t num, size_t size) = nullptr;
    void* (*_realloc)(void* ptr, size_t new_size) = nullptr;
    void (*_free)(void* ptr) = nullptr;
    void (*_qsort)(void* ptr, size_t count, size_t size,
                  int (*comp)(const void*, const void*)) = nullptr;
    int (*_rand)() = nullptr;
    void (*_srand)(unsigned seed) = nullptr;
    int (*_abs)(int n) = nullptr;
    long (*_labs)(long n) = nullptr;
    long long (*_llabs)(long long n) = nullptr;
    int (*_atoi)(const char* str) = nullptr;
    long (*_atol)(const char* str) = nullptr;
    long long (*_atoll)(const char* str) = nullptr;
    double (*_atof)(const char* str) = nullptr;
    long (* _strtol)(const char* str, char** endptr, int base) = nullptr;
    long long (* _strtoll)(const char* str, char** endptr, int base) = nullptr;
    unsigned long (* _strtoul)(const char* str, char** endptr, int base) = nullptr;
    unsigned long long (* _strtoull)(const char* str, char** endptr, int base) = nullptr;
    double (* _strtod)(const char* str, char** endptr) = nullptr;
    float (* _strtof)(const char* str, char** endptr) = nullptr;
    long double (* _strtold)(const char* str, char** endptr) = nullptr;
    int (*_system)(const char* command) = nullptr;
    void (*_exit_)(int exit_code) = nullptr;
    void (*_abort)() = nullptr;
    int (*_atexit)(void (*func)()) = nullptr;
    void* (*_bsearch)(const void* key, const void* ptr, size_t count, size_t size,
                     int (*comp)(const void*, const void*)) = nullptr;
    int (*_time)(int* arg) = nullptr;
    void (*_clock)() = nullptr;
    int (*_difftime)(int time_end, int time_beg) = nullptr;
    int (*_isdigit)(int ch) = nullptr;
    int (*_isalpha)(int ch) = nullptr;
    int (*_isalnum)(int ch) = nullptr;
    int (*_iscntrl)(int ch) = nullptr;
    int (*_isgraph)(int ch) = nullptr;
    int (*_islower)(int ch) = nullptr;
    int (*_isprint)(int ch) = nullptr;
    int (*_ispunct)(int ch) = nullptr;
    int (*_isspace)(int ch) = nullptr;
    int (*_isupper)(int ch) = nullptr;
    int (*_isxdigit)(int ch) = nullptr;
    int (*__tolower)(int ch) = nullptr;
    int (*__toupper)(int ch) = nullptr;
    double (*_floor)(double x) = nullptr;
    double (*_ceil)(double x) = nullptr;
    double (*_pow)(double x, double y) = nullptr;
    double (*_cos)(double x) = nullptr;
    double (*_sin)(double x) = nullptr;
    double (*_tan)(double x) = nullptr;
    double (*_sqrt)(double x) = nullptr;
    double (*_fabs)(double x) = nullptr;
    int (*_mprotect)(void* addr, size_t len, int prot) = nullptr;

void libc() {
    void* libc_handle = xdl_open(oxorany("libc.so"), XDL_DEFAULT);

    if (libc_handle) {
        auto load = [&](void** ptr, const char* name) {
            *ptr = xdl_sym(libc_handle, name, nullptr);
        };

        const char* stdio_names[] = {
            oxorany("printf"), oxorany("sprintf"), oxorany("snprintf"), oxorany("vsnprintf"), 
            oxorany("fprintf"), oxorany("scanf"), oxorany("sscanf"),
            oxorany("gets"), oxorany("fgets"), oxorany("puts"), oxorany("fputs"), 
            oxorany("fgetc"), oxorany("getc"), oxorany("getchar"),
            oxorany("putchar"), oxorany("fputc"), oxorany("fopen"), oxorany("fclose"), 
            oxorany("fflush"), oxorany("fread"), oxorany("fwrite"),
            oxorany("fseek"), oxorany("ftell"), oxorany("rewind"), oxorany("feof"), 
            oxorany("ferror")
        };

        void* stdio_funcs[] = {
            (void*)&_printf, (void*)&_sprintf, (void*)&_snprintf, (void*)&_vsnprintf, 
            (void*)&_fprintf,
            (void*)&_scanf, (void*)&_sscanf, (void*)&_gets, (void*)&_fgets,
            (void*)&_puts, (void*)&_fputs, (void*)&_fgetc, (void*)&_getc,
            (void*)&_getchar, (void*)&_putchar, (void*)&_fputc, (void*)&_fopen,
            (void*)&_fclose, (void*)&_fflush_, (void*)&_fread, (void*)&_fwrite,
            (void*)&_fseek, (void*)&_ftell, (void*)&_rewind, (void*)&_feof, 
            (void*)&_ferror
        };
        
        const char* memory_names[] = {
            oxorany("memcpy"), oxorany("memmove"), oxorany("memset"), 
            oxorany("memcmp"), oxorany("memchr")
        };

        void* memory_funcs[] = {
            (void*)&_memcpy, (void*)&_memmove, (void*)&_memset, 
            (void*)&_memcmp, (void*)&_memchr
        };

        const char* string_names[] = {
            oxorany("strcpy"), oxorany("strncpy"), oxorany("strcat"), 
            oxorany("strncat"),
            oxorany("strcmp"), oxorany("strncmp"), oxorany("strchr"), 
            oxorany("strrchr"),
            oxorany("strspn"), oxorany("strcspn"), oxorany("strpbrk"), 
            oxorany("strstr"), oxorany("strtok"),
            oxorany("strlen"), oxorany("strerror")
        };

        void* string_funcs[] = {
            (void*)&_strcpy, (void*)&_strncpy, (void*)&_strcat, (void*)&_strncat,
            (void*)&_strcmp, (void*)&_strncmp, (void*)&_strchr, (void*)&_strrchr,
            (void*)&_strspn, (void*)&_strcspn, (void*)&_strpbrk, (void*)&_strstr, 
            (void*)&_strtok,
            (void*)&_strlen, (void*)&_strerror
        };

        const char* stdlib_names[] = {
            oxorany("malloc"), oxorany("calloc"), oxorany("realloc"), 
            oxorany("free"), oxorany("rand"), oxorany("srand"), oxorany("abs"),
            oxorany("labs"), oxorany("llabs"), oxorany("atoi"), oxorany("atol"), 
            oxorany("atoll"), oxorany("atof"), oxorany("strtol"),
            oxorany("strtoll"), oxorany("strtoul"), oxorany("strtoull"), 
            oxorany("strtod"), oxorany("strtof"), oxorany("strtold"),
            oxorany("system"), oxorany("exit"), oxorany("abort"), 
            oxorany("atexit"), oxorany("bsearch"), oxorany("qsort")
        };

        void* stdlib_funcs[] = {
            (void*)&_malloc, (void*)&_calloc, (void*)&_realloc, (void*)&_free,
            (void*)&_rand, (void*)&_srand, (void*)&_abs, (void*)&_labs,
            (void*)&_llabs, (void*)&_atoi, (void*)&_atol, (void*)&_atoll,
            (void*)&_atof, (void*)&_strtol, (void*)&_strtoll, (void*)&_strtoul,
            (void*)&_strtoull, (void*)&_strtod, (void*)&_strtof, (void*)&_strtold,
            (void*)&_system, (void*)&_exit_, (void*)&_abort, (void*)&_atexit,
            (void*)&_bsearch, (void*)&_qsort
        };

        const char* time_names[] = {
            oxorany("time"), oxorany("difftime")
        };

        void* time_funcs[] = {
            (void*)&_time, (void*)&_difftime
        };

        const char* ctype_names[] = {
            oxorany("isdigit"), oxorany("isalpha"), oxorany("isalnum"), 
            oxorany("iscntrl"), oxorany("isgraph"), oxorany("islower"),
            oxorany("isprint"), oxorany("ispunct"), oxorany("isspace"), 
            oxorany("isupper"), oxorany("isxdigit"), oxorany("tolower"),
            oxorany("toupper")
        };

        void* ctype_funcs[] = {
            (void*)&_isdigit, (void*)&_isalpha, (void*)&_isalnum, (void*)&_iscntrl,
            (void*)&_isgraph, (void*)&_islower, (void*)&_isprint, (void*)&_ispunct,
            (void*)&_isspace, (void*)&_isupper, (void*)&_isxdigit, (void*)&__tolower,
            (void*)&__toupper
        };

        const char* math_names[] = {
            oxorany("floor"), oxorany("ceil"), oxorany("pow"), oxorany("cos"), 
            oxorany("sin"), oxorany("tan"), oxorany("sqrt"), oxorany("fabs")
        };

        void* math_funcs[] = {
            (void*)&_floor, (void*)&_ceil, (void*)&_pow, (void*)&_cos,
            (void*)&_sin, (void*)&_tan, (void*)&_sqrt, (void*)&_fabs
        };

        const char* mman_names[] = {
            oxorany("mprotect")
        };

        void* mman_funcs[] = {
            (void*)&_mprotect
        };

        for(int i = 0; i < sizeof(stdio_names)/sizeof(stdio_names[0]); i++) {
            load((void**)stdio_funcs[i], stdio_names[i]);
        }

        for(int i = 0; i < sizeof(memory_names)/sizeof(memory_names[0]); i++) {
            load((void**)memory_funcs[i], memory_names[i]);
        }

        for(int i = 0; i < sizeof(string_names)/sizeof(string_names[0]); i++) {
            load((void**)string_funcs[i], string_names[i]);
        }

        for(int i = 0; i < sizeof(stdlib_names)/sizeof(stdlib_names[0]); i++) {
            load((void**)stdlib_funcs[i], stdlib_names[i]);
        }

        for(int i = 0; i < sizeof(time_names)/sizeof(time_names[0]); i++) {
            load((void**)time_funcs[i], time_names[i]);
        }
        
        for(int i = 0; i < sizeof(ctype_names)/sizeof(ctype_names[0]); i++) {
            load((void**)ctype_funcs[i], ctype_names[i]);
        }

        for(int i = 0; i < sizeof(math_names)/sizeof(math_names[0]); i++) {
            load((void**)math_funcs[i], math_names[i]);
        }

        for(int i = 0; i < sizeof(mman_names)/sizeof(mman_names[0]); i++) {
            load((void**)mman_funcs[i], mman_names[i]);
        }
    }
}