#pragma once
#include "glegl/glegl.h"
#include "libc/libc.h"
#include "libz/libz.h"
#include "libdl/libdl.h"
#include "xdl/xdl.h"
#include "hks/got.h"
#include "hks/pph.h"
#include "hks/icall.h"

extern void lolw();
extern int glHeight;
extern int glWidth;
extern uintptr_t base;
