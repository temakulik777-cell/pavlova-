#include "glegl.h"
#include "../xdl/xdl.h"

void (*glActiveTexture)(GLenum texture) = nullptr;
void (*glBlendFunc)(GLenum sfactor, GLenum dfactor) = nullptr;
void (*glClear)(GLbitfield mask) = nullptr;
void (*glClearColor)(GLfloat red, GLfloat green, GLfloat blue, GLfloat alpha) = nullptr;
void (*glClearDepthf)(GLfloat depth) = nullptr;
void (*glClearStencil)(GLint s) = nullptr;
void (*glColorMask)(GLboolean red, GLboolean green, GLboolean blue, GLboolean alpha) = nullptr;
void (*glCullFace)(GLenum mode) = nullptr;
void (*glDepthFunc)(GLenum func) = nullptr;
void (*glDepthMask)(GLboolean flag) = nullptr;
void (*glDepthRangef)(GLfloat n, GLfloat f) = nullptr;
void (*glDisable)(GLenum cap) = nullptr;
void (*glEnable)(GLenum cap) = nullptr;
void (*glFinish)() = nullptr;
void (*glFlush)() = nullptr;
void (*glFrontFace)(GLenum mode) = nullptr;
void (*glHint)(GLenum target, GLenum mode) = nullptr;
void (*glLineWidth)(GLfloat width) = nullptr;
void (*glPixelStorei)(GLenum pname, GLint param) = nullptr;
void (*glPolygonOffset)(GLfloat factor, GLfloat units) = nullptr;
void (*glSampleCoverage)(GLfloat value, GLboolean invert) = nullptr;
void (*glScissor)(GLint x, GLint y, GLsizei width, GLsizei height) = nullptr;
void (*glStencilFunc)(GLenum func, GLint ref, GLuint mask) = nullptr;
void (*glStencilMask)(GLuint mask) = nullptr;
void (*glStencilOp)(GLenum fail, GLenum zfail, GLenum zpass) = nullptr;
void (*glViewport)(GLint x, GLint y, GLsizei width, GLsizei height) = nullptr;
void (*glBlendColor)(GLfloat red, GLfloat green, GLfloat blue, GLfloat alpha) = nullptr;
void (*glBlendEquation)(GLenum mode) = nullptr;
void (*glBlendEquationSeparate)(GLenum modeRGB, GLenum modeAlpha) = nullptr;
void (*glBlendFuncSeparate)(GLenum sfactorRGB, GLenum dfactorRGB, GLenum sfactorAlpha, GLenum dfactorAlpha) = nullptr;
void (*glBindBuffer)(GLenum target, GLuint buffer) = nullptr;
void (*glBufferData)(GLenum target, GLsizeiptr size, const void *data, GLenum usage) = nullptr;
void (*glBufferSubData)(GLenum target, GLintptr offset, GLsizeiptr size, const void *data) = nullptr;
void (*glDeleteBuffers)(GLsizei n, const GLuint *buffers) = nullptr;
void (*glGenBuffers)(GLsizei n, GLuint *buffers) = nullptr;
GLboolean (*glIsBuffer)(GLuint buffer) = nullptr;
void (*glBindFramebuffer)(GLenum target, GLuint framebuffer) = nullptr;
void (*glBindRenderbuffer)(GLenum target, GLuint renderbuffer) = nullptr;
void (*glDeleteFramebuffers)(GLsizei n, const GLuint *framebuffers) = nullptr;
void (*glDeleteRenderbuffers)(GLsizei n, const GLuint *renderbuffers) = nullptr;
void (*glFramebufferRenderbuffer)(GLenum target, GLenum attachment, GLenum renderbuffertarget, GLuint renderbuffer) = nullptr;
void (*glFramebufferTexture2D)(GLenum target, GLenum attachment, GLenum textarget, GLuint texture, GLint level) = nullptr;
void (*glGenFramebuffers)(GLsizei n, GLuint *framebuffers) = nullptr;
void (*glGenRenderbuffers)(GLsizei n, GLuint *renderbuffers) = nullptr;
void (*glGenerateMipmap)(GLenum target) = nullptr;
GLboolean (*glIsFramebuffer)(GLuint framebuffer) = nullptr;
GLboolean (*glIsRenderbuffer)(GLuint renderbuffer) = nullptr;
void (*glRenderbufferStorage)(GLenum target, GLenum internalformat, GLsizei width, GLsizei height) = nullptr;
void (*glBindTexture)(GLenum target, GLuint texture) = nullptr;
void (*glCompressedTexImage2D)(GLenum target, GLint level, GLenum internalformat, GLsizei width, GLsizei height, GLint border, GLsizei imageSize, const void *data) = nullptr;
void (*glCompressedTexSubImage2D)(GLenum target, GLint level, GLint xoffset, GLint yoffset, GLsizei width, GLsizei height, GLenum format, GLsizei imageSize, const void *data) = nullptr;
void (*glCopyTexImage2D)(GLenum target, GLint level, GLenum internalformat, GLint x, GLint y, GLsizei width, GLsizei height, GLint border) = nullptr;
void (*glCopyTexSubImage2D)(GLenum target, GLint level, GLint xoffset, GLint yoffset, GLint x, GLint y, GLsizei width, GLsizei height) = nullptr;
void (*glDeleteTextures)(GLsizei n, const GLuint *textures) = nullptr;
void (*glGenTextures)(GLsizei n, GLuint *textures) = nullptr;
GLboolean (*glIsTexture)(GLuint texture) = nullptr;
void (*glTexImage2D)(GLenum target, GLint level, GLint internalformat, GLsizei width, GLsizei height, GLint border, GLenum format, GLenum type, const void *pixels) = nullptr;
void (*glTexParameterf)(GLenum target, GLenum pname, GLfloat param) = nullptr;
void (*glTexParameterfv)(GLenum target, GLenum pname, const GLfloat *params) = nullptr;
void (*glTexParameteri)(GLenum target, GLenum pname, GLint param) = nullptr;
void (*glTexParameteriv)(GLenum target, GLenum pname, const GLint *params) = nullptr;
void (*glTexSubImage2D)(GLenum target, GLint level, GLint xoffset, GLint yoffset, GLsizei width, GLsizei height, GLenum format, GLenum type, const void *pixels) = nullptr;
void (*glAttachShader)(GLuint program, GLuint shader) = nullptr;
void (*glBindAttribLocation)(GLuint program, GLuint index, const char *name) = nullptr;
void (*glCompileShader)(GLuint shader) = nullptr;
GLuint (*glCreateProgram)() = nullptr;
GLuint (*glCreateShader)(GLenum type) = nullptr;
void (*glDeleteProgram)(GLuint program) = nullptr;
void (*glDeleteShader)(GLuint shader) = nullptr;
void (*glDetachShader)(GLuint program, GLuint shader) = nullptr;
void (*glDisableVertexAttribArray)(GLuint index) = nullptr;
void (*glEnableVertexAttribArray)(GLuint index) = nullptr;
GLint (*glGetAttribLocation)(GLuint program, const char *name) = nullptr;
void (*glGetProgramiv)(GLuint program, GLenum pname, GLint *params) = nullptr;
void (*glGetProgramInfoLog)(GLuint program, GLsizei bufSize, GLsizei *length, char *infoLog) = nullptr;
void (*glGetShaderiv)(GLuint shader, GLenum pname, GLint *params) = nullptr;
void (*glGetShaderInfoLog)(GLuint shader, GLsizei bufSize, GLsizei *length, char *infoLog) = nullptr;
GLboolean (*glIsProgram)(GLuint program) = nullptr;
GLboolean (*glIsShader)(GLuint shader) = nullptr;
void (*glLinkProgram)(GLuint program) = nullptr;
void (*glShaderBinary)(GLsizei count, const GLuint *shaders, GLenum binaryformat, const void *binary, GLsizei length) = nullptr;
void (*glShaderSource)(GLuint shader, GLsizei count, const char *const*string, const GLint *length) = nullptr;
void (*glUseProgram)(GLuint program) = nullptr;
void (*glValidateProgram)(GLuint program) = nullptr;
GLint (*glGetUniformLocation)(GLuint program, const char *name) = nullptr;
void (*glUniform1f)(GLint location, GLfloat v0) = nullptr;
void (*glUniform1fv)(GLint location, GLsizei count, const GLfloat *value) = nullptr;
void (*glUniform1i)(GLint location, GLint v0) = nullptr;
void (*glUniform1iv)(GLint location, GLsizei count, const GLint *value) = nullptr;
void (*glUniform2f)(GLint location, GLfloat v0, GLfloat v1) = nullptr;
void (*glUniform2fv)(GLint location, GLsizei count, const GLfloat *value) = nullptr;
void (*glUniform2i)(GLint location, GLint v0, GLint v1) = nullptr;
void (*glUniform2iv)(GLint location, GLsizei count, const GLint *value) = nullptr;
void (*glUniform3f)(GLint location, GLfloat v0, GLfloat v1, GLfloat v2) = nullptr;
void (*glUniform3fv)(GLint location, GLsizei count, const GLfloat *value) = nullptr;
void (*glUniform3i)(GLint location, GLint v0, GLint v1, GLint v2) = nullptr;
void (*glUniform3iv)(GLint location, GLsizei count, const GLint *value) = nullptr;
void (*glUniform4f)(GLint location, GLfloat v0, GLfloat v1, GLfloat v2, GLfloat v3) = nullptr;
void (*glUniform4fv)(GLint location, GLsizei count, const GLfloat *value) = nullptr;
void (*glUniform4i)(GLint location, GLint v0, GLint v1, GLint v2, GLint v3) = nullptr;
void (*glUniform4iv)(GLint location, GLsizei count, const GLint *value) = nullptr;
void (*glUniformMatrix2fv)(GLint location, GLsizei count, GLboolean transpose, const GLfloat *value) = nullptr;
void (*glUniformMatrix3fv)(GLint location, GLsizei count, GLboolean transpose, const GLfloat *value) = nullptr;
void (*glUniformMatrix4fv)(GLint location, GLsizei count, GLboolean transpose, const GLfloat *value) = nullptr;
void (*glVertexAttrib1f)(GLuint index, GLfloat x) = nullptr;
void (*glVertexAttrib1fv)(GLuint index, const GLfloat *v) = nullptr;
void (*glVertexAttrib2f)(GLuint index, GLfloat x, GLfloat y) = nullptr;
void (*glVertexAttrib2fv)(GLuint index, const GLfloat *v) = nullptr;
void (*glVertexAttrib3f)(GLuint index, GLfloat x, GLfloat y, GLfloat z) = nullptr;
void (*glVertexAttrib3fv)(GLuint index, const GLfloat *v) = nullptr;
void (*glVertexAttrib4f)(GLuint index, GLfloat x, GLfloat y, GLfloat z, GLfloat w) = nullptr;
void (*glVertexAttrib4fv)(GLuint index, const GLfloat *v) = nullptr;
void (*glVertexAttribPointer)(GLuint index, GLint size, GLenum type, GLboolean normalized, GLsizei stride, const void *pointer) = nullptr;
void (*glGetBooleanv)(GLenum pname, GLboolean *data) = nullptr;
void (*glGetBufferParameteriv)(GLenum target, GLenum pname, GLint *params) = nullptr;
GLenum (*glGetError)() = nullptr;
void (*glGetFloatv)(GLenum pname, GLfloat *data) = nullptr;
void (*glGetFramebufferAttachmentParameteriv)(GLenum target, GLenum attachment, GLenum pname, GLint *params) = nullptr;
void (*glGetIntegerv)(GLenum pname, GLint *data) = nullptr;
void (*glGetRenderbufferParameteriv)(GLenum target, GLenum pname, GLint *params) = nullptr;
void (*glGetShaderPrecisionFormat)(GLenum shadertype, GLenum precisiontype, GLint *range, GLint *precision) = nullptr;
void (*glGetShaderSource)(GLuint shader, GLsizei bufSize, GLsizei *length, char *source) = nullptr;
const GLubyte* (*glGetString)(GLenum name) = nullptr;
void (*glGetTexParameterfv)(GLenum target, GLenum pname, GLfloat *params) = nullptr;
void (*glGetTexParameteriv)(GLenum target, GLenum pname, GLint *params) = nullptr;
void (*glGetTexLevelParameteriv)(GLenum target, GLint level, GLenum pname, GLint *params) = nullptr;
void (*glGetTexImage)(GLenum target, GLint level, GLenum format, GLenum type, void *pixels) = nullptr;
void (*glGetUniformfv)(GLuint program, GLint location, GLfloat *params) = nullptr;
void (*glGetUniformiv)(GLuint program, GLint location, GLint *params) = nullptr;
void (*glGetVertexAttribfv)(GLuint index, GLenum pname, GLfloat *params) = nullptr;
void (*glGetVertexAttribiv)(GLuint index, GLenum pname, GLint *params) = nullptr;
void (*glGetVertexAttribPointerv)(GLuint index, GLenum pname, void **pointer) = nullptr;
GLboolean (*glIsEnabled)(GLenum cap) = nullptr;
void (*glDrawArrays)(GLenum mode, GLint first, GLsizei count) = nullptr;
void (*glDrawElements)(GLenum mode, GLsizei count, GLenum type, const void *indices) = nullptr;
void (*glReadPixels)(GLint x, GLint y, GLsizei width, GLsizei height, GLenum format, GLenum type, void *pixels) = nullptr;
void (*glStencilFuncSeparate)(GLenum face, GLenum func, GLint ref, GLuint mask) = nullptr;
void (*glStencilMaskSeparate)(GLenum face, GLuint mask) = nullptr;
void (*glStencilOpSeparate)(GLenum face, GLenum sfail, GLenum dpfail, GLenum dppass) = nullptr;
void (*glReleaseShaderCompiler)() = nullptr;
void (*glGetActiveAttrib)(GLuint program, GLuint index, GLsizei bufSize, GLsizei *length, GLint *size, GLenum *type, char *name) = nullptr;
void (*glGetActiveUniform)(GLuint program, GLuint index, GLsizei bufSize, GLsizei *length, GLint *size, GLenum *type, char *name) = nullptr;
void (*glGetAttachedShaders)(GLuint program, GLsizei maxCount, GLsizei *count, GLuint *shaders) = nullptr;
void (*glBlitFramebuffer)(GLint srcX0, GLint srcY0, GLint srcX1, GLint srcY1, GLint dstX0, GLint dstY0, GLint dstX1, GLint dstY1, GLbitfield mask, GLenum filter) = nullptr;
void* (*glMapBuffer)(GLenum target, GLenum access) = nullptr;
void (*glUnmapBuffer)(GLenum target) = nullptr;
GLsync (*glFenceSync)(GLenum condition, GLbitfield flags) = nullptr;
GLenum (*glWaitSync)(GLsync sync, GLbitfield flags, GLuint64 timeout) = nullptr;
void (*glDeleteSync)(GLsync sync) = nullptr;
void* (*glMapBufferRange)(GLenum target, GLintptr offset, GLsizeiptr length, GLbitfield access) = nullptr;
EGLBoolean (*eglQuerySurface)(EGLDisplay dpy, EGLSurface surface, EGLint attribute, EGLint* value) = nullptr;
void (*glDrawElementsBaseVertex)(GLenum mode, GLsizei count, GLenum type, const void* indices, GLint basevertex) = nullptr;
void (*glGenVertexArrays)(GLsizei n, GLuint* arrays) = nullptr;
void (*glDeleteVertexArrays)(GLsizei n, GLuint* arrays) = nullptr;
void (*glBindVertexArray)(GLuint array) = nullptr;
void (*glPolygonMode)(GLenum face, GLenum mode) = nullptr;
void (*glBindSampler)(GLuint unit, GLuint sampler) = nullptr;
void (*glColor4f)(GLfloat red, GLfloat green, GLfloat blue, GLfloat alpha) = nullptr;
EGLDisplay (*eglGetCurrentDisplay)() = nullptr;
EGLSurface (*eglGetCurrentSurface)(EGLint readdraw) = nullptr;

GLboolean glegl_get_depth_writemask() {
    GLboolean value = GL_TRUE;
    if (glGetBooleanv) {
        glGetBooleanv(GL_DEPTH_WRITEMASK, &value);
    }
    return value;
}

GLenum glegl_get_depth_func() {
    GLint value = GL_LESS;
    if (glGetIntegerv) {
        glGetIntegerv(GL_DEPTH_FUNC, &value);
    }
    return (GLenum)value;
}

void glegl() {
    void* libEGL,*libGLESv2;
    libEGL=xdl_open(oxorany("libEGL.so"),XDL_DEFAULT);
    libGLESv2=xdl_open(oxorany("libGLESv2.so"),XDL_DEFAULT);

    if(libEGL) {
        eglQuerySurface=(EGLBoolean(*)(EGLDisplay,EGLSurface,EGLint,EGLint*))xdl_sym(libEGL,oxorany("eglQuerySurface"),nullptr);
        eglGetCurrentDisplay=(EGLDisplay(*)())xdl_sym(libEGL,oxorany("eglGetCurrentDisplay"),nullptr);
        eglGetCurrentSurface=(EGLSurface(*)(EGLint))xdl_sym(libEGL,oxorany("eglGetCurrentSurface"),nullptr);
    }

    if(libGLESv2) {
        auto load=[&](void** ptr, const char* name) {
            *ptr=xdl_sym(libGLESv2,name,nullptr);
        };

        const char* special_names[]={
            oxorany("glDrawElementsBaseVertex"),
            oxorany("glGenVertexArrays"),
            oxorany("glGenVertexArraysOES"),
            oxorany("glDeleteVertexArrays"),
            oxorany("glDeleteVertexArraysOES"),
            oxorany("glBindVertexArray"),
            oxorany("glBindVertexArrayOES"),
            oxorany("glPolygonMode"),
            oxorany("glColor4f"),
            oxorany("glBlitFramebuffer"),
            oxorany("glMapBuffer"),
            oxorany("glUnmapBuffer"),
            oxorany("glFenceSync"),
            oxorany("glWaitSync"),
            oxorany("glDeleteSync"),
            oxorany("glMapBufferRange")
        };

        void* special_funcs[]={
            (void*)&glDrawElementsBaseVertex,
            (void*)&glGenVertexArrays,
            (void*)&glGenVertexArrays,
            (void*)&glDeleteVertexArrays,
            (void*)&glDeleteVertexArrays,
            (void*)&glBindVertexArray,
            (void*)&glBindVertexArray,
            (void*)&glPolygonMode,
            (void*)&glColor4f,
            (void*)&glBlitFramebuffer,
            (void*)&glMapBuffer,
            (void*)&glUnmapBuffer,
            (void*)&glFenceSync,
            (void*)&glWaitSync,
            (void*)&glDeleteSync,
            (void*)&glMapBufferRange
        };

        for(int i=0;i<sizeof(special_names)/sizeof(special_names[0]);i++) {
            load((void**)special_funcs[i],special_names[i]);
        }

        if(!glGenVertexArrays) load((void**)&glGenVertexArrays,oxorany("glGenVertexArraysOES"));
        if(!glDeleteVertexArrays) load((void**)&glDeleteVertexArrays,oxorany("glDeleteVertexArraysOES"));
        if(!glBindVertexArray) load((void**)&glBindVertexArray,oxorany("glBindVertexArrayOES"));

        const char* names[]={
            oxorany("glActiveTexture"),oxorany("glBlendFunc"),oxorany("glClear"),oxorany("glClearColor"),oxorany("glClearDepthf"),
            oxorany("glClearStencil"),oxorany("glColorMask"),oxorany("glCullFace"),oxorany("glDepthFunc"),oxorany("glDepthMask"),
            oxorany("glDepthRangef"),oxorany("glDisable"),oxorany("glEnable"),oxorany("glFinish"),oxorany("glFlush"),oxorany("glFrontFace"),
            oxorany("glHint"),oxorany("glLineWidth"),oxorany("glPixelStorei"),oxorany("glPolygonOffset"),oxorany("glSampleCoverage"),
            oxorany("glScissor"),oxorany("glStencilFunc"),oxorany("glStencilMask"),oxorany("glStencilOp"),oxorany("glViewport"),
            oxorany("glBlendColor"),oxorany("glBlendEquation"),oxorany("glBlendEquationSeparate"),oxorany("glBlendFuncSeparate"),
            oxorany("glBindBuffer"),oxorany("glBufferData"),oxorany("glBufferSubData"),oxorany("glDeleteBuffers"),oxorany("glGenBuffers"),
            oxorany("glIsBuffer"),oxorany("glBindFramebuffer"),oxorany("glBindRenderbuffer"),oxorany("glDeleteFramebuffers"),
            oxorany("glDeleteRenderbuffers"),oxorany("glFramebufferRenderbuffer"),oxorany("glFramebufferTexture2D"),
            oxorany("glGenFramebuffers"),oxorany("glGenRenderbuffers"),oxorany("glGenerateMipmap"),oxorany("glIsFramebuffer"),
            oxorany("glIsRenderbuffer"),oxorany("glRenderbufferStorage"),oxorany("glBindTexture"),oxorany("glCompressedTexImage2D"),
            oxorany("glCompressedTexSubImage2D"),oxorany("glCopyTexImage2D"),oxorany("glCopyTexSubImage2D"),
            oxorany("glDeleteTextures"),oxorany("glGenTextures"),oxorany("glIsTexture"),oxorany("glTexImage2D"),oxorany("glTexParameterf"),
            oxorany("glTexParameterfv"),oxorany("glTexParameteri"),oxorany("glTexParameteriv"),oxorany("glTexSubImage2D"),
            oxorany("glAttachShader"),oxorany("glBindAttribLocation"),oxorany("glCompileShader"),oxorany("glCreateProgram"),
            oxorany("glCreateShader"),oxorany("glDeleteProgram"),oxorany("glDeleteShader"),oxorany("glDetachShader"),
            oxorany("glDisableVertexAttribArray"),oxorany("glEnableVertexAttribArray"),oxorany("glGetAttribLocation"),
            oxorany("glGetProgramiv"),oxorany("glGetProgramInfoLog"),oxorany("glGetShaderiv"),oxorany("glGetShaderInfoLog"),
            oxorany("glIsProgram"),oxorany("glIsShader"),oxorany("glLinkProgram"),oxorany("glShaderBinary"),oxorany("glShaderSource"),
            oxorany("glUseProgram"),oxorany("glValidateProgram"),oxorany("glGetUniformLocation"),oxorany("glUniform1f"),
            oxorany("glUniform1fv"),oxorany("glUniform1i"),oxorany("glUniform1iv"),oxorany("glUniform2f"),oxorany("glUniform2fv"),
            oxorany("glUniform2i"),oxorany("glUniform2iv"),oxorany("glUniform3f"),oxorany("glUniform3fv"),oxorany("glUniform3i"),
            oxorany("glUniform3iv"),oxorany("glUniform4f"),oxorany("glUniform4fv"),oxorany("glUniform4i"),oxorany("glUniform4iv"),
            oxorany("glUniformMatrix2fv"),oxorany("glUniformMatrix3fv"),oxorany("glUniformMatrix4fv"),oxorany("glBindSampler"),
            oxorany("glVertexAttrib1f"),oxorany("glVertexAttrib1fv"),oxorany("glVertexAttrib2f"),oxorany("glVertexAttrib2fv"),
            oxorany("glVertexAttrib3f"),oxorany("glVertexAttrib3fv"),oxorany("glVertexAttrib4f"),oxorany("glVertexAttrib4fv"),
            oxorany("glVertexAttribPointer"),oxorany("glGetBooleanv"),oxorany("glGetBufferParameteriv"),oxorany("glGetError"),
            oxorany("glGetFloatv"),oxorany("glGetFramebufferAttachmentParameteriv"),oxorany("glGetIntegerv"),
            oxorany("glGetProgramInfoLog"),oxorany("glGetRenderbufferParameteriv"),oxorany("glGetShaderPrecisionFormat"),
            oxorany("glGetShaderSource"),oxorany("glGetString"),oxorany("glGetTexParameterfv"),oxorany("glGetTexParameteriv"),
            oxorany("glGetTexLevelParameteriv"),oxorany("glGetTexImage"),oxorany("glGetUniformfv"),oxorany("glGetUniformiv"),oxorany("glGetVertexAttribfv"),oxorany("glGetVertexAttribiv"),
            oxorany("glGetVertexAttribPointerv"),oxorany("glIsEnabled"),oxorany("glDrawArrays"),oxorany("glDrawElements"),
            oxorany("glReadPixels"),oxorany("glStencilFuncSeparate"),oxorany("glStencilMaskSeparate"),oxorany("glStencilOpSeparate"),
            oxorany("glReleaseShaderCompiler"),oxorany("glGetActiveAttrib"),oxorany("glGetActiveUniform"),oxorany("glGetAttachedShaders")
        };

        void* funcs[]={
            (void*)&glActiveTexture,(void*)&glBlendFunc,(void*)&glClear,(void*)&glClearColor,(void*)&glClearDepthf,
            (void*)&glClearStencil,(void*)&glColorMask,(void*)&glCullFace,(void*)&glDepthFunc,(void*)&glDepthMask,
            (void*)&glDepthRangef,(void*)&glDisable,(void*)&glEnable,(void*)&glFinish,(void*)&glFlush,(void*)&glFrontFace,
            (void*)&glHint,(void*)&glLineWidth,(void*)&glPixelStorei,(void*)&glPolygonOffset,(void*)&glSampleCoverage,
            (void*)&glScissor,(void*)&glStencilFunc,(void*)&glStencilMask,(void*)&glStencilOp,(void*)&glViewport,
            (void*)&glBlendColor,(void*)&glBlendEquation,(void*)&glBlendEquationSeparate,(void*)&glBlendFuncSeparate,
            (void*)&glBindBuffer,(void*)&glBufferData,(void*)&glBufferSubData,(void*)&glDeleteBuffers,(void*)&glGenBuffers,
            (void*)&glIsBuffer,(void*)&glBindFramebuffer,(void*)&glBindRenderbuffer,(void*)&glDeleteFramebuffers,
            (void*)&glDeleteRenderbuffers,(void*)&glFramebufferRenderbuffer,(void*)&glFramebufferTexture2D,
            (void*)&glGenFramebuffers,(void*)&glGenRenderbuffers,(void*)&glGenerateMipmap,(void*)&glIsFramebuffer,
            (void*)&glIsRenderbuffer,(void*)&glRenderbufferStorage,(void*)&glBindTexture,(void*)&glCompressedTexImage2D,
            (void*)&glCompressedTexSubImage2D,(void*)&glCopyTexImage2D,(void*)&glCopyTexSubImage2D,
            (void*)&glDeleteTextures,(void*)&glGenTextures,(void*)&glIsTexture,(void*)&glTexImage2D,(void*)&glTexParameterf,
            (void*)&glTexParameterfv,(void*)&glTexParameteri,(void*)&glTexParameteriv,(void*)&glTexSubImage2D,
            (void*)&glAttachShader,(void*)&glBindAttribLocation,(void*)&glCompileShader,(void*)&glCreateProgram,
            (void*)&glCreateShader,(void*)&glDeleteProgram,(void*)&glDeleteShader,(void*)&glDetachShader,
            (void*)&glDisableVertexAttribArray,(void*)&glEnableVertexAttribArray,(void*)&glGetAttribLocation,
            (void*)&glGetProgramiv,(void*)&glGetProgramInfoLog,(void*)&glGetShaderiv,(void*)&glGetShaderInfoLog,
            (void*)&glIsProgram,(void*)&glIsShader,(void*)&glLinkProgram,(void*)&glShaderBinary,(void*)&glShaderSource,
            (void*)&glUseProgram,(void*)&glValidateProgram,(void*)&glGetUniformLocation,(void*)&glUniform1f,
            (void*)&glUniform1fv,(void*)&glUniform1i,(void*)&glUniform1iv,(void*)&glUniform2f,(void*)&glUniform2fv,
            (void*)&glUniform2i,(void*)&glUniform2iv,(void*)&glUniform3f,(void*)&glUniform3fv,(void*)&glUniform3i,
            (void*)&glUniform3iv,(void*)&glUniform4f,(void*)&glUniform4fv,(void*)&glUniform4i,(void*)&glUniform4iv,
            (void*)&glUniformMatrix2fv,(void*)&glUniformMatrix3fv,(void*)&glUniformMatrix4fv,(void*)&glBindSampler,
            (void*)&glVertexAttrib1f,(void*)&glVertexAttrib1fv,(void*)&glVertexAttrib2f,(void*)&glVertexAttrib2fv,
            (void*)&glVertexAttrib3f,(void*)&glVertexAttrib3fv,(void*)&glVertexAttrib4f,(void*)&glVertexAttrib4fv,
            (void*)&glVertexAttribPointer,(void*)&glGetBooleanv,(void*)&glGetBufferParameteriv,(void*)&glGetError,
            (void*)&glGetFloatv,(void*)&glGetFramebufferAttachmentParameteriv,(void*)&glGetIntegerv,
            (void*)&glGetProgramInfoLog,(void*)&glGetRenderbufferParameteriv,(void*)&glGetShaderPrecisionFormat,
            (void*)&glGetShaderSource,(void*)&glGetString,(void*)&glGetTexParameterfv,(void*)&glGetTexParameteriv,
            (void*)&glGetTexLevelParameteriv,(void*)&glGetTexImage,(void*)&glGetUniformfv,(void*)&glGetUniformiv,(void*)&glGetVertexAttribfv,(void*)&glGetVertexAttribiv,
            (void*)&glGetVertexAttribPointerv,(void*)&glIsEnabled,(void*)&glDrawArrays,(void*)&glDrawElements,
            (void*)&glReadPixels,(void*)&glStencilFuncSeparate,(void*)&glStencilMaskSeparate,(void*)&glStencilOpSeparate,
            (void*)&glReleaseShaderCompiler,(void*)&glGetActiveAttrib,(void*)&glGetActiveUniform,(void*)&glGetAttachedShaders
        };

        for(int i=0;i<sizeof(names)/sizeof(names[0]);i++) {
            load((void**)funcs[i],names[i]);
        }
    }
}
