#pragma once
#include <cstddef>
#include "../oxo/include.h"

#define GL_FRAMEBUFFER oxorany(0x8D40)
#define GL_COLOR_ATTACHMENT0 oxorany(0x8CE0)
#define GL_FRAMEBUFFER_BINDING oxorany(0x8CA6)
#define GL_READ_FRAMEBUFFER oxorany(0x8CA8)
#define GL_DRAW_FRAMEBUFFER oxorany(0x8CA9)
#define GL_NEAREST oxorany(0x2600)
#define GL_COLOR_BUFFER_BIT oxorany(0x00004000)
#define GL_COLOR_WRITEMASK oxorany(0x0C23)
#define GL_COLOR_CLEAR_VALUE oxorany(0x0C22)
#define GL_COLOR_LOGIC_OP oxorany(0x0BF2)
#define GL_DEPTH_TEST oxorany(0x0B71)
#define GL_DEPTH_WRITEMASK oxorany(0x0B72)
#define GL_DEPTH_FUNC oxorany(0x0B74)
#define GL_SCISSOR_TEST oxorany(0x0C11)
#define GL_STENCIL_TEST oxorany(0x0B90)
#define GL_CULL_FACE oxorany(0x0B44)
#define GL_BLEND oxorany(0x0BE2)
#define GL_TEXTURE_2D oxorany(0x0DE1)
#define GL_ARRAY_BUFFER oxorany(0x8892)
#define GL_ELEMENT_ARRAY_BUFFER oxorany(0x8893)
#define GL_STREAM_DRAW oxorany(0x88E0)
#define GL_FRAGMENT_SHADER oxorany(0x8B30)
#define GL_VERTEX_SHADER oxorany(0x8B31)
#define GL_COMPILE_STATUS oxorany(0x8B81)
#define GL_LINK_STATUS oxorany(0x8B82)
#define GL_INFO_LOG_LENGTH oxorany(0x8B84)
#define GL_ACTIVE_TEXTURE oxorany(0x84E0)
#define GL_TEXTURE0 oxorany(0x84C0)
#define GL_TEXTURE_BINDING_2D oxorany(0x8069)
#define GL_SAMPLER_BINDING oxorany(0x8919)
#define GL_ARRAY_BUFFER_BINDING oxorany(0x8894)
#define GL_ELEMENT_ARRAY_BUFFER_BINDING oxorany(0x8895)
#define GL_VERTEX_ARRAY_BINDING oxorany(0x85B5)
#define GL_VIEWPORT oxorany(0x0BA2)
#define GL_SCISSOR_BOX oxorany(0x0C10)
#define GL_BLEND_SRC_RGB oxorany(0x80C9)
#define GL_BLEND_DST_RGB oxorany(0x80C8)
#define GL_BLEND_SRC_ALPHA oxorany(0x80CB)
#define GL_BLEND_DST_ALPHA oxorany(0x80CA)
#define GL_BLEND_EQUATION_RGB oxorany(0x8009)
#define GL_BLEND_EQUATION_ALPHA oxorany(0x883D)
#define GL_FUNC_ADD oxorany(0x8006)
#define GL_BLEND_COLOR oxorany(0x8005)
#define GL_VERTEX_ATTRIB_ARRAY_POINTER oxorany(0x8645)
#define GL_SRC_ALPHA oxorany(0x0302)
#define GL_ONE_MINUS_SRC_ALPHA oxorany(0x0303)
#define GL_ONE oxorany(1)
#define GL_TRIANGLES oxorany(0x0004)
#define GL_TRIANGLE_STRIP oxorany(0x0005)
#define GL_UNSIGNED_SHORT oxorany(0x1403)
#define GL_UNSIGNED_INT oxorany(0x1405)
#define GL_FRONT_AND_BACK oxorany(0x0408)
#define GL_FILL oxorany(0x1B02)
#define GL_LINEAR oxorany(0x2601)
#define GL_CLAMP_TO_EDGE oxorany(0x812F)
#define GL_RGBA oxorany(0x1908)
#define GL_UNSIGNED_BYTE oxorany(0x1401)
#define GL_UNSIGNED_SHORT_5_6_5 oxorany(0x8363)
#define GL_MAJOR_VERSION oxorany(0x821B)
#define GL_MINOR_VERSION oxorany(0x821C)
#define GL_MAX_TEXTURE_SIZE oxorany(0x0D33)
#define GL_VERSION oxorany(0x1F02)
#define GL_VENDOR oxorany(0x1F00)
#define GL_RENDERER oxorany(0x1F01)
#define GL_EXTENSIONS oxorany(0x1F03)
#define GL_NUM_EXTENSIONS oxorany(0x821D)
#define GL_CLIP_ORIGIN oxorany(0x935C)
#define GL_UPPER_LEFT oxorany(0x8CA2)
#define GL_PIXEL_UNPACK_BUFFER oxorany(0x88EC)
#define GL_PIXEL_UNPACK_BUFFER_BINDING oxorany(0x88EF)
#define GL_PIXEL_PACK_BUFFER oxorany(0x88EB)
#define GL_PRIMITIVE_RESTART oxorany(0x8F9D)
#define GL_LINE oxorany(0x1B01)
#define GL_FRONT oxorany(0x0404)
#define GL_BACK oxorany(0x0405)
#define GL_CONTEXT_PROFILE_MASK oxorany(0x9126)
#define GL_CONTEXT_COMPATIBILITY_PROFILE_BIT oxorany(0x00000002)
#define GL_POLYGON_MODE oxorany(0x0B40)
#define GL_UNPACK_ROW_LENGTH 0x0CF2
#define GL_UNPACK_ALIGNMENT oxorany(0x0CF5)
#define GL_NO_ERROR oxorany(0)
#define GL_TEXTURE_WIDTH oxorany(0x1000)
#define GL_TEXTURE_HEIGHT oxorany(0x1001)
#define GL_TEXTURE_MIN_FILTER oxorany(0x2801)
#define GL_TEXTURE_MAG_FILTER oxorany(0x2800)
#define GL_TEXTURE_WRAP_S oxorany(0x2802)
#define GL_TEXTURE_WRAP_T oxorany(0x2803)
#define GL_STREAM_READ oxorany(0x88E1)
#define GL_READ_ONLY oxorany(0x88B8)
#define GL_TIMEOUT_IGNORED oxorany(0xFFFFFFFFFFFFFFFF)
#define GL_MAP_READ_BIT oxorany(0x0001)
#define GL_SYNC_GPU_COMMANDS_COMPLETE oxorany(0x9117)
#define GL_LOW_FLOAT oxorany(0x8DF0)
#define GL_MEDIUM_FLOAT oxorany(0x8DF1)
#define GL_HIGH_FLOAT oxorany(0x8DF2)
#define GL_LOW_INT oxorany(0x8DF3)
#define GL_MEDIUM_INT oxorany(0x8DF4)
#define GL_HIGH_INT oxorany(0x8DF5)
#define GL_COLOR_ATTACHMENT0 oxorany(0x8CE0)
#define GL_DEPTH_ATTACHMENT oxorany(0x8D00)
#define GL_STENCIL_ATTACHMENT oxorany(0x8D20)
#define GL_FUNC_SUBTRACT oxorany(0x800A)
#define GL_FUNC_REVERSE_SUBTRACT oxorany(0x800B)
#define GL_MIN oxorany(0x8007)
#define GL_MAX oxorany(0x8008)
#define GL_NEVER oxorany(0x0200)
#define GL_LESS oxorany(0x0201)
#define GL_EQUAL oxorany(0x0202)
#define GL_LEQUAL oxorany(0x0203)
#define GL_GREATER oxorany(0x0204)
#define GL_NOTEQUAL oxorany(0x0205)
#define GL_GEQUAL oxorany(0x0206)
#define GL_ALWAYS oxorany(0x0207)
#define GL_KEEP oxorany(0x1E00)
#define GL_ZERO oxorany(0x0000)
#define GL_REPLACE oxorany(0x1E01)
#define GL_INCR oxorany(0x1E02)
#define GL_INCR_WRAP oxorany(0x8507)
#define GL_DECR oxorany(0x1E03)
#define GL_DECR_WRAP oxorany(0x8508)
#define GL_INVERT oxorany(0x150A)
#define GL_RGB oxorany(0x1907)
#define GL_ALPHA oxorany(0x1906)
#define GL_LUMINANCE oxorany(0x1909)
#define GL_LUMINANCE_ALPHA oxorany(0x190A)
#define GL_FLOAT oxorany(0x1406)
#define GL_FIXED oxorany(0x140C)
#define GL_STATIC_DRAW oxorany(0x88E4)
#define GL_DYNAMIC_DRAW oxorany(0x88E8)
#define GL_CW oxorany(0x0900)
#define GL_CCW oxorany(0x0901)
#define GL_FRONT oxorany(0x0404)
#define GL_BACK oxorany(0x0405)
#define GL_POINT oxorany(0x1B00)
#define GL_LINE oxorany(0x1B01)
#define GL_FILL oxorany(0x1B02)
#define GL_TEXTURE_CUBE_MAP oxorany(0x8513)
#define GL_TEXTURE_CUBE_MAP_POSITIVE_X oxorany(0x8515)
#define GL_COMPUTE_SHADER oxorany(0x91B9)
#define GL_ANY_SAMPLES_PASSED oxorany(0x8C2F)
#define GL_ANY_SAMPLES_PASSED_CONSERVATIVE oxorany(0x8D6A)
#define GL_TRANSFORM_FEEDBACK_BUFFER oxorany(0x8C8E)
#define GL_TEXTURE_WRAP_R oxorany(0x8072)
#define GL_TEXTURE_MIN_LOD oxorany(0x813A)
#define GL_TEXTURE_MAX_LOD oxorany(0x813B)
#define GL_TEXTURE_BASE_LEVEL oxorany(0x813C)
#define GL_TEXTURE_MAX_LEVEL oxorany(0x813D)
#define GL_VERTEX_ARRAY_BINDING_OES oxorany(0x85B5)
#define GL_CURRENT_PROGRAM oxorany(0x8B8D)
#define GL_SAMPLER_BINDING oxorany(0x8919)
typedef char GLchar;
typedef unsigned int GLenum;
typedef unsigned char GLboolean;
typedef unsigned int GLbitfield;
typedef signed char GLbyte;
typedef short GLshort;
typedef int GLint;
typedef int GLsizei;
typedef unsigned char GLubyte;
typedef unsigned short GLushort;
typedef unsigned int GLuint;
typedef float GLfloat;
typedef float GLclampf;
typedef void GLvoid;
typedef int GLfixed;
typedef int64_t GLint64;
typedef uint64_t GLuint64;
typedef ptrdiff_t GLsizeiptr;
typedef ptrdiff_t GLintptr;
typedef void* GLsync;
typedef void* EGLDisplay;
typedef void* EGLSurface;
typedef int EGLint;
typedef unsigned int EGLBoolean;
#define GL_FALSE oxorany(0)
#define GL_TRUE oxorany(1)
#define EGL_WIDTH oxorany(0x3057)
#define EGL_HEIGHT oxorany(0x3056)
#define EGL_NONE oxorany(0x3038)
#define EGL_DRAW oxorany(0x3059)
#define EGL_READ oxorany(0x305A)
#define EGL_SUCCESS oxorany(0x3000)

extern void (*glActiveTexture)(GLenum texture);
extern void (*glBlendFunc)(GLenum sfactor, GLenum dfactor);
extern void (*glClear)(GLbitfield mask);
extern void (*glClearColor)(GLfloat red, GLfloat green, GLfloat blue, GLfloat alpha);
extern void (*glClearDepthf)(GLfloat depth);
extern void (*glClearStencil)(GLint s);
extern void (*glColorMask)(GLboolean red, GLboolean green, GLboolean blue, GLboolean alpha);
extern void (*glCullFace)(GLenum mode);
extern void (*glDepthFunc)(GLenum func);
extern void (*glDepthMask)(GLboolean flag);
extern void (*glDepthRangef)(GLfloat n, GLfloat f);
extern void (*glDisable)(GLenum cap);
extern void (*glEnable)(GLenum cap);
extern void (*glFinish)();
extern void (*glFlush)();
extern void (*glFrontFace)(GLenum mode);
extern void (*glHint)(GLenum target, GLenum mode);
extern void (*glLineWidth)(GLfloat width);
extern void (*glPixelStorei)(GLenum pname, GLint param);
extern void (*glPolygonOffset)(GLfloat factor, GLfloat units);
extern void (*glSampleCoverage)(GLfloat value, GLboolean invert);
extern void (*glScissor)(GLint x, GLint y, GLsizei width, GLsizei height);
extern void (*glStencilFunc)(GLenum func, GLint ref, GLuint mask);
extern void (*glStencilMask)(GLuint mask);
extern void (*glStencilOp)(GLenum fail, GLenum zfail, GLenum zpass);
extern void (*glViewport)(GLint x, GLint y, GLsizei width, GLsizei height);
extern void (*glBlendColor)(GLfloat red, GLfloat green, GLfloat blue, GLfloat alpha);
extern void (*glBlendEquation)(GLenum mode);
extern void (*glBlendEquationSeparate)(GLenum modeRGB, GLenum modeAlpha);
extern void (*glBlendFuncSeparate)(GLenum sfactorRGB, GLenum dfactorRGB, GLenum sfactorAlpha, GLenum dfactorAlpha);
extern void (*glBindBuffer)(GLenum target, GLuint buffer);
extern void (*glBufferData)(GLenum target, GLsizeiptr size, const void *data, GLenum usage);
extern void (*glBufferSubData)(GLenum target, GLintptr offset, GLsizeiptr size, const void *data);
extern void (*glDeleteBuffers)(GLsizei n, const GLuint *buffers);
extern void (*glGenBuffers)(GLsizei n, GLuint *buffers);
extern GLboolean (*glIsBuffer)(GLuint buffer);
extern void (*glBindFramebuffer)(GLenum target, GLuint framebuffer);
extern void (*glBindRenderbuffer)(GLenum target, GLuint renderbuffer);
extern void (*glDeleteFramebuffers)(GLsizei n, const GLuint *framebuffers);
extern void (*glDeleteRenderbuffers)(GLsizei n, const GLuint *renderbuffers);
extern void (*glFramebufferRenderbuffer)(GLenum target, GLenum attachment, GLenum renderbuffertarget, GLuint renderbuffer);
extern void (*glFramebufferTexture2D)(GLenum target, GLenum attachment, GLenum textarget, GLuint texture, GLint level);
extern void (*glGenFramebuffers)(GLsizei n, GLuint *framebuffers);
extern void (*glGenRenderbuffers)(GLsizei n, GLuint *renderbuffers);
extern void (*glGenerateMipmap)(GLenum target);
extern GLboolean (*glIsFramebuffer)(GLuint framebuffer);
extern GLboolean (*glIsRenderbuffer)(GLuint renderbuffer);
extern void (*glRenderbufferStorage)(GLenum target, GLenum internalformat, GLsizei width, GLsizei height);
extern void (*glBindTexture)(GLenum target, GLuint texture);
extern void (*glCompressedTexImage2D)(GLenum target, GLint level, GLenum internalformat, GLsizei width, GLsizei height, GLint border, GLsizei imageSize, const void *data);
extern void (*glCompressedTexSubImage2D)(GLenum target, GLint level, GLint xoffset, GLint yoffset, GLsizei width, GLsizei height, GLenum format, GLsizei imageSize, const void *data);
extern void (*glCopyTexImage2D)(GLenum target, GLint level, GLenum internalformat, GLint x, GLint y, GLsizei width, GLsizei height, GLint border);
extern void (*glCopyTexSubImage2D)(GLenum target, GLint level, GLint xoffset, GLint yoffset, GLint x, GLint y, GLsizei width, GLsizei height);
extern void (*glDeleteTextures)(GLsizei n, const GLuint *textures);
extern void (*glGenTextures)(GLsizei n, GLuint *textures);
extern GLboolean (*glIsTexture)(GLuint texture);
extern void (*glTexImage2D)(GLenum target, GLint level, GLint internalformat, GLsizei width, GLsizei height, GLint border, GLenum format, GLenum type, const void *pixels);
extern void (*glTexParameterf)(GLenum target, GLenum pname, GLfloat param);
extern void (*glTexParameterfv)(GLenum target, GLenum pname, const GLfloat *params);
extern void (*glTexParameteri)(GLenum target, GLenum pname, GLint param);
extern void (*glTexParameteriv)(GLenum target, GLenum pname, const GLint *params);
extern void (*glTexSubImage2D)(GLenum target, GLint level, GLint xoffset, GLint yoffset, GLsizei width, GLsizei height, GLenum format, GLenum type, const void *pixels);
extern void (*glAttachShader)(GLuint program, GLuint shader);
extern void (*glBindAttribLocation)(GLuint program, GLuint index, const char *name);
extern void (*glCompileShader)(GLuint shader);
extern GLuint (*glCreateProgram)();
extern GLuint (*glCreateShader)(GLenum type);
extern void (*glDeleteProgram)(GLuint program);
extern void (*glDeleteShader)(GLuint shader);
extern void (*glDetachShader)(GLuint program, GLuint shader);
extern void (*glDisableVertexAttribArray)(GLuint index);
extern void (*glEnableVertexAttribArray)(GLuint index);
extern GLint (*glGetAttribLocation)(GLuint program, const char *name);
extern void (*glGetProgramiv)(GLuint program, GLenum pname, GLint *params);
extern void (*glGetProgramInfoLog)(GLuint program, GLsizei bufSize, GLsizei *length, char *infoLog);
extern void (*glGetShaderiv)(GLuint shader, GLenum pname, GLint *params);
extern void (*glGetShaderInfoLog)(GLuint shader, GLsizei bufSize, GLsizei *length, char *infoLog);
extern GLboolean (*glIsProgram)(GLuint program);
extern GLboolean (*glIsShader)(GLuint shader);
extern void (*glLinkProgram)(GLuint program);
extern void (*glShaderBinary)(GLsizei count, const GLuint *shaders, GLenum binaryformat, const void *binary, GLsizei length);
extern void (*glShaderSource)(GLuint shader, GLsizei count, const char *const*string, const GLint *length);
extern void (*glUseProgram)(GLuint program);
extern void (*glValidateProgram)(GLuint program);
extern GLint (*glGetUniformLocation)(GLuint program, const char *name);
extern void (*glUniform1f)(GLint location, GLfloat v0);
extern void (*glUniform1fv)(GLint location, GLsizei count, const GLfloat *value);
extern void (*glUniform1i)(GLint location, GLint v0);
extern void (*glUniform1iv)(GLint location, GLsizei count, const GLint *value);
extern void (*glUniform2f)(GLint location, GLfloat v0, GLfloat v1);
extern void (*glUniform2fv)(GLint location, GLsizei count, const GLfloat *value);
extern void (*glUniform2i)(GLint location, GLint v0, GLint v1);
extern void (*glUniform2iv)(GLint location, GLsizei count, const GLint *value);
extern void (*glUniform3f)(GLint location, GLfloat v0, GLfloat v1, GLfloat v2);
extern void (*glUniform3fv)(GLint location, GLsizei count, const GLfloat *value);
extern void (*glUniform3i)(GLint location, GLint v0, GLint v1, GLint v2);
extern void (*glUniform3iv)(GLint location, GLsizei count, const GLint *value);
extern void (*glUniform4f)(GLint location, GLfloat v0, GLfloat v1, GLfloat v2, GLfloat v3);
extern void (*glUniform4fv)(GLint location, GLsizei count, const GLfloat *value);
extern void (*glUniform4i)(GLint location, GLint v0, GLint v1, GLint v2, GLint v3);
extern void (*glUniform4iv)(GLint location, GLsizei count, const GLint *value);
extern void (*glUniformMatrix2fv)(GLint location, GLsizei count, GLboolean transpose, const GLfloat *value);
extern void (*glUniformMatrix3fv)(GLint location, GLsizei count, GLboolean transpose, const GLfloat *value);
extern void (*glUniformMatrix4fv)(GLint location, GLsizei count, GLboolean transpose, const GLfloat *value);
extern void (*glVertexAttrib1f)(GLuint index, GLfloat x);
extern void (*glVertexAttrib1fv)(GLuint index, const GLfloat *v);
extern void (*glVertexAttrib2f)(GLuint index, GLfloat x, GLfloat y);
extern void (*glVertexAttrib2fv)(GLuint index, const GLfloat *v);
extern void (*glVertexAttrib3f)(GLuint index, GLfloat x, GLfloat y, GLfloat z);
extern void (*glVertexAttrib3fv)(GLuint index, const GLfloat *v);
extern void (*glVertexAttrib4f)(GLuint index, GLfloat x, GLfloat y, GLfloat z, GLfloat w);
extern void (*glVertexAttrib4fv)(GLuint index, const GLfloat *v);
extern void (*glVertexAttribPointer)(GLuint index, GLint size, GLenum type, GLboolean normalized, GLsizei stride, const void *pointer);
extern void (*glGetBooleanv)(GLenum pname, GLboolean *data);
extern void (*glGetBufferParameteriv)(GLenum target, GLenum pname, GLint *params);
extern GLenum (*glGetError)();
extern void (*glGetFloatv)(GLenum pname, GLfloat *data);
extern void (*glGetFramebufferAttachmentParameteriv)(GLenum target, GLenum attachment, GLenum pname, GLint *params);
extern void (*glGetIntegerv)(GLenum pname, GLint *data);
extern void (*glGetRenderbufferParameteriv)(GLenum target, GLenum pname, GLint *params);
extern void (*glGetShaderPrecisionFormat)(GLenum shadertype, GLenum precisiontype, GLint *range, GLint *precision);
extern void (*glGetShaderSource)(GLuint shader, GLsizei bufSize, GLsizei *length, char *source);
extern const GLubyte* (*glGetString)(GLenum name);
extern void (*glGetTexParameterfv)(GLenum target, GLenum pname, GLfloat *params);
extern void (*glGetTexParameteriv)(GLenum target, GLenum pname, GLint *params);
extern void (*glGetTexLevelParameteriv)(GLenum target, GLint level, GLenum pname, GLint *params);
extern void (*glGetTexImage)(GLenum target, GLint level, GLenum format, GLenum type, void *pixels);
extern void (*glGetUniformfv)(GLuint program, GLint location, GLfloat *params);
extern void (*glGetUniformiv)(GLuint program, GLint location, GLint *params);
extern void (*glGetVertexAttribfv)(GLuint index, GLenum pname, GLfloat *params);
extern void (*glGetVertexAttribiv)(GLuint index, GLenum pname, GLint *params);
extern void (*glGetVertexAttribPointerv)(GLuint index, GLenum pname, void **pointer);
extern GLboolean (*glIsEnabled)(GLenum cap);
extern void (*glDrawArrays)(GLenum mode, GLint first, GLsizei count);
extern void (*glDrawElements)(GLenum mode, GLsizei count, GLenum type, const void *indices);
extern void (*glReadPixels)(GLint x, GLint y, GLsizei width, GLsizei height, GLenum format, GLenum type, void *pixels);
extern void (*glStencilFuncSeparate)(GLenum face, GLenum func, GLint ref, GLuint mask);
extern void (*glStencilMaskSeparate)(GLenum face, GLuint mask);
extern void (*glStencilOpSeparate)(GLenum face, GLenum sfail, GLenum dpfail, GLenum dppass);
extern void (*glReleaseShaderCompiler)();
extern void (*glGetActiveAttrib)(GLuint program, GLuint index, GLsizei bufSize, GLsizei *length, GLint *size, GLenum *type, char *name);
extern void (*glGetActiveUniform)(GLuint program, GLuint index, GLsizei bufSize, GLsizei *length, GLint *size, GLenum *type, char *name);
extern void (*glGetAttachedShaders)(GLuint program, GLsizei maxCount, GLsizei *count, GLuint *shaders);
extern void (*glBlitFramebuffer)(GLint srcX0, GLint srcY0, GLint srcX1, GLint srcY1, GLint dstX0, GLint dstY0, GLint dstX1, GLint dstY1, GLbitfield mask, GLenum filter);
extern void* (*glMapBuffer)(GLenum target, GLenum access);
extern void (*glUnmapBuffer)(GLenum target);
extern GLsync (*glFenceSync)(GLenum condition, GLbitfield flags);
extern GLenum (*glWaitSync)(GLsync sync, GLbitfield flags, GLuint64 timeout);
extern void (*glDeleteSync)(GLsync sync);
extern void* (*glMapBufferRange)(GLenum target, GLintptr offset, GLsizeiptr length, GLbitfield access);
extern EGLBoolean (*eglQuerySurface)(EGLDisplay dpy, EGLSurface surface, EGLint attribute, EGLint* value);
extern void (*glDrawElementsBaseVertex)(GLenum mode, GLsizei count, GLenum type, const void* indices, GLint basevertex);
extern void (*glGenVertexArrays)(GLsizei n, GLuint* arrays);
extern void (*glDeleteVertexArrays)(GLsizei n, GLuint* arrays);
extern void (*glBindVertexArray)(GLuint array);
extern void (*glPolygonMode)(GLenum face, GLenum mode);
extern void (*glBindSampler)(GLuint unit, GLuint sampler);
extern void (*glColor4f)(GLfloat red, GLfloat green, GLfloat blue, GLfloat alpha);
extern EGLDisplay (*eglGetCurrentDisplay)();
extern EGLSurface (*eglGetCurrentSurface)(EGLint readdraw);

GLboolean glegl_get_depth_writemask();
GLenum glegl_get_depth_func();

extern void glegl();
