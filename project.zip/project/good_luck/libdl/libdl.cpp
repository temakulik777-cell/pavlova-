#include "libdl.h"
#include "../xdl/xdl.h"

void* (*dlopen_)(const char* filename, int flags) = nullptr;
void* (*dlsym_)(void* handle, const char* symbol) = nullptr;
int (*dlclose_)(void* handle) = nullptr;
char* (*dlerror_)() = nullptr;
int (*dladdr_)(void* addr, Dl_info_* info) = nullptr;
    
void libdl() {
    void* libdl_handle = xdl_open(oxorany("libdl.so"), XDL_DEFAULT);
    if (libdl_handle) {
        auto load = [&](void** ptr, const char* name) { 
            *ptr = xdl_sym(libdl_handle, name, nullptr); 
        };
        
        const char* names[] = {
            oxorany("dlopen"), 
            oxorany("dlsym"), 
            oxorany("dlclose"), 
            oxorany("dlerror"), 
            oxorany("dladdr")
        };
        
        void* funcs[] = { 
            (void*)&dlopen_, 
            (void*)&dlsym_, 
            (void*)&dlclose_, 
            (void*)&dlerror_, 
            (void*)&dladdr_ 
        };
        
        for(int i = 0; i < sizeof(names)/sizeof(names[0]); i++) { 
            load((void**)funcs[i], names[i]); 
        }
    }
}