#pragma once
#include <cstddef>
#include "../oxo/include.h"

typedef struct dl_info {
    const char *dli_fname;
    void       *dli_fbase;
    const char *dli_sname;
    void       *dli_saddr;
} Dl_info_;

extern void* (*dlopen_)(const char* filename, int flags);
extern void* (*dlsym_)(void* handle, const char* symbol);
extern int (*dlclose_)(void* handle);
extern char* (*dlerror_)();
extern int (*dladdr_)(void* addr, Dl_info_* info);

extern void libdl();