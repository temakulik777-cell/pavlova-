#pragma once

#include "../oxo/include.h"

typedef unsigned char Bytef_;
typedef unsigned long uLong_;
typedef unsigned long uLongf_;

extern int (*uncompressFn)(Bytef_* dest, uLongf_* dest_len, const Bytef_* source, uLong_ source_len);

extern void libz();
