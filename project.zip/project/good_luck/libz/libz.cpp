#include "libz.h"
#include "../xdl/xdl.h"

int (*uncompressFn)(Bytef_* dest, uLongf_* dest_len, const Bytef_* source, uLong_ source_len) = nullptr;

void libz() {
    void* libz_handle = xdl_open(oxorany("libz.so.1"), XDL_DEFAULT);
    if (!libz_handle) {
        libz_handle = xdl_open(oxorany("libz.so"), XDL_DEFAULT);
    }

    if (libz_handle) {
        uncompressFn = (int (*)(Bytef_*, uLongf_*, const Bytef_*, uLong_))
            xdl_sym(libz_handle, oxorany("uncompress"), nullptr);
    }
}
