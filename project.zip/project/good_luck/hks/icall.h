#include "../../unity_engine/Il2Cpp/Utils/Il2CppUtils.h"
#include "../oxo/include.h"
#include <thread> 
#include <chrono>

struct hook_info {
    void* ptr_addr;
    void* hook_addr;
    void* orig_addr;
    bool is_swap_hook;
};

extern std::vector<hook_info*> hooked_funcs;
struct icall {
    const char* dll_name;
    const char* function_name;
    icall(const char* dll, const char* function) : 
        dll_name(dll), function_name(function) {}
    void* resolve_icall() {
        return il2cpp.resolve_icall(this);
    }
    void* resolve_icall_unity() {
        return il2cpp.resolve_icall_unity(this->function_name);
    }
};

template<class H, class O>
bool icall_hook(void* delegate_addr, const char* method_name, 
               H hook, O orig, const char* dll = "libunity") {
    if (!delegate_addr || !method_name || !hook)
        return false;
    icall resolver(dll, method_name);
    void* original = nullptr;
    if (!strcmp(dll, "libunity"))
        original = resolver.resolve_icall_unity();
    else
        original = resolver.resolve_icall();
    if (!original)
        return false;
    if (orig)
        *(void**)orig = original;
    *(void**)delegate_addr = (void*)hook;
    return true;
}

template<typename T>
bool icall(uintptr_t delegate_addr, const char* method_name, 
          T hook, T* orig) {
   if (!delegate_addr || !method_name || !hook)
        return false;
    void* ptr = (void*)((uintptr_t)delegate_addr);
    while (!*(void**)ptr) { std::this_thread::sleep_for(std::chrono::seconds(1)); }
    return icall_hook(ptr, method_name, hook, orig);
}
