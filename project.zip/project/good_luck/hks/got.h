#ifndef PROT_READ
    #define PROT_READ   1
    #define PROT_WRITE  2
    #define PROT_EXEC   4
    #define PROT_NONE   0
#endif

#define got(base, offset, old_ptr, new_func) do { \
    uintptr_t got = (base) + (offset); \
    uintptr_t page_start = got & ~0xFFF; \
    _mprotect((void*)page_start, 0x1000, PROT_READ | PROT_WRITE); \
    uintptr_t old_addr = *(uintptr_t*)got; \
    (old_ptr) = (decltype(old_ptr))old_addr; \
    *(uintptr_t*)got = (uintptr_t)&(new_func); \
    _mprotect((void*)page_start, 0x1000, PROT_READ | PROT_EXEC); \
} while(0)