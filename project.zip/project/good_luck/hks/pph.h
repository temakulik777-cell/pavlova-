template<typename T, typename U>
bool pph(T original_func, U& target_ptr) {
    target_ptr = reinterpret_cast<U>(original_func);
    return target_ptr != nullptr;
}