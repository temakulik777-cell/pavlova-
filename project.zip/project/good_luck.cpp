#include <atomic>
#include <chrono>
#include <cstdio>
#include <cstring>
#include <thread>

#include "good_luck/good_luck.h"

int glHeight = 0;
int glWidth = 0;
uintptr_t base = 0;

#include "v_memory.h"
#include "clickgui/clickgui.h"
#include "clickgui/imgui/imgui.h"
#include "clickgui/imgui/backends/imgui_impl_opengl3.h"
#include "clickgui/imgui/backends/imgui_impl_android.h"
#include "clickgui/imgui/im_anim/im_anim.h"
#include "../unity_engine/Il2Cpp/Utils/Il2CppUtils.h"
#include "good_luck/glegl/glegl.h"
#include "clickgui/render/blur/blur.hpp"
#include "clickgui/render/post_processing.h"
#include "axlebolt/player_controller.h"

void goodluck(int vr);

static std::atomic_bool libunity_ready{false};

static void libunity(uintptr_t unity_base) {
	if (unity_base == 0) return;
	bool expected = false;
	if (!libunity_ready.compare_exchange_strong(expected, true, std::memory_order_acq_rel)) return;
	base = unity_base;
	il2cpp.il2cpp_base = base;
	il2cpp.init_api();
	goodluck(1);
}

static void libunity_wait() {
	if (libunity_ready.load(std::memory_order_acquire)) return;
	uintptr_t unity_base = 0;

	void* handle = xdl_open(oxorany("libunity.so"), XDL_DEFAULT);
	if (handle) {
		xdl_info_t info{};
		if (xdl_info(handle, XDL_DI_DLINFO, &info) == 0 && info.dli_fbase)
			unity_base = reinterpret_cast<uintptr_t>(info.dli_fbase);
		xdl_close(handle);
	}

	if (unity_base == 0)
		if (FILE* fp = fopen("/proc/self/maps", "r")) {
			char line[512];
			while (fgets(line, sizeof(line), fp)) {
				if (!strstr(line, "libunity.so")) continue;
				unsigned long start = 0;
				if (sscanf(line, "%lx-%*lx", &start) == 1) {
					unity_base = (uintptr_t)start;
					break;
				}
			}
			fclose(fp);
		}

	if (unity_base != 0)
		libunity(unity_base);
}

void panache() {
	static bool egl_ = false;
	static int install_retry_frame = 0;
	static bool install_done = false;
	if (!egl_) {
		ClickGUI::Get().Init();
		egl_ = true;
	}

	if (!install_done && base != 0) {
		++install_retry_frame;
		if (install_retry_frame >= 30) {
			install_retry_frame = 0;
			install_done = Axlebolt::PlayerControllerHook::Install();
		}
	}

	GLint prevProgram = 0;
	GLint prevActiveTexture = GL_TEXTURE0;
	GLint prevTex0 = 0;
	GLint prevTex1 = 0;
	GLint prevVao = 0;
	GLint prevArrayBuffer = 0;
	GLint prevElementArrayBuffer = 0;
	GLint prevFramebuffer = 0;
	GLint prevViewport[4] = {0, 0, glWidth, glHeight};
	GLint prevScissorBox[4] = {0, 0, glWidth, glHeight};
	GLint prevBlendSrcRgb = GL_ONE;
	GLint prevBlendDstRgb = GL_ZERO;
	GLint prevBlendSrcAlpha = GL_ONE;
	GLint prevBlendDstAlpha = GL_ZERO;
	GLint prevBlendEqRgb = GL_FUNC_ADD;
	GLint prevBlendEqAlpha = GL_FUNC_ADD;
	GLenum prevDepthFunc = glegl_get_depth_func();
	GLboolean prevScissorTest = GL_FALSE;
	GLboolean prevDepthTest = GL_FALSE;
	GLboolean prevBlendTest = GL_FALSE;
	GLboolean prevCullFace = GL_FALSE;
	GLboolean prevStencilTest = GL_FALSE;
	GLboolean prevDepthMask = GL_TRUE;
	GLboolean prevColorMaskVals[4] = {1, 1, 1, 1};

	if (glGetIntegerv) {
		glGetIntegerv(GL_CURRENT_PROGRAM, &prevProgram);
		glGetIntegerv(GL_ACTIVE_TEXTURE, &prevActiveTexture);
		glActiveTexture(GL_TEXTURE0);
		glGetIntegerv(GL_TEXTURE_BINDING_2D, &prevTex0);
		glActiveTexture((GLenum)(GL_TEXTURE0 + 1));
		glGetIntegerv(GL_TEXTURE_BINDING_2D, &prevTex1);
		glActiveTexture((GLenum)prevActiveTexture);
		glGetIntegerv(GL_VERTEX_ARRAY_BINDING, &prevVao);
		glGetIntegerv(GL_ARRAY_BUFFER_BINDING, &prevArrayBuffer);
		glGetIntegerv(GL_ELEMENT_ARRAY_BUFFER_BINDING, &prevElementArrayBuffer);
		glGetIntegerv(GL_FRAMEBUFFER_BINDING, &prevFramebuffer);
		glGetIntegerv(GL_VIEWPORT, prevViewport);
		glGetIntegerv(GL_SCISSOR_BOX, prevScissorBox);
		glGetIntegerv(GL_BLEND_SRC_RGB, &prevBlendSrcRgb);
		glGetIntegerv(GL_BLEND_DST_RGB, &prevBlendDstRgb);
		glGetIntegerv(GL_BLEND_SRC_ALPHA, &prevBlendSrcAlpha);
		glGetIntegerv(GL_BLEND_DST_ALPHA, &prevBlendDstAlpha);
		glGetIntegerv(GL_BLEND_EQUATION_RGB, &prevBlendEqRgb);
		glGetIntegerv(GL_BLEND_EQUATION_ALPHA, &prevBlendEqAlpha);
	}
	if (glIsEnabled) {
		prevScissorTest = (GLboolean)glIsEnabled(GL_SCISSOR_TEST);
		prevDepthTest = (GLboolean)glIsEnabled(GL_DEPTH_TEST);
		prevBlendTest = (GLboolean)glIsEnabled(GL_BLEND);
		prevCullFace = (GLboolean)glIsEnabled(GL_CULL_FACE);
		prevStencilTest = (GLboolean)glIsEnabled(GL_STENCIL_TEST);
	}
	if (glGetBooleanv) {
		glGetBooleanv(GL_COLOR_WRITEMASK, prevColorMaskVals);
		glGetBooleanv(GL_DEPTH_WRITEMASK, &prevDepthMask);
	}

	if (glWidth > 0 && glHeight > 0) {
		post_processing.ApplyColorGrading(glWidth, glHeight);
	}

	if (glDisable) {
		glDisable(GL_SCISSOR_TEST);
		glDisable(GL_DEPTH_TEST);
	}

	if (glColorMask) {
		glColorMask(1, 1, 1, 1);
	}

	ImGuiIO& mainIO = ImGui::GetIO();
	mainIO.DisplaySize = ImVec2((float)glWidth, (float)glHeight);

	ImGui_ImplOpenGL3_NewFrame();
	ImGui_ImplAndroid_NewFrame(glWidth, glHeight);
	ImGui::NewFrame();

	iam_update_begin_frame();
	iam_clip_update(ImGui::GetIO().DeltaTime);

	if (glWidth > 0 && glHeight > 0) {
		ClickGUI::Get().Update();
	}

	ImGui::EndFrame();
	ImGui::Render();

	glViewport(0, 0, glWidth, glHeight);
	ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());

	ClickGUI::Get().PostOverlay(glWidth, glHeight);

	if (glBindFramebuffer) {
		glBindFramebuffer(GL_FRAMEBUFFER, (GLuint)prevFramebuffer);
	}
	if (glViewport) {
		glViewport(prevViewport[0], prevViewport[1], prevViewport[2], prevViewport[3]);
	}
	if (glScissor) {
		glScissor(prevScissorBox[0], prevScissorBox[1], prevScissorBox[2], prevScissorBox[3]);
	}
	if (glBlendFuncSeparate) {
		glBlendFuncSeparate(prevBlendSrcRgb, prevBlendDstRgb, prevBlendSrcAlpha, prevBlendDstAlpha);
	}
	if (glBlendEquationSeparate) {
		glBlendEquationSeparate(prevBlendEqRgb, prevBlendEqAlpha);
	}
	if (glUseProgram) {
		glUseProgram((GLuint)prevProgram);
	}
	if (glBindVertexArray) {
		glBindVertexArray((GLuint)prevVao);
	}
	if (glBindBuffer) {
		glBindBuffer(GL_ARRAY_BUFFER, (GLuint)prevArrayBuffer);
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, (GLuint)prevElementArrayBuffer);
	}
	if (glActiveTexture && glBindTexture) {
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, (GLuint)prevTex0);
		glActiveTexture((GLenum)(GL_TEXTURE0 + 1));
		glBindTexture(GL_TEXTURE_2D, (GLuint)prevTex1);
		glActiveTexture((GLenum)prevActiveTexture);
	}
	if (glDepthMask) {
		glDepthMask(prevDepthMask);
	}
	if (glDepthFunc) {
		glDepthFunc(prevDepthFunc);
	}
	if (glColorMask) {
		glColorMask(prevColorMaskVals[0], prevColorMaskVals[1], prevColorMaskVals[2], prevColorMaskVals[3]);
	}
	if (glEnable && glDisable) {
		if (prevScissorTest) glEnable(GL_SCISSOR_TEST); else glDisable(GL_SCISSOR_TEST);
		if (prevDepthTest) glEnable(GL_DEPTH_TEST); else glDisable(GL_DEPTH_TEST);
		if (prevBlendTest) glEnable(GL_BLEND); else glDisable(GL_BLEND);
		if (prevCullFace) glEnable(GL_CULL_FACE); else glDisable(GL_CULL_FACE);
		if (prevStencilTest) glEnable(GL_STENCIL_TEST); else glDisable(GL_STENCIL_TEST);
	}
}

void (*reglSwapBuffers)(void* dpy, void* surface) = nullptr;
void eglSwapBuffers(void* dpy, void* surface) {
	if (eglQuerySurface) {
		eglQuerySurface((EGLDisplay)dpy, (EGLSurface)surface, EGL_WIDTH, &glWidth);
		eglQuerySurface((EGLDisplay)dpy, (EGLSurface)surface, EGL_HEIGHT, &glHeight);
	}

	panache();
	reglSwapBuffers(dpy, surface);
}

int (*rGfxDeviceGLES_PresentFrame)(uintptr_t instance) = nullptr;
int GfxDeviceGLES_PresentFrame(uintptr_t instance) {
	EGLDisplay dpy = nullptr;
	EGLSurface surf = nullptr;

	if (eglGetCurrentDisplay) {
		dpy = eglGetCurrentDisplay();
	}
	if (eglGetCurrentSurface) {
		surf = eglGetCurrentSurface(EGL_DRAW);
	}

	if (dpy != NULL && surf != NULL && eglQuerySurface) {
		eglQuerySurface(dpy, surf, EGL_WIDTH, &glWidth);
		eglQuerySurface(dpy, surf, EGL_HEIGHT, &glHeight);
	}

	panache();
	return rGfxDeviceGLES_PresentFrame(instance);
}

int (*rGetTouchCount)() = nullptr;
int GetTouchCount() {
	if (!rGetTouchCount) {
		return 0;
	}

	int count = rGetTouchCount();
	if (count < 0) {
		count = 0;
	}

	if (ImGui::GetCurrentContext()) {
		ImGuiIO& io = ImGui::GetIO();
		if (base != 0) {
			ClickGUI::Get().touch.Update(io, count);
		}
		const bool pointer_down_or_click = io.MouseDown[0] || io.MouseClicked[0];
		if (ClickGUI::Get().ShouldBlockGameInput(io.MousePos, pointer_down_or_click)) {
			return 0;
		}
	}

	return count;
}

void goodluck(int vr) {
	std::thread([vr]() {
		if (vr == 0) {
			got(base, vMemory::Unity::eglSwapBuffers, reglSwapBuffers, eglSwapBuffers);
		} else {
			got(base, vMemory::Unity::PresentFrame, rGfxDeviceGLES_PresentFrame, GfxDeviceGLES_PresentFrame);
		}

		icall(base + vMemory::UnityEngine::Input::Delegate::GetTouchCount,
			  "UnityEngine.Input::get_touchCount()",
			  GetTouchCount,
			  &rGetTouchCount);

	}).detach();
}

void lolw() {
	libc(); /*/->/*/ glegl(); /*/->/*/ libz(); /*/->/*/ libdl();
	std::thread([]() {
		while (!libunity_ready.load(std::memory_order_acquire)) {
			libunity_wait();
			if (!libunity_ready.load(std::memory_order_acquire))
				std::this_thread::sleep_for(std::chrono::milliseconds(200));
		}
	}).detach();
}
